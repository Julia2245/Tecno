# Telegram Bot Core — Phase 5

نواة عامة قابلة لإعادة الاستخدام لبوتات Telegram مبنية على **aiogram + PostgreSQL**، بدون ربط الكود بهوية بوت محددة.

> هذه المرحلة تجمع: النواة + Wallet Core + شحن رصيد البوت + iChancy + سحب رصيد البوت + إدارة الشحن والسحب + Durable Notification Outbox.

## الأساس المالي

- PostgreSQL async عبر `asyncpg` وmigrations داخل schema مستقل `bot_core`.
- Wallet Core محمي: ledger append-only، idempotency، row locks، holds، وقيود سلامة على مستوى قاعدة البيانات.
- أي حركة رصيد تمر عبر `WalletRepository`؛ الـrouters لا تكتب على الرصيد مباشرة.
- إنشاء Hold والطلب المالي المرتبط به يتمان في Transaction واحدة.
- التسوية/الإلغاء/الرفض المالي يتم بصورة ذرية قدر الإمكان.
- العمليات الخارجية غير المؤكدة لا يعاد إرسال POST لها بصورة عمياء.

## شحن رصيد البوت

الطرق الحالية:

- Syriatel Cash — Auto / Manual.
- Sham Cash SYP — Auto / Manual.
- Sham Cash USD — Auto / Manual.
- Whish Money — Manual مع صورة إثبات Telegram.
- Binance USDT — TRC20 / BEP20.

الحماية تشمل namespaces مشتركة لمنع إعادة استخدام نفس Tx عبر تحويل العملة/الشبكة، وclaims/idempotency، وربط النجاح بعملية Wallet ثابتة.

- التحقق الآلي يعرض حالة واحدة تتحدث بالنتيجة، مع منع المستخدم من بدء تحقق شحن ثانٍ قبل حسم الأول.
- طلبات التحقق read-only إلى API Syria موزعة بفاصل قصير وTimeout قصير؛ عند rate-limit/تعذر المزود لا يتم اعتماد العملية ويطلب من المستخدم إعادة المحاولة بنفس رقم العملية.
- أكواد استلام Syriatel وعناوين Sham Cash قابلة للتعديل من لوحة الإدارة، وتبقى قيم `.env` قيم bootstrap لقاعدة بيانات جديدة.

### تحويل العملة المحلية

Sham Cash SYP وSyriatel Cash يستخدمان **معامل تحويل واحد مشترك** محفوظ في Runtime Settings:

`money.local_syp_wallet_multiplier`

القيمة الافتراضية الحالية `100`، أي:

`200` من العملة المحلية → `20,000` رصيد محفظة.

يمكن تغييره لاحقاً من لوحة الإدارة إلى `1` لتصبح العلاقة 1:1. كل طلب يحفظ Snapshot للسعر الذي بدأ عليه، لذلك تغيير الإعداد لا يعيد تسعير الطلبات القديمة.

## iChancy

### إنشاء الحساب

- المستخدم يدخل الاسم فقط.
- الأسماء العربية تنظف وتحوّل تلقائياً إلى صيغة لاتينية صالحة.
- اسم الحساب النهائي يستخدم عداداً ذرياً عاماً في PostgreSQL، مثل:
  - `tecno1_ahmad`
  - `tecno2_samer`
- الـprefix ليس ثابتاً في السورس؛ يحدد عبر `ICHANCY_USERNAME_PREFIX` أو لوحة إدارة iChancy.
- كلمة المرور تولد آلياً بمولد آمن وتخزن مشفرة، ولا تسجل في logs.
- لو كانت نتيجة registerPlayer غير مؤكدة، لا يعاد POST بصورة عمياء؛ تتم مطابقة الـusername الثابت أولاً.

### الدخول الفوري

المسار يطابق تجربة البوت المرجعي:

1. تسجيل الدخول عبر BetConstruct Swarm WebSocket.
2. استخراج `auth_token` مؤقت.
3. إظهار زر WebApp لفتح الموقع مباشرة بالحساب.
4. التوكن لا يخزن في قاعدة البيانات.
5. عند مشكلة فتح الموقع تظهر ملاحظة استخدام VPN على سنغافورة.

### العمليات

- شحن مبلغ إلى iChancy.
- سحب مبلغ من iChancy إلى المحفظة.
- شحن كامل الرصيد المتاح.
- الحد الأدنى للشحن والسحب قابل للتعديل من لوحة الإدارة؛ الافتراضي 20,000.
- العمليات تستخدم queue دائمة وحالات مالية منفصلة عن Telegram handlers.
- يتم حفظ snapshots لرصيد اللاعب والكاشير قبل/بعد عند توفرها.
- النتيجة غير المؤكدة تدخل `reconciling` ولا تعاد العملية المالية تلقائياً.
- توجد لوحة `⚠️ عمليات تحتاج مراجعة` لحسم العملية يدوياً بدون إرسال POST مالي جديد.

## إضافة / استبدال كاشيرة iChancy

عند عدم وجود كاشيرة نشطة، يمكن إدخال بيانات أول كاشيرة من لوحة الإدارة، اختبارها، ثم اعتمادها مباشرة. بعد وجود كاشيرة نشطة يستخدم النظام مسار الاستبدال المحمي أدناه.

الاستبدال Workflow دائم وقابل للاستكمال بعد Restart:

- اختبار الكاشيرة الجديدة قبل بدء الاستبدال.
- منع البدء عند وجود عمليات iChancy أو إنشاءات حساب غير محسومة على الكاشيرة القديمة.
- تحويل الكاشيرة القديمة وحساباتها إلى حالة retiring؛ لا يتم حذف أي حساب قديم.
- فحص أرصدة الحسابات وتصنيفها إلى:
  - صفر.
  - أقل من الحد الأدنى للسحب.
  - مؤهل للسحب.
  - فشل فحص / يحتاج مراجعة.
- الأرصدة المؤهلة تنشأ لها jobs مستقلة لسحب الرصيد وإعادته إلى Wallet المستخدم.
- بعد كل تسوية ناجحة تتم إعادة قراءة رصيد اللاعب:
  - صفر → تمت التصفية.
  - أقل من الحد → يحفظ كرصد متبقٍ في السجل القديم.
  - ما يزال فوق الحد → تنشأ محاولة تسوية جديدة مستقلة.
- الاعتماد النهائي يتطلب عدم وجود jobs نشطة وتطابق إجمالي ما سحب من iChancy مع إجمالي ما أضيف للمحافظ.
- التقدم يعرض في **رسالة إدارة واحدة تتحدث** بدلاً من إرسال رسالة لكل حساب.

### سجلات الكاشيرات القديمة

من إدارة iChancy يمكن البحث بـTelegram ID واستعراض الحسابات المتقاعدة، الرصيد المرصود والمتبقي وحالة التسوية.

الرصيد المتبقي الأقل من الحد يمكن تعويضه يدوياً بعد اكتمال الاستبدال. التعويض مرتبط بالسجل القديم وidempotent، فلا يمكن إضافته مرتين.

## سحب رصيد البوت

الطرق:

- Syriatel Cash.
- Sham Cash مع محاولة جلب اسم الحساب قبل إدخال المبلغ.
- حوالة — هرم / الفؤاد، مع بيانات المستلم.
- USDT — TRC20 / BEP20 مع تحكم مستقل لكل شبكة.

الحماية:

- Hold قبل التنفيذ.
- طلب واحد نشط لكل مستخدم.
- تنفيذ آلي لـSyriatel/Sham فقط؛ الحوالة وUSDT تنفيذ يدوي ثم تأكيد دفع.
- نتيجة مزود مؤكدة النجاح تحفظ أولاً كـ`provider_success`، وبعدها تكتمل التسوية المحلية بدون إعادة POST.
- نتيجة غير مؤكدة → `needs_review`، ولا يجوز رفضها وتحرير الـHold مباشرة.
- الأدمن يقرر صراحة: «تم الدفع» أو «لم يتم الدفع».
- أي `processing` قديم بعد Restart يتحول للمراجعة بدلاً من إعادة التحويل.
- بطاقة طلب السحب للأدمن تعرض آخر 3 عمليات شحن ناجحة للمستخدم مع البونص.
- أثناء التنفيذ الآلي تتحول البطاقة فوراً إلى «جاري التنفيذ» بلا أزرار تنفيذ إضافية، وبعد النجاح تعرض وقت الطلب ووقت التنفيذ ورقم عملية المزود عند إعادته من API.

## التنبيهات والإشعارات

الإشعارات المالية تستخدم **Durable Notification Outbox** داخل PostgreSQL:

- إنشاء حساب iChancy → قناة حسابات iChancy.
- شحن/سحب iChancy → قناة عمليات iChancy.
- شحن/سحب رصيد البوت → قناة عمليات البوت.
- فشل Telegram أو Restart لا يحذف الحدث؛ العامل يعيد المحاولة.
- `event_key` فريد لمنع إنشاء إشعار منطقي مكرر.

حدود «المبلغ الكبير» قابلة للتعديل من لوحة الإدارة بصورة مستقلة:

- شحن iChancy.
- سحب iChancy.
- شحن رصيد البوت.
- سحب رصيد البوت.

عند تجاوز الحد لا ترسل رسالة ثانية؛ نفس رسالة العملية تحمل شارة `🚨 مبلغ كبير`، ولا يظهر رقم الحد في الإشعار.

## Custom Emoji

القيم مركزية داخل `app/core/emojis.py`:

- التحقق/التحميل: `5386367538735104399`
- المعالجة/التدقيق: `5884447890960552542`
- النجاح/التأكيد: `5796205953913196373`

## إعداد iChancy المطلوب قبل التشغيل الحقيقي

في `.env`:

```env
ICHANCY_BASE_URL=https://agents.ichancy.com
ICHANCY_API_USERNAME=
ICHANCY_API_PASSWORD=
ICHANCY_PARENT_ID=
ICHANCY_CURRENCY=SYP
ICHANCY_USERNAME_PREFIX=bot
ICHANCY_CREDENTIALS_KEY=
ICHANCY_WEBSITE_URL=https://www.ichancy300.com/ar
ICHANCY_WS_URL=wss://eu-swarm-springre.betcoswarm.com/
ICHANCY_WS_ORIGIN=https://www.ichancy.com
ICHANCY_WS_SITE_ID=18755655
ICHANCY_WS_SOURCE=42
```

لبيئة Tecno التجريبية اضبط:

```env
ICHANCY_USERNAME_PREFIX=tecno
```

قبل إنشاء أول حساب. لا ترفع `.env` إلى GitHub.

إن لم يكن `ICHANCY_CREDENTIALS_KEY` موجوداً، أنشئ مفتاح Fernet مرة واحدة فقط واحفظه في `.env`. تغيير هذا المفتاح بعد تخزين بيانات الحسابات يجعل بياناتها المشفرة غير قابلة للفك.

## الفحوص قبل اعتماد أي إصدار

فحص ثابت لا يحتاج قاعدة بيانات:

```bash
PYTHONPATH=. python -m scripts.preflight
```

ثم داخل بيئة السيرفر التي تحتوي الاعتماديات:

```bash
python -m pytest -q
python -m scripts.wallet_audit
python -m scripts.deposit_audit
python -m scripts.ichancy_audit
python -m scripts.withdraw_audit
python -m scripts.outbox_audit
```

النتائج السليمة يجب أن تحتوي:

```text
PROJECT PREFLIGHT: OK
WALLET AUDIT: OK
DEPOSIT AUDIT: OK
ICHANCY AUDIT: OK
WITHDRAW AUDIT: OK
OUTBOX AUDIT: OK
```

> Audits الجديدة read-only؛ معالجة `processing` المنقطع في السحب تتم عند تشغيل التطبيق، وليس داخل audit.

## قاعدة التطوير

- لا يوجد اسم بوت ثابت داخل منطق التطبيق.
- لا يكتب Router إلى Wallet أو Ledger مباشرة.
- أي API مالي خارجي يجب أن يفرق بين الفشل المؤكد والنتيجة غير المؤكدة.
- لا يعاد POST مالي بسبب Timeout دون reconciliation أو قرار صريح.
- إعدادات المال والحدود تحفظ Snapshot داخل العملية عند الحاجة حتى لا تغير الإعدادات الجديدة التاريخ المالي القديم.
## v0.5.2 callback safety
- Shortened UUID-bearing iChancy admin callback payloads that could exceed Telegram's 64-byte callback_data limit and trigger `BUTTON_DATA_INVALID`. Legacy callback handlers remain accepted where safe for already-open messages.


## v0.5.4 iChancy user-result UX
- Deposit progress is intentionally minimal: `جاري شحن حسابك...`; internal UUID/amount details stay out of the user's progress screen.
- The original progress message is updated to success/failure when the durable job finishes, without blocking callback/menu responsiveness.
- User success/failure outbox messages are delayed fallback notifications only; they are paused after a successful inline edit.
- Pre-transfer temporary provider/read failures are retried briefly, then fail safely so a wallet hold cannot remain queued forever.
