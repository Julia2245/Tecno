from __future__ import annotations

from html import escape

LOADING_EMOJI_ID = "5386367538735104399"
PROCESSING_EMOJI_ID = "5884447890960552542"
SUCCESS_EMOJI_ID = "5796205953913196373"


def custom_emoji(emoji_id: str, fallback: str) -> str:
    """Telegram HTML custom emoji with a readable fallback glyph."""
    return f'<tg-emoji emoji-id="{escape(str(emoji_id))}">{escape(fallback)}</tg-emoji>'


LOADING = custom_emoji(LOADING_EMOJI_ID, "⏳")
PROCESSING = custom_emoji(PROCESSING_EMOJI_ID, "🔄")
SUCCESS = custom_emoji(SUCCESS_EMOJI_ID, "✅")
