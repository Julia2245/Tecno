from __future__ import annotations

import html
import re
from uuid import UUID

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.emojis import LOADING, PROCESSING, SUCCESS
from app.core.ui import safe_edit
from app.keyboards.admin_ichancy import (
    admin_ichancy_menu,
    old_record_actions,
    old_records_menu,
    review_job_actions,
    review_jobs_menu,
    replacement_menu,
    staged_cashier_menu,
)
from app.repositories.ichancy_replacements import CashierReplacementRepository
from app.services.ichancy_accounts import IchancyAccountsService
from app.services.ichancy_replacements import CashierReplacementError, CashierReplacementService
from app.services.ichancy_jobs import IchancyJobError, IchancyJobService
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin_ichancy")
_PREFIX_RE = re.compile(r"^[a-z][a-z0-9_]{0,19}$")


class AdminIchancyStates(StatesGroup):
    setting_value = State()
    replace_username = State()
    replace_password = State()
    replace_parent = State()
    old_search = State()


def _admin(user_id: int, settings: Settings) -> bool:
    return user_id in settings.super_admin_ids


async def _delete_input(message: Message) -> None:
    try:
        await message.delete()
    except Exception:
        pass


async def _edit_origin(bot: Bot, data: dict, text: str, *, reply_markup=None) -> None:
    chat_id = data.get("origin_chat_id")
    message_id = data.get("origin_message_id")
    if chat_id and message_id:
        await bot.edit_message_text(chat_id=int(chat_id), message_id=int(message_id), text=text, reply_markup=reply_markup, parse_mode="HTML")


@router.callback_query(F.data == "admin:ichancy")
async def home(callback: CallbackQuery, settings: Settings, replacement_service: CashierReplacementService) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    active = await replacement_service.repository.get_open()
    extra = ""
    if active:
        extra = f"\n\n⚠️ يوجد استبدال كاشيرة بحالة: <b>{html.escape(active.status)}</b>"
    await safe_edit(callback, "🎰 <b>إدارة iChancy</b>" + extra, reply_markup=admin_ichancy_menu())


@router.callback_query(F.data == "admin:ichancy:cashier")
async def cashier_status(callback: CallbackQuery, settings: Settings, ichancy_accounts: IchancyAccountsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    cashier = await ichancy_accounts.repository.get_active_cashier()
    if cashier is None:
        await safe_edit(callback, "🏦 <b>الكاشيرة الحالية</b>\n\n❌ لا توجد كاشيرة نشطة.", reply_markup=admin_ichancy_menu())
        return
    try:
        username = await ichancy_accounts.cashier_username(cashier)
    except Exception:
        username = "غير متاح"
    await safe_edit(
        callback,
        "🏦 <b>الكاشيرة الحالية</b>\n\n"
        f"👤 الحساب: <code>{html.escape(username)}</code>\n"
        f"🔢 الجيل: <code>{cashier.generation}</code>\n"
        f"💱 العملة: <code>{html.escape(cashier.currency)}</code>\n"
        f"📌 الحالة: <b>{html.escape(cashier.status)}</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🧪 اختبار الكاشيرة وفحص الرصيد", callback_data=f"admin:ichancy:cashier:test:{cashier.id}")],
            [InlineKeyboardButton(text="⬅️ رجوع", callback_data="admin:ichancy")],
        ]),
    )


@router.callback_query(F.data.startswith("admin:ichancy:cashier:test:"))
async def cashier_test(callback: CallbackQuery, settings: Settings, ichancy_accounts: IchancyAccountsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    try:
        cashier_id = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception:
        return
    cashier = await ichancy_accounts.repository.get_cashier(cashier_id)
    if cashier is None:
        await safe_edit(callback, "❌ الكاشيرة غير موجودة.", reply_markup=admin_ichancy_menu()); return
    await safe_edit(callback, f"{LOADING} <b>جاري اختبار اتصال الكاشيرة...</b>")
    try:
        balance = await ichancy_accounts.test_cashier(cashier)
        username = await ichancy_accounts.cashier_username(cashier)
        balance_text = "غير متاح" if balance is None else f"{balance:,}"
        await safe_edit(
            callback,
            f"{SUCCESS} <b>الكاشيرة تعمل بشكل صحيح</b>\n\n"
            f"👤 <code>{html.escape(username)}</code>\n💰 الرصيد: <code>{balance_text}</code>",
            reply_markup=admin_ichancy_menu(),
        )
    except Exception as exc:
        await safe_edit(callback, f"❌ فشل اختبار الكاشيرة:\n<code>{html.escape(str(exc)[:700])}</code>", reply_markup=admin_ichancy_menu())


_SETTING_META = {
    "ichancy.min_deposit": ("الحد الأدنى لشحن iChancy", "int"),
    "ichancy.min_withdraw": ("الحد الأدنى لسحب iChancy", "int"),
    "ichancy.username_prefix": ("بادئة أسماء حسابات iChancy", "prefix"),
}


@router.callback_query(F.data.startswith("admin:ichancy:setting:"))
async def setting_start(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    key = str(callback.data or "")[len("admin:ichancy:setting:"):]
    meta = _SETTING_META.get(key)
    if not meta: return
    label, kind = meta
    await state.clear()
    await state.update_data(setting_key=key, setting_kind=kind, origin_chat_id=callback.message.chat.id if isinstance(callback.message, Message) else None, origin_message_id=callback.message.message_id if isinstance(callback.message, Message) else None)
    await state.set_state(AdminIchancyStates.setting_value)
    await safe_edit(callback, f"✏️ <b>{label}</b>\n\nالقيمة الحالية: <code>{html.escape(str(runtime_settings.get(key)))}</code>\n\nأرسل القيمة الجديدة.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:ichancy")]]))


@router.message(AdminIchancyStates.setting_value, F.text)
async def setting_value(message: Message, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data(); raw = (message.text or "").strip(); kind = str(data.get("setting_kind") or "")
    try:
        if kind == "int":
            value = int(raw.replace(",", ""))
            if value <= 0:
                raise ValueError
        elif kind == "prefix":
            value = raw.lower().strip()
            if not _PREFIX_RE.fullmatch(value):
                raise ValueError
        else:
            raise ValueError
    except Exception:
        await _delete_input(message)
        await _edit_origin(message.bot, data, "❌ القيمة غير صالحة. أرسل رقماً موجباً، أو بادئة إنكليزية مثل <code>bot</code>.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:ichancy")]]))
        return
    await runtime_settings.set(str(data["setting_key"]), value, updated_by=message.from_user.id)
    await _delete_input(message)
    await state.clear()
    await _edit_origin(message.bot, data, f"{SUCCESS} <b>تم حفظ الإعداد</b>\n\nالقيمة الجديدة: <code>{html.escape(str(value))}</code>", reply_markup=admin_ichancy_menu())


@router.callback_query(F.data == "admin:ichancy:replace")
async def replace_begin(callback: CallbackQuery, state: FSMContext, settings: Settings, replacement_service: CashierReplacementService) -> None:
    if not _admin(callback.from_user.id, settings): return
    current = await replacement_service.repository.get_open()
    if current:
        await safe_edit(callback, replacement_service.progress_text(current), reply_markup=replacement_menu(current.id, current.status)); return
    await state.clear()
    if not isinstance(callback.message, Message): return
    active_cashier = await replacement_service.accounts.get_active_cashier()
    await state.update_data(origin_chat_id=callback.message.chat.id, origin_message_id=callback.message.message_id)
    await state.set_state(AdminIchancyStates.replace_username)
    if active_cashier is None:
        prompt = "➕ <b>إضافة أول كاشيرة iChancy</b>\n\nأرسل اسم مستخدم API للكاشيرة.\nسيتم اختبارها أولاً ولن تُعتمد قبل نجاح الاختبار."
    else:
        prompt = "🔄 <b>استبدال كاشيرة iChancy</b>\n\nأرسل اسم مستخدم API للكاشيرة الجديدة.\nلن يتم إيقاف الكاشيرة الحالية قبل نجاح اختبار الحساب الجديد."
    await safe_edit(callback, prompt, reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:ichancy")]]))


@router.message(AdminIchancyStates.replace_username, F.text)
async def replace_username(message: Message, state: FSMContext, settings: Settings) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    value = (message.text or "").strip()
    if len(value) < 2:
        await _delete_input(message); return
    await state.update_data(new_cashier_username=value)
    data = await state.get_data(); await _delete_input(message)
    await state.set_state(AdminIchancyStates.replace_password)
    await _edit_origin(message.bot, data, "🔐 <b>أرسل كلمة مرور API للكاشيرة الجديدة</b>\n\nسيتم حذف رسالتك من المحادثة فور التقاطها وتخزينها مشفرة فقط.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:ichancy")]]))


@router.message(AdminIchancyStates.replace_password, F.text)
async def replace_password(message: Message, state: FSMContext, settings: Settings) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    value = message.text or ""
    if len(value) < 3:
        await _delete_input(message); return
    await state.update_data(new_cashier_password=value)
    data = await state.get_data(); await _delete_input(message)
    await state.set_state(AdminIchancyStates.replace_parent)
    await _edit_origin(message.bot, data, "🆔 <b>Parent ID للكاشيرة الجديدة</b>\n\nأرسل Parent ID، أو أرسل <code>-</code> لاستخدام نفس Parent ID للكاشيرة الحالية.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:ichancy")]]))


@router.message(AdminIchancyStates.replace_parent, F.text)
async def replace_parent(message: Message, state: FSMContext, settings: Settings, ichancy_accounts: IchancyAccountsService) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data(); parent = (message.text or "").strip(); await _delete_input(message)
    parent_id = None if parent in {"", "-"} else parent
    await _edit_origin(message.bot, data, f"{LOADING} <b>جاري اختبار الكاشيرة الجديدة...</b>")
    try:
        staged = await ichancy_accounts.stage_cashier(
            username=str(data.get("new_cashier_username") or ""),
            password=str(data.get("new_cashier_password") or ""),
            parent_id=parent_id,
            created_by=message.from_user.id,
        )
        balance = await ichancy_accounts.test_cashier(staged)
        username = await ichancy_accounts.cashier_username(staged)
    except Exception as exc:
        await state.clear()
        await _edit_origin(message.bot, data, f"❌ <b>فشل اختبار الكاشيرة الجديدة</b>\n\n<code>{html.escape(str(exc)[:800])}</code>\n\nلم يتم تغيير الكاشيرة الحالية.", reply_markup=admin_ichancy_menu())
        return
    await state.clear()
    bal = "غير متاح" if balance is None else f"{balance:,}"
    active_cashier = await ichancy_accounts.repository.get_active_cashier()
    initial_setup = active_cashier is None
    if initial_setup:
        note = "✅ لا توجد كاشيرة حالية. يمكنك اعتماد هذه الكاشيرة مباشرة كأول كاشيرة للبوت."
    else:
        note = "⚠️ عند بدء الاستبدال سيتم إيقاف حسابات الجيل القديم عن العمليات الجديدة، فحص أرصدتها، وسحب الأرصدة التي تحقق الحد إلى محافظ أصحابها قبل اعتماد الكاشيرة الجديدة."
    await _edit_origin(
        message.bot, data,
        f"{SUCCESS} <b>تم اختبار الكاشيرة الجديدة بنجاح</b>\n\n👤 الحساب: <code>{html.escape(username)}</code>\n💰 رصيد الكاشيرة: <code>{bal}</code>\n\n{note}",
        reply_markup=staged_cashier_menu(staged.id, initial_setup=initial_setup),
    )


@router.callback_query(F.data.startswith("ai:ca:"))
@router.callback_query(F.data.startswith("admin:ichancy:cashier:activate:"))
async def activate_initial_cashier(callback: CallbackQuery, settings: Settings, ichancy_accounts: IchancyAccountsService) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    try:
        cashier_id = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception:
        return
    await safe_edit(callback, f"{PROCESSING} <b>جاري اعتماد الكاشيرة الأولى...</b>")
    try:
        cashier = await ichancy_accounts.repository.activate_initial_cashier(
            cashier_id, admin_id=callback.from_user.id
        )
        username = await ichancy_accounts.cashier_username(cashier)
    except ValueError as exc:
        mapping = {
            "ACTIVE_ICHANCY_CASHIER_EXISTS": "توجد كاشيرة نشطة بالفعل؛ استخدم مسار استبدال الكاشيرة.",
            "NEW_CASHIER_NOT_STAGED": "الكاشيرة لم تعد بحالة جاهزة للاعتماد.",
            "NEW_CASHIER_NOT_TESTED": "يجب اختبار الكاشيرة بنجاح قبل اعتمادها.",
        }
        await safe_edit(callback, f"❌ {html.escape(mapping.get(str(exc), str(exc)))}", reply_markup=admin_ichancy_menu())
        return
    except Exception as exc:
        await safe_edit(callback, f"❌ تعذر اعتماد الكاشيرة: <code>{html.escape(str(exc)[:700])}</code>", reply_markup=admin_ichancy_menu())
        return
    await safe_edit(
        callback,
        f"{SUCCESS} <b>تم اعتماد الكاشيرة بنجاح</b>\n\n👤 الحساب: <code>{html.escape(username)}</code>\n🔢 الجيل: <code>{cashier.generation}</code>",
        reply_markup=admin_ichancy_menu(),
    )


@router.callback_query(F.data.startswith("admin:ichancy:replace:start:"))
async def replace_start(callback: CallbackQuery, settings: Settings, replacement_service: CashierReplacementService) -> None:
    if not _admin(callback.from_user.id, settings): return
    try: cashier_id = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception: return
    if not isinstance(callback.message, Message): return
    await safe_edit(callback, f"{PROCESSING} <b>جاري بدء استبدال الكاشيرة...</b>\nلن يتم حذف أي سجل مالي.")
    try:
        rec = await replacement_service.start(new_cashier_id=cashier_id, admin_id=callback.from_user.id, progress_chat_id=callback.message.chat.id, progress_message_id=callback.message.message_id)
    except CashierReplacementError as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}", reply_markup=admin_ichancy_menu()); return
    await replacement_service.update_progress(rec, force=True)


@router.callback_query(F.data.startswith("admin:ichancy:replace:view:"))
async def replace_view(callback: CallbackQuery, settings: Settings, replacement_service: CashierReplacementService) -> None:
    if not _admin(callback.from_user.id, settings): return
    try: rid = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception: return
    rec = await replacement_service.repository.refresh_stats(rid)
    await safe_edit(callback, replacement_service.progress_text(rec), reply_markup=replacement_menu(rec.id, rec.status))


@router.callback_query(F.data.startswith("admin:ichancy:replace:retry:"))
async def replace_retry(callback: CallbackQuery, settings: Settings, replacement_service: CashierReplacementService) -> None:
    if not _admin(callback.from_user.id, settings): return
    rid = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    rec = await replacement_service.retry_failed(rid)
    await safe_edit(callback, replacement_service.progress_text(rec), reply_markup=replacement_menu(rec.id, rec.status))


@router.callback_query(F.data.startswith("ai:rf:"))
@router.callback_query(F.data.startswith("admin:ichancy:replace:finalize:"))
async def replace_finalize(callback: CallbackQuery, settings: Settings, replacement_service: CashierReplacementService) -> None:
    if not _admin(callback.from_user.id, settings): return
    rid = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    try:
        rec = await replacement_service.finalize(rid, callback.from_user.id)
    except CashierReplacementError as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}", reply_markup=admin_ichancy_menu()); return
    await safe_edit(callback, replacement_service.progress_text(rec), reply_markup=admin_ichancy_menu())


@router.callback_query(F.data == "admin:ichancy:review")
async def review_jobs(
    callback: CallbackQuery,
    settings: Settings,
    ichancy_jobs: IchancyJobService,
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    jobs = await ichancy_jobs.jobs.list_needs_review(limit=30)
    if not jobs:
        await safe_edit(
            callback,
            f"{SUCCESS} <b>لا توجد عمليات iChancy تحتاج مراجعة حالياً</b>",
            reply_markup=admin_ichancy_menu(),
        )
        return
    rows = [(j.id, j.operation_type, j.telegram_id, j.amount) for j in jobs]
    await safe_edit(
        callback,
        "⚠️ <b>عمليات iChancy تحتاج مراجعة</b>\n\n"
        "هذه العمليات لم تُعد تلقائياً لأن نتيجة المزود غير مؤكدة. "
        "افتح العملية ولا تحسمها إلا بعد التحقق من النتيجة الفعلية.",
        reply_markup=review_jobs_menu(rows),
    )


@router.callback_query(F.data.startswith("admin:ichancy:review:view:"))
async def review_job_view(
    callback: CallbackQuery,
    settings: Settings,
    ichancy_jobs: IchancyJobService,
    ichancy_accounts: IchancyAccountsService,
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    try:
        job_id = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception:
        return
    job = await ichancy_jobs.jobs.get(job_id)
    if job is None or job.status != "reconciling":
        await safe_edit(callback, "❌ العملية لم تعد بحالة مراجعة.", reply_markup=admin_ichancy_menu())
        return
    account = await ichancy_accounts.repository.get_account(job.account_id)
    account_name = account.username if account else "غير متاح"
    player_id = account.player_id if account else "غير متاح"
    type_labels = {
        "deposit": "شحن حساب iChancy",
        "withdraw": "سحب رصيد iChancy",
        "retirement_withdraw": "تصفية حساب من كاشيرة قديمة",
    }
    pb = "غير متاح" if job.player_balance_before is None else f"{job.player_balance_before:,}"
    cb = "غير متاح" if job.cashier_balance_before is None else f"{job.cashier_balance_before:,}"
    error = html.escape((job.last_error or "نتيجة العملية الخارجية غير مؤكدة")[:700])
    await safe_edit(
        callback,
        "⚠️ <b>مراجعة عملية iChancy</b>\n\n"
        f"🧾 رقم العملية: <code>{job.id}</code>\n"
        f"📌 النوع: <b>{html.escape(type_labels.get(job.operation_type, job.operation_type))}</b>\n"
        f"🆔 Telegram ID: <code>{job.telegram_id}</code>\n"
        f"🎰 الحساب: <code>{html.escape(account_name)}</code>\n"
        f"🎮 Player ID: <code>{html.escape(player_id)}</code>\n"
        f"💰 المبلغ: <code>{job.amount:,}</code>\n"
        f"🎮 رصيد اللاعب قبل: <code>{pb}</code>\n"
        f"🏦 رصيد الكاشيرة قبل: <code>{cb}</code>\n\n"
        f"⚠️ السبب: <code>{error}</code>\n\n"
        "<b>تنبيه:</b> زر «تمت» لا يعيد إرسال أي تحويل للمزود؛ "
        "هو يثبت النتيجة محلياً فقط. استخدمه بعد التأكد من أن العملية تمت فعلاً.",
        reply_markup=review_job_actions(job.id),
    )


@router.callback_query(F.data.startswith("admin:ichancy:review:done:"))
async def review_job_done(
    callback: CallbackQuery,
    settings: Settings,
    ichancy_jobs: IchancyJobService,
    replacement_service: CashierReplacementService,
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    try:
        job_id = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception:
        return
    await safe_edit(
        callback,
        f"{PROCESSING} <b>جاري تثبيت نتيجة العملية محلياً...</b>\nلن يتم إرسال أي تحويل جديد إلى iChancy.",
    )
    try:
        job = await ichancy_jobs.confirm_review_done(job_id, callback.from_user.id)
    except IchancyJobError as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}", reply_markup=admin_ichancy_menu())
        return
    replacement_service.wake()
    await safe_edit(
        callback,
        f"{SUCCESS} <b>تم تثبيت العملية بنجاح</b>\n\n"
        f"🧾 رقم العملية: <code>{job.id}</code>\n"
        "لم يتم إرسال أي طلب مالي جديد للمزود.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="⬅️ عمليات تحتاج مراجعة", callback_data="admin:ichancy:review")
        ]]),
    )


@router.callback_query(F.data.startswith("ai:jn:"))
@router.callback_query(F.data.startswith("admin:ichancy:review:notdone:"))
async def review_job_not_done(
    callback: CallbackQuery,
    settings: Settings,
    ichancy_jobs: IchancyJobService,
    replacement_service: CashierReplacementService,
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    try:
        job_id = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception:
        return
    await safe_edit(callback, f"{PROCESSING} <b>جاري إغلاق العملية باعتبارها غير منفذة...</b>")
    try:
        job = await ichancy_jobs.confirm_review_not_done(job_id, callback.from_user.id)
    except IchancyJobError as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}", reply_markup=admin_ichancy_menu())
        return
    replacement_service.wake()
    await safe_edit(
        callback,
        f"{SUCCESS} <b>تم حسم العملية كغير منفذة</b>\n\n"
        f"🧾 رقم العملية: <code>{job.id}</code>\n"
        "إذا كانت العملية شحناً من المحفظة فقد تم تحرير الحجز دون تنفيذ تحويل جديد.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="⬅️ عمليات تحتاج مراجعة", callback_data="admin:ichancy:review")
        ]]),
    )


@router.callback_query(F.data == "admin:ichancy:old")
async def old_search_start(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    if not isinstance(callback.message, Message): return
    await state.update_data(origin_chat_id=callback.message.chat.id, origin_message_id=callback.message.message_id)
    await state.set_state(AdminIchancyStates.old_search)
    await safe_edit(callback, "📚 <b>سجلات الكاشيرات القديمة</b>\n\nأرسل Telegram ID للمستخدم الذي تريد البحث عنه.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ رجوع", callback_data="admin:ichancy")]]))


@router.message(AdminIchancyStates.old_search, F.text)
async def old_search_value(message: Message, state: FSMContext, settings: Settings, replacement_repository: CashierReplacementRepository) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data(); raw = (message.text or "").strip(); await _delete_input(message)
    if not raw.isdigit():
        await _edit_origin(message.bot, data, "❌ Telegram ID غير صالح. أرسل أرقام فقط.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ رجوع", callback_data="admin:ichancy")]])); return
    items = await replacement_repository.list_old_for_user(int(raw))
    await state.clear()
    if not items:
        await _edit_origin(message.bot, data, f"📚 لا توجد حسابات iChancy قديمة محفوظة للمستخدم <code>{raw}</code>.", reply_markup=admin_ichancy_menu()); return
    rows = [(r.id, r.username, r.final_balance_snapshot if r.final_balance_snapshot is not None else r.balance_snapshot, r.compensation_wallet_operation_id is not None) for r in items]
    await _edit_origin(message.bot, data, f"📚 <b>الحسابات القديمة</b>\n\nTelegram ID: <code>{raw}</code>\nالعدد: <b>{len(items)}</b>", reply_markup=old_records_menu(rows))


@router.callback_query(F.data.startswith("admin:ichancy:old:view:"))
async def old_view(callback: CallbackQuery, settings: Settings, replacement_repository: CashierReplacementRepository) -> None:
    if not _admin(callback.from_user.id, settings): return
    rid = UUID(str(callback.data or "").rsplit(":", 1)[-1]); rec = await replacement_repository.get_retirement(rid)
    if not rec:
        await safe_edit(callback, "❌ السجل غير موجود.", reply_markup=admin_ichancy_menu()); return
    first_balance = "غير مؤكد" if rec.balance_snapshot is None else f"{rec.balance_snapshot:,}"
    final_value = rec.final_balance_snapshot if rec.final_balance_snapshot is not None else rec.balance_snapshot
    final_balance = "غير مؤكد" if final_value is None else f"{final_value:,}"
    comp = "لم يتم" if rec.compensation_wallet_operation_id is None else f"تم ({rec.compensated_amount:,})"
    class_labels = {
        "zero":"رصيد صفر",
        "below_minimum":"أقل من حد السحب",
        "residual_below_minimum":"متبقي أقل من حد السحب بعد التصفية",
        "settled":"تمت التصفية تلقائياً",
        "review":"تحتاج مراجعة",
        "check_failed":"تعذر الفحص",
        "settling":"قيد التصفية",
        "rechecking":"تدقيق الرصيد بعد السحب",
        "withdrawable":"قابل للسحب",
    }
    can_comp = rec.classification in {"below_minimum", "residual_below_minimum"} and bool(final_value) and rec.compensation_wallet_operation_id is None
    await safe_edit(
        callback,
        "📦 <b>سجل حساب iChancy قديم</b>\n\n"
        f"🆔 Telegram ID: <code>{rec.telegram_id}</code>\n"
        f"🎰 الحساب: <code>{html.escape(rec.username)}</code>\n"
        f"🎮 Player ID: <code>{html.escape(rec.player_id)}</code>\n"
        f"💰 الرصيد عند أول فحص: <code>{first_balance}</code>\n"
        f"📦 الرصيد المتبقي عند التقاعد: <code>{final_balance}</code>\n"
        f"📌 الحالة: <b>{html.escape(class_labels.get(rec.classification, rec.classification))}</b>\n"
        f"💳 التعويض اليدوي: <b>{comp}</b>",
        reply_markup=old_record_actions(rec.id, can_compensate=bool(can_comp)),
    )


@router.callback_query(F.data.regexp(r"^ai:oc:[0-9a-fA-F-]{36}$"))
@router.callback_query(F.data.regexp(r"^admin:ichancy:old:compensate:[0-9a-fA-F-]{36}$"))
async def old_compensate_confirm(callback: CallbackQuery, settings: Settings, replacement_repository: CashierReplacementRepository) -> None:
    if not _admin(callback.from_user.id, settings): return
    rid = UUID(str(callback.data or "").rsplit(":", 1)[-1]); rec = await replacement_repository.get_retirement(rid)
    final_value = None if not rec else (rec.final_balance_snapshot if rec.final_balance_snapshot is not None else rec.balance_snapshot)
    if not rec or final_value is None or int(final_value) <= 0 or rec.classification not in {"below_minimum", "residual_below_minimum"}:
        await safe_edit(callback, "❌ لا يوجد رصيد متبقٍ مؤكد صالح للتعويض.", reply_markup=admin_ichancy_menu()); return
    await safe_edit(callback, "⚠️ <b>تأكيد تعويض رصيد حساب قديم</b>\n\n"
                    f"👤 المستخدم: <code>{rec.telegram_id}</code>\n🎰 الحساب: <code>{html.escape(rec.username)}</code>\n💰 سيضاف للمحفظة: <code>{int(final_value):,}</code>\n\nلا يمكن تنفيذ التعويض مرتين لنفس السجل.",
                    reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                        [InlineKeyboardButton(text="✅ تأكيد التعويض", callback_data=f"ai:ocy:{rid}")],
                        [InlineKeyboardButton(text="❌ إلغاء", callback_data=f"admin:ichancy:old:view:{rid}")],
                    ]))


@router.callback_query(F.data.regexp(r"^ai:ocy:[0-9a-fA-F-]{36}$"))
@router.callback_query(F.data.regexp(r"^admin:ichancy:old:compensate:yes:[0-9a-fA-F-]{36}$"))
async def old_compensate_yes(callback: CallbackQuery, settings: Settings, replacement_service: CashierReplacementService) -> None:
    if not _admin(callback.from_user.id, settings): return
    rid = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    try:
        rec = await replacement_service.compensate(rid, callback.from_user.id)
    except CashierReplacementError as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}", reply_markup=admin_ichancy_menu()); return
    await safe_edit(callback, f"{SUCCESS} <b>تم تعويض المستخدم بنجاح</b>\n\n💰 المبلغ: <code>{rec.compensated_amount:,}</code>\n👤 Telegram ID: <code>{rec.telegram_id}</code>", reply_markup=old_record_actions(rec.id, can_compensate=False))
