from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.services.deposits import DepositService


def deposit_methods_menu(service: DepositService) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    icons = {
        "syriatel": "📱",
        "sham_syp": "💵",
        "sham_usd": "💵",
        "whish_money": "💸",
        "binance_trc20": "🪙",
        "binance_bep20": "🪙",
    }
    for cfg in service.all_methods():
        suffix = "" if cfg.enabled else " — متوقف"
        rows.append([
            InlineKeyboardButton(
                text=f"{icons.get(cfg.method, '💳')} {cfg.label}{suffix}",
                callback_data=f"deposit:method:{cfg.method}",
            )
        ])
    rows.append([InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def deposit_back_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ طرق الشحن", callback_data="deposit:methods")],
            [InlineKeyboardButton(text="🏠 الرئيسية", callback_data="core:home")],
        ]
    )


def deposit_cancel_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="❌ إلغاء العملية", callback_data="deposit:cancel")],
            [InlineKeyboardButton(text="⬅️ طرق الشحن", callback_data="deposit:methods")],
        ]
    )


def deposit_confirm_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ تأكيد", callback_data="deposit:confirm"),
                InlineKeyboardButton(text="❌ إلغاء", callback_data="deposit:cancel"),
            ],
            [InlineKeyboardButton(text="⬅️ طرق الشحن", callback_data="deposit:methods")],
        ]
    )


def whish_photo_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ تعديل المبلغ", callback_data="deposit:whish:back_amount")],
            [InlineKeyboardButton(text="❌ إلغاء العملية", callback_data="deposit:cancel")],
        ]
    )


def manual_review_menu(deposit_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ اعتماد", callback_data=f"deposit:admin:approve:{deposit_id}"),
                InlineKeyboardButton(text="❌ رفض", callback_data=f"deposit:admin:reject:{deposit_id}"),
            ]
        ]
    )


def admin_pending_deposits_menu(items: list[tuple[str, str]]) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for deposit_id, label in items:
        rows.append([
            InlineKeyboardButton(text=label, callback_data=f"deposit:admin:view:{deposit_id}")
        ])
    rows.append([InlineKeyboardButton(text="⬅️ لوحة الإدارة", callback_data="admin:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
