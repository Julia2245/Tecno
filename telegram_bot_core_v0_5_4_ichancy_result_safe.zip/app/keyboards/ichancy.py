from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from app.core.emojis import SUCCESS_EMOJI_ID


def ichancy_menu(*, has_account: bool) -> InlineKeyboardMarkup:
    if not has_account:
        rows = [
            [InlineKeyboardButton(text="➕ إنشاء حساب iChancy", callback_data="ichancy:create")],
            [InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")],
        ]
    else:
        rows = [
            [InlineKeyboardButton(text="🚀 دخول فوري إلى أيشانسي", callback_data="ichancy:website")],
            [
                InlineKeyboardButton(text="💳 شحن رصيد حسابك", callback_data="ichancy:deposit"),
                InlineKeyboardButton(text="💸 سحب رصيد حسابك", callback_data="ichancy:withdraw"),
            ],
            [InlineKeyboardButton(text="⚡ شحن كامل الرصيد", callback_data="ichancy:deposit_all")],
            [InlineKeyboardButton(text="ℹ️ معلومات حسابك", callback_data="ichancy:account")],
            [InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")],
        ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back_to_ichancy() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="ichancy:menu")]
    ])


def cancel_to_ichancy() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ إلغاء", callback_data="ichancy:cancel")]
    ])


def full_deposit_confirm() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="تأكيد", callback_data="ichancy:deposit_all:confirm", icon_custom_emoji_id=SUCCESS_EMOJI_ID),
            InlineKeyboardButton(text="❌ إلغاء", callback_data="ichancy:cancel"),
        ],
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="ichancy:menu")],
    ])


def website_open(url: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="افتح الحساب 🚀", web_app=WebAppInfo(url=url))],
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="ichancy:menu")],
    ])


def replacement_wait_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")],
    ])
