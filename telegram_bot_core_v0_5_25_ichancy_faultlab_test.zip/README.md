# Telegram Bot Core — Phase 5

نواة عامة قابلة لإعادة الاستخدام لبوتات Telegram مبنية على **aiogram + PostgreSQL**، بدون ربط الكود بهوية بوت محددة.

> هذه المرحلة تجمع: النواة + Wallet Core + شحن رصيد البوت + iChancy + سحب رصيد البوت + إدارة الشحن والسحب + Durable Notification Outbox.

## v0.5.25 — الإشعارات + السحب + مباريات اليوم

- توحيد `💬 إدارة التواصل والرسائل الجماعية` ليضم الرسائل الجماعية، الدعم، وسبع قنوات إشعارات مرجعية في مكان واحد.
- وجهة مستقلة لطلبات الشحن اليدوي، مع إبقاء قيم `.env` bootstrap فقط وإتاحة التعطيل/التعديل من لوحة الإدارة.
- قناة شحن البوت تستقبل النجاح وكذلك الفشل المؤكد/تعذر المزود/النتيجة غير المؤكدة بتصنيف واضح، دون تغيير نتيجة العملية المالية.
- إشعارات أحداث الأدمن (كود هدية/إهداء/ولاء) أصبحت Durable عبر Notification Outbox.
- Outbox يوقف الإشعارات التي لا تملك قناة مضبوطة بدلاً من إعادة المحاولة بلا نهاية، ويستأنفها عند ضبط القناة.
- رقم عرض مرتب لطلبات السحب بصيغة `TECNO-000001` مع إبقاء UUID الداخلي للحماية والـidempotency.
- بطاقة السحب النهائية تخفي آخر 3 شحنات، وتضع الفاصل قبل الحالة، ويرسل نجاح السحب للمستخدم عبر Outbox بعد النجاح المحلي المؤكد فقط.
- `⚽ مباريات اليوم` مفعلة عند الترقية، وتفتح قائمة البطولات أولاً. Worker واحد يجلب بيانات يوم دمشق ويخزنها في PostgreSQL؛ ضغط المستخدم لا يستدعي Football API مطلقاً.
- Football API له مفتاح افتراضي داخل التطبيق مع `FOOTBALL_API_KEY` كـoverride اختياري، وكاش اليوم يبقى صالحاً بعد Restart.


## الأساس المالي

- PostgreSQL async عبر `asyncpg` وmigrations داخل schema مستقل `bot_core`.
- Wallet Core محمي: ledger append-only، idempotency، row locks، holds، وقيود سلامة على مستوى قاعدة البيانات.
- أي حركة رصيد تمر عبر `WalletRepository`؛ الـrouters لا تكتب على الرصيد مباشرة.
- إنشاء Hold والطلب المالي المرتبط به يتمان في Transaction واحدة.
- التسوية/الإلغاء/الرفض المالي يتم بصورة ذرية قدر الإمكان.
- العمليات الخارجية غير المؤكدة لا يعاد إرسال POST لها بصورة عمياء.

## شحن رصيد البوت

الطرق الحالية:

- Syriatel Cash — Auto / Manual.
- Sham Cash SYP — Auto / Manual.
- Sham Cash USD — Auto / Manual.
- Whish Money — Manual مع صورة إثبات Telegram.
- Binance USDT — TRC20 / BEP20.

الحماية تشمل namespaces مشتركة لمنع إعادة استخدام نفس Tx عبر تحويل العملة/الشبكة، وclaims/idempotency، وربط النجاح بعملية Wallet ثابتة.

- التحقق الآلي يعرض حالة واحدة تتحدث بالنتيجة، مع منع المستخدم من بدء تحقق شحن ثانٍ قبل حسم الأول.
- طلبات التحقق read-only تمر عبر مزود الـAPI النشط (API SYRIA أو TSA) بفاصل قصير وTimeout قصير؛ عند rate-limit/تعذر المزود لا يتم اعتماد العملية ويطلب من المستخدم إعادة المحاولة بنفس رقم العملية.
- أثناء تحقق الشحن يمنع `/start` و`/menu` والرجوع للرئيسية بدء تدفق موازٍ، وتبقى رسالة التحقق نفسها هي التي تتحدث بالنتيجة.
- أكواد استلام Syriatel وعناوين Sham Cash قابلة للتعديل من لوحة الإدارة، وتبقى قيم `.env` قيم bootstrap لقاعدة بيانات جديدة.
- أسعار Sham Cash USD وWhish Money وBinance TRC20/BEP20 مستقلة وقابلة للتعديل فورياً من صفحة كل وسيلة.

### تحويل العملة المحلية

Sham Cash SYP وSyriatel Cash يستخدمان **معامل تحويل واحد مشترك** محفوظ في Runtime Settings:

`money.local_syp_wallet_multiplier`

القيمة الافتراضية الحالية `100`، أي:

`200` من العملة المحلية → `20,000` رصيد محفظة.

يمكن تغييره لاحقاً من لوحة الإدارة إلى `1` لتصبح العلاقة 1:1. كل طلب يحفظ Snapshot للسعر الذي بدأ عليه، لذلك تغيير الإعداد لا يعيد تسعير الطلبات القديمة.

## مزود API لشام كاش وسيرياتيل

البوت يدعم مزودين حالياً عبر طبقة موحدة قابلة للتوسعة:

- `API SYRIA`
- `TSA API`

من **إدارة الشحن والسحب → مزود API** يختار الأدمن مزوداً واحداً فقط كـActive، ويمكن فحص حالته من نفس الصفحة. الاختيار يحفظ في Runtime Settings ولا يحتاج Restart.

مفاتيح المزودين تبقى أسرار Deployment داخل `.env`:

```env
PAYMENT_API_PROVIDER=api_syria
API_SYRIA_BASE_URL=https://apisyria.com/api/v1
API_SYRIA_KEY=
TSA_API_BASE_URL=https://tsa-api.com/api/v1
TSA_API_KEY=
```

قواعد الأمان:

- المزود يُجمّد عند بداية كل عملية مالية؛ تغييره من لوحة الإدارة لا يبدل مزود عملية بدأت بالفعل.
- لا يوجد fallback تلقائي بعد أي POST مالي. Timeout/Network/5xx تعني نتيجة غير مؤكدة ومراجعة، وليس تجربة المزود الآخر.
- معرف المزود يحفظ في `provider_payload` قبل POST للسحب/الحوالة اليدوية، حتى يمكن معرفة المزود الصحيح بعد Restart أو نتيجة غير مؤكدة.
- TSA يستخدم `accounts/list` لتحويل Cash Code القديم إلى GSM عند الحاجة، لأن عمليات Syriatel في TSA تعتمد رقم GSM.
- TSA يتحقق من عملية Syriatel على أنها ناجحة وواردة (`status=1`, `history_type=incoming`) قبل اعتماد الشحن.
- TSA يستخدم `resolve` للتحقق من اسم مستلم Sham Cash قبل السحب، ويستفيد من `tran_id` العائد مباشرة بعد نجاح التحويل.
- PIN شام كاش الاختياري لـTSA يمكن ضبطه مشفراً من صفحة سحب Sham Cash؛ لا يُعرض مرة أخرى في الواجهة.

## iChancy

### إنشاء الحساب

- المستخدم يدخل الاسم فقط.
- الأسماء العربية تنظف وتحوّل تلقائياً إلى صيغة لاتينية صالحة.
- اسم الحساب النهائي يستخدم عداداً ذرياً عاماً في PostgreSQL، مثل:
  - `tecno1_ahmad`
  - `tecno2_samer`
- الـprefix ليس ثابتاً في السورس؛ يحدد عبر `ICHANCY_USERNAME_PREFIX` أو لوحة إدارة iChancy.
- كلمة المرور تولد آلياً بمولد آمن وتخزن مشفرة، ولا تسجل في logs.
- لو كانت نتيجة registerPlayer غير مؤكدة، لا يعاد POST بصورة عمياء؛ تتم مطابقة الـusername الثابت أولاً.

### الدخول الفوري

المسار يطابق تجربة البوت المرجعي:

1. تسجيل الدخول عبر BetConstruct Swarm WebSocket.
2. استخراج `auth_token` مؤقت.
3. إظهار زر WebApp لفتح الموقع مباشرة بالحساب.
4. التوكن لا يخزن في قاعدة البيانات.
5. عند مشكلة فتح الموقع تظهر ملاحظة استخدام VPN على سنغافورة.

### العمليات

- شحن مبلغ إلى iChancy.
- سحب مبلغ من iChancy إلى المحفظة.
- شحن كامل الرصيد المتاح.
- الحد الأدنى للشحن والسحب قابل للتعديل من لوحة الإدارة؛ الافتراضي 20,000.
- العمليات تستخدم queue دائمة وحالات مالية منفصلة عن Telegram handlers.
- يتم حفظ snapshots لرصيد اللاعب والكاشير قبل/بعد عند توفرها.
- النتيجة غير المؤكدة تدخل `reconciling` ولا تعاد العملية المالية تلقائياً.
- توجد لوحة `⚠️ عمليات تحتاج مراجعة` لحسم العملية يدوياً بدون إرسال POST مالي جديد.

## إضافة / استبدال كاشيرة iChancy

عند عدم وجود كاشيرة نشطة، يمكن إدخال بيانات أول كاشيرة من لوحة الإدارة، اختبارها، ثم اعتمادها مباشرة. بعد وجود كاشيرة نشطة يستخدم النظام مسار الاستبدال المحمي أدناه.

الاستبدال Workflow دائم وقابل للاستكمال بعد Restart:

- اختبار الكاشيرة الجديدة قبل بدء الاستبدال.
- منع البدء عند وجود عمليات iChancy أو إنشاءات حساب غير محسومة على الكاشيرة القديمة.
- تحويل الكاشيرة القديمة وحساباتها إلى حالة retiring؛ لا يتم حذف أي حساب قديم.
- فحص أرصدة الحسابات وتصنيفها إلى:
  - صفر.
  - أقل من الحد الأدنى للسحب.
  - مؤهل للسحب.
  - فشل فحص / يحتاج مراجعة.
- الأرصدة المؤهلة تنشأ لها jobs مستقلة لسحب الرصيد وإعادته إلى Wallet المستخدم.
- بعد كل تسوية ناجحة تتم إعادة قراءة رصيد اللاعب:
  - صفر → تمت التصفية.
  - أقل من الحد → يحفظ كرصد متبقٍ في السجل القديم.
  - ما يزال فوق الحد → تنشأ محاولة تسوية جديدة مستقلة.
- الاعتماد النهائي يتطلب عدم وجود jobs نشطة وتطابق إجمالي ما سحب من iChancy مع إجمالي ما أضيف للمحافظ.
- التقدم يعرض في **رسالة إدارة واحدة تتحدث** بدلاً من إرسال رسالة لكل حساب.

### سجلات الكاشيرات القديمة

من إدارة iChancy يمكن البحث بـTelegram ID واستعراض الحسابات المتقاعدة، الرصيد المرصود والمتبقي وحالة التسوية.

الرصيد المتبقي الأقل من الحد يمكن تعويضه يدوياً بعد اكتمال الاستبدال. التعويض مرتبط بالسجل القديم وidempotent، فلا يمكن إضافته مرتين.

## سحب رصيد البوت

الطرق:

- Syriatel Cash.
- Sham Cash مع محاولة جلب اسم الحساب قبل إدخال المبلغ.
- حوالة — هرم / الفؤاد، مع بيانات المستلم.
- USDT — TRC20 / BEP20 مع تحكم مستقل لكل شبكة.

الحماية:

- Hold قبل التنفيذ.
- طلب واحد نشط لكل مستخدم.
- تنفيذ آلي لـSyriatel/Sham فقط؛ الحوالة وUSDT تنفيذ يدوي ثم تأكيد دفع.
- نتيجة مزود مؤكدة النجاح تحفظ أولاً كـ`provider_success`، وبعدها تكتمل التسوية المحلية بدون إعادة POST.
- نتيجة غير مؤكدة → `needs_review`، ولا يجوز رفضها وتحرير الـHold مباشرة.
- الأدمن يقرر صراحة: «تم الدفع» أو «لم يتم الدفع».
- أي `processing` قديم بعد Restart يتحول للمراجعة بدلاً من إعادة التحويل.
- بطاقة طلب السحب للأدمن تعرض آخر 3 عمليات شحن ناجحة للمستخدم مع البونص.
- أثناء التنفيذ الآلي تتحول البطاقة فوراً إلى «جاري التنفيذ» بلا أزرار تنفيذ إضافية، وبعد النجاح تعرض وقت الطلب ووقت التنفيذ ورقم عملية المزود عند إعادته من API.

## التنبيهات والإشعارات

الإشعارات المالية تستخدم **Durable Notification Outbox** داخل PostgreSQL:

- إنشاء حساب iChancy → قناة حسابات iChancy.
- شحن/سحب iChancy → قناة عمليات iChancy.
- شحن رصيد البوت → قناة عمليات الشحن المستقلة.
- سحب رصيد البوت → قناة عمليات السحب المستقلة.
- فشل Telegram أو Restart لا يحذف الحدث؛ العامل يعيد المحاولة.
- `event_key` فريد لمنع إنشاء إشعار منطقي مكرر.

حدود «المبلغ الكبير» قابلة للتعديل من لوحة الإدارة بصورة مستقلة:

- شحن iChancy.
- سحب iChancy.
- شحن رصيد البوت.
- سحب رصيد البوت.

عند تجاوز الحد لا ترسل رسالة ثانية؛ نفس رسالة العملية تحمل شارة `🚨 مبلغ كبير`، ولا يظهر رقم الحد في الإشعار.

## Custom Emoji

القيم مركزية داخل `app/core/emojis.py` وتشمل هوية الأزرار وحالات التنفيذ، ومن ضمنها:

- iChancy: `5994683681220861528`
- Sham Cash: `5996853812231413145`
- Syriatel Cash: `5994366253072916034`
- شحن رصيد البوت: `5377548235709619284`
- سحب رصيد البوت: `5994385322727709668`
- التحقق/التحميل: `5386367538735104399`
- المعالجة/التدقيق: `5884447890960552542`
- النجاح/التأكيد: `5796205953913196373`

## إعداد iChancy المطلوب قبل التشغيل الحقيقي

في `.env`:

```env
ICHANCY_BASE_URL=https://agents.ichancy.com
ICHANCY_API_USERNAME=
ICHANCY_API_PASSWORD=
ICHANCY_PARENT_ID=
ICHANCY_CURRENCY=SYP
ICHANCY_USERNAME_PREFIX=bot
ICHANCY_CREDENTIALS_KEY=
ICHANCY_WEBSITE_URL=https://www.ichancy300.com/ar
ICHANCY_WS_URL=wss://eu-swarm-springre.betcoswarm.com/
ICHANCY_WS_ORIGIN=https://www.ichancy.com
ICHANCY_WS_SITE_ID=18755655
ICHANCY_WS_SOURCE=42
```

لبيئة Tecno التجريبية اضبط:

```env
ICHANCY_USERNAME_PREFIX=tecno
```

قبل إنشاء أول حساب. لا ترفع `.env` إلى GitHub.

إن لم يكن `ICHANCY_CREDENTIALS_KEY` موجوداً، أنشئ مفتاح Fernet مرة واحدة فقط واحفظه في `.env`. تغيير هذا المفتاح بعد تخزين بيانات الحسابات يجعل بياناتها المشفرة غير قابلة للفك.

## الفحوص قبل اعتماد أي إصدار

فحص ثابت لا يحتاج قاعدة بيانات:

```bash
PYTHONPATH=. python -m scripts.preflight
```

ثم داخل بيئة السيرفر التي تحتوي الاعتماديات:

```bash
python -m pytest -q
python -m scripts.wallet_audit
python -m scripts.deposit_audit
python -m scripts.ichancy_audit
python -m scripts.withdraw_audit
python -m scripts.outbox_audit
```

النتائج السليمة يجب أن تحتوي:

```text
PROJECT PREFLIGHT: OK
WALLET AUDIT: OK
DEPOSIT AUDIT: OK
ICHANCY AUDIT: OK
WITHDRAW AUDIT: OK
OUTBOX AUDIT: OK
```

> Audits الجديدة read-only؛ معالجة `processing` المنقطع في السحب تتم عند تشغيل التطبيق، وليس داخل audit.

## قاعدة التطوير

- لا يوجد اسم بوت ثابت داخل منطق التطبيق.
- لا يكتب Router إلى Wallet أو Ledger مباشرة.
- أي API مالي خارجي يجب أن يفرق بين الفشل المؤكد والنتيجة غير المؤكدة.
- لا يعاد POST مالي بسبب Timeout دون reconciliation أو قرار صريح.
- إعدادات المال والحدود تحفظ Snapshot داخل العملية عند الحاجة حتى لا تغير الإعدادات الجديدة التاريخ المالي القديم.
## v0.5.2 callback safety
- Shortened UUID-bearing iChancy admin callback payloads that could exceed Telegram's 64-byte callback_data limit and trigger `BUTTON_DATA_INVALID`. Legacy callback handlers remain accepted where safe for already-open messages.


## v0.5.4 iChancy user-result UX
- Deposit progress is intentionally minimal: `جاري شحن حسابك...`; internal UUID/amount details stay out of the user's progress screen.
- The original progress message is updated to success/failure when the durable job finishes, without blocking callback/menu responsiveness.
- User success/failure outbox messages are delayed fallback notifications only; they are paused after a successful inline edit.
- Pre-transfer temporary provider/read failures are retried briefly, then fail safely so a wallet hold cannot remain queued forever.

## v0.5.5 iChancy safe reconciliation
- Every new iChancy financial job gets a unique provider comment/reference derived from its immutable job UUID (`TEC-D-...` for deposits, `TEC-W-...` for withdrawals).
- The reference is persisted before the financial POST and sent in the documented iChancy `comment` field.
- Explicit provider success settles normally; explicit rejection fails normally.
- Timeout/network/HTTP 429/5xx after a financial POST is never replayed blindly. The job enters read-only reconciliation.
- Reconciliation requires the exact two-sided delta: player balance and cashier balance must both match the transfer amount and direction.
- Reconciliation is throttled and bounded. Unprovable outcomes stop automatic polling and appear in the admin review queue without sending another financial POST.
- The original Telegram progress message is stored with the job and is edited to reconciling/success/failure even after a process restart when possible; delayed outbox messages remain a fallback.
- User progress/result messages contain no amount, UUID, Player ID, cashier balance, or provider reference. Those details remain admin-only.
- Fast callback/navigation files are unchanged from v0.5.4.


## v0.5.6 finance controls + instant capture
- iChancy withdrawal now performs a live player-balance precheck before creating a durable job, then retains the authoritative second balance read immediately before the financial POST.
- iChancy withdrawal progress is user-clean: balance check → withdrawal processing → final/reconciliation result in the same stored progress message, without exposing UUIDs or internal financial metadata.
- Bot-wallet deposit methods have independent runtime minimums and independent admin pages for Syriatel, Sham SYP, Sham USD, Whish, TRC20, and BEP20.
- Bot-wallet withdrawal administration is split into method settings, pending/review/history, commission, and immutable security information. Syriatel and Sham have independent minimums.
- Finance-setting input uses first-message capture: persist immediately, delete the input when possible, clear/cancel FSM safely, and edit the original admin screen with the effective value immediately. Arabic/Persian digits are accepted for numeric settings.
- Bot-wallet operation notifications are split into independent deposit and withdrawal channels. Migration `0007` seeds both from the legacy channel once, while all new events use their dedicated target.
- Approved custom emoji IDs are centralized in `app/core/emojis.py`; UI buttons reference the registry rather than embedding IDs throughout business logic.
- The fast callback ACK/render patch is unchanged byte-for-byte.

### v0.5.7 finance hotfix
- The runtime `notify.bot_deposits` channel is reserved for successful bot-wallet deposit notifications; pending manual-review requests remain on the dedicated review target/admin fallback.
- Sham Cash addresses are canonicalized on input/read; migration `0008` cleans existing runtime values pasted with quotes/whitespace.
- Syriatel withdrawal PIN can be set from the admin withdrawal page. Runtime PIN is encrypted with the deployment credential key and never displayed back in the UI.


### v0.5.8 withdrawal channel + admin transfer parity
- Every new bot-wallet withdrawal is posted as a live actionable card to `notify.bot_withdrawals`; the same channel message is stored and edited through processing, success, rejection, or admin-review states. Automatic execution follows the reference flow: read configured source balances, choose the source, review a confirmation card, then issue exactly one financial POST after the final confirmation.
- Confirmed withdrawal success notifies the user only after final settlement. Explicit admin rejection is the only rejection path that notifies the user. Timeout/network/5xx or any uncertain provider outcome stays admin-only in review and sends no user result.
- Sham Cash withdrawal cards keep the verified recipient account name and resolve the real provider transaction number after a successful POST using read-only outgoing-history reconciliation; the financial POST is never repeated for that lookup.
- The bot-deposit channel remains success-only. Manual pending-deposit review is kept separate from operation notifications.
- Added the admin manual-transfer section with Sham Cash/Syriatel source selection, live source balance, recipient, amount, confirmation, provider transaction reference, before/after balance, and paged immutable success audit. Sham Cash manual transfer intentionally omits the optional note field.
- Added read-only transaction search for Sham Cash, Syriatel Cash, and local bot records; it never credits a wallet or sends a financial transfer.
- Manual-transfer intent claims are durable so a repeated confirmation cannot issue the same financial POST twice; uncertain outcomes require admin review rather than an automatic retry.
- Migration `0009` stores withdrawal-channel message identity and the durable manual-transfer intent/audit tables.
- Callback-ACK, latency, and core UI speed-patch files remain unchanged.

### v0.5.9 multi-provider TSA + finance completion
- Added a runtime-selectable payment-provider layer. API SYRIA remains available and TSA API is added without changing wallet accounting or withdrawal idempotency. Only one provider is active at a time from **إدارة الشحن والسحب → مزود API**.
- Provider selection is frozen per financial operation. There is deliberately no automatic provider fallback after a financial POST, preventing cross-provider double payout after timeout or uncertain outcomes.
- The selected provider id is persisted before withdrawal/manual-transfer execution and retained in audit payloads for restart/reconciliation safety.
- TSA integration includes status/accounts, Sham Cash balance/logs/find/resolve/transfer, Syriatel balance/find/outgoing/transfer, Cash Code→GSM mapping, successful-incoming validation, and direct `tran_id` support.
- Added encrypted optional Sham Cash PIN support for TSA.
- Added independent admin-editable USD/USDT conversion rates for Sham USD, Whish Money, Binance TRC20, and Binance BEP20.
- `/start`, `/menu`, and main-menu navigation now respect the active deposit-verification guard so one user cannot start a second flow while a provider lookup is still in progress.
- Existing v0.5.8 withdrawal-channel processing/success cards, split deposit/withdraw notification channels, manual-transfer one-POST safety, and Julia finance behavior are preserved.


### v0.5.10 bot deposit notification channel fix

- `DEPOSIT_NOTIFY_CHAT_ID` is now the bootstrap/fallback for runtime `notify.bot_deposits`; an admin-panel channel override still takes precedence.
- Legacy pending `bot-deposit-success:*` outbox rows that still target `notify.bot_operations` are safely retargeted to `notify.bot_deposits` by migration `0010`.
- No withdrawal, iChancy, wallet-credit, provider, or settlement logic is changed.


### v0.5.11 Julia-style admin wallet

- Added **👛 محفظة الأدمن** beside **إدارة الشحن والسحب**, mirroring the reference Julia admin-wallet layout and callbacks.
- The wallet exposes read-only balances for Syriatel Cash, Sham Cash, Binance USDT, and the active iChancy cashier.
- Syriatel/Sham balance reads follow the currently active payment provider (TSA API or API SYRIA); switching provider from the admin panel immediately changes the source used by this wallet screen.
- Binance uses the signed read-only capital configuration endpoint to show USDT free/locked/frozen/withdrawing values and TRC20/BEP20 deposit availability.
- iChancy reads the current active cashier from Tecno's cashier repository, so a cashier replacement is reflected automatically.
- No transfer, wallet-credit, deposit settlement, or withdrawal execution logic is invoked by the admin-wallet screen.
### v0.5.12 Manual transfers moved to Admin Wallet
- UI-only move: removed `💸 حوالات يدوية` from `💳 إدارة الشحن والسحب`.
- Added the same `admin:manual_transfers` button under `👛 محفظة الأدمن`.
- The manual-transfer home Back button now returns to `👛 محفظة الأدمن`.
- No transfer callbacks, execution logic, repositories, provider calls, permissions, or financial safeguards were changed.

### v0.5.13 Julia bonus + commission parity
- Added the Julia-style **Bonus Management** hub with ordinary per-method deposit bonuses for Syriatel, Sham SYP, Sham USD, Binance USDT, and Whish Money. Existing `.env` percentages remain bootstrap defaults; admin-saved runtime values take precedence.
- Added **deposit bonus tiers** by original provider input amount and payment-method scope. The highest eligible threshold wins; a method-specific tier wins over `all` at the same threshold. Tier bonus replaces the ordinary method bonus and is calculated on the post-conversion base wallet credit.
- Added **special per-user deposit bonus** with once-only, 24-hour, and custom-duration modes; active bonuses can be listed, edited, or cancelled. A once-only bonus is consumed atomically with the successful deposit.
- Added **first-entry bonus** with Julia-compatible direct-wallet and first-successful-deposit modes. Each activation creates a new eligibility boundary for newly-created users, while every user can claim at most once. First-deposit entitlement is snapshotted and consumed atomically on settlement.
- Deposit bonus priority is: pending first-deposit welcome bonus → special-user bonus → eligible deposit tier → ordinary payment-method bonus. Bonuses never stack.
- Added the Julia-style **Commission Management** hub with ordinary withdrawal commission, ordinary hawala commission, and withdrawal-fee tiers. The highest eligible withdrawal tier replaces the ordinary commission.
- Manual deposits re-evaluate the applicable bonus inside the approval transaction, so an expired special bonus is not silently paid and a newly-applicable rule is evaluated at the successful approval point. Automatic deposits resolve and consume their rule inside the settlement transaction as well.
- Withdrawal fee percentage is resolved before the wallet hold/request is created and is frozen into the withdrawal row; later admin setting changes do not rewrite an existing request.
- Migration `0011` adds the tier, special-bonus, and welcome-claim audit tables and only relaxes deposit immutability enough to allow a controlled bonus refresh while a manual request is still `manual_pending`.

### v0.5.14 Cashback + referrals + Wheel of Fortune parity
- Added the Julia-compatible **cashback/refund engine** using a separate eligible-principal ledger. Only successful real bot deposits add eligible principal; bonuses, wheel prizes, referral rewards, welcome rewards, and prior cashback never become cashback principal.
- Eligible principal follows the money through bot-wallet spending and iChancy deposits/withdrawals. Failed/explicitly-not-executed iChancy deposits restore the reserved eligible source; confirmed iChancy withdrawals return eligible principal first up to the outstanding principal.
- Cashback cycles use exact **Asia/Damascus** boundaries: daily 00:00→00:00 and weekly Monday 00:00→next Monday 00:00. Mode changes cannot rewrite a cycle that already contains eligible financial activity and are safely scheduled for the next boundary instead.
- Cashback settlement snapshots each iChancy account at the closing boundary, reverses successful post-boundary transfers from a later live balance, quarantines uncertain principal on failed balance reads, supports retrying failed snapshots, and blocks payout until all uncertain snapshots are resolved. Distribution/skip require explicit admin confirmation and payouts remain cashback-ineligible.
- Added the Julia-compatible **referral system** with immutable first-touch ownership, direct mode or 3-level hierarchical mode, frozen cycle settings, active-direct-referral qualification, independent fixed referral reward (`verify`/first successful deposit), user referral list, earnings history, admin cycle history, and manual distribute/skip controls.
- Referral-cycle profit/loss is calculated from successful iChancy activity using boundary-adjusted live balances. Profitable referred players offset losing referred players within the same referrer/level/rate bucket before commission is created; level 2/3 use their own effective relationship windows. Payout revalidates the recipient immediately before wallet credit.
- Tecno has no required-channel membership gate, so a valid referral is confirmed atomically only on the referred user's **first-ever registration** instead of using Julia's channel-verification pending step. Existing users cannot be retroactively reassigned by reopening a referral link.
- Added the Julia-compatible **Wheel of Fortune**: one daily claim after the configured Damascus-day deposit threshold, plus an optional independent once-ever free spin granted only to users whose first registration occurs while the feature is enabled. The server authoritatively validates every `claim_wheel` deep-link result; client-provided prize data is never trusted.
- Wheel deposit qualification and reward behavior match the reference: daily successful deposits use their original request creation day, `special_user` deposits count base credit while other successful deposits count total credited value, and wheel rewards are normal spendable wallet cash but never cashback-eligible.
- Migration `0012` adds referral ownership/cycle/audit tables, wheel claim/free-entitlement tables, cashback principal/reservation/allocation/snapshot/settlement tables, and the indexes/constraints needed for idempotent financial processing.

### v0.5.15 Referral + cashback Julia parity hardening
- Referral ownership now follows the Julia pending-confirmation flow: the first valid `/start <referrer>` attribution is immutable and remains `pending` until the referred user presses the verification action. If `REQUIRED_CHANNEL` is configured, membership is checked before confirmation; no later referral link can replace the first owner.
- Fixed referral rewards are frozen at confirmation and executed inside an isolated savepoint. A reward-side failure cannot roll back a successful referral confirmation or a successful deposit, and failed entitlements are retryable with the same idempotent wallet key.
- Hierarchical referral settlement now freezes one closing iChancy balance per player account and reuses that same snapshot for every level/window. Level-specific effective relationship windows, active-direct qualification, upstream traversal, profitable-player offsets, and recipient revalidation match the Julia reference behavior.
- Referral balance-read failures are persisted and preparation stops at the first unresolved referred user. Admin retry resumes from frozen snapshots, and the beneficiary-detail screen is read-only and never performs a live balance request or accounting mutation.
- Cashback cycle-user states are aligned to Julia (`eligible`, `not_eligible`, `failed`, `banned`, `paid`, `skipped`). If any authoritative iChancy balance lookup fails, every relevant eligible-principal account for that user is quarantined until a successful retry, preventing uncertain principal from leaking into a later cycle.
- Cashback failed-snapshot retry is allowed until distribution begins, including a previously skipped cycle, matching the Julia service gate. Distribution remains blocked while unresolved failed snapshots exist and revalidates the user immediately before payout.
- Migration `0013_referral_cashback_parity.sql` is additive/constraint-only and preserves existing financial rows while adding the parity statuses, failure metadata, and retry counters.
- Sham Cash address normalization from v0.5.14 is preserved unchanged, including removal of pasted quote characters before provider use.

### v0.5.16 Cashback V2 + isolated provider traffic control
- Cashback now uses the cycle-scoped V2 rule: only eligible real-money iChancy deposits inside the exact cycle can create entitlement. The frozen user loss is `max(0, eligible cycle deposits - all actual cycle withdrawals - closing balances of cycle-deposit accounts)`. Historical principal can no longer create cashback in a later cycle.
- Legacy `ready`/`empty` cashback cycles that have not started payout are upgraded to V2 from their already-saved historical closing snapshots only. Missing required historical snapshots fail closed; distributed, skipped, or payout-started legacy cycles are never rewritten.
- Cashback preparation, failed-snapshot retry, preview, distribution, and skip are protected by V2 upgrade/freeze gates. Ambiguous iChancy provider operations block finalization until reconciliation reaches a safe terminal state.
- Referral cycle freezing now uses provider-success timestamps, reuses a single closing snapshot, reverses known post-boundary provider successes, and blocks ambiguous pre-boundary/post-boundary iChancy operations instead of guessing.
- API SYRIA and TSA now use isolated long-lived HTTP sessions/connection pools with keep-alive, independent provider traffic governors, bounded read/financial concurrency, short local queue timeouts, and lightweight request-start pacing. Pressure or rate limiting on one provider cannot consume the other provider's socket pool.
- Read-only provider GET requests may retry once on transient network/HTTP 429/5xx outcomes with a short capped delay. Financial POST requests are executed exactly once and are never automatically retried after timeout, network failure, 429, 5xx, or an uncertain response.
- Provider traffic metrics now track request counts, 429s, server/network failures, queue rejections, read retries, in-flight/max concurrency, and average latency for diagnostics/dashboard integration.
- New `.env` controls allow independent tuning of SYRIA/TSA read concurrency, financial concurrency, queue timeouts, minimum request-start spacing, and maximum read retry delay. Defaults are conservative and based on the live provider stress-test behavior.
- Migration `0014_cashback_v2_and_provider_traffic.sql` is additive and preserves existing financial history while adding V2 cycle metadata and indexes for safe recalculation/freeze checks.

### v0.5.17 Per-user serialization + safe user management
- Added per-user update serialization at the aiogram update layer. Updates from the same Telegram user are processed in order, while different users remain fully concurrent. Lock entries are reference-counted and removed immediately after the last running/waiting update, avoiding an unbounded lock cache.
- Added a global user-access middleware. Locally blocked users are stopped before business routers, while super admins bypass the block. The middleware never creates unknown users, so `/start <referrer>` remains the first writer for brand-new users and first-touch referral ownership is preserved.
- Existing-user profile/activity refresh is throttled in memory and updates `last_active_at` at most once per minute per active process, reducing unnecessary PostgreSQL writes.
- Added **Admin → User Management** with search by Telegram ID, Telegram username/name, iChancy username, or Player ID; forwarded-message Telegram ID extraction; highest-balance ranking; 24-hour activity ranking; and paged blocked-user listing.
- Added a consolidated user card with bot-wallet available/held balances, join/last-active/block status, successful bot deposit/withdraw totals, active iChancy account + last locally recorded player balance, iChancy transfer totals, referral count, and referral income.
- Admin balance add/subtract actions never write wallet balances directly. They exclusively use the existing `WalletService` + immutable wallet ledger with an idempotency key tied to the admin Telegram message and the admin actor stored in the wallet operation.
- After a successful admin wallet mutation, FSM state is cleared before supplementary audit/Telegram notifications. A later non-financial failure can therefore never invite an automatic second credit/debit.
- Added read-only paginated user histories for bot deposits, bot withdrawals, iChancy jobs, direct referrals, and admin user actions. History views execute SELECTs only and never call a payment/iChancy provider.
- Added a read-only 24-hour admin overview covering total/active/blocked users, user wallet available/held totals, successful bot deposits/withdrawals, unresolved finance requests, and successful iChancy flow totals.
- Live iChancy balance lookup from a user card is an explicit separate button with a bounded timeout; simply opening cards/reports never adds load to the cashier API.
- Migration `0015_user_management_and_activity.sql` adds activity/block metadata and an immutable `admin_user_actions` audit table. It creates no alternate wallet balance column and does not change existing financial tables or settlement logic.

## وضع الصيانة المركزي — v0.5.18

وضع الصيانة لم يعد فحصًا داخل `/start` أو القوائم الجديدة فقط، بل أصبح **Update Outer Middleware** مركزيًا قبل جميع Routers وFSM:

- عند التفعيل، أي مستخدم عادي يُمنع من الوصول إلى أي Handler في البوت.
- أزرار Inline القديمة المحفوظة في رسائل سابقة تُحجب أيضًا؛ الـcallback يُجاب مباشرة بتنبيه صيانة ولا يصل إلى منطق الشحن/السحب/iChancy.
- الرسائل والأوامر ومدخلات FSM القديمة تُحجب أثناء الصيانة كذلك.
- الأدمن مستثنى حتى يبقى قادرًا على إدارة البوت وإيقاف الصيانة.
- حالة الصيانة ورسالتها محفوظتان في Runtime Settings داخل PostgreSQL، لذلك تستمران بعد Restart.
- يمكن تعديل رسالة الصيانة من لوحة الإدارة.
- الصيانة تمنع **بدء تفاعلات مالية جديدة** لكنها لا توقف عمال reconciliation/outbox للعمليات التي بدأت قبل التفعيل، لأن إيقافها قد يترك نجاحًا خارجيًا دون تسوية محلية.

ملاحظة: أزرار Telegram التي تفتح URL/WebApp مباشرة لا ترسل callback للبوت عند مجرد الفتح، لذلك لا يمكن للـMiddleware اعتراض فتح رابط خارجي قديم. جميع أزرار الشحن والسحب والتحويل المالية في البوت تمر عبر callbacks/messages وتُحجب مركزيًا.

### v0.5.19 User experience batch 1
- Added new-user-only terms acceptance. Existing users are not retroactively forced through the gate; newly-created users must accept before normal routers/FSM can continue. The gate is enforced centrally and preserves required-channel/referral verification and pending wheel deep links.
- Added a user-visible successful-operation history for bot deposits, bot withdrawals, and iChancy jobs. Views are paginated, read-only, and do not call external providers.
- Added runtime-editable support contacts for Telegram, WhatsApp, Facebook, and iChancy. Each contact can be edited and independently shown/hidden from Admin → Communication Settings.
- Added safe recovery of the user's current withdrawal while it is still strictly `pending`. Cancellation locks the request row, releases the existing wallet hold through `WalletService`, releases cashback spend tracking, and atomically marks the request cancelled. Once provider/admin execution has begun, automatic recovery is refused.
- Added admin-only iChancy account unlink/transfer workflows. Unlink refuses uncertain/non-zero remote balances and unresolved iChancy jobs; transfer additionally refuses unresolved jobs, blocked/occupied targets, and accounts with activity inside open cashback/referral cycles. Historical financial rows are preserved.
- Removed the user-facing callback-speed test button from the main menu; diagnostics remain internal.
- Migration `0016_user_experience_batch1.sql` is additive and preserves existing users/financial history while adding terms state and safe account-unlink metadata.


### v0.5.20 UI customization + complete current-feature reports
- Added **Admin → Texts & Buttons** without changing business callbacks. Main-menu button labels, Telegram Custom Emoji IDs, visibility, and row order are stored in runtime settings and apply immediately without restart. Deposit-method, withdrawal-method, iChancy, and support button labels/Custom Emoji are also runtime-editable; payment-method enable/disable remains governed only by its original finance settings.
- Main-menu visibility is presentation-only: hiding a button never deletes data or rewrites its callback. Maintenance, blocking, and terms enforcement remain centralized and cannot be bypassed by an old button.
- Added a protected message-template catalog. Every registered template is wired to a real output path; unknown/missing placeholders are rejected, each required placeholder must remain exactly once, invalid stored templates safely fall back to defaults, and previews use non-financial sample values.
- Added Julia-style **copy-the-real-message search**: an admin can paste a message exactly as a user saw it even when it contains a real amount, balance, or transaction/request id. Dynamic placeholders are treated as wildcards, only static visible text fragments are offered for editing, cross-placeholder Telegram HTML is preserved, and a preview/confirmation step is required before saving.
- Wired runtime-editable text to the home, terms gate, support, history, withdrawal-refund success, wheel result, iChancy create/success messages, and critical deposit verification states (verifying, already-processing, provider unavailable, transaction not found, and mismatch). Provider failure wording remains presentation-only; retry/idempotency behavior is unchanged.
- Added read-only **financial reports** using exact `Asia/Damascus` calendar boundaries for today, yesterday, current week, month, year, and a validated custom date range. Reports separate real deposit principal from deposit bonus, successful net withdrawals from fees, internal credits, iChancy flow, user activity, current wallet balances, unresolved operations, and top depositors.
- Added read-only detail screens for deposits, withdrawals, rewards, iChancy, wallet/unresolved state, users, and top depositors. Reports never call API SYRIA, TSA, Binance, or iChancy providers and never mutate financial tables.
- `0017_ui_reports_batch2.sql` adds reporting indexes only. UI customization reuses the existing runtime-settings table and does not rewrite historical financial data.
- The reporting catalog reflects features that exist in Tecno v0.5.20. Future gift-code/loyalty/contest/roulette modules must register their own reward sources when those later batches are added; no synthetic zero rows are presented as if those modules already existed.

## v0.5.21 — Durable broadcast batch 3

- Admin broadcast flow with draft, preview and explicit confirmation before any send.
- PostgreSQL-backed recipient snapshot and per-recipient delivery state; no file/RAM queue is the source of truth.
- Background broadcast worker survives restarts. A delivery interrupted after dispatch is marked `unknown` and is **not** blindly resent, avoiding duplicate Telegram messages.
- Live user blocking is re-checked before dispatch; users blocked after confirmation are skipped safely.
- Controlled rate/concurrency (`BROADCAST_PER_MINUTE`, `BROADCAST_CONCURRENCY`) with Telegram `RetryAfter` handling.
- Campaign history, live counters and explicit stop confirmation. Stop affects only recipients not yet dispatched.
- Successful Telegram `message_id` values are recorded per recipient, allowing a later best-effort “delete from everyone” job with durable deletion progress and retry of failed deletions.
- Broadcast tables are isolated from Wallet/Deposits/Withdrawals/iChancy financial state.

## v0.5.22 — Admin protection + backup batch 4

- Added persistent **assistant-admin management**. Deployment owners still come only from `SUPER_ADMINS`; an owner can add/remove assistants from the bot, and the effective admin set is refreshed immediately without restart. Removing an assistant revokes access even for stale admin buttons because maintenance/access guards read the live admin set on every update.
- Sensitive controls remain owner-only: assistant management, database backup/restore, full reserved-number clearing, and immutable security/financial audit screens. Existing normal admin workflows remain available to assistants, matching the reference assistant behavior.
- Added an immutable `admin_security_events` audit trail for assistant changes, backup configuration/restore scheduling, and reserved transaction administration. Manual balance audit reads the canonical immutable Wallet Ledger instead of a secondary mutable balance table.
- Exposed management for the existing `reserved_transaction_numbers` deposit-core table: add by provider scope, paged listing, cross-scope search, single deletion, and owner-confirmed clear-all. This UI does not delete provider claims or historical deposits; deposit anti-reuse checks continue to read the same core table.
- Added PostgreSQL custom-format backups for the `bot_core` schema. Manual backups can be sent to the configured backup channel (or the requesting owner when no channel is configured); optional daily backups run around 03:00 Asia/Damascus. Backup history is immutable and SHA-256 is shown for generated archives.
- Restore is intentionally safer than an in-process `pg_restore`: only `.dump` files that pass `pg_restore --list` and contain `bot_core` are accepted. On confirmation the bot enables maintenance plus a short-lived **restore lock that blocks every new update including admin updates**, waits for in-flight handlers to quiesce, refuses restore while financial work is unresolved, creates a new pre-restore safety backup, persists a restore marker, then exits under the systemd `Restart=always` policy. `pg_restore --single-transaction` runs at the next clean startup **before** asyncpg, polling, or any financial worker starts. After success/failure, the restore lock is released but maintenance is forced on so the owner can review state before reopening the bot.
- Automatic and manual backup/restore require the server package that provides `pg_dump` and `pg_restore` (normally `postgresql-client`). If it is absent the bot reports the missing binary and does not attempt a partial backup/restore.
- Migration `0019_admin_ops_batch4.sql` adds assistant/admin-audit/backup-history metadata and report indexes only; it does not create another wallet balance path or alter settlement equations.

## v0.5.23 — Gifts, balance gifting & loyalty batch 5

- Added durable **gift codes** with public single-use, multi-use, private per-user, atomic batch generation, fake-code batches, immediate disable, redemption history, cooldown, and admin-event notifications. Code redemption is row-locked and unique per user; fake codes never touch Wallet.
- Added user-to-user **balance gifting** with an admin enable/disable switch, explicit confirmation, idempotent request tokens, stable advisory-lock ordering, immutable transfer history, sender/recipient notifications, and no direct wallet writes. Transfers use the existing WalletService + immutable Wallet Ledger in one PostgreSQL transaction.
- Added a non-transferable promotional-credit model for new gift-code credits, loyalty wallet rewards, wheel/referral rewards, instant welcome bonus, and the bonus-only portion of a first-deposit welcome reward. These funds remain spendable/withdrawable/iChancy-usable but cannot be gifted to another user. Legacy balances are intentionally not retroactively reclassified, matching the reference behavior.
- Protected promotional credit follows the wallet lifecycle: ordinary debit/hold consumes it first, hold release restores the protected portion, capture keeps it spent, and a gift debit cannot consume it. This preserves correct gifting limits across pending withdrawals and cancellations.
- Added **loyalty points** with runtime enable/disable, configurable SYP-per-point and minimum eligible deposit, per-deposit settings snapshots, immutable point events, paginated user/admin history, search, holder list, point set/add/sub with preview + stale-balance recheck, and reset-all confirmation.
- Loyalty points are earned only from the successful deposit's real/base amount, never from deposit bonuses. Loyalty settlement is an isolated side effect: a loyalty failure cannot roll back a successful deposit and is instead stored for reconciliation by a dedicated worker.
- Added fixed loyalty rewards: immediate wallet-balance rewards (tagged non-transferable) and manual/physical rewards that remain pending for admin approve/reject. Rejecting a pending manual reward atomically refunds the spent points.
- Added a global shared/exclusive PostgreSQL advisory lock for loyalty-wide reset. Normal point mutations take the shared lock; reset-all takes the exclusive lock and rechecks pending deposit awards inside the same transaction, eliminating reset-vs-deposit/claim races.
- Integrated gift-code wallet credits and loyalty wallet rewards into the read-only financial reports as separate internal-credit sources. User-to-user gifting is intentionally excluded from system cash-flow/internal-credit totals because it is a zero-sum internal transfer.
- Added runtime-editable user message templates for the core gifting, gift-code and loyalty flows so Batch 5 participates in the existing Texts & Buttons customization layer.
- Migration `0020_gifts_loyalty_batch5.sql` adds gift-transfer/code/loyalty tables and immutable history triggers. Existing Wallet/Deposits/Withdrawals/iChancy/Cashback equations are not replaced.

## v0.5.24 — Competitions, matches & advanced roulette batch 6

- Added three isolated event engines instead of mixing contest rules together: **template contests**, read-only **today's football matches**, and **advanced roulette/draws**.
- Contest templates match the reference behavior: match prediction (score/corners/cards), transaction-suffix cash luck, top real-deposit ranking, and deposit raffle (`user_once` / `per_deposit`). Match predictions are confirmed once and cannot be edited afterward.
- Contest/roulette prizes are deliberately not credited as ordinary cash. A balance prize becomes a **24-hour iChancy promotional reward**; a deposit-bonus prize is a **single-use 24-hour bonus on the next successful real bot deposit** and has priority over normal/welcome/special/tier bonuses.
- iChancy deposit jobs now persist the exact `wallet_amount_syp + promo_amount_syp` split and at most one promo reward. A definite external failure releases both the wallet hold and the promo reservation; an uncertain result keeps both reserved for reconciliation; successful settlement consumes each source once. Cashback principal uses only the real wallet portion, never promo value.
- Successful real deposits snapshot contest/roulette side effects independently from the financial deposit. A contest bookkeeping failure cannot roll back a successful deposit; the side effect is reconciled by the competition worker. Event closing waits for relevant in-window pending/failed effects so a deposit that succeeded near the deadline cannot lose its chance because of a delayed side effect.
- Advanced roulette supports free or per-successful-deposit participation, minimum deposit per chance (small deposits are never accumulated), optional chance/user and participant caps, per-position prizes, automatic/manual draw, manual completion when automatic candidates are insufficient, custom prizes with separate fulfillment state, event-specific photo/GIF/video, manual early close, publish retry, and one unique winner per roulette.
- Stale admin callbacks cannot draw a contest/roulette before it is ready. Manual early roulette close truncates the participation window and refuses to close while an already-successful qualifying deposit is still awaiting chance reconciliation.
- Added user ranking for top-depositor contests, per-contest and global winner history, and admin active/waiting/ended history screens. Contest permanent deletion requires confirmation and is refused once any award exists; deleting an unpaid contest never changes wallets or financial history. Roulette cancellation also requires confirmation and is refused after awards begin.
- Channel publication uses the configured required channel, supports event media and deep links, is retried durably when the initial Telegram publish fails, and publishes the final result separately. Deep-link intent survives required-channel and terms gates.
- Added read-only **Matches Today** via API-Football using `FOOTBALL_API_KEY` from `.env` only; no provider secret is hardcoded. Fixtures are fetched once per refresh window for the Damascus-local date/timezone, cached, then categorized locally into La Liga, EPL, UCL, UEL, Serie A, Bundesliga, Ligue 1, and mixed/other matches. A stale cache is used when the provider is temporarily unavailable.
- Existing reports now show contest/roulette promo awards as informational non-cash promotional commitments and split successful iChancy deposits into real wallet vs promo portions. These promo values are intentionally excluded from `total_internal_credits` to avoid double counting; consumed contest/roulette deposit bonuses remain part of the existing deposit-bonus total and are also shown by provenance.
- Migration `0021_competitions_roulette_matches.sql` adds the event, award, promotional-reward, iChancy split, and durable deposit-effect contracts. The Wallet write boundary remains unchanged; competition code does not write `wallet_accounts` or Wallet Ledger directly.
