from __future__ import annotations

import compileall
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

REQUIRED_FILES = [
    ROOT / "migrations/0001_core.sql",
    ROOT / "migrations/0002_wallet_core.sql",
    ROOT / "migrations/0003_deposit_core.sql",
    ROOT / "migrations/0004_runtime_outbox_ichancy.sql",
    ROOT / "migrations/0005_withdraw_core.sql",
    ROOT / "migrations/0006_ichancy_reconciliation.sql",
    ROOT / "migrations/0007_split_bot_operation_channels.sql",
    ROOT / "migrations/0008_shamcash_address_cleanup.sql",
    ROOT / "migrations/0009_withdraw_channel_manual_transfers.sql",
    ROOT / "migrations/0010_retarget_legacy_bot_deposit_outbox.sql",
    ROOT / "migrations/0011_bonus_commission_rules.sql",
    ROOT / "migrations/0012_cashback_referrals_wheel.sql",
    ROOT / "migrations/0013_referral_cashback_parity.sql",
    ROOT / "migrations/0014_cashback_v2_and_provider_traffic.sql",
    ROOT / "migrations/0015_user_management_and_activity.sql",
    ROOT / "migrations/0016_user_experience_batch1.sql",
    ROOT / "migrations/0017_ui_reports_batch2.sql",
    ROOT / "migrations/0018_broadcast_durable.sql",
    ROOT / "migrations/0019_admin_ops_batch4.sql",
    ROOT / "migrations/0020_gifts_loyalty_batch5.sql",
    ROOT / "migrations/0021_competitions_roulette_matches.sql",
    ROOT / "migrations/0022_notifications_withdraw_matches_polish.sql",
    ROOT / "app/services/backups.py",
    ROOT / "app/services/admin_access.py",
    ROOT / "app/routers/admin_ops.py",
    ROOT / "app/services/gifts_loyalty.py",
    ROOT / "app/repositories/gifts_loyalty.py",
    ROOT / "app/routers/gifts_loyalty.py",
    ROOT / "app/routers/admin_gifts_loyalty.py",
    ROOT / "scripts/admin_ops_audit.py",
    ROOT / "app/middlewares/maintenance.py",
    ROOT / "app/services/ichancy_jobs.py",
    ROOT / "app/services/ichancy_replacements.py",
    ROOT / "app/services/withdrawals.py",
    ROOT / "app/services/manual_transfers.py",
    ROOT / "app/repositories/manual_transfers.py",
    ROOT / "app/services/outbox.py",
    ROOT / "app/services/rewards.py",
    ROOT / "app/routers/rewards.py",
    ROOT / "app/routers/admin_rewards.py",
]

FORBIDDEN_BRANDS = re.compile(r"\b(?:julia|professor|naya)\b", re.I)
CUSTOM_EMOJI_IDS = {
    "loading": "5386367538735104399",
    "processing": "5884447890960552542",
    "success": "5796205953913196373",
}


def iter_source_files():
    for base in (ROOT / "app", ROOT / "scripts", ROOT / "migrations"):
        for path in base.rglob("*"):
            if path.is_file() and path.suffix in {".py", ".sql"}:
                yield path


def main() -> int:
    failures: list[str] = []

    for path in REQUIRED_FILES:
        if not path.exists():
            failures.append(f"missing required file: {path.relative_to(ROOT)}")

    if not compileall.compile_dir(ROOT / "app", quiet=1):
        failures.append("Python compile failed under app/")
    if not compileall.compile_dir(ROOT / "scripts", quiet=1):
        failures.append("Python compile failed under scripts/")

    for path in iter_source_files():
        if path.resolve() == Path(__file__).resolve():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if FORBIDDEN_BRANDS.search(text):
            failures.append(f"hardcoded bot brand found: {path.relative_to(ROOT)}")

    emoji_text = (ROOT / "app/core/emojis.py").read_text(encoding="utf-8")
    for label, emoji_id in CUSTOM_EMOJI_IDS.items():
        if emoji_id not in emoji_text:
            failures.append(f"missing custom emoji id ({label}): {emoji_id}")

    # Financial wallet writes must stay behind the WalletRepository boundary.
    direct_wallet_write = re.compile(
        r"(?:UPDATE\s+bot_core\.wallet_accounts|INSERT\s+INTO\s+bot_core\.wallet_(?:accounts|ledger|operations|holds))",
        re.I,
    )
    for path in (ROOT / "app").rglob("*.py"):
        if path.name == "wallet.py" and path.parent.name == "repositories":
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if direct_wallet_write.search(text):
            failures.append(f"direct wallet DB write outside WalletRepository: {path.relative_to(ROOT)}")

    m4 = (ROOT / "migrations/0004_runtime_outbox_ichancy.sql").read_text(encoding="utf-8")
    for required in (
        "notification_outbox",
        "ichancy_username_seq",
        "ichancy_jobs",
        "ichancy_cashier_replacements",
        "ichancy_retirement_records",
        "ux_ichancy_one_active_job_per_user",
    ):
        if required not in m4:
            failures.append(f"0004 migration missing contract: {required}")

    m5 = (ROOT / "migrations/0005_withdraw_core.sql").read_text(encoding="utf-8")
    for required in (
        "provider_success",
        "needs_review",
        "ux_withdraw_one_active_per_user",
        "withdraw_identity_guard",
    ):
        if required not in m5:
            failures.append(f"0005 migration missing contract: {required}")


    m6 = (ROOT / "migrations/0006_ichancy_reconciliation.sql").read_text(encoding="utf-8")
    for required in (
        "provider_reference",
        "financial_post_started_at",
        "reconcile_attempt_count",
        "reconcile_next_at",
        "result_message_id",
        "ux_ichancy_job_provider_reference",
    ):
        if required not in m6:
            failures.append(f"0006 migration missing contract: {required}")


    m12 = (ROOT / "migrations/0012_cashback_referrals_wheel.sql").read_text(encoding="utf-8")
    for required in (
        "cashback_wallet_principal",
        "cashback_cycles",
        "cashback_principal_holds",
        "referral_cycles",
        "referral_loss_snapshots",
        "referral_fixed_entitlements",
        "wheel_claims",
        "wheel_free_entitlements",
    ):
        if required not in m12:
            failures.append(f"0012 migration missing contract: {required}")


    m13 = (ROOT / "migrations/0013_referral_cashback_parity.sql").read_text(encoding="utf-8")
    for required in (
        "users_referral_status_allowed",
        "referral_fixed_entitlements",
        "attempts",
        "last_error",
        "cashback_cycle_users_status_check",
        "eligible",
        "banned",
        "error_code",
        "failed_count",
        "referral_loss_snapshots",
        "error_message",
    ):
        if required not in m13:
            failures.append(f"0013 migration missing contract: {required}")


    m16 = (ROOT / "migrations/0016_user_experience_batch1.sql").read_text(encoding="utf-8")
    for required in (
        "terms_required",
        "terms_accepted_at",
        "pending_start_action",
        "unlinked_at",
        "unlinked_by",
        "unlink_reason",
        "status IN ('active','retiring','retired','unlinked')",
    ):
        if required not in m16:
            failures.append(f"0016 migration missing contract: {required}")

    maintenance = (ROOT / "app/middlewares/maintenance.py").read_text(encoding="utf-8")
    main_text = (ROOT / "app/main.py").read_text(encoding="utf-8")
    runtime_text = (ROOT / "app/services/runtime_settings.py").read_text(encoding="utf-8")
    for required in (
        "MaintenanceModeMiddleware",
        'runtime.get_bool("maintenance.enabled", False)',
        "await callback.answer(alert_text, show_alert=True)",
        "return None",
    ):
        if required not in maintenance:
            failures.append(f"maintenance middleware missing contract: {required}")
    if "dp.update.outer_middleware(MaintenanceModeMiddleware" not in main_text:
        failures.append("maintenance middleware is not wired globally")
    if '"maintenance.enabled": False' not in runtime_text:
        failures.append("maintenance runtime default missing")

    m19 = (ROOT / "migrations/0019_admin_ops_batch4.sql").read_text(encoding="utf-8")
    for required in (
        "CREATE TABLE IF NOT EXISTS bot_core.admin_assistants",
        "CREATE TABLE IF NOT EXISTS bot_core.admin_security_events",
        "CREATE TABLE IF NOT EXISTS bot_core.backup_history",
        "admin_security_events_immutable",
        "backup_history_immutable",
    ):
        if required not in m19:
            failures.append(f"0019 migration missing contract: {required}")

    m20 = (ROOT / "migrations/0020_gifts_loyalty_batch5.sql").read_text(encoding="utf-8")
    for required in (
        "CREATE TABLE IF NOT EXISTS bot_core.gift_transfers",
        "CREATE TABLE IF NOT EXISTS bot_core.gift_codes",
        "CREATE TABLE IF NOT EXISTS bot_core.gift_code_redemptions",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_accounts",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_deposit_awards",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_events",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_rewards",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_reward_claims",
        "gift_transfers_immutable",
        "gift_code_redemptions_immutable",
        "loyalty_events_immutable",
        "is_fake BOOLEAN",
    ):
        if required not in m20:
            failures.append(f"0020 migration missing contract: {required}")

    m21 = (ROOT / "migrations/0021_competitions_roulette_matches.sql").read_text(encoding="utf-8")
    for required in (
        "CREATE TABLE IF NOT EXISTS bot_core.contests",
        "CREATE TABLE IF NOT EXISTS bot_core.roulettes",
        "CREATE TABLE IF NOT EXISTS bot_core.promo_rewards",
        "CREATE TABLE IF NOT EXISTS bot_core.contest_bonus_rewards",
        "CREATE TABLE IF NOT EXISTS bot_core.competition_deposit_effects",
        "CREATE TABLE IF NOT EXISTS bot_core.roulette_bonus_rewards",
        "wallet_amount_syp", "promo_amount_syp",
    ):
        if required not in m21:
            failures.append(f"0021 migration missing contract: {required}")

    m18 = (ROOT / "migrations/0018_broadcast_durable.sql").read_text(encoding="utf-8")
    for required in (
        "CREATE TABLE IF NOT EXISTS bot_core.broadcast_campaigns",
        "CREATE TABLE IF NOT EXISTS bot_core.broadcast_recipients",
        "send_status IN ('pending','sending','sent','blocked','failed','unknown')",
        "delete_status IN ('none','pending','deleting','deleted','failed')",
    ):
        if required not in m18:
            failures.append(f"0018 migration missing contract: {required}")

    if failures:
        print("PROJECT PREFLIGHT: FAILED")
        for failure in failures:
            print(" -", failure)
        return 2

    print("PROJECT PREFLIGHT: OK")
    print(" - source compiles")
    print(" - required migrations/files exist")
    print(" - custom emoji ids present")
    print(" - no forbidden bot brands in source/migrations")
    print(" - wallet DB writes remain isolated")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
