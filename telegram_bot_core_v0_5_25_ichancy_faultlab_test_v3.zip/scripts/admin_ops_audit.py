from __future__ import annotations

import asyncio
from pathlib import Path

from app.config import get_settings
from app.core.db import Database

PROJECT_ROOT = Path(__file__).resolve().parent.parent


async def run() -> int:
    settings = get_settings()
    db = Database(settings.database_url, min_size=1, max_size=2, command_timeout=settings.pg_command_timeout)
    await db.connect()
    try:
        await db.apply_migrations(PROJECT_ROOT / "migrations")
        pool = db.require_pool()
        async with pool.acquire() as conn:
            orphan_assistants = await conn.fetch(
                """
                SELECT a.telegram_id
                FROM bot_core.admin_assistants a
                LEFT JOIN bot_core.users u ON u.telegram_id=a.telegram_id
                WHERE u.telegram_id IS NULL
                """
            )
            owner_assistants = await conn.fetch(
                "SELECT telegram_id FROM bot_core.admin_assistants WHERE telegram_id=ANY($1::bigint[])",
                list(settings.owner_admin_ids),
            ) if settings.owner_admin_ids else []
            reserved_claim_conflicts = await conn.fetch(
                """
                SELECT r.provider_scope,r.provider_tx,c.deposit_id
                FROM bot_core.reserved_transaction_numbers r
                JOIN bot_core.deposit_tx_claims c
                  ON c.provider_scope=r.provider_scope AND c.provider_tx=r.provider_tx
                ORDER BY r.created_at DESC
                """
            )
            pending_restore = (PROJECT_ROOT / ".runtime" / "pending_restore.json").exists()
            restore_result = (PROJECT_ROOT / ".runtime" / "restore_result.json").exists()
            summary = await conn.fetchrow(
                """
                SELECT
                  (SELECT COUNT(*) FROM bot_core.admin_assistants)::bigint AS assistants,
                  (SELECT COUNT(*) FROM bot_core.reserved_transaction_numbers)::bigint AS reserved_numbers,
                  (SELECT COUNT(*) FROM bot_core.admin_security_events)::bigint AS security_events,
                  (SELECT COUNT(*) FROM bot_core.backup_history)::bigint AS backup_events
                """
            )

        failed = False
        for row in orphan_assistants:
            failed = True
            print("orphan assistant:", dict(row))
        for row in owner_assistants:
            failed = True
            print("owner duplicated as assistant:", dict(row))
        # This is not a financial corruption (the claim remains authoritative), but
        # it should not normally occur because the admin UI refuses to reserve a
        # transaction that is already claimed.
        for row in reserved_claim_conflicts:
            failed = True
            print("reserved/claimed conflict:", dict(row))
        if pending_restore:
            print("warning: pending restore marker exists")
        if restore_result:
            print("warning: unconsumed restore result marker exists")

        print("summary:", dict(summary or {}))
        if failed:
            print("ADMIN OPS AUDIT: FAILED")
            return 2
        print("ADMIN OPS AUDIT: OK")
        return 0
    finally:
        await db.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
