from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from app.providers.traffic import ProviderQueueBusy, ProviderTrafficGovernor

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.asyncio
async def test_read_governor_caps_parallelism_without_serializing_every_read():
    governor = ProviderTrafficGovernor(
        "test",
        read_concurrency=2,
        financial_concurrency=1,
        queue_timeout_seconds=1,
        min_start_interval_seconds=0,
    )
    active = 0
    max_active = 0

    async def worker():
        nonlocal active, max_active
        async with governor.read_slot():
            active += 1
            max_active = max(max_active, active)
            await asyncio.sleep(0.02)
            active -= 1

    await asyncio.gather(*(worker() for _ in range(8)))
    snap = governor.snapshot()
    assert max_active == 2
    assert snap.max_in_flight_reads == 2
    assert snap.reads_started == 8


@pytest.mark.asyncio
async def test_governor_fails_fast_when_local_read_queue_is_stuck():
    governor = ProviderTrafficGovernor(
        "test",
        read_concurrency=1,
        queue_timeout_seconds=0.02,
        min_start_interval_seconds=0,
    )
    entered = asyncio.Event()
    release = asyncio.Event()

    async def holder():
        async with governor.read_slot():
            entered.set()
            await release.wait()

    task = asyncio.create_task(holder())
    await entered.wait()
    with pytest.raises(ProviderQueueBusy):
        async with governor.read_slot():
            pass
    release.set()
    await task
    assert governor.snapshot().queue_rejected == 1


def test_retry_after_is_capped():
    governor = ProviderTrafficGovernor("test", max_retry_after_seconds=0.75)
    assert governor.retry_delay("99") == 0.75
    assert governor.retry_delay("0.2") == 0.2


def test_syria_and_tsa_use_isolated_http_sessions():
    main = (ROOT / "app/main.py").read_text(encoding="utf-8")
    assert "api_syria_session = aiohttp.ClientSession" in main
    assert "tsa_session = aiohttp.ClientSession" in main
    assert "ApiSyriaClient(\n        api_syria_session" in main
    assert "TsaApiClient(\n        tsa_session" in main


def test_read_get_may_retry_but_financial_posts_never_loop():
    syria = (ROOT / "app/providers/api_syria.py").read_text(encoding="utf-8")
    tsa = (ROOT / "app/providers/tsa.py").read_text(encoding="utf-8")

    read_start = syria.index("async def _read_json")
    post_start = syria.index("async def _financial_post", read_start)
    read_body = syria[read_start:post_start]
    post_body = syria[post_start:syria.index("@staticmethod\n    def _decimal_text", post_start)]
    tsa_post = tsa[tsa.index("async def _financial_post_tsa"):]

    assert "for attempt in range(2)" in read_body
    assert "for attempt" not in post_body
    assert "while True" not in post_body
    assert "for attempt" not in tsa_post
    assert "while True" not in tsa_post
