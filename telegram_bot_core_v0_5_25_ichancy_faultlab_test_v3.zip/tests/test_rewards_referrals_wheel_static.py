from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_rewards_migration_contains_all_core_ledgers():
    s = text("migrations/0012_cashback_referrals_wheel.sql")
    for table in (
        "cashback_wallet_principal",
        "cashback_wallet_holds",
        "ichancy_cashback_allocations",
        "cashback_cycles",
        "cashback_cycle_users",
        "cashback_principal_settlements",
        "cashback_principal_holds",
        "referral_cycles",
        "referral_loss_snapshots",
        "referral_earnings",
        "referral_cycle_payouts",
        "referral_fixed_entitlements",
        "referral_fixed_rewards",
        "wheel_claims",
        "wheel_free_entitlements",
    ):
        assert f"bot_core.{table}" in s
    assert "referrer_telegram_id" in s
    assert "referral_confirmed_at" in s


def test_start_uses_atomic_pending_first_touch_and_free_wheel():
    start = text("app/routers/start.py")
    users = text("app/repositories/users.py")
    service = text("app/services/rewards.py")
    assert "sync_profile_with_created" in start
    assert "referrer_id=referrer_id" in start
    assert "if created:" in start
    assert "grant_new_user_free_entitlement" in start
    assert "referral_status='pending'" in service
    assert "CASE WHEN candidate.telegram_id IS NULL THEN 'none' ELSE 'pending' END" in users
    assert "referrer_telegram_id" in users
    assert "start:check" in start
    assert "confirm_pending(user_id)" in start

def test_wheel_client_is_animation_only_and_server_awards_authoritatively():
    start = text("app/routers/start.py")
    user = text("app/routers/rewards.py")
    service = text("app/services/rewards.py")
    assert 'arg.startswith("claim_wheel")' in start
    assert "wheel_service.claim(user_id)" in start
    assert "super-nasturtium-2ead66.netlify.app/?prize=" in user
    assert "pg_advisory_xact_lock" in service
    assert "wheel_claims" in service
    assert 'idempotency_key=f"wheel:' in service
    assert 'idempotency_key=f"wheel-free:' in service
    assert '"cashback_eligible": False' in service


def test_wheel_free_entitlement_is_new_user_only_and_not_backfilled():
    start = text("app/routers/start.py")
    service = text("app/services/rewards.py")
    assert "if created:" in start
    assert "grant_new_user_free_entitlement" in start
    assert "if not enabled:" in service
    assert "wheel_free_entitlements" in service


def test_deposits_feed_only_real_base_principal_and_referral_success_hook():
    s = text("app/services/deposits.py")
    assert "add_real_deposit(conn, done.telegram_id, done.base_credit_syp)" in s
    assert "on_successful_deposit(conn, done.telegram_id, done.id)" in s
    assert s.count("add_real_deposit(conn, done.telegram_id, done.base_credit_syp)") >= 2


def test_ichancy_cashback_allocation_has_reserve_release_finalize_paths():
    service = text("app/services/rewards.py")
    jobs = text("app/services/ichancy_jobs.py")
    for marker in (
        "create_ichancy_deposit_allocation",
        "release_ichancy_deposit",
        "finalize_ichancy_deposit",
        "finalize_ichancy_withdraw",
    ):
        assert marker in service
        assert marker in jobs
    assert "eligible_amount_syp" in service


def test_cashback_source_reservation_excludes_older_wallet_holds():
    s = text("app/services/rewards.py")
    assert "unreserved_before_this_hold = max(0, available_after_hold + amount)" in s
    assert "eligible = min(eligible, unreserved_before_this_hold)" in s
    assert "ineligible = max(0, unreserved_before_this_hold - eligible)" in s


def test_bot_withdraw_restores_or_consumes_cashback_principal_reservation():
    s = text("app/services/withdrawals.py")
    assert 'source_type="bot_withdraw"' in s
    assert "reserve_wallet_spend" in s
    assert s.count("release_wallet_spend") >= 2
    assert "consume_wallet_spend" in s


def test_cashback_rewards_are_ineligible_and_failed_snapshots_block_payout():
    s = text("app/services/rewards.py")
    assert "cashback_eligible':False" in s or '"cashback_eligible": False' in s
    assert "CASHBACK_HAS_FAILED_SNAPSHOTS" in s
    assert "cashback_principal_holds" in s
    assert "retry_failed" in s
    assert "banned_before_payout" in s
    assert "المستخدم محظور وقت التوزيع" in s


def test_cashback_cycle_is_contiguous_and_distribution_is_confirmed_by_admin_ui():
    service = text("app/services/rewards.py")
    admin = text("app/routers/admin_rewards.py")
    assert "previous_end" in service
    assert "_cashback_aligned_start(now, days)" in service
    assert "end = _cashback_cycle_end_for(start, days)" in service
    assert "admin:cashback_distribute_confirm:" in admin
    assert "admin:cashback_skip_confirm:" in admin
    assert "admin:cashback_retry_failed:" in admin



def test_cashback_cycle_boundaries_match_damascus_day_and_monday_rules():
    s = text("app/services/rewards.py")
    assert "def _cashback_aligned_start" in s
    assert "def _cashback_cycle_end_for" in s
    assert "local.weekday()" in s
    assert "timedelta(days=7)" in s
    assert "datetime(local.year, local.month, local.day, 0, 0, 0, tzinfo=DAMASCUS)" in s
    assert '"end_local": _fmt_local(cycle["cycle_end"] - timedelta(minutes=1))' in s
    assert 'new_end = _cashback_cycle_end_for(cycle[\"cycle_start\"], days)' in s

def test_referral_first_touch_cannot_overwrite_existing_relation():
    s = text("app/services/rewards.py")
    users = text("app/repositories/users.py")
    assert 'user["referrer_telegram_id"] is not None' in s
    assert 'str(user["referral_status"]) != "none"' in s
    assert "referrer_id) == int(telegram_id)" in s
    assert "referral_status='pending'" in s
    assert "referral_status='confirmed'" in s
    assert "ON CONFLICT (telegram_id) DO NOTHING" in users

def test_referral_network_has_cycle_guard_owner_validation_and_three_levels():
    s = text("app/services/rewards.py")
    assert "max_level = 1 if mode == \"direct\" else 3" in s
    assert "seen = {int(referred_id)}" in s
    assert "if referrer in seen:" in s
    assert 'bool(owner["is_blocked"])' in s
    assert 'bool(owner["is_bot"])' in s
    assert "active_direct_count" in s


def test_referral_signed_result_offsets_profit_and_uses_boundary_adjustment():
    s = text("app/services/rewards.py")
    assert "cash_net = dep - wd" in s
    assert "signed = cash_net if cash_net < 0 else max(0, cash_net - int(snap[\"adjusted_end_balance\"]))" in s
    assert "post_deposits" in s
    assert "post_withdrawals" in s
    assert "aggregated[key] = aggregated.get(key, 0) + int(signed)" in s


def test_referral_cycle_payout_revalidates_user_and_rewards_are_not_cashback_principal():
    s = text("app/services/rewards.py")
    assert "NOT is_blocked AND NOT is_bot" in s
    assert "referral-cycle:" in s
    assert 'metadata={"cycle_id": cycle_id, "cashback_eligible": False, "non_transferable_credit": True}' in s
    assert "skipped_count" in s


def test_referral_fixed_reward_modes_and_notifications_exist():
    s = text("app/services/rewards.py")
    assert '"first_deposit"' in s
    assert '"verify"' in s
    assert "referral_fixed_entitlements" in s
    assert "referral-join:" in s
    assert "referral-fixed-user:" in s


def test_referral_snapshot_retry_stops_on_first_authoritative_failure():
    s = text("app/services/rewards.py")
    assert "failed_telegram_id" in s
    assert "balance_lookup_failed" in s
    assert "remaining_failed" in s
    assert "status='preparing'" in s
    assert "_signed_results_for_windows" in s
    assert "frozen_results" in s


def test_referral_fixed_reward_failure_is_isolated_and_retryable():
    s = text("app/services/rewards.py")
    assert "async with conn.transaction():" in s
    assert "retry_pending_fixed_rewards" in s
    assert "attempts=attempts+1" in s
    assert "last_error" in s
    assert 'idempotency_key=f"referral-fixed:{referred_id}"' in s


def test_referral_chain_does_not_sever_upstream_on_invalid_intermediate_owner():
    s = text("app/services/rewards.py")
    assert "owner_valid = bool(owner" in s
    assert "active_count = await self.active_direct_count" in s
    assert "qualifies = owner_valid" in s
    assert "current = referrer" in s


def test_referral_cashback_parity_migration_is_additive():
    s = text("migrations/0013_referral_cashback_parity.sql")
    for marker in (
        "invalid", "attempts", "last_error", "eligible", "banned",
        "error_code", "error_message", "failed_count", "referral_loss_snapshots",
    ):
        assert marker in s
    assert "UPDATE bot_core.cashback_cycle_users" in s
    assert "SET status='eligible'" in s


def test_user_and_admin_navigation_exposes_all_three_systems():
    kb = text("app/keyboards/common.py")
    routers = text("app/routers/__init__.py")
    assert 'callback_data="ref:home"' in kb
    assert 'callback_data="cashback:home"' in kb
    assert 'callback_data="wheel:open"' in kb
    assert 'callback_data="admin:cashback"' in kb
    assert 'callback_data="admin:referrals"' in kb
    assert 'callback_data="admin:wheel_manage"' in kb
    assert "admin_rewards.router" in routers
    assert "rewards.router" in routers


def test_main_wires_rewards_into_financial_services_and_maintenance():
    s = text("app/main.py")
    for marker in (
        "CashbackPrincipalTracker",
        "CashbackService",
        "ReferralService",
        "WheelService",
        "RewardsMaintenanceService",
        "cashback_tracker=cashback_tracker",
        "referral_service=referral_service",
    ):
        assert marker in s
    assert "rewards_maintenance.run" in s or "reward_maintenance.run" in s


def test_referral_user_copy_matches_reference_explanation():
    s = text("app/routers/rewards.py")
    assert "من صافي الخسارة المؤهلة للأشخاص الذين دعوتهم مباشرة" in s
    assert "بنفس آلية الاسترداد" in s
    assert "المدة المتبقية على توزيع الأرباح" in s
    assert "تستوفي شروط التأكيد المحددة" in s
    assert "📲 <b>سيريتل كاش</b>" in s


def test_referral_admin_due_has_read_only_beneficiary_audit():
    admin = text("app/routers/admin_rewards.py")
    service = text("app/services/rewards.py")
    assert "admin:ref_due_detail:" in admin
    assert "تفاصيل إحالات المستحق" in admin
    assert "cycle_referrer_activity" in service
    assert "frozen referral snapshots" in service
    # Opening the audit screen must not invoke a live balance read or rewrite accounting.
    method = service.split("async def cycle_referrer_activity", 1)[1].split("class CashbackService", 1)[0]
    assert "_balance_for_account" not in method
    assert "_signed_results_for_windows" not in method
    assert "UPDATE bot_core.referral" not in method
    assert "INSERT INTO bot_core.referral" not in method


def test_referral_profitable_snapshot_still_offsets_network_after_retry():
    s = text("app/services/rewards.py")
    assert 'snapshot_status = "ready" if int(base_signed) > 0 else "not_eligible"' in s
    assert 'if frozen and str(frozen["status"]) in {"ready", "not_eligible"}' in s
    frozen_block = s.split('if frozen and str(frozen["status"]) in {"ready", "not_eligible"}', 1)[1].split("continue", 1)[0]
    assert 'merge_levels(frozen["details"])' in frozen_block


def test_cashback_v2_failed_snapshot_quarantines_all_cycle_deposit_accounts():
    s = text("app/services/rewards.py")
    cashback = s.split("class CashbackService:", 1)[1]
    store = cashback.split("async def _store_v2_user_result", 1)[1].split("async def _prepare_user_v2", 1)[0]
    prepare = cashback.split("async def _prepare_user_v2", 1)[1].split("async def _refresh_v2_cycle_totals", 1)[0]
    # A failed balance read must hold every account that received an eligible
    # deposit in this exact cycle, including accounts not reached after failure.
    assert "for row in inputs.get('accounts') or []:" in store
    assert "cashback_principal_holds" in store
    assert "amount = max(0, int(row.get('eligible_deposits') or 0))" in store
    assert "snapshot_status': 'not_checked_after_failure'" in prepare


def test_cashback_v2_failed_retry_reuses_cycle_formula_and_freeze_gate():
    s = text("app/services/rewards.py")
    cashback = s.split("class CashbackService:", 1)[1]
    retry = cashback.split("async def retry_failed", 1)[1].split("async def distribute", 1)[0]
    assert "str(cycle['status']) in {'distributing','distributed'}" in retry
    assert "_v2_unresolved_before_cycle_end" in retry
    assert "await self._prepare_user_v2" in retry
    assert "_refresh_v2_cycle_totals" in retry


def test_referral_cycle_uses_provider_success_time_and_freeze_gate():
    s = text("app/services/rewards.py")
    referral = s.split("class ReferralService:", 1)[1].split("class CashbackService:", 1)[0]
    signed = referral.split("async def _signed_results_for_windows", 1)[1].split("async def _signed_result_for_user", 1)[0]
    prepare = referral.split("async def prepare_ended_cycle", 1)[1]
    assert "COALESCE(remote_success_at,finished_at)" in signed
    assert "status IN ('success','remote_success')" in signed
    assert "status IN ('executing','reconciling')" in signed
    assert "_unresolved_referral_financial_jobs" in referral
    assert '"blocked": "unresolved_ichancy_jobs"' in prepare
