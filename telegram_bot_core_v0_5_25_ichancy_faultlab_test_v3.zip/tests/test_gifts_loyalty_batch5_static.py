from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_batch5_migration_has_atomic_history_and_fake_codes():
    sql = read("migrations/0020_gifts_loyalty_batch5.sql")
    for marker in (
        "CREATE TABLE IF NOT EXISTS bot_core.gift_transfers",
        "CREATE TABLE IF NOT EXISTS bot_core.gift_codes",
        "CREATE TABLE IF NOT EXISTS bot_core.gift_code_redemptions",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_accounts",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_deposit_awards",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_events",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_rewards",
        "CREATE TABLE IF NOT EXISTS bot_core.loyalty_reward_claims",
        "gift_transfers_immutable",
        "gift_code_redemptions_immutable",
        "loyalty_events_immutable",
        "is_fake BOOLEAN NOT NULL DEFAULT FALSE",
    ):
        assert marker in sql
    assert "UPDATE bot_core.wallet_accounts" not in sql
    assert "INSERT INTO bot_core.wallet_ledger" not in sql


def test_gift_transfer_is_one_transaction_and_uses_wallet_service_only():
    src = read("app/services/gifts_loyalty.py")
    block = src.split("async def transfer", 1)[1].split("def _prefix", 1)[0]
    assert "async with conn.transaction()" in block
    assert "pg_advisory_xact_lock" in block
    assert "debit_in_transaction" in block
    assert "credit_in_transaction" in block
    assert 'idempotency_key=f"gift:{token}:debit"' in block
    assert 'idempotency_key=f"gift:{token}:credit"' in block
    assert "UPDATE bot_core.wallet_accounts" not in block


def test_nontransferable_rewards_are_marked_and_gift_debit_preserves_them():
    rewards = read("app/services/rewards.py")
    gifts = read("app/services/gifts_loyalty.py")
    repo = read("app/repositories/gifts_loyalty.py")
    assert rewards.count('"non_transferable_credit": True') >= 4
    assert '"gift_transfer":True' in gifts
    assert 'if not bool(meta.get("gift_transfer"))' in repo
    assert 'meta.get("non_transferable_credit")' in repo
    assert 'entry == "hold"' in repo and 'entry == "release"' in repo


def test_gift_code_redemption_is_locked_unique_and_nontransferable():
    src = read("app/services/gifts_loyalty.py")
    block = src.split("async def redeem_code", 1)[1].split("class LoyaltyService", 1)[0]
    assert "FOR UPDATE" in block
    assert "gift_code_redemptions" in block
    assert '"non_transferable_credit":True' in block
    assert "is_fake" in block
    sql = read("migrations/0020_gifts_loyalty_batch5.sql")
    assert "PRIMARY KEY(code,telegram_id)" in sql


def test_fake_codes_are_zero_value_and_never_credit_wallet():
    src = read("app/services/gifts_loyalty.py")
    fake = src.split("async def create_fake_batch", 1)[1].split("async def redeem_code", 1)[0]
    assert "amount_syp,is_fake" in fake
    assert "VALUES($1,0,TRUE,1,NULL,$2)" in fake
    redeem = src.split("async def redeem_code", 1)[1].split("class LoyaltyService", 1)[0]
    assert 'if bool(row[\'is_fake\'])' in redeem
    assert "تم استخدام هذا الكود من قبل مستخدم آخر" in redeem


def test_batch_code_creation_is_atomic_and_bounded():
    src = read("app/services/gifts_loyalty.py")
    block = src.split("async def create_batch", 1)[1].split("async def create_fake_batch", 1)[0]
    assert "count>200" in block
    assert "async with conn.transaction()" in block
    assert "ON CONFLICT(code) DO NOTHING RETURNING code" in block


def test_loyalty_deposit_award_snapshots_settings_and_never_rolls_back_deposit():
    svc = read("app/services/gifts_loyalty.py")
    dep = read("app/services/deposits.py")
    assert "enabled_snapshot" in svc
    assert "earn_syp_per_point" in svc
    assert "min_deposit_syp" in svc
    side = dep.split("async def _loyalty_side_effect", 1)[1].split("async def approve_manual", 1)[0]
    assert "async with conn.transaction()" in side
    assert "mark_award_failed" in side
    assert dep.count("await self._loyalty_side_effect(conn, done)") >= 2


def test_loyalty_reward_balance_is_atomic_and_nontransferable():
    src = read("app/services/gifts_loyalty.py")
    block = src.split("async def claim_reward", 1)[1].split("async def decide_claim", 1)[0]
    assert "FOR UPDATE" in block
    assert "credit_in_transaction" in block
    assert '"non_transferable_credit":True' in block
    assert "loyalty_reward_claims" in block
    assert "loyalty_events" in block


def test_manual_reward_rejection_refunds_points_atomically():
    src = read("app/services/gifts_loyalty.py")
    block = src.split("async def decide_claim", 1)[1].split("async def create_reward", 1)[0]
    assert "FOR UPDATE" in block
    assert "status='rejected'" in block
    assert "reward_refund" in block
    assert "points=bot_core.loyalty_accounts.points+$2" in block


def test_admin_point_changes_require_preview_confirmation_and_stale_balance_guard():
    router = read("app/routers/admin_gifts_loyalty.py")
    svc = read("app/services/gifts_loyalty.py")
    assert "تأكيد تعديل نقاط الولاء" in router
    assert '"a5:p:y"' in router and '"a5:p:n"' in router
    assert "expected_old" in svc
    assert "تغير رصيد النقاط منذ شاشة التأكيد" in svc


def test_loyalty_worker_is_wired_to_bot_lifecycle():
    main = read("app/main.py")
    assert "GiftsLoyaltyRepository(db)" in main
    assert "LoyaltyReconciliationWorker(loyalty_service)" in main
    assert 'name="loyalty-reconciliation-worker"' in main
    assert "loyalty_service=loyalty_service" in main
    assert "gift_service=gift_service" in main
    assert "loyalty_worker.stop()" in main


def test_batch5_public_and_admin_routes_and_menu_are_wired():
    routers = read("app/routers/__init__.py")
    menu = read("app/keyboards/common.py")
    ui = read("app/core/ui_customization.py")
    assert "admin_gifts_loyalty.router" in routers
    assert "gifts_loyalty.router" in routers
    assert 'callback_data="admin:benefits"' in menu
    for cb in ("gift:send", "gift:code", "gift:history", "loyalty:home"):
        assert cb in ui or cb in menu


def test_gift_code_admin_has_reference_feature_set():
    router = read("app/routers/admin_gifts_loyalty.py")
    for marker in (
        "مفرد عام", "متعدد الاستخدام", "خاص لمستخدم", "دفعة أكواد",
        "أكواد وهمية", "سجل الاستخدام", "إنهاء كود", "مهلة الاستخدام",
    ):
        assert marker in router


def test_loyalty_admin_has_search_user_history_rewards_and_pending_claims():
    router = read("app/routers/admin_gifts_loyalty.py")
    for marker in (
        "admin:loyalty:search", "a5:lu:", "a5:lh:", "a5:pa:",
        "admin:loyalty:rewards:", "admin:loyalty:claims:", "admin:loyalty:reset",
    ):
        assert marker in router


def test_batch5_callback_data_examples_fit_telegram_limit():
    uid = "9" * 19
    claim = "0" * 36
    samples = [
        f"a5:c:{claim}:y", f"a5:c:{claim}:n",
        f"a5:lu:{uid}:999", f"a5:lh:{uid}:999:999", f"a5:pa:set:{uid}:999",
    ]
    assert max(len(x.encode("utf-8")) for x in samples) <= 64


def test_loyalty_reset_is_globally_serialized_against_normal_mutations():
    src = read("app/services/gifts_loyalty.py")
    assert "LOYALTY_RESET_LOCK_KEY" in src
    assert "pg_advisory_xact_lock_shared" in src
    assert "async def _lock_global_reset" in src
    reset = src.split("async def reset_all", 1)[1].split("async def stats", 1)[0]
    assert "await self._lock_global_reset(conn)" in reset
    # Pending award check must happen after the exclusive lock is acquired.
    assert reset.index("await self._lock_global_reset(conn)") < reset.index("loyalty_deposit_awards")
    for fn in ("prepare_deposit_award", "settle_deposit_award", "claim_reward", "decide_claim", "adjust_points"):
        block = src.split(f"async def {fn}", 1)[1].split("async def ", 1)[0]
        assert "_lock_normal_mutation" in block


def test_reports_include_gift_codes_and_loyalty_balance_but_not_gift_transfers_as_cash_flow():
    svc = read("app/services/reports.py")
    router = read("app/routers/admin_reports.py")
    assert "gift_code_redemptions" in svc and "AS gift_codes" in svc
    assert "loyalty_reward_claims" in svc and "AS loyalty_balance" in svc
    assert 'int(rew.get("gift_codes") or 0)' in svc
    assert 'int(rew.get("loyalty_balance") or 0)' in svc
    assert "gift_transfers" not in svc
    assert "أكواد الهدايا" in router
    assert "جوائز الولاء (رصيد)" in router


def test_batch5_user_messages_join_runtime_text_customization():
    ui = read("app/core/ui_customization.py")
    router = read("app/routers/gifts_loyalty.py")
    for key in (
        "gift_send_prompt", "gift_amount_prompt", "gift_confirm", "gift_send_success",
        "gift_received", "gift_code_prompt", "gift_code_success", "loyalty_home",
        "loyalty_balance_success", "loyalty_manual_success",
    ):
        assert f'"{key}": MessageSpec' in ui
        assert f'"{key}"' in router
    assert "render_message" in router


def test_welcome_rewards_match_reference_nontransferable_rules_without_locking_real_deposit_principal():
    finance = read("app/services/finance_rules.py")
    deposits = read("app/services/deposits.py")
    repo = read("app/repositories/gifts_loyalty.py")
    assert '"mode": "instant", "non_transferable_credit": True' in finance
    assert 'deposit.bonus_source == "welcome_first_deposit"' in deposits
    assert 'metadata["non_transferable_amount"] = int(deposit.bonus_credit_syp)' in deposits
    assert 'meta.get("non_transferable_amount")' in repo
    # A first-deposit wallet ledger row contains base + bonus, therefore it must
    # not use the whole-credit flag that would accidentally lock real principal.
    metadata_block = deposits.split("def _wallet_metadata", 1)[1].split("async def", 1)[0]
    assert 'non_transferable_credit' not in metadata_block
