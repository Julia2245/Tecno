from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "app/main.py").read_text(encoding="utf-8")
MW = (ROOT / "app/middlewares/maintenance.py").read_text(encoding="utf-8")
ADMIN = (ROOT / "app/routers/admin.py").read_text(encoding="utf-8")
KEYBOARD = (ROOT / "app/keyboards/common.py").read_text(encoding="utf-8")
RUNTIME = (ROOT / "app/services/runtime_settings.py").read_text(encoding="utf-8")


def test_maintenance_is_global_update_outer_middleware_before_business_router() -> None:
    assert "MaintenanceModeMiddleware" in MAIN
    mw_pos = MAIN.index("dp.update.outer_middleware(MaintenanceModeMiddleware")
    router_pos = MAIN.index("dp.include_router(build_root_router())")
    per_user_pos = MAIN.index("dp.update.outer_middleware(PerUserSerializationMiddleware())")
    assert mw_pos < per_user_pos < router_pos


def test_maintenance_blocks_stale_callbacks_without_calling_handler() -> None:
    block = MW.split("class MaintenanceModeMiddleware", 1)[1]
    assert 'runtime.get_bool("maintenance.enabled", False)' in block
    assert "if user_id in self._admin_ids()" in block
    assert "await callback.answer(alert_text, show_alert=True)" in block
    # The enabled non-admin branch terminates instead of delegating to any router.
    assert "return None" in block


def test_maintenance_blocks_messages_and_old_fsm_inputs() -> None:
    block = MW.split("class MaintenanceModeMiddleware", 1)[1]
    assert "elif message is not None:" in block
    assert "await message.answer(text, parse_mode=None)" in block


def test_admin_can_toggle_and_edit_maintenance_message() -> None:
    assert 'F.data == "admin:maintenance"' in ADMIN
    assert 'F.data == "admin:maintenance:toggle"' in ADMIN
    assert 'runtime_settings.set("maintenance.enabled", new_value' in ADMIN
    assert 'F.data == "admin:maintenance:message"' in ADMIN
    assert 'runtime_settings.set("maintenance.message", text' in ADMIN
    assert 'callback_data="admin:maintenance"' in KEYBOARD


def test_maintenance_defaults_safe_and_persists_in_runtime_settings() -> None:
    assert '"maintenance.enabled": False' in RUNTIME
    assert '"maintenance.message":' in RUNTIME
    assert "await self.repository.set(key, value, updated_by=updated_by)" in RUNTIME


def test_background_workers_are_not_stopped_by_maintenance_toggle() -> None:
    # Maintenance is an update middleware only. It must not cancel financial workers,
    # because provider-success operations may still need local reconciliation.
    assert "ichancy_jobs.stop" not in MW
    assert "outbox_worker.stop" not in MW
    assert "rewards_maintenance.stop" not in MW
