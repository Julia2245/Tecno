from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_unified_communications_has_reference_channel_set():
    menu = read("app/keyboards/common.py")
    router = read("app/routers/admin_support.py")
    assert 'admin:communications' in menu
    assert 'إدارة التواصل والرسائل الجماعية' in menu
    for key in (
        'notify.ichancy_accounts', 'notify.ichancy_operations', 'notify.admin_events',
        'notify.bot_deposits', 'notify.manual_deposit_requests', 'notify.bot_withdrawals',
        'backup.channel',
    ):
        assert key in router
    assert 'admin:bcast' in router and 'admin:support' in router and 'admin:notify_channels' in router


def test_missing_notification_target_pauses_instead_of_retrying_forever():
    worker = read("app/services/outbox.py")
    repo = read("app/repositories/outbox.py")
    assert 'await self.repository.pause(' in worker
    assert "SET status='paused'" in repo
    assert 'resume_target' in repo
    assert "status='pending'" in repo


def test_manual_deposit_channel_uses_runtime_then_env_fallback():
    router = read("app/routers/deposits.py")
    main = read("app/main.py")
    assert 'runtime_settings.get("notify.manual_deposit_requests")' in router
    assert 'settings.deposit_manual_review_chat_id' not in router.split('async def _notify_manual_admins',1)[1].split('async def _clear_to_methods',1)[0]
    assert '"notify.manual_deposit_requests": settings.deposit_manual_review_chat_id' in main


def test_bot_deposit_failures_are_durable_and_classified():
    service = read("app/services/deposits.py")
    router = read("app/routers/deposits.py")
    assert 'enqueue_attempt_notification' in service
    assert 'target_key="notify.bot_deposits"' in service
    for outcome in ('rejected', 'unavailable', 'uncertain', 'internal'):
        assert f'outcome="{outcome}"' in router
    assert 'bot-deposit-attempt:' in service


def test_admin_events_moved_to_durable_outbox():
    gifts = read("app/routers/gifts_loyalty.py")
    assert 'target_key="notify.admin_events"' in gifts
    assert 'outbox_worker.repository.enqueue' in gifts
    # direct channel sender helper was removed
    assert '_admin_target' not in gifts


def test_withdraw_public_number_is_sequence_backed_but_uuid_stays_internal():
    mig = read("migrations/0022_notifications_withdraw_matches_polish.sql")
    core = read("app/core/withdrawals.py")
    repo = read("app/repositories/withdrawals.py")
    assert 'withdraw_display_seq' in mig
    assert 'display_no BIGINT' in mig
    assert 'ux_withdraw_display_no' in mig
    assert 'return f"TECNO-{int(self.display_no):06d}"' in core
    assert 'id: UUID' in core and 'display_no: int' in core
    assert 'display_no=int(row["display_no"])' in repo


def test_withdraw_success_card_hides_last_three_and_separator_precedes_status():
    ui = read("app/core/withdrawal_admin_ui.py")
    assert 'if not success:' in ui
    assert 'آخر 3 عمليات شحن ناجحة' in ui
    assert ui.index('"──────────────"') < ui.index('f"📌 الحالة:')
    assert 'rec.public_id' in ui


def test_withdraw_success_user_notice_is_only_finalization_outbox():
    repo = read("app/repositories/withdrawals.py")
    service = read("app/services/withdrawals.py")
    assert 'bot-withdraw-user-success:' in repo
    assert "SET status='success'" in repo
    assert '🧾 رقم الطلب: <code>{rec.public_id}</code>' in service
    assert '💵 المبلغ المستلم:' in service


def test_matches_user_router_is_cache_only_and_opens_reference_menu():
    router = read("app/routers/matches.py")
    service = read("app/services/matches.py")
    assert 'session.get' not in router
    assert '@router.callback_query(F.data == "menu:matches")' in router
    for key in ('laliga','epl','ucl','uel','seriea','bundesliga','ligue1','mixed'):
        assert key in service
    # today() is read-only; provider HTTP exists only in the refresh path.
    today_body = service.split('async def today',1)[1].split('@staticmethod\n    def _normalize',1)[0]
    assert 'session.get' not in today_body
    refresh_body = service.split('async def refresh_today_if_needed',1)[1].split('async def run_daily_worker',1)[0]
    assert 'self.session.get' in refresh_body


def test_matches_daily_cache_survives_restart_and_worker_runs():
    service = read("app/services/matches.py")
    main = read("app/main.py")
    cfg = read("app/config.py")
    assert 'CACHE_PREFIX = "football.matches.daily."' in service
    assert "replace('-', '')" in service
    assert 'if self._valid(self._cache(day), day):\n            return False' in service
    assert 'run_daily_worker' in service and 'football-daily-cache-worker' in main
    assert '828956f2bf4a80f5bfcd611b8796e8fd' in cfg


def test_withdraw_success_channel_sync_skips_last_deposits_query():
    router = read("app/routers/admin_finance.py")
    body = router.split("async def _sync_withdraw_channel", 1)[1].split("async def _mark_withdraw_channel_processing", 1)[0]
    assert 'if str(rec.status) != "success":' in body
    assert 'last_successful_deposits' in body


def test_matches_button_is_reenabled_once_on_upgrade():
    mig = read("migrations/0022_notifications_withdraw_matches_polish.sql")
    assert "ui.button_visible.home_matches" in mig
    assert "'true'::jsonb" in mig
