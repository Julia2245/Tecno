from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_migration_0021_has_competition_contracts():
    s=read('migrations/0021_competitions_roulette_matches.sql')
    for token in ('promo_rewards','promo_reward_spends','competition_deposit_effects','contests','contest_entries','contest_awards','contest_bonus_rewards','roulettes','roulette_prizes','roulette_entries','roulette_awards','roulette_bonus_rewards'):
        assert token in s
    for token in ('wallet_amount_syp','promo_reward_id','promo_amount_syp','ichancy_job_wallet_promo_sum'):
        assert token in s


def test_promo_rewards_are_24h_and_separate_from_wallet():
    s=read('app/services/competitions.py')
    assert "INTERVAL '24 hours'" in s
    assert 'bot_core.promo_rewards' in s
    assert 'UPDATE bot_core.wallet_accounts' not in s
    assert 'INSERT INTO bot_core.wallet_accounts' not in s


def test_competition_deposit_side_effect_cannot_abort_real_deposit():
    s=read('app/services/deposits.py')
    assert 'async def _competition_side_effect' in s
    assert 'async with conn.transaction()' in s
    assert 'Could not persist competition side-effect retry' in s
    assert 'await self._competition_side_effect(conn, done)' in s


def test_side_effect_retries_before_event_close_and_blocks_relevant_close():
    s=read('app/services/competitions.py')
    block=s[s.index('async def maintenance_tick'):s.index('class CompetitionMaintenanceWorker')]
    assert block.index('await self.retry_pending_deposit_effects()') < block.index("UPDATE bot_core.contests c")
    assert "e.status IN ('pending','failed')" in block
    assert "c.template_type='match_prediction' OR NOT EXISTS" in block
    assert "r.participation_mode='free' OR NOT EXISTS" in block
    assert 'e.base_amount_syp >= r.min_deposit_syp' in block


def test_stale_admin_callback_cannot_draw_early():
    s=read('app/services/competitions.py')
    assert "c['status'] != 'ready_for_draw'" in s
    assert "الروليت ليست جاهزة للسحب بعد" in s


def test_contest_templates_and_raffle_modes_present():
    s=read('app/services/competitions.py') + read('app/routers/admin_competitions.py') + read('migrations/0021_competitions_roulette_matches.sql')
    for token in ('match_prediction','cash_luck','top_depositors','deposit_raffle','user_once','per_deposit'):
        assert token in s


def test_draw_randomness_and_unique_winners():
    s=read('app/services/competitions.py')
    assert 'secrets.SystemRandom()' in s
    assert 'existing_users' in s
    assert 'existing_user' in s


def test_award_idempotency_uses_existing_award_owner():
    s=read('app/services/competitions.py')
    assert "telegram_id=int(award['telegram_id']), source_type='contest'" in s
    assert "telegram_id=int(award['telegram_id']), source_type='roulette'" in s
    assert "award['telegram_id'], contest['prize_value']" in s
    assert "award['telegram_id'], prize['prize_value']" in s


def test_manual_winner_must_be_real_participant():
    s=read('app/services/competitions.py')
    assert 'المستخدم ليس مشاركًا مؤهلًا في المسابقة' in s
    assert 'المستخدم ليس مشاركًا في الروليت' in s


def test_contest_bonus_has_priority_in_deposit_finance_rules():
    s=read('app/services/finance_rules.py')
    idx_comp=min(x for x in [s.find('contest_bonus_rewards'),s.find('roulette_bonus_rewards')] if x>=0)
    for later in ('welcome','special','tier'):
        idx=s.find(later,idx_comp+1)
        assert idx_comp < idx if idx >= 0 else True


def test_ichancy_job_tracks_wallet_and_single_promo_breakdown():
    r=read('app/repositories/ichancy_jobs.py')
    svc=read('app/services/ichancy_jobs.py')
    for token in ('wallet_amount_syp','promo_reward_id','promo_amount_syp'):
        assert token in r and token in svc
    assert 'select_promo_for_spend' in svc
    assert 'reserve_promo_spend' in svc
    assert 'release_promo_spend' in svc
    assert 'consume_promo_spend' in svc


def test_cashback_principal_only_uses_real_wallet_part():
    s=read('app/services/ichancy_jobs.py')
    assert 'wallet_amount' in s
    # Promo rewards must never be principal for cashback.
    assert 'promo_amount' in s
    assert 'create_allocation' in s or 'cashback' in s


def test_football_api_key_has_built_in_reference_default_with_optional_env_override():
    cfg=read('app/config.py')
    svc=read('app/services/matches.py')
    assert 'FOOTBALL_API_KEY' in cfg
    assert '828956f2bf4a80f5bfcd611b8796e8fd' in cfg
    assert 'api_key' in svc
    assert 'x-apisports-key' in svc.lower()


def test_match_league_ids_match_reference_categories():
    s=read('app/services/matches.py')
    for league_id in ('140','39','2','3','135','78','61'):
        assert league_id in s
    assert 'Asia/Damascus' in s


def test_deep_links_survive_terms_and_channel_gates():
    start=read('app/routers/start.py')
    users=read('app/repositories/users.py')
    ux=read('app/routers/user_experience.py')
    for token in ('contest_','roulette_','roulette_result_'):
        assert token in start
    for token in ('contest','roulette','roulette_result'):
        assert token in users
    assert 'pending_start_action' in ux


def test_channel_publication_supports_event_media_and_deeplink():
    s=read('app/services/competitions.py')
    for method in ('send_photo','send_animation','send_video','send_message'):
        assert method in s
    assert '?start=contest_' in s
    assert '?start=roulette_' in s
    assert 'channel_message_id' in s


def test_failed_initial_channel_publish_is_retried_durably():
    s=read('app/services/competitions.py')
    assert "publish_to_channel AND channel_message_id IS NULL" in s
    assert "roulettes WHERE channel_message_id IS NULL" in s
    assert 'self.channel_raw' in s
    main=read('app/main.py')
    assert 'settings.required_channel' in main


def test_roulette_custom_prize_has_separate_fulfillment_state():
    mig=read('migrations/0021_competitions_roulette_matches.sql')
    svc=read('app/services/competitions.py')
    assert 'fulfillment_status' in mig
    assert 'fulfill_custom_roulette_prize' in svc


def test_user_and_admin_routers_registered():
    init=read('app/routers/__init__.py')
    main=read('app/main.py')
    for token in ('admin_competitions','competitions','matches'):
        assert token in init
    assert 'CompetitionMaintenanceWorker' in main
    assert 'MatchesService' in main


def test_main_menu_has_contests_and_matches_without_changing_financial_callbacks():
    s=read('app/core/ui_customization.py')
    assert "'home_contests'" in s or '"home_contests"' in s
    assert 'contest:home' in s
    assert 'menu:matches' in s


def test_result_and_initial_channel_publications_are_distinct():
    s=read('app/services/competitions.py')
    assert 'result_message_id' in s
    assert 'channel_message_id' in s
    assert 'نتيجة المسابقة' in s
    assert 'نتيجة الروليت' in s


def test_deposit_roulette_is_per_successful_deposit_not_accumulated():
    s=read('app/services/competitions.py')
    assert "min_deposit_syp <= $2" in s
    assert "f'dep:{deposit_id}'" in s
    assert 'SUM(effect' not in s


def test_preflight_requires_migration_0021():
    s=read('scripts/preflight.py')
    assert '0021_competitions_roulette_matches.sql' in s


def test_admin_fulfill_returns_to_same_roulette_card():
    s=read('app/routers/admin_competitions.py')
    assert "SELECT roulette_id FROM bot_core.roulette_awards WHERE id=$1" in s
    assert 'await roulette_admin_view(callback,settings,competition_service,int(rid))' in s

def test_authoritative_services_reject_early_result_and_invalid_bonus_percent():
    s=read('app/services/competitions.py')
    assert 'لم ينته وقت استقبال التوقعات بعد' in s
    assert "prize_type == 'deposit_bonus' and prize_value > 100" in s
    assert "ptype == 'deposit_bonus' and pvalue > 100" in s
    assert "c['status'] != 'ready_for_draw'" in s


def test_manual_roulette_close_is_safe_and_closes_window():
    s=read('app/services/competitions.py')
    assert 'force_roulette_ready' in s
    assert 'توجد عمليات شحن قيد تسوية فرصها' in s
    assert 'end_at=LEAST(end_at,NOW())' in s
    admin=read('app/routers/admin_competitions.py')
    assert 'admin:roulette:close:' in admin
    assert 'إغلاق المشاركة الآن' in admin


def test_admin_can_retry_channel_publication_explicitly():
    s=read('app/routers/admin_competitions.py')
    assert 'admin:contest:publish:' in s
    assert 'admin:roulette:publish:' in s
    assert 'publish_contest(bot,cid,settings.required_channel)' in s
    assert 'publish_roulette(bot,rid,settings.required_channel)' in s

def test_julia_parity_user_ranking_and_global_winners_present():
    s=read('app/routers/competitions.py')
    assert 'contest:ranking:' in s
    assert 'contest:winners:all' in s
    assert 'SUM(e.base_amount_syp)' in s


def test_admin_histories_and_permanent_contest_delete_are_present_and_guarded():
    admin=read('app/routers/admin_competitions.py')
    svc=read('app/services/competitions.py')
    for token in ('admin:contest:list:active:0','admin:contest:list:waiting:0','admin:contest:list:ended:0'):
        assert token in admin
    assert 'إلغاء وحذف نهائي' in admin
    assert 'cancel_confirm' in admin
    assert 'delete_contest_permanently' in svc
    assert 'لا يمكن حذف مسابقة تم اعتماد أو صرف جائزة فيها' in svc


def test_roulette_history_winners_and_cancel_confirmation_present():
    s=read('app/routers/admin_competitions.py')
    for token in ('admin:roulette:list:active:0','admin:roulette:list:waiting:0','admin:roulette:list:ended:0','admin:roulette:winners:','admin:roulette:cancel_confirm:'):
        assert token in s

def test_reports_show_batch6_rewards_without_double_counting_promo_as_wallet_credit():
    svc=read('app/services/reports.py')
    ui=read('app/routers/admin_reports.py')
    for token in ('contest_promo_awarded','roulette_promo_awarded','contest_bonus_used','roulette_bonus_used','deposit_wallet','deposit_promo'):
        assert token in svc
    assert 'contest_promo_awarded' in ui and 'deposit_promo' in ui
    # Promo awards are informational commitments, not cash-wallet internal credits.
    ordinary=svc[svc.index('ordinary_internal ='):svc.index('return {',svc.index('ordinary_internal ='))]
    assert 'contest_promo_awarded' not in ordinary
    assert 'roulette_promo_awarded' not in ordinary
