from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_delayed_failure_mode_is_ssh_only_and_suppresses_provider_post():
    worker = (ROOT / "app/services/ichancy_jobs.py").read_text()
    script = (ROOT / "scripts/ichancy_faultlab.py").read_text()
    assert '"timeout_then_confirmed_failure"' in script
    assert '"before_financial_post"' in script
    assert 'stage="before_financial_post"' in worker
    assert "provider_post_suppressed=true" in worker
    hook = worker.index('stage="before_financial_post"')
    deposit_post = worker.index("payload = await client.deposit_to_player", hook)
    assert hook < deposit_post
    for p in (ROOT / "app/routers").glob("*.py"):
        assert "timeout_then_confirmed_failure" not in p.read_text()


def test_delayed_failure_reuses_production_definite_failure_path():
    worker = (ROOT / "app/services/ichancy_jobs.py").read_text()
    marker = worker.index('startswith("FAULTLAB timeout_then_confirmed_failure")')
    definite = worker.index("await self._definite_fail(", marker)
    return_after = worker.index("return", definite)
    assert marker < definite < return_after
    assert "release_hold_in_transaction" in worker
    assert "release_ichancy_deposit" in worker
    assert "release_promo_spend" in worker


def test_delayed_failure_arm_message_does_not_claim_real_provider_post():
    script = (ROOT / "scripts/ichancy_faultlab.py").read_text()
    assert "SAFE FAILURE TEST: provider POST will be suppressed" in script


def test_delayed_failure_writes_audit_events_and_cli_counts_them():
    worker = (ROOT / "app/services/ichancy_jobs.py").read_text()
    script = (ROOT / "scripts/ichancy_faultlab.py").read_text()
    assert '"faultlab_provider_post_suppressed"' in worker
    assert '"faultlab_delayed_failure_confirmed"' in worker
    assert 'faultlab_provider_post_suppressed_count:' in script
    assert 'faultlab_delayed_failure_confirmed_count:' in script
