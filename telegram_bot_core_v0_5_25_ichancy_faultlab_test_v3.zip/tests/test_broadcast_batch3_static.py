from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_broadcast_migration_is_durable_and_separate_from_finance():
    sql = read("migrations/0018_broadcast_durable.sql")
    assert "CREATE TABLE IF NOT EXISTS bot_core.broadcast_campaigns" in sql
    assert "CREATE TABLE IF NOT EXISTS bot_core.broadcast_recipients" in sql
    assert "send_status IN ('pending','sending','sent','blocked','failed','unknown')" in sql
    assert "delete_status IN ('none','pending','deleting','deleted','failed')" in sql
    assert "message_id BIGINT" in sql
    assert "stop_requested BOOLEAN" in sql
    assert "wallet_accounts" not in sql
    assert "wallet_ledger" not in sql


def test_confirmation_snapshots_only_nonblocked_real_users_atomically():
    repo = read("app/repositories/broadcasts.py")
    assert "WHERE NOT u.is_blocked AND NOT u.is_bot" in repo
    assert "FOR UPDATE" in repo
    assert "INSERT INTO bot_core.broadcast_recipients" in repo
    assert "ON CONFLICT DO NOTHING" in repo
    assert "status=CASE WHEN $2::int>0 THEN 'queued' ELSE 'completed' END" in repo


def test_restart_recovery_is_fail_closed_for_ambiguous_sends():
    repo = read("app/repositories/broadcasts.py")
    assert "SET send_status='unknown',send_error='interrupted_after_dispatch'" in repo
    assert "WHERE send_status='sending'" in repo
    assert "SET delete_status='pending',delete_error='resumed_after_restart'" in repo
    assert "WHERE delete_status='deleting'" in repo


def test_worker_does_not_blindly_retry_ambiguous_telegram_failures():
    service = read("app/services/broadcasts.py")
    assert "except (TelegramNetworkError, TelegramServerError) as exc:" in service
    assert 'BroadcastSendResult("unknown"' in service
    assert "Never repeat blindly and risk a duplicate message" in service
    assert "except TelegramRetryAfter as exc:" in service


def test_broadcast_worker_is_started_and_stopped_with_bot_lifecycle():
    main = read("app/main.py")
    assert "BroadcastRepository(db)" in main
    assert "BroadcastService(" in main
    assert 'asyncio.create_task(broadcast_service.run_worker(), name="broadcast-worker")' in main
    assert "broadcast_service=broadcast_service" in main
    assert "broadcast_service.stop()" in main
    assert "broadcast_task.cancel()" not in main  # lifecycle uses the common task loop
    assert "broadcast_task" in main


def test_admin_flow_has_preview_confirmation_stop_history_and_delete():
    router = read("app/routers/admin_broadcasts.py")
    for marker in (
        'callback_data="admin:bcast:new"',
        "admin:bcast:confirm:",
        "admin:bcast:preview:",
        "admin:bcast:history:",
        "admin:bcast:stop:",
        "admin:bcast:stopok:",
        "admin:bcast:delete:",
        "admin:bcast:delok:",
    ):
        assert marker in router
    assert "لن يبدأ الإرسال قبل" in router
    assert "المستخدمين غير المحظورين" in router


def test_broadcast_is_exposed_via_unified_admin_communications_only():
    menu = read("app/keyboards/common.py")
    support = read("app/routers/admin_support.py")
    assert 'text="💬 إدارة التواصل والرسائل الجماعية", callback_data="admin:communications"' in menu
    assert 'text="📣 الرسائل الجماعية", callback_data="admin:bcast"' in support
    # It must not become a public main-menu button.
    public_part = menu.split("def admin_menu", 1)[0]
    assert "admin:bcast" not in public_part


def test_broadcast_callbacks_stay_under_telegram_64_byte_limit():
    cid = "0" * 36
    values = [
        f"admin:bcast:confirm:{cid}", f"admin:bcast:preview:{cid}", f"admin:bcast:edit:{cid}",
        f"admin:bcast:cancel:{cid}", f"admin:bcast:view:{cid}:999", f"admin:bcast:stop:{cid}",
        f"admin:bcast:stopok:{cid}", f"admin:bcast:delete:{cid}", f"admin:bcast:delok:{cid}",
    ]
    assert max(len(v.encode("utf-8")) for v in values) <= 64


def test_broadcast_rate_settings_are_bounded():
    cfg = read("app/config.py")
    env = read(".env.example")
    assert 'BROADCAST_PER_MINUTE' in cfg and 'ge=5, le=5000' in cfg
    assert 'BROADCAST_CONCURRENCY' in cfg and 'ge=1, le=32' in cfg
    assert 'BROADCAST_WORKER_POLL_SECONDS' in cfg
    assert "BROADCAST_PER_MINUTE=700" in env
    assert "BROADCAST_CONCURRENCY=8" in env


def test_per_recipient_progress_uses_incremental_campaign_counters():
    repo = read("app/repositories/broadcasts.py")
    assert "sent_count=sent_count+CASE WHEN $2='sent' THEN 1 ELSE 0 END" in repo
    assert "blocked_count=blocked_count+CASE WHEN $2='blocked' THEN 1 ELSE 0 END" in repo
    assert "deleted_count=deleted_count+CASE WHEN $2::boolean THEN 1 ELSE 0 END" in repo


def test_users_blocked_after_confirmation_are_skipped_before_dispatch():
    repo = read("app/repositories/broadcasts.py")
    assert "blocked_before_dispatch" in repo
    assert "u.is_blocked OR u.is_bot" in repo
    assert "blocked_count=blocked_count+$2" in repo
