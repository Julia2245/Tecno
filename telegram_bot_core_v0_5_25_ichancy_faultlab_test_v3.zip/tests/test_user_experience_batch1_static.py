from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_main_menu_has_batch1_user_entries_and_speed_button_is_removed():
    src = read("app/keyboards/common.py")
    for token in ("withdraw:cancel_last", "history:home", "support:home", "menu:terms"):
        assert token in src
    assert "اختبار سرعة الأزرار" not in src


def test_terms_are_new_user_only_and_centrally_guarded():
    migration = read("migrations/0016_user_experience_batch1.sql")
    users = read("app/repositories/users.py")
    middleware = read("app/middlewares/user_access.py")
    assert "terms_required BOOLEAN NOT NULL DEFAULT FALSE" in migration
    assert "NOW(), TRUE, NULL" in users
    assert "needs_terms_cached" in middleware
    assert 'callback_data.startswith("terms:accept")' in middleware
    assert 'callback_data in {"terms:reject", "menu:terms"}' in middleware


def test_public_history_exposes_only_successful_financial_records():
    users = read("app/repositories/users.py")
    assert "async def public_history" in users
    assert "deposit_requests WHERE telegram_id=$1 AND status='success'" in users
    assert "withdraw_requests WHERE telegram_id=$1 AND status='success'" in users
    assert "ichancy_jobs WHERE telegram_id=$1 AND status='success'" in users


def test_withdraw_refund_reuses_atomic_hold_release_path():
    router = read("app/routers/withdrawals.py")
    service = read("app/services/withdrawals.py")
    assert "withdraw:cancel_confirm:" in router
    assert "await withdraw_service.cancel_user" in router
    assert "SELECT * FROM bot_core.withdraw_requests WHERE id=$1 AND telegram_id=$2 FOR UPDATE" in service
    assert "release_hold_in_transaction" in service
    assert "WHERE id=$1 AND status='pending' RETURNING *" in service


def test_support_contacts_are_runtime_editable_and_visibility_controlled():
    defaults = read("app/services/runtime_settings.py")
    admin = read("app/routers/admin_support.py")
    for kind in ("telegram", "whatsapp", "facebook", "ichancy"):
        assert f'"support.{kind}_url"' in defaults
        assert f'"support.{kind}_visible"' in defaults
        assert f'"{kind}":' in admin
    assert 'callback_data=f"admin:support:edit:{kind}"' in admin
    assert 'callback_data=f"admin:support:toggle:{kind}"' in admin


def test_ichancy_unlink_and_transfer_have_financial_guards():
    repo = read("app/repositories/ichancy.py")
    service = read("app/services/ichancy_accounts.py")
    migration = read("migrations/0016_user_experience_batch1.sql")
    assert "'unlinked'" in migration
    assert "status IN ('queued','executing','remote_success','reconciling')" in repo
    assert "cashback_cycles" in repo and "referral_cycles" in repo
    assert "لا يمكن نقل الحساب أثناء وجود نشاط له ضمن دورة استرداد أو إحالات مفتوحة" in repo
    assert "if int(balance) != 0" in service
    assert "تعذر التأكد من رصيد iChancy" in service
