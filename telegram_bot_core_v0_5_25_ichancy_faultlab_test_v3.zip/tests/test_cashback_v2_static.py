from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REWARDS = (ROOT / "app/services/rewards.py").read_text(encoding="utf-8")
CASHBACK = REWARDS.split("class CashbackService:", 1)[1].split("class RewardsMaintenanceService:", 1)[0]
MIGRATION = (ROOT / "migrations/0014_cashback_v2_and_provider_traffic.sql").read_text(encoding="utf-8")


def _method_block(name: str, next_name: str | None = None) -> str:
    async_marker = f"    async def {name}("
    sync_marker = f"    def {name}("
    marker = async_marker if async_marker in CASHBACK else sync_marker
    start = CASHBACK.index(marker)
    if next_name:
        candidates = [
            CASHBACK.find(f"    async def {next_name}(", start + len(marker)),
            CASHBACK.find(f"    def {next_name}(", start + len(marker)),
        ]
        candidates = [x for x in candidates if x >= 0]
        if not candidates:
            raise ValueError(f"next method not found: {next_name}")
        end = min(candidates)
    else:
        end = len(CASHBACK)
    return CASHBACK[start:end]


def test_v2_candidates_require_cycle_scoped_eligible_deposit() -> None:
    block = _method_block("_v2_candidate_users", "_v2_user_inputs")
    assert "a.operation_type='deposit'" in block
    assert "a.eligible_amount_syp>0" in block
    assert "COALESCE(j.remote_success_at,j.finished_at,a.settled_at) >= $1" in block
    assert "COALESCE(j.remote_success_at,j.finished_at,a.settled_at) < $2" in block


def test_v2_formula_is_cycle_deposit_minus_all_withdrawals_minus_closing_balance() -> None:
    block = _method_block("_prepare_user_v2", "_refresh_v2_cycle_totals")
    assert "if eligible_deposits <= 0:" in block
    assert "net_loss = max(0, eligible_deposits - withdrawals - int(end_balance_total))" in block
    assert "start_principal" not in block


def test_v2_withdrawals_use_full_successful_ichancy_amounts_not_principal_bucket() -> None:
    block = _method_block("_v2_user_inputs", "_store_v2_user_result")
    assert "FROM bot_core.ichancy_jobs" in block
    assert "operation_type IN ('withdraw','retirement_withdraw')" in block
    assert "COALESCE(SUM(amount),0)::BIGINT" in block
    assert "cashback_principal" not in block


def test_v2_cycle_freeze_gate_blocks_ambiguous_provider_posts() -> None:
    block = _method_block("_v2_unresolved_before_cycle_end", "_v2_candidate_users")
    assert "status IN ('executing','remote_success','reconciling')" in block
    assert "financial_post_started_at" in block
    prepare = _method_block("prepare", "_legacy_v1_snapshot_map")
    assert "blocked': 'unresolved_ichancy_jobs'" in prepare


def test_legacy_recalculation_uses_saved_snapshots_not_live_balance() -> None:
    block = _method_block("_recalculate_legacy_cycle_v2", "_ensure_cycle_v2")
    assert "_legacy_v1_snapshot_map" in block
    assert "historical_snapshot_incomplete_v2" in block
    assert "_balance_account_at_end" not in block


def test_preview_distribution_and_skip_force_safe_v2_upgrade() -> None:
    due = _method_block("due", "ready_cycle")
    distribute = _method_block("distribute", "skip")
    skip = _method_block("skip", "history")
    assert "_ensure_cycle_v2" in due
    assert "_ensure_cycle_v2" in distribute
    assert "_ensure_cycle_v2" in skip


def test_maintenance_repairs_legacy_cycles_before_current_cycle_work() -> None:
    maintenance = REWARDS.split("class RewardsMaintenanceService:", 1)[1]
    block = maintenance.split("async def _tick", 1)[1]
    legacy_pos = block.index("recalculate_pending_legacy(limit=3)")
    ensure_pos = block.index("self.cashback.ensure_cycle()")
    assert legacy_pos < ensure_pos


def test_migration_marks_existing_cycles_legacy_and_supports_safe_claimed_repair() -> None:
    assert "ADD COLUMN IF NOT EXISTS calc_version INTEGER NOT NULL DEFAULT 1" in MIGRATION
    assert "ADD COLUMN IF NOT EXISTS last_error TEXT" in MIGRATION
    assert "ADD COLUMN IF NOT EXISTS v2_recalc_token UUID" in MIGRATION
    assert "ADD COLUMN IF NOT EXISTS v2_recalc_started_at TIMESTAMPTZ" in MIGRATION
    assert "idx_cashback_cycles_v2_repair" in MIGRATION


def test_cycle_mode_cannot_rewrite_after_provider_post_started() -> None:
    block = _method_block("set_mode", "_account_principal")
    assert "JOIN bot_core.ichancy_jobs j ON j.id=a.job_id" in block
    assert "COALESCE(j.remote_success_at,j.finished_at,a.settled_at)" in block
    assert "j.financial_post_started_at IS NOT NULL" in block
