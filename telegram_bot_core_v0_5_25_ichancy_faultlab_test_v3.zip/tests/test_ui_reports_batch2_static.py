from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding='utf-8')


def test_dynamic_main_menu_keeps_callbacks_immutable():
    s = read('app/core/ui_customization.py')
    assert 'ButtonSpec("شحن رصيد", "شحن رصيد", "deposit:methods"' in s
    assert 'ButtonSpec("سحب رصيد", "سحب رصيد", "withdraw:methods"' in s
    assert 'ButtonSpec("iChancy", "iChancy", "ichancy:menu"' in s
    assert 'ui.button_label.' in s or '_k("button_label", key)' in s
    assert 'ui.button_icon.' in s or '_k("button_icon", key)' in s
    assert 'ui.button_visible.' in s or '_k("button_visible", key)' in s


def test_main_menu_visibility_and_layout_are_runtime_only():
    s = read('app/core/ui_customization.py')
    assert 'MAIN_MENU_BUTTON_KEYS' in s
    assert 'ui.main_menu_layout' in s
    assert 'len(row) < 2' in s
    kb = read('app/keyboards/common.py')
    assert 'main_menu_layout(runtime_settings)' in kb
    assert 'button_visible(runtime_settings, key)' in kb
    assert 'callback_data=spec.callback' in kb


def test_admin_ui_supports_label_icon_visibility_layout_and_search():
    s = read('app/routers/admin_ui.py')
    for token in (
        'admin:ui:button_label:', 'admin:ui:button_icon:', 'admin:ui:visibility_toggle:',
        'admin:ui:layout_up:', 'admin:ui:layout_down:', 'admin:ui:layout_swap:',
        'admin:ui:search', 'message.html_text', 'custom_emoji_id',
    ):
        assert token in s


def test_message_templates_protect_placeholders():
    s = read('app/core/ui_customization.py')
    assert 'found.count(field) != 1' in s
    assert 'unknown = set(found) - allowed' in s
    assert 'return spec.default.format(**safe)' in s
    assert 'withdraw_refund_success' in s
    assert 'wheel_win' in s
    assert 'terms' in s


def test_terms_guard_uses_runtime_customized_text():
    s = read('app/middlewares/user_access.py')
    assert 'render_message(self.runtime_settings, "terms")' in s
    start = read('app/routers/start.py')
    assert 'render_message(runtime_settings, "terms")' in start


def test_financial_reports_are_read_only_and_use_damascus_boundaries():
    s = read('app/services/reports.py')
    assert 'ZoneInfo("Asia/Damascus")' in s
    assert 'base_credit_syp' in s
    assert 'net_wallet' in s
    assert 'net_cash_flow' in s
    assert 'deposit_bonus' in s
    upper = s.upper()
    # Service contains reporting SELECTs only: no direct financial mutation contract.
    assert 'INSERT INTO BOT_CORE.' not in upper
    assert 'UPDATE BOT_CORE.' not in upper
    assert 'DELETE FROM BOT_CORE.' not in upper


def test_reports_have_all_requested_periods_and_custom_range():
    s = read('app/routers/admin_reports.py')
    for period in ('today','yesterday','week','month','year','custom'):
        assert period in s
    assert 'YYYY-MM-DD' in s
    assert 'صافي التدفق النقدي' in s
    assert 'الائتمانات الداخلية' in s
    assert 'iChancy' in s


def test_batch2_migration_adds_reporting_indexes_only():
    s = read('migrations/0017_ui_reports_batch2.sql')
    assert 'idx_deposit_success_settled_report' in s
    assert 'idx_withdraw_success_finished_report' in s
    assert 'idx_ichancy_success_finished_report' in s
    assert 'idx_users_last_active_report' in s
    assert 'CREATE INDEX' in s
    assert 'ALTER TABLE' not in s.upper()


def test_reports_service_is_wired_without_provider_dependency():
    s = read('app/main.py')
    assert 'reports_service = ReportsService(db)' in s
    assert 'reports_service=reports_service' in s
    r = read('app/services/reports.py')
    assert 'ApiSyria' not in r and 'TsaApi' not in r and 'aiohttp' not in r


def test_user_financial_method_buttons_are_customizable_without_visibility_side_effects():
    s = read('app/core/ui_customization.py')
    for key in ('deposit_syriatel','deposit_sham_syp','withdraw_syriatel','withdraw_shamcash','ichancy_create','ichancy_deposit','ichancy_withdraw'):
        assert key in s
    assert 'if v.group == "القائمة الرئيسية"' in s


def test_customized_financial_and_ichancy_messages_are_wired_to_real_paths():
    wd = read('app/routers/withdrawals.py')
    assert 'render_message(' in wd and '"withdraw_refund_success"' in wd
    ich = read('app/routers/ichancy.py')
    assert 'render_message(runtime_settings, "ichancy_create_prompt")' in ich
    jobs = read('app/services/ichancy_jobs.py')
    assert '"ichancy_deposit_success" if job.operation_type == "deposit" else "ichancy_withdraw_success"' in jobs
    assert 'amount=f"{job.amount:,}"' in jobs


def test_support_buttons_share_runtime_label_and_custom_emoji_controls_without_changing_urls():
    specs = read('app/core/ui_customization.py')
    for key in ('support_telegram','support_whatsapp','support_facebook','support_ichancy'):
        assert key in specs
    support = read('app/core/user_experience.py')
    assert 'ui.button_label.{ui_key}' in support
    assert 'ui.button_icon.{ui_key}' in support
    assert 'support.{kind}_url' in support
    assert 'icon_custom_emoji_id=icon' in support


def test_withdraw_refund_template_keeps_request_id_amount_and_balance():
    s = read('app/core/ui_customization.py')
    assert 'frozenset({"withdraw_id", "amount", "balance"})' in s
    assert '"withdraw_id": "00000000-0000-0000-0000-000000000000"' in s


def test_copied_message_search_and_part_editor_protect_dynamic_placeholders():
    core = read('app/core/ui_customization.py')
    for token in (
        'find_message_templates_by_rendered_text', 'message_editable_parts',
        'replace_message_editable_part', 'pieces.append(r"[\\s\\S]*?")',
        'placeholders are never editable',
    ):
        assert token in core
    admin = read('app/routers/admin_ui.py')
    assert 'find_message_templates_by_rendered_text(runtime_settings,copied)' in admin
    assert 'UiAdminState.message_part_confirm' in admin
    assert 'admin:ui:message_part_save' in admin
    assert 'replace_message_editable_part(get_message_template(runtime_settings,key),idx,formatted)' in admin
    assert 'validate_message_template(key,candidate)' in admin


def test_reports_have_reference_style_read_only_detail_sections():
    s = read('app/routers/admin_reports.py')
    for section in ('deposits','withdrawals','rewards','ichancy','wallet','users','top'):
        assert f'section == "{section}"' in s
    assert 'admin:report_detail:' in s
    assert '_report_actions(period)' in s


def test_deposit_status_and_failure_messages_are_customizable_without_changing_financial_flow():
    catalog = read('app/core/ui_customization.py')
    for key in ('deposit_verifying','deposit_processing_previous','deposit_api_failed','deposit_not_found','deposit_mismatch'):
        assert f'"{key}"' in catalog
    dep = read('app/routers/deposits.py')
    assert 'render_message(runtime_settings, "deposit_verifying")' in dep
    assert 'render_message(runtime_settings, "deposit_processing_previous")' in dep
    assert 'render_message(runtime_settings, "deposit_api_failed")' in dep
    assert '_verification_failure_message(runtime_settings, exc)' in dep
    assert 'DepositProviderUnavailable' in dep
    # Provider-unavailable presentation is editable, but safe retry semantics remain explicit.
    assert 'same TxID retryable' in dep
