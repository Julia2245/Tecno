from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_admin_ops_migration_only_adds_admin_metadata_not_wallet_paths():
    sql = read("migrations/0019_admin_ops_batch4.sql")
    assert "CREATE TABLE IF NOT EXISTS bot_core.admin_assistants" in sql
    assert "CREATE TABLE IF NOT EXISTS bot_core.admin_security_events" in sql
    assert "CREATE TABLE IF NOT EXISTS bot_core.backup_history" in sql
    assert "admin_security_events_immutable" in sql
    assert "backup_history_immutable" in sql
    assert "UPDATE bot_core.wallet_accounts" not in sql
    assert "INSERT INTO bot_core.wallet_ledger" not in sql


def test_dynamic_assistants_extend_admin_access_but_not_owner_set():
    cfg = read("app/config.py")
    assert "def owner_admin_ids" in cfg
    assert "def super_admin_ids" in cfg
    assert "set(self.owner_admin_ids) | set(self._runtime_assistant_ids)" in cfg
    assert "def replace_runtime_assistants" in cfg
    access = read("app/services/admin_access.py")
    assert "if not self.is_owner(actor)" in access
    assert "target in self.settings.owner_admin_ids" in access


def test_global_guards_read_dynamic_admin_ids_after_add_remove():
    maintenance = read("app/middlewares/maintenance.py")
    access = read("app/middlewares/user_access.py")
    main = read("app/main.py")
    assert "getattr(source, \"super_admin_ids\", source)" in maintenance
    assert "getattr(source, \"super_admin_ids\", source)" in access
    assert "MaintenanceModeMiddleware(runtime_settings, settings)" in main
    assert "UserAccessMiddleware(user_service, settings, runtime_settings)" in main


def test_reserved_tx_management_reuses_financial_core_table():
    core = read("migrations/0003_deposit_core.sql")
    repo = read("app/repositories/admin_ops.py")
    deposits = read("app/repositories/deposits.py")
    assert "CREATE TABLE IF NOT EXISTS bot_core.reserved_transaction_numbers" in core
    assert "INSERT INTO bot_core.reserved_transaction_numbers" in repo
    assert "DELETE FROM bot_core.reserved_transaction_numbers" in repo
    assert "SELECT 1 FROM bot_core.reserved_transaction_numbers" in deposits
    assert "provider_scope=$1 AND provider_tx=$2" in deposits


def test_reserved_clear_is_owner_only_and_does_not_delete_claims():
    router = read("app/routers/admin_ops.py")
    clear = router.split("async def reserved_clear_do", 1)[1].split("# -------------------- immutable", 1)[0]
    assert "not _owner" in clear
    assert "reserved_clear" in clear
    assert "deposit_tx_claims" not in clear


def test_financial_admin_audit_reads_immutable_wallet_ledger():
    repo = read("app/repositories/admin_ops.py")
    block = repo.split("async def wallet_admin_audit", 1)[1].split("async def reserved_count", 1)[0]
    assert "bot_core.wallet_ledger" in block
    assert "bot_core.wallet_operations" in block
    assert "admin user balance credit" in block
    assert "UPDATE " not in block
    assert "DELETE " not in block


def test_restore_is_deferred_until_clean_startup_and_single_transaction():
    svc = read("app/services/backups.py")
    main = read("app/main.py")
    assert '"--single-transaction"' in svc
    assert "process_pending_restore" in svc
    assert "pending_restore.json" in svc
    assert "await self.runtime_settings.set(\"maintenance.enabled\", True" in svc
    assert "unresolved_financial_count" in svc
    assert "kind=\"pre_restore\"" in svc
    # Must happen before Database() / workers are constructed.
    assert main.index("process_pending_restore") < main.index("db = Database(")


def test_restore_upload_requires_bot_generated_custom_dump():
    svc = read("app/services/backups.py")
    assert 'path.suffix.lower() != ".dump"' in svc
    assert 'pg_restore, "--list"' in svc
    assert '"bot_core" not in listing' in svc


def test_backup_worker_uses_postgres_custom_dump_and_bot_core_schema_only():
    svc = read("app/services/backups.py")
    assert '"--format=custom"' in svc
    assert '"--schema=bot_core"' in svc
    assert '"backup.auto_enabled"' in svc
    assert 'name="postgres-backup-worker"' in read("app/main.py")


def test_batch4_router_is_wired_and_sensitive_sections_owner_only():
    routers = read("app/routers/__init__.py")
    menu = read("app/keyboards/common.py")
    src = read("app/routers/admin_ops.py")
    assert "admin_ops.router" in routers
    assert 'callback_data="admin:ops"' in menu
    for marker in ("admin:ops:assistants", "admin:ops:backup", "admin:ops:audit:wallet:0", "admin:ops:audit:security:0"):
        assert marker in src
    assert "if not _owner" in src


def test_restore_schedule_exits_only_after_persistent_marker_and_confirmation_path():
    src = read("app/routers/admin_ops.py")
    service = read("app/services/backups.py")
    confirm = src.split("async def restore_confirm", 1)[1].split("# -------------------- reserved", 1)[0]
    assert "await backup_service.schedule_restore" in confirm
    assert "call_later(1.0, os._exit, 75)" in confirm
    assert "os.replace(tmp, marker)" in service
    assert "database_restore_scheduled" in service


def test_reserving_already_claimed_transaction_is_refused():
    repo = read("app/repositories/admin_ops.py")
    block = repo.split("async def reserved_add_many", 1)[1].split("async def reserved_delete", 1)[0]
    assert "deposit_tx_claims" in block
    assert "WHERE NOT EXISTS" in block


def test_read_only_admin_ops_audit_script_exists():
    src = read("scripts/admin_ops_audit.py")
    assert "ADMIN OPS AUDIT: OK" in src
    assert "reserved/claimed conflict" in src
    assert "UPDATE bot_core" not in src
    assert "DELETE FROM bot_core" not in src


def test_restore_lock_blocks_before_admin_bypass():
    src = Path('app/middlewares/maintenance.py').read_text(encoding='utf-8')
    lock = 'runtime.get_bool("system.restore_lock", False)'
    admin = 'if user_id in self._admin_ids():'
    assert lock in src
    assert admin in src
    assert src.index(lock) < src.index(admin)


def test_restore_lock_lifecycle_is_explicit():
    runtime = Path('app/services/runtime_settings.py').read_text(encoding='utf-8')
    backups = Path('app/services/backups.py').read_text(encoding='utf-8')
    assert '"system.restore_lock": False' in runtime
    assert 'runtime_settings.set("system.restore_lock", True' in backups
    assert 'runtime_settings.set("system.restore_lock", False' in backups
