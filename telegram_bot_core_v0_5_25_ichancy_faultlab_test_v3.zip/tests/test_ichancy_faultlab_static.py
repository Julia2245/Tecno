from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_faultlab_is_one_shot_and_after_real_post():
    text = (ROOT / "app/services/ichancy_jobs.py").read_text()
    assert "DELETE FROM bot_core.runtime_settings WHERE key='test.ichancy_fault'" in text
    post = text.index("payload = await client.deposit_to_player")
    hook = text.index('stage="after_post_response"')
    remote = text.index("await self.jobs.mark_remote_success(", hook)
    assert post < hook < remote
    assert "raise IchancyTransferUncertain(\"FAULTLAB simulated timeout after financial POST\")" in text


def test_faultlab_not_exposed_in_telegram_routers():
    for p in (ROOT / "app/routers").glob("*.py"):
        assert "ichancy_faultlab" not in p.read_text().lower()


def test_faultlab_decodes_runtime_jsonb_string_and_last_uses_real_column():
    worker = (ROOT / "app/services/ichancy_jobs.py").read_text()
    script = (ROOT / "scripts/ichancy_faultlab.py").read_text()
    assert "if isinstance(value, str):" in worker
    assert "value = json.loads(value)" in worker
    assert 'row["reconcile_attempt_count"]' in script
    assert 'row["reconcile_attempts"]' not in script
