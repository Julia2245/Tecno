from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_per_user_serialization_is_outer_middleware_and_reference_counted() -> None:
    main = _read("app/main.py")
    src = _read("app/middlewares/per_user.py")
    assert "PerUserSerializationMiddleware()" in main
    assert "self._entries: dict[int, _LockEntry]" in src
    assert "entry.users += 1" in src
    assert "self._entries.pop(user_id, None)" in src
    assert "await entry.lock.acquire()" in src


def test_access_middleware_does_not_create_unknown_user_before_start() -> None:
    src = _read("app/middlewares/user_access.py")
    users = _read("app/repositories/users.py")
    assert "touch_existing" in src
    assert "touch_existing_from_telegram" in users
    touch = users.split("async def touch_existing_from_telegram", 1)[1].split("async def set_blocked", 1)[0]
    assert "UPDATE bot_core.users" in touch
    assert "INSERT INTO bot_core.users" not in touch


def test_blocked_users_are_stopped_before_business_router() -> None:
    main = _read("app/main.py")
    access = _read("app/middlewares/user_access.py")
    assert "UserAccessMiddleware(user_service, settings, runtime_settings)" in main
    assert "if blocked:" in access
    assert "return None" in access


def test_admin_balance_adjustments_only_use_wallet_service() -> None:
    src = _read("app/routers/admin_users.py")
    balance = src.split("async def balance_value", 1)[1].split("@router.callback_query(F.data.startswith(\"admin:user:ichancy_balance:\"))", 1)[0]
    assert "wallet_service.credit(" in balance
    assert "wallet_service.debit(" in balance
    assert "UPDATE bot_core.wallet_accounts" not in balance
    assert "admin-user-{action}" in balance
    assert "await state.clear()" in balance


def test_admin_user_audit_is_immutable_and_separate_from_wallet_ledger() -> None:
    migration = _read("migrations/0015_user_management_and_activity.sql")
    assert "CREATE TABLE IF NOT EXISTS bot_core.admin_user_actions" in migration
    assert "admin_user_actions_immutable" in migration
    assert "BEFORE UPDATE OR DELETE" in migration
    assert "alternate balance column" in migration


def test_user_management_is_wired_into_admin_menu() -> None:
    kb = _read("app/keyboards/common.py")
    routers = _read("app/routers/__init__.py")
    assert 'callback_data="admin:users"' in kb
    assert "admin_users.router" in routers


def test_search_supports_telegram_and_ichancy_identifiers() -> None:
    repo = _read("app/repositories/users.py")
    assert "u.telegram_id=$1" in repo
    assert "LOWER(COALESCE(u.username,''))" in repo
    assert "LOWER(COALESCE(ia.username,''))" in repo
    assert "LOWER(COALESCE(ia.player_id,''))" in repo


def test_user_history_queries_are_read_only() -> None:
    repo = _read("app/repositories/users.py")
    history = repo.split("async def user_history", 1)[1]
    assert "SELECT" in history
    assert "UPDATE bot_core" not in history
    assert "INSERT INTO bot_core" not in history
    assert "DELETE FROM bot_core" not in history


def test_overview_is_read_only_and_uses_terminal_financial_states() -> None:
    repo = _read("app/repositories/users.py")
    overview = repo.split("async def admin_overview", 1)[1].split("async def user_history", 1)[0]
    assert "status='success'" in overview
    assert "SELECT" in overview
    assert "UPDATE " not in overview
    assert "INSERT " not in overview


def test_balance_audit_cannot_trigger_second_financial_write() -> None:
    src = _read("app/routers/admin_users.py")
    balance = src.split("async def balance_value", 1)[1].split("@router.callback_query(F.data == \"admin:users:overview\")", 1)[0]
    assert balance.index("await state.clear()") < balance.index("await user_service.log_admin_action")
    assert "except Exception:" in balance
    assert balance.count("wallet_service.credit(") == 1
    assert balance.count("wallet_service.debit(") == 1
