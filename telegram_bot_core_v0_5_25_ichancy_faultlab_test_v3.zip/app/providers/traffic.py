from __future__ import annotations

import asyncio
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass


class ProviderQueueBusy(RuntimeError):
    """The local provider queue is full/slow; fail fast instead of piling up work."""


@dataclass
class ProviderTrafficSnapshot:
    provider_id: str
    reads_started: int
    financial_started: int
    succeeded: int
    rate_limited: int
    server_errors: int
    network_errors: int
    queue_rejected: int
    read_retries: int
    in_flight_reads: int
    in_flight_financial: int
    max_in_flight_reads: int
    max_in_flight_financial: int
    avg_latency_ms: float


class ProviderTrafficGovernor:
    """Small per-provider traffic governor.

    The bot may process many Telegram updates concurrently, but upstream payment
    APIs usually have much lower burst limits.  Each provider gets an isolated
    governor so pressure on one provider cannot stall the other provider.

    Read-only calls may be retried by the caller because they are idempotent.
    Financial POSTs must never be retried automatically; the governor only
    limits/queues them and records metrics.
    """

    def __init__(
        self,
        provider_id: str,
        *,
        read_concurrency: int = 3,
        financial_concurrency: int = 1,
        queue_timeout_seconds: float = 2.0,
        financial_queue_timeout_seconds: float = 4.0,
        min_start_interval_seconds: float = 0.08,
        max_retry_after_seconds: float = 0.75,
    ) -> None:
        self.provider_id = str(provider_id or "provider")
        self.read_concurrency = max(1, int(read_concurrency))
        self.financial_concurrency = max(1, int(financial_concurrency))
        self.queue_timeout_seconds = max(0.05, float(queue_timeout_seconds))
        self.financial_queue_timeout_seconds = max(0.05, float(financial_queue_timeout_seconds))
        self.min_start_interval_seconds = max(0.0, float(min_start_interval_seconds))
        self.max_retry_after_seconds = max(0.0, float(max_retry_after_seconds))

        self._read_sem = asyncio.Semaphore(self.read_concurrency)
        self._financial_sem = asyncio.Semaphore(self.financial_concurrency)
        self._start_gate = asyncio.Lock()
        self._next_start_at = 0.0

        self._reads_started = 0
        self._financial_started = 0
        self._succeeded = 0
        self._rate_limited = 0
        self._server_errors = 0
        self._network_errors = 0
        self._queue_rejected = 0
        self._read_retries = 0
        self._in_flight_reads = 0
        self._in_flight_financial = 0
        self._max_in_flight_reads = 0
        self._max_in_flight_financial = 0
        self._latency_total_ms = 0.0
        self._latency_samples = 0

    async def _acquire(self, sem: asyncio.Semaphore, timeout: float) -> None:
        try:
            await asyncio.wait_for(sem.acquire(), timeout=timeout)
        except asyncio.TimeoutError as exc:
            self._queue_rejected += 1
            raise ProviderQueueBusy(f"{self.provider_id}_local_queue_busy") from exc

    async def _pace_start(self) -> None:
        if self.min_start_interval_seconds <= 0:
            return
        loop = asyncio.get_running_loop()
        async with self._start_gate:
            now = loop.time()
            delay = self._next_start_at - now
            if delay > 0:
                await asyncio.sleep(delay)
            self._next_start_at = loop.time() + self.min_start_interval_seconds

    @asynccontextmanager
    async def read_slot(self):
        await self._acquire(self._read_sem, self.queue_timeout_seconds)
        started = time.perf_counter()
        self._reads_started += 1
        self._in_flight_reads += 1
        self._max_in_flight_reads = max(self._max_in_flight_reads, self._in_flight_reads)
        try:
            await self._pace_start()
            yield
        finally:
            self._record_latency(started)
            self._in_flight_reads -= 1
            self._read_sem.release()

    @asynccontextmanager
    async def financial_slot(self):
        await self._acquire(self._financial_sem, self.financial_queue_timeout_seconds)
        started = time.perf_counter()
        self._financial_started += 1
        self._in_flight_financial += 1
        self._max_in_flight_financial = max(
            self._max_in_flight_financial, self._in_flight_financial
        )
        try:
            # Financial operations share the same provider start pacer with reads,
            # but have their own semaphore so a read burst cannot occupy the only
            # financial execution slot.
            await self._pace_start()
            yield
        finally:
            self._record_latency(started)
            self._in_flight_financial -= 1
            self._financial_sem.release()

    def _record_latency(self, started: float) -> None:
        self._latency_total_ms += (time.perf_counter() - started) * 1000.0
        self._latency_samples += 1

    def mark_success(self) -> None:
        self._succeeded += 1

    def mark_rate_limited(self) -> None:
        self._rate_limited += 1

    def mark_server_error(self) -> None:
        self._server_errors += 1

    def mark_network_error(self) -> None:
        self._network_errors += 1

    def mark_read_retry(self) -> None:
        self._read_retries += 1

    def retry_delay(self, retry_after: object = None, *, fallback: float = 0.20) -> float:
        try:
            parsed = float(str(retry_after or "").strip())
        except (TypeError, ValueError):
            parsed = float(fallback)
        parsed = max(0.0, parsed)
        return min(parsed, self.max_retry_after_seconds)

    def snapshot(self) -> ProviderTrafficSnapshot:
        avg = (
            self._latency_total_ms / self._latency_samples
            if self._latency_samples
            else 0.0
        )
        return ProviderTrafficSnapshot(
            provider_id=self.provider_id,
            reads_started=self._reads_started,
            financial_started=self._financial_started,
            succeeded=self._succeeded,
            rate_limited=self._rate_limited,
            server_errors=self._server_errors,
            network_errors=self._network_errors,
            queue_rejected=self._queue_rejected,
            read_retries=self._read_retries,
            in_flight_reads=self._in_flight_reads,
            in_flight_financial=self._in_flight_financial,
            max_in_flight_reads=self._max_in_flight_reads,
            max_in_flight_financial=self._max_in_flight_financial,
            avg_latency_ms=round(avg, 2),
        )
