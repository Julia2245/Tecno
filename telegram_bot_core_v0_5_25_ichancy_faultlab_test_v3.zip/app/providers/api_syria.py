from __future__ import annotations

import asyncio
from datetime import datetime
from decimal import Decimal
from zoneinfo import ZoneInfo

import aiohttp

from app.core.deposits import DepositProviderUnavailable, DepositVerificationFailed, ProviderTransaction
from app.core.money import parse_decimal
from app.providers.payment import ProviderFinancialError, ProviderFinancialDefiniteError, ProviderFinancialUncertain
from app.providers.traffic import ProviderQueueBusy, ProviderTrafficGovernor

_DAMASCUS = ZoneInfo("Asia/Damascus")


class ApiSyriaClient:
    """API SYRIA adapter used for verification, balances, and one-shot transfers."""

    provider_id = "api_syria"
    provider_label = "API SYRIA"

    def __init__(
        self,
        session: aiohttp.ClientSession,
        *,
        base_url: str,
        api_key: str,
        read_concurrency: int = 3,
        financial_concurrency: int = 1,
        queue_timeout_seconds: float = 2.0,
        financial_queue_timeout_seconds: float = 4.0,
        min_start_interval_seconds: float = 0.08,
        max_retry_after_seconds: float = 0.75,
    ) -> None:
        self.session = session
        self.base_url = (base_url or "").strip().rstrip("/")
        self.api_key = (api_key or "").strip()
        # Keep read verification fast, but govern provider traffic separately from
        # Telegram update concurrency.  GETs may retry once; financial POSTs never do.
        self._verify_timeout = aiohttp.ClientTimeout(total=10, connect=4, sock_read=8)
        self._read_timeout = aiohttp.ClientTimeout(total=12, connect=4, sock_read=10)
        self._traffic = ProviderTrafficGovernor(
            self.provider_id,
            read_concurrency=read_concurrency,
            financial_concurrency=financial_concurrency,
            queue_timeout_seconds=queue_timeout_seconds,
            financial_queue_timeout_seconds=financial_queue_timeout_seconds,
            min_start_interval_seconds=min_start_interval_seconds,
            max_retry_after_seconds=max_retry_after_seconds,
        )

    def traffic_snapshot(self) -> dict[str, object]:
        return vars(self._traffic.snapshot())

    @property
    def configured(self) -> bool:
        return bool(self.base_url and self.api_key)

    @property
    def _error_prefix(self) -> str:
        return str(getattr(self, "provider_id", "api_syria") or "api_syria")

    @property
    def _display_label(self) -> str:
        return str(getattr(self, "provider_label", "API SYRIA") or "API SYRIA")

    async def healthcheck(self) -> dict:
        return await self._generic_get({"resource": "status"})

    async def find_syriatel(self, tx: str, gsm: str) -> ProviderTransaction | None:
        payload = await self._find(resource="syriatel", tx=tx, gsm=gsm)
        if payload is None:
            return None
        obj = payload.get("transaction") or {}
        amount = self._amount(obj)
        return ProviderTransaction(
            provider="syriatel",
            tx_key=tx,
            amount=amount,
            currency="SYP",
            destination=gsm,
            occurred_at=self._parse_datetime(obj.get("date")),
            raw=dict(obj),
        )

    async def find_shamcash(self, tx: str, account_address: str) -> ProviderTransaction | None:
        payload = await self._find(
            resource="shamcash", tx=tx, account_address=account_address
        )
        if payload is None:
            return None
        obj = payload.get("transaction") or {}
        amount = self._amount(obj)
        currency = str(obj.get("currency") or "").strip().upper()
        if not currency:
            raise DepositVerificationFailed("provider currency is missing")
        return ProviderTransaction(
            provider="shamcash",
            tx_key=tx,
            amount=amount,
            currency=currency,
            destination=account_address,
            occurred_at=self._parse_datetime(obj.get("datetime") or obj.get("date")),
            raw=dict(obj),
        )


    async def list_accounts(self) -> dict:
        return await self._generic_get({"resource": "accounts", "action": "list"})

    async def syriatel_balance(self, gsm: str) -> tuple[str, Decimal]:
        data = await self._generic_get({"resource": "syriatel", "action": "balance", "gsm": gsm})
        info = data.get("data") or {}
        source = str(info.get("cash_code") or info.get("gsm") or gsm).strip()
        try:
            balance = parse_decimal(info.get("balance") or 0)
        except ValueError as exc:
            raise DepositProviderUnavailable(f"{self._error_prefix}_invalid_balance") from exc
        return source, balance

    async def resolve_shamcash_recipient_name(self, *, source: str, receiver: str) -> str:
        """Best-effort read-only ShamCash name lookup from provider history.

        Unknown addresses are still valid; this method never probes with a transfer.
        """
        wanted = str(receiver or "").strip().casefold()
        if not wanted or not source:
            return ""
        checks = (("outgoing_logs", "outgoing"), ("logs", "incoming"))
        for action, direction in checks:
            try:
                data = await self._generic_get({"resource": "shamcash", "action": action, "account_address": source})
            except Exception:
                continue
            payload = data.get("data") or {}
            items = payload.get("items") or [] if isinstance(payload, dict) else []
            for item in items if isinstance(items, list) else []:
                if not isinstance(item, dict):
                    continue
                other = str(
                    item.get("account") or item.get("to") or item.get("to_address") or item.get("receiver")
                    or item.get("from") or item.get("from_address") or item.get("sender") or ""
                ).strip()
                if other.casefold() != wanted:
                    continue
                keys = ("to_name", "receiver_name", "recipient_name", "toName") if direction == "outgoing" else ("from_name", "sender_name", "source_name", "fromName")
                for key in keys:
                    name = str(item.get(key) or "").strip()
                    if name and name != "-":
                        return name
        return ""

    async def transfer_syriatel(self, *, source: str, receiver: str, amount: Decimal, pin_code: str) -> dict:
        return await self._financial_post(
            {"resource": "syriatel", "action": "transfer_cash"},
            {"gsm": source, "to_gsm": receiver, "amount": self._decimal_text(amount), "pin_code": pin_code},
        )

    async def transfer_shamcash(
        self, *, source: str, receiver: str, amount: Decimal, currency: str = "SYP", note: str | None = "مبروك",
        pin: str | None = None,
    ) -> dict:
        form = {
            "account_address": source,
            "receive_key": receiver,
            "amount": self._decimal_text(amount),
            "currency": str(currency or "SYP").upper(),
        }
        # Manual transfer intentionally omits the optional note field when requested.
        # Normal bot withdrawals keep their existing "مبروك" note.
        if note is not None:
            form["note"] = str(note)
        return await self._financial_post(
            {"resource": "shamcash", "action": "transfer"},
            form,
        )

    async def shamcash_balances(self, account_address: str) -> list[dict]:
        """Return every visible Sham Cash currency balance for one linked account (read-only)."""
        data = await self._generic_get({
            "resource": "shamcash", "action": "balance", "account_address": account_address,
        })
        info = data.get("data") or {}
        balances = info.get("balances") or [] if isinstance(info, dict) else []
        return [dict(item) for item in balances if isinstance(item, dict)]

    async def shamcash_balance(self, account_address: str, currency: str = "SYP") -> Decimal:
        wanted = str(currency or "SYP").upper()
        for item in await self.shamcash_balances(account_address):
            if str(item.get("currency") or "").upper() != wanted:
                continue
            try:
                return parse_decimal(item.get("balance") or 0)
            except ValueError as exc:
                raise DepositProviderUnavailable(f"{self._error_prefix}_invalid_balance") from exc
        raise DepositProviderUnavailable(f"{self._error_prefix}_{wanted.lower()}_balance_missing")

    async def source_is_linked(self, kind: str, source: str) -> bool | None:
        """Read-only source validation against accounts/list.

        None means the diagnostic account-list read itself was unavailable.
        """
        try:
            accounts_data = await self.list_accounts()
        except Exception:
            return None
        try:
            data = accounts_data.get("data") or {}
            source_s = str(source or "").strip()
            if not source_s:
                return False
            if kind == "syriatel":
                for item in data.get("syriatel") or []:
                    if not isinstance(item, dict):
                        continue
                    vals = {str(item.get("gsm") or "").strip(), str(item.get("cash_code") or "").strip()}
                    if source_s in vals:
                        return True
                return False
            if kind == "shamcash":
                for item in data.get("shamcash") or []:
                    if isinstance(item, dict) and source_s == str(item.get("account_address") or "").strip():
                        return True
                return False
        except Exception:
            return None
        return None

    async def shamcash_outgoing_snapshot(self, source: str) -> tuple[set[str], bool]:
        source = str(source or "").strip()
        if not source:
            return set(), False
        try:
            data = await self._generic_get({
                "resource": "shamcash", "action": "outgoing_logs", "account_address": source,
            })
            items = ((data.get("data") or {}).get("items") or [])
            found = {self.provider_reference(item) for item in items if isinstance(item, dict)}
            return {x for x in found if x}, True
        except Exception:
            return set(), False

    async def syriatel_outgoing_snapshot(self, source: str) -> tuple[set[str], bool]:
        source = str(source or "").strip()
        if not source:
            return set(), False
        try:
            data = await self._generic_get({
                "resource": "syriatel", "action": "outgoing_history", "gsm": source, "period": "7",
            })
            items = ((data.get("data") or {}).get("items") or [])
            found = {self.provider_reference(item) for item in items if isinstance(item, dict)}
            return {x for x in found if x}, True
        except Exception:
            return set(), False

    async def resolve_shamcash_outgoing_transfer(
        self, *, source: str, receiver: str, amount: Decimal, currency: str, note: str = "",
        api_data: dict | None = None, exclude_tx_ids: set[str] | None = None,
    ) -> tuple[str, str]:
        """Resolve real Sham Cash tx number/name after one successful POST only.

        Subsequent work is GET-only, conservative and never
        repeats the financial transfer.
        """
        tx_no = self.provider_reference(api_data or {})
        recipient_name = self.shamcash_recipient_name(api_data or {})
        source_s = str(source or "").strip()
        if not source_s or (tx_no and recipient_name):
            return tx_no, recipient_name
        receiver_s = str(receiver or "").strip()
        currency_s = str(currency or "").upper().strip()
        note_s = str(note or "").strip()
        excluded = {str(x).strip() for x in (exclude_tx_ids or set()) if str(x).strip()}
        for delay in (0.0, 0.9, 1.8):
            if delay:
                await asyncio.sleep(delay)
            try:
                data = await self._generic_get({
                    "resource": "shamcash", "action": "outgoing_logs", "account_address": source_s,
                })
            except Exception:
                continue
            items = ((data.get("data") or {}).get("items") or [])
            structural: list[dict] = []
            exact_note: list[dict] = []
            for item in items if isinstance(items, list) else []:
                if not isinstance(item, dict):
                    continue
                item_tx = self.provider_reference(item)
                if item_tx and item_tx in excluded:
                    continue
                item_currency = str(item.get("currency") or "").upper().strip()
                if currency_s and item_currency and item_currency != currency_s:
                    continue
                if not self._same_amount(item.get("amount"), amount):
                    continue
                other = str(
                    item.get("account") or item.get("to") or item.get("to_address")
                    or item.get("receiver") or ""
                ).strip()
                if receiver_s and other and other != receiver_s:
                    continue
                structural.append(item)
                if note_s and str(item.get("note") or "").strip() == note_s:
                    exact_note.append(item)
            chosen = exact_note[0] if len(exact_note) == 1 else (structural[0] if not exact_note and len(structural) == 1 else None)
            if chosen is not None:
                if not tx_no:
                    tx_no = self.provider_reference(chosen)
                if not recipient_name:
                    recipient_name = self.shamcash_recipient_name(chosen)
            if tx_no:
                break
        return tx_no, recipient_name

    async def resolve_syriatel_outgoing_transfer(
        self, *, source: str, receiver: str, amount: Decimal, exclude_tx_ids: set[str] | None = None,
    ) -> str:
        source_s = str(source or "").strip()
        receiver_s = str(receiver or "").strip()
        excluded = {str(x).strip() for x in (exclude_tx_ids or set()) if str(x).strip()}
        if not source_s:
            return ""
        for delay in (0.0, 0.9, 1.8):
            if delay:
                await asyncio.sleep(delay)
            try:
                data = await self._generic_get({
                    "resource": "syriatel", "action": "outgoing_history", "gsm": source_s, "period": "7",
                })
            except Exception:
                continue
            items = ((data.get("data") or {}).get("items") or [])
            matches: list[dict] = []
            for item in items if isinstance(items, list) else []:
                if not isinstance(item, dict):
                    continue
                tx = self.provider_reference(item)
                if tx and tx in excluded:
                    continue
                if not self._same_amount(item.get("amount"), amount):
                    continue
                other = str(item.get("to") or item.get("to_gsm") or item.get("receiver") or item.get("receiver_gsm") or "").strip()
                if receiver_s and other and other != receiver_s:
                    continue
                matches.append(item)
            if len(matches) == 1:
                tx = self.provider_reference(matches[0])
                if tx:
                    return tx
        return ""

    @staticmethod
    def provider_reference(value: object) -> str:
        wanted = (
            "billcode", "bill_code", "transaction_no", "transaction_number", "tran_id",
            "transaction_id", "transactionId", "tx_no", "reference_no", "reference",
            "operation_no", "operation_id",
        )
        def walk(obj: object) -> str:
            if isinstance(obj, dict):
                for key in wanted:
                    raw = obj.get(key)
                    if raw not in (None, ""):
                        return str(raw).strip()
                for child in obj.values():
                    found = walk(child)
                    if found:
                        return found
            elif isinstance(obj, list):
                for child in obj:
                    found = walk(child)
                    if found:
                        return found
            return ""
        return walk(value)

    @staticmethod
    def shamcash_recipient_name(value: object) -> str:
        wanted = ("to_name", "receiver_name", "recipient_name", "toName", "receiverName", "recipientName")
        recipient_keys = ("userName", "username", "name", "to_name", "receiver_name")
        def clean(raw: object) -> str:
            text = str(raw or "").strip()
            return text if text and text != "-" else ""
        def walk(obj: object) -> str:
            if isinstance(obj, dict):
                recipient = obj.get("recipient")
                if isinstance(recipient, dict):
                    for key in recipient_keys:
                        text = clean(recipient.get(key))
                        if text:
                            return text
                for key in wanted:
                    text = clean(obj.get(key))
                    if text:
                        return text
                for child in obj.values():
                    found = walk(child)
                    if found:
                        return found
            elif isinstance(obj, list):
                for child in obj:
                    found = walk(child)
                    if found:
                        return found
            return ""
        return walk(value)

    @staticmethod
    def _same_amount(left: object, right: object) -> bool:
        try:
            return parse_decimal(left) == parse_decimal(right)
        except Exception:
            return str(left or "").replace(",", "").strip() == str(right or "").replace(",", "").strip()

    async def _read_json(self, params: dict[str, str], *, timeout: aiohttp.ClientTimeout) -> dict:
        """Execute an idempotent provider GET with bounded local queueing.

        A read may retry once on a transient network/5xx/429 response.  The retry
        is deliberately short so the user gets a clear failure instead of waiting
        behind a long provider backlog.
        """
        headers = {"X-Api-Key": self.api_key, "Accept": "application/json"}
        for attempt in range(2):
            retry_delay: float | None = None
            try:
                async with self._traffic.read_slot():
                    async with self.session.get(
                        self.base_url, params=params, headers=headers, timeout=timeout
                    ) as response:
                        if response.status == 429:
                            self._traffic.mark_rate_limited()
                            if attempt == 0:
                                retry_delay = self._traffic.retry_delay(
                                    response.headers.get("Retry-After"), fallback=0.20
                                )
                            else:
                                raise DepositProviderUnavailable(
                                    f"{self._error_prefix}_rate_limit"
                                )
                        elif response.status >= 500:
                            self._traffic.mark_server_error()
                            if attempt == 0:
                                retry_delay = self._traffic.retry_delay(None, fallback=0.18)
                            else:
                                raise DepositProviderUnavailable(
                                    f"{self._error_prefix}_http_{response.status}"
                                )
                        elif response.status != 200:
                            raise DepositProviderUnavailable(
                                f"{self._error_prefix}_http_{response.status}"
                            )
                        else:
                            try:
                                data = await response.json(content_type=None)
                            except Exception as exc:
                                raise DepositProviderUnavailable(
                                    f"{self._error_prefix}_invalid_json"
                                ) from exc
                            if not isinstance(data, dict):
                                raise DepositProviderUnavailable(
                                    f"{self._error_prefix}_unexpected_response"
                                )
                            if data.get("success") is False:
                                raise DepositProviderUnavailable(
                                    str(data.get("error") or f"{self._error_prefix}_unsuccessful")
                                )
                            self._traffic.mark_success()
                            return data
            except ProviderQueueBusy as exc:
                raise DepositProviderUnavailable(
                    f"{self._error_prefix}_busy"
                ) from exc
            except DepositProviderUnavailable:
                raise
            except (aiohttp.ClientError, asyncio.TimeoutError, TimeoutError) as exc:
                self._traffic.mark_network_error()
                if attempt == 0:
                    retry_delay = self._traffic.retry_delay(None, fallback=0.15)
                else:
                    raise DepositProviderUnavailable(
                        f"{self._error_prefix}_network_error"
                    ) from exc

            if retry_delay is not None:
                self._traffic.mark_read_retry()
                if retry_delay > 0:
                    await asyncio.sleep(retry_delay)
                continue

        raise DepositProviderUnavailable(f"{self._error_prefix}_unavailable")

    async def _generic_get(self, params: dict[str, str]) -> dict:
        if not self.configured:
            raise DepositProviderUnavailable(f"{self._display_label} is not configured")
        merged = dict(params)
        merged["api_key"] = self.api_key
        return await self._read_json(merged, timeout=self._read_timeout)

    async def _financial_post(self, params: dict[str, str], form: dict[str, str]) -> dict:
        if not self.configured:
            raise ApiSyriaFinancialDefiniteError("API Syria is not configured")
        merged = dict(params)
        merged["api_key"] = self.api_key
        headers = {
            "X-Api-Key": self.api_key,
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        try:
            # Exactly one financial POST.  The governor limits/queues it, but this
            # method never repeats a POST after network, timeout, 429, or 5xx.
            async with self._traffic.financial_slot():
                async with self.session.post(
                    self.base_url, params=merged, data=form, headers=headers,
                    timeout=aiohttp.ClientTimeout(total=35, connect=5, sock_read=30),
                ) as response:
                    text = await response.text()
                    try:
                        data = await response.json(content_type=None)
                    except Exception as exc:
                        if response.status >= 500 or response.status == 200:
                            self._traffic.mark_server_error()
                            raise ApiSyriaFinancialUncertain(
                                f"non-json HTTP {response.status}: {text[:300]}"
                            ) from exc
                        raise ApiSyriaFinancialDefiniteError(
                            f"HTTP {response.status}: {text[:300]}"
                        ) from exc
                    if response.status == 429:
                        self._traffic.mark_rate_limited()
                        raise ApiSyriaFinancialDefiniteError("API Syria rate limit")
                    if response.status >= 500:
                        self._traffic.mark_server_error()
                        raise ApiSyriaFinancialUncertain(
                            f"HTTP {response.status}: {text[:300]}"
                        )
                    if response.status >= 400:
                        raise ApiSyriaFinancialDefiniteError(
                            str(data.get("error") or data.get("message") or f"HTTP {response.status}")
                        )
                    if not isinstance(data, dict):
                        raise ApiSyriaFinancialUncertain("unexpected financial response")
                    if data.get("success") is False:
                        raise ApiSyriaFinancialDefiniteError(
                            str(data.get("error") or data.get("message") or "provider rejected transfer")
                        )
                    self._traffic.mark_success()
                    return data
        except ProviderQueueBusy as exc:
            raise ApiSyriaFinancialDefiniteError("API Syria busy; try again shortly") from exc
        except (ApiSyriaFinancialDefiniteError, ApiSyriaFinancialUncertain):
            raise
        except (aiohttp.ClientError, asyncio.TimeoutError, TimeoutError) as exc:
            self._traffic.mark_network_error()
            raise ApiSyriaFinancialUncertain(
                f"financial network outcome uncertain: {exc}"
            ) from exc

    @staticmethod
    def _decimal_text(value: Decimal) -> str:
        if value == value.to_integral_value():
            return str(int(value))
        return format(value.normalize(), "f")

    async def _find(
        self,
        *,
        resource: str,
        tx: str,
        gsm: str | None = None,
        account_address: str | None = None,
    ) -> dict | None:
        if not self.configured:
            raise DepositProviderUnavailable(f"{self._display_label} is not configured")

        params: dict[str, str] = {
            "resource": resource,
            "action": "find_tx",
            "tx": tx,
            "api_key": self.api_key,
        }
        if gsm:
            params["gsm"] = gsm
        if account_address:
            params["account_address"] = account_address

        data = await self._read_json(params, timeout=self._verify_timeout)
        payload = data.get("data") or {}
        if not isinstance(payload, dict):
            raise DepositProviderUnavailable(f"{self._error_prefix}_invalid_payload")
        if not payload.get("found"):
            return None
        return payload

    @staticmethod
    def _amount(obj: dict) -> Decimal:
        try:
            amount = parse_decimal(obj.get("amount"))
        except ValueError as exc:
            raise DepositVerificationFailed("provider amount is invalid") from exc
        if amount <= 0:
            raise DepositVerificationFailed("provider amount must be positive")
        return amount

    @staticmethod
    def _parse_datetime(raw: object) -> datetime | None:
        text = str(raw or "").strip()
        if not text:
            return None
        # API Syria historically returned local Syrian timestamps without timezone.
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
            try:
                parsed = datetime.strptime(text, fmt)
                return parsed.replace(tzinfo=_DAMASCUS)
            except ValueError:
                continue
        # A calendar date without a time is not precise enough for an automatic
        # financial cutover check. Failing closed is safer than inventing a time
        # that could turn an old transfer into a valid fresh one.
        try:
            datetime.strptime(text, "%Y-%m-%d")
            return None
        except ValueError:
            pass
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=_DAMASCUS)
            return parsed
        except ValueError:
            return None


class ApiSyriaFinancialError(ProviderFinancialError):
    pass


class ApiSyriaFinancialDefiniteError(ProviderFinancialDefiniteError, ApiSyriaFinancialError):
    """Provider definitely rejected the transfer; safe to leave request pending."""


class ApiSyriaFinancialUncertain(ProviderFinancialUncertain, ApiSyriaFinancialError):
    """Transfer may have executed. Never repeat the POST without reconciliation."""
