from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import aiohttp
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode

from app.config import get_settings
from app.core.db import Database
from app.core.logging import configure_logging
from app.middlewares.callback_ack import FastCallbackAckMiddleware
from app.middlewares.latency import UpdateLatencyMiddleware
from app.middlewares.maintenance import MaintenanceModeMiddleware
from app.middlewares.per_user import PerUserSerializationMiddleware
from app.middlewares.user_access import UserAccessMiddleware
from app.repositories.users import UserRepository
from app.repositories.deposits import DepositRepository
from app.repositories.wallet import WalletRepository
from app.repositories.runtime_settings import RuntimeSettingsRepository
from app.repositories.outbox import OutboxRepository
from app.repositories.ichancy import IchancyRepository
from app.repositories.ichancy_jobs import IchancyJobRepository
from app.repositories.withdrawals import WithdrawRepository
from app.repositories.broadcasts import BroadcastRepository
from app.repositories.manual_transfers import ManualTransferRepository
from app.repositories.finance_rules import FinanceRulesRepository
from app.repositories.ichancy_replacements import CashierReplacementRepository
from app.repositories.admin_ops import AdminOpsRepository
from app.repositories.gifts_loyalty import GiftsLoyaltyRepository
from app.repositories.competitions import CompetitionRepository
from app.routers import build_root_router
from app.services.users import UserService
from app.services.deposits import DepositService
from app.providers.api_syria import ApiSyriaClient
from app.providers.tsa import TsaApiClient
from app.providers.payment import PaymentProviderManager
from app.providers.binance import BinanceDepositClient
from app.services.wallet import WalletService
from app.services.runtime_settings import RuntimeSettingsService
from app.services.reports import ReportsService
from app.services.outbox import NotificationOutboxWorker
from app.services.ichancy_accounts import IchancyAccountsService
from app.services.ichancy_jobs import IchancyJobService
from app.services.withdrawals import WithdrawService
from app.services.broadcasts import BroadcastService
from app.services.manual_transfers import ManualTransferService
from app.services.finance_rules import FinanceRulesService
from app.services.ichancy_replacements import CashierReplacementService
from app.services.admin_access import AdminAccessService
from app.services.backups import BackupService, process_pending_restore
from app.services.gifts_loyalty import GiftService, LoyaltyService, LoyaltyReconciliationWorker
from app.services.competitions import CompetitionService, CompetitionMaintenanceWorker
from app.services.matches import MatchesService
from app.services.rewards import (
    CashbackPrincipalTracker, WheelService, ReferralService, CashbackService, RewardsMaintenanceService,
)
from app.core.crypto import CredentialCipher

logger = logging.getLogger(__name__)
PROJECT_ROOT = Path(__file__).resolve().parent.parent


async def run() -> None:
    settings = get_settings()
    configure_logging(settings.log_level)

    # A confirmed restore is applied only during a clean process startup, before
    # any DB pool, Telegram polling or financial worker exists.
    restore_boot_result = await asyncio.to_thread(process_pending_restore, settings.database_url, PROJECT_ROOT)
    if restore_boot_result:
        logger.warning("Deferred restore processed at startup: %s", restore_boot_result.get("status"))

    db = Database(
        settings.database_url,
        min_size=settings.pg_pool_min,
        max_size=settings.pg_pool_max,
        command_timeout=settings.pg_command_timeout,
    )
    await db.connect()
    await db.apply_migrations(PROJECT_ROOT / "migrations")

    admin_ops_repository = AdminOpsRepository(db)
    admin_access = AdminAccessService(admin_ops_repository, settings)
    await admin_access.load()

    session = AiohttpSession(limit=settings.telegram_connection_limit)
    bot = Bot(
        token=settings.bot_token,
        session=session,
        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML,
            link_preview_is_disabled=True,
        ),
    )
    dp = Dispatcher()

    user_repository = UserRepository(db)
    user_service = UserService(user_repository)
    wallet_repository = WalletRepository(db)
    wallet_service = WalletService(wallet_repository)
    deposit_repository = DepositRepository(db)
    finance_rules_repository = FinanceRulesRepository(db)
    runtime_repository = RuntimeSettingsRepository(db)
    runtime_settings = RuntimeSettingsService(
        runtime_repository,
        default_overrides={
            "ichancy.username_prefix": settings.ichancy_username_prefix,
            # Runtime-editable receiving accounts.  The .env values remain the
            # bootstrap/fallback values for a fresh database only.
            "deposit.syriatel.codes": ",".join(settings.syriatel_codes),
            "deposit.sham.address_syp": settings.shamcash_address_syp.strip(),
            "deposit.sham.address_usd": settings.shamcash_address_usd.strip(),
            "payments.api_provider": settings.payment_api_provider,
            # Keep the legacy .env channel as the bootstrap/fallback for the
            # runtime-editable bot-deposit channel. A value saved from the admin
            # panel still wins because runtime DB values are loaded afterwards.
            "notify.bot_deposits": settings.deposit_notify_chat_id,
            "notify.manual_deposit_requests": settings.deposit_manual_review_chat_id,
            # Compatibility only for already-queued rows created before the
            # deposit/withdraw notification channels were split. New events never
            # target notify.bot_operations.
            "notify.bot_operations": settings.deposit_notify_chat_id,
            "bonus.syriatel_pct": str(settings.bonus_syriatel_pct),
            "bonus.sham_syp_pct": str(settings.bonus_sham_syp_pct),
            "bonus.sham_usd_pct": str(settings.bonus_sham_usd_pct),
            "bonus.binance_usdt_pct": str(settings.bonus_binance_usdt_pct),
            "bonus.whish_money_pct": str(settings.bonus_whish_money_pct),
        },
    )
    await runtime_settings.load()
    backup_service = BackupService(
        admin_ops_repository, runtime_settings, bot, dsn=settings.database_url, project_root=PROJECT_ROOT
    )
    restore_result = await backup_service.consume_restore_result()
    if restore_result is None:
        await backup_service.recover_stale_restore_lock()
    reports_service = ReportsService(db)
    competition_repository = CompetitionRepository(db)
    competition_service = CompetitionService(competition_repository, runtime_settings)
    broadcast_repository = BroadcastRepository(db)

    # Global update guards are wired only after Runtime Settings is loaded, so
    # maintenance state is available synchronously from the first polled update.
    # Fast callback ACK remains inside the callback observer; maintenance blocks
    # stale callbacks one layer earlier and explicitly answers them itself.
    dp.callback_query.middleware(FastCallbackAckMiddleware())
    dp.update.outer_middleware(UpdateLatencyMiddleware(settings.slow_update_warning_ms))
    dp.update.outer_middleware(MaintenanceModeMiddleware(runtime_settings, settings))
    dp.update.outer_middleware(PerUserSerializationMiddleware())
    # Blocked users are stopped before any business router. This middleware never
    # creates unknown users, preserving first-touch /start referral attribution.
    dp.update.outer_middleware(UserAccessMiddleware(user_service, settings, runtime_settings))
    dp.include_router(build_root_router())

    finance_rules = FinanceRulesService(finance_rules_repository, runtime_settings, wallet_service)
    outbox_repository = OutboxRepository(db)
    outbox_worker = NotificationOutboxWorker(outbox_repository, runtime_settings, bot)
    ichancy_repository = IchancyRepository(db)
    ichancy_job_repository = IchancyJobRepository(db)
    withdraw_repository = WithdrawRepository(db)
    manual_transfer_repository = ManualTransferRepository(db)

    # One deployment-level Fernet key protects stored operational secrets.
    # It already protects iChancy credentials; reuse it for the runtime Syriatel
    # withdrawal PIN so the PIN is never stored as plaintext in runtime_settings.
    cipher = None
    if settings.ichancy_credentials_key:
        try:
            cipher = CredentialCipher(settings.ichancy_credentials_key)
        except Exception:
            logger.exception("Invalid ICHANCY_CREDENTIALS_KEY; encrypted credential operations disabled")

    # A restart while a provider POST was in-flight must never silently re-send it.
    # Any stale `processing` request is moved to manual review; explicit
    # `provider_success` rows remain locally finalizable without another POST.
    recovered_withdraws = await withdraw_repository.recover_stale_processing()
    if recovered_withdraws:
        logger.warning("Recovered %s interrupted withdrawal(s) to needs_review", recovered_withdraws)
    recovered_manual_transfers = await manual_transfer_repository.recover_stale_processing()
    if recovered_manual_transfers:
        logger.warning(
            "Recovered %s interrupted manual transfer(s) to needs_review; no financial retry was attempted",
            recovered_manual_transfers,
        )
    replacement_repository = CashierReplacementRepository(db)

    # Payment APIs are intentionally isolated at the HTTP transport level.
    # A slow/rate-limited TSA connection pool cannot consume API SYRIA sockets
    # (and vice versa).  Long-lived sessions preserve DNS/TCP/TLS keep-alive.
    api_syria_session = aiohttp.ClientSession(
        connector=aiohttp.TCPConnector(
            limit=12, limit_per_host=8, ttl_dns_cache=300, keepalive_timeout=45
        ),
        timeout=aiohttp.ClientTimeout(total=30, connect=5, sock_read=25),
        headers={"Accept": "application/json"},
    )
    tsa_session = aiohttp.ClientSession(
        connector=aiohttp.TCPConnector(
            limit=12, limit_per_host=8, ttl_dns_cache=300, keepalive_timeout=45
        ),
        timeout=aiohttp.ClientTimeout(total=30, connect=5, sock_read=25),
        headers={"Accept": "application/json"},
    )
    provider_session = aiohttp.ClientSession(
        connector=aiohttp.TCPConnector(limit=40, limit_per_host=20, ttl_dns_cache=300, keepalive_timeout=45),
        timeout=aiohttp.ClientTimeout(total=30, connect=5, sock_read=25),
        headers={"Accept": "application/json"},
    )
    matches_service = MatchesService(
        provider_session, runtime_settings, api_key=settings.football_api_key,
        base_url=settings.football_api_base_url, cache_minutes=settings.football_cache_minutes,
    )
    api_syria = ApiSyriaClient(
        api_syria_session,
        base_url=settings.api_syria_base_url,
        api_key=settings.api_syria_key,
        read_concurrency=settings.api_syria_read_concurrency,
        financial_concurrency=settings.api_syria_financial_concurrency,
        queue_timeout_seconds=settings.api_syria_queue_timeout_seconds,
        financial_queue_timeout_seconds=settings.api_syria_financial_queue_timeout_seconds,
        min_start_interval_seconds=settings.api_syria_min_start_interval_ms / 1000.0,
        max_retry_after_seconds=settings.api_syria_max_retry_after_seconds,
    )
    tsa_api = TsaApiClient(
        tsa_session,
        base_url=settings.tsa_api_base_url,
        api_key=settings.tsa_api_key,
        read_concurrency=settings.tsa_read_concurrency,
        financial_concurrency=settings.tsa_financial_concurrency,
        queue_timeout_seconds=settings.tsa_queue_timeout_seconds,
        financial_queue_timeout_seconds=settings.tsa_financial_queue_timeout_seconds,
        min_start_interval_seconds=settings.tsa_min_start_interval_ms / 1000.0,
        max_retry_after_seconds=settings.tsa_max_retry_after_seconds,
    )
    payment_providers = PaymentProviderManager(
        runtime_settings,
        providers=[api_syria, tsa_api],
        default_provider=settings.payment_api_provider,
    )
    binance_client = BinanceDepositClient(
        provider_session,
        api_key=settings.binance_api_key,
        api_secret=settings.binance_api_secret,
        base_url=settings.binance_base_url,
    )

    # Build iChancy accounts before the reward engines: reference-style cashback and
    # referral cycle settlement both require authoritative player balances.
    ichancy_accounts = IchancyAccountsService(
        ichancy_repository, runtime_settings, settings, provider_session, cipher
    )
    if settings.ichancy_api_username and settings.ichancy_api_password:
        try:
            await ichancy_accounts.bootstrap_from_env()
        except Exception:
            logger.exception("Could not bootstrap iChancy cashier from environment")

    cashback_tracker = CashbackPrincipalTracker(db)
    wheel_service = WheelService(db, runtime_settings, wallet_service)
    referral_service = ReferralService(db, runtime_settings, wallet_service, ichancy_accounts, outbox_repository)
    cashback_service = CashbackService(db, runtime_settings, wallet_service, ichancy_accounts, cashback_tracker, outbox_repository)
    await cashback_service.ensure_cycle()

    gifts_loyalty_repository = GiftsLoyaltyRepository(db)
    gift_service = GiftService(db, gifts_loyalty_repository, runtime_settings, wallet_service)
    loyalty_service = LoyaltyService(db, gifts_loyalty_repository, runtime_settings, wallet_service)
    loyalty_worker = LoyaltyReconciliationWorker(loyalty_service)

    deposit_service = DepositService(
        deposit_repository,
        wallet_service,
        settings,
        api_syria,
        binance_client,
        runtime_settings,
        outbox_repository,
        outbox_worker,
        payment_providers=payment_providers,
        finance_rules=finance_rules,
        cashback_tracker=cashback_tracker,
        referral_service=referral_service,
        loyalty_service=loyalty_service,
        competition_service=competition_service,
    )
    withdraw_service = WithdrawService(
        withdraw_repository,
        wallet_service,
        runtime_settings,
        settings,
        api_syria,
        outbox_worker,
        deposit_repository,
        cipher,
        payment_providers=payment_providers,
        finance_rules=finance_rules,
        cashback_tracker=cashback_tracker,
    )
    manual_transfer_service = ManualTransferService(
        manual_transfer_repository, runtime_settings, api_syria, withdraw_service,
        payment_providers=payment_providers,
    )

    ichancy_jobs = IchancyJobService(
        ichancy_job_repository, ichancy_repository, ichancy_accounts, wallet_service, runtime_settings, outbox_worker, bot,
        cashback_tracker=cashback_tracker,
        competition_service=competition_service,
    )
    replacement_service = CashierReplacementService(
        replacement_repository, ichancy_repository, ichancy_accounts, ichancy_job_repository,
        ichancy_jobs, wallet_service, runtime_settings, outbox_repository, outbox_worker, bot,
    )
    broadcast_service = BroadcastService(
        broadcast_repository, bot,
        per_minute=settings.broadcast_per_minute,
        concurrency=settings.broadcast_concurrency,
        poll_seconds=settings.broadcast_worker_poll_seconds,
    )
    outbox_task = asyncio.create_task(outbox_worker.run(), name="notification-outbox-worker")
    backup_task = asyncio.create_task(backup_service.run_auto_worker(), name="postgres-backup-worker")
    broadcast_task = asyncio.create_task(broadcast_service.run_worker(), name="broadcast-worker")
    ichancy_task = asyncio.create_task(
        ichancy_jobs.run_worker(settings.ichancy_worker_poll_seconds, settings.ichancy_reconcile_delay_seconds),
        name="ichancy-financial-worker",
    )
    replacement_task = asyncio.create_task(
        replacement_service.run_worker(), name="ichancy-cashier-replacement-worker"
    )
    rewards_maintenance = RewardsMaintenanceService(
        cashback_service, referral_service, bot, settings.super_admin_ids
    )
    rewards_task = asyncio.create_task(
        rewards_maintenance.run(), name="cashback-referral-maintenance-worker"
    )
    loyalty_task = asyncio.create_task(
        loyalty_worker.run(), name="loyalty-reconciliation-worker"
    )
    competition_worker = CompetitionMaintenanceWorker(competition_service, bot, settings.super_admin_ids, settings.required_channel)
    competition_task = asyncio.create_task(
        competition_worker.run(settings.competition_worker_poll_seconds), name="competition-maintenance-worker"
    )
    matches_task = asyncio.create_task(
        matches_service.run_daily_worker(), name="football-daily-cache-worker"
    )

    try:
        me = await bot.get_me()
        if not settings.bot_display_name:
            # Mutable runtime display label only; no project branding is hardcoded.
            settings.bot_display_name = me.first_name or "البوت"
        logger.info("Starting @%s (%s)", me.username or "", me.id)

        # False by default so a restart never silently discards legitimate updates.
        await bot.delete_webhook(drop_pending_updates=settings.drop_pending_updates)
        await dp.start_polling(
            bot,
            settings=settings,
            db=db,
            user_service=user_service,
            wallet_service=wallet_service,
            deposit_service=deposit_service,
            runtime_settings=runtime_settings,
            reports_service=reports_service,
            broadcast_service=broadcast_service,
            admin_ops_repository=admin_ops_repository,
            admin_access=admin_access,
            backup_service=backup_service,
            finance_rules=finance_rules,
            outbox_worker=outbox_worker,
            ichancy_accounts=ichancy_accounts,
            ichancy_jobs=ichancy_jobs,
            withdraw_service=withdraw_service,
            manual_transfer_service=manual_transfer_service,
            payment_providers=payment_providers,
            binance_client=binance_client,
            replacement_repository=replacement_repository,
            replacement_service=replacement_service,
            cashback_tracker=cashback_tracker,
            cashback_service=cashback_service,
            referral_service=referral_service,
            wheel_service=wheel_service,
            gift_service=gift_service,
            loyalty_service=loyalty_service,
            competition_service=competition_service,
            matches_service=matches_service,
            allowed_updates=dp.resolve_used_update_types(),
            tasks_concurrency_limit=settings.max_concurrent_updates,
            close_bot_session=False,
        )
    finally:
        ichancy_jobs.stop()
        replacement_service.stop()
        rewards_maintenance.stop()
        loyalty_worker.stop()
        competition_worker.stop()
        matches_service.stop()
        outbox_worker.stop()
        broadcast_service.stop()
        backup_service.stop()
        for task in (matches_task, competition_task, loyalty_task, rewards_task, replacement_task, ichancy_task, broadcast_task, backup_task, outbox_task):
            task.cancel()
        await asyncio.gather(matches_task, competition_task, loyalty_task, rewards_task, replacement_task, ichancy_task, broadcast_task, backup_task, outbox_task, return_exceptions=True)
        await asyncio.gather(
            api_syria_session.close(),
            tsa_session.close(),
            provider_session.close(),
            return_exceptions=True,
        )
        await db.close()
        await bot.session.close()


def main() -> None:
    asyncio.run(run())


if __name__ == "__main__":
    main()
