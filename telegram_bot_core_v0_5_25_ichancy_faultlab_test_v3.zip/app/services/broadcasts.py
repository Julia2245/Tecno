from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Any
from uuid import UUID

from aiogram import Bot
from aiogram.exceptions import (
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramNetworkError,
    TelegramRetryAfter,
    TelegramServerError,
)
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.repositories.broadcasts import BroadcastRepository

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class BroadcastSendResult:
    status: str
    message_id: int | None = None
    error: str | None = None


class _StartPacer:
    def __init__(self, per_minute: int) -> None:
        self.interval = 60.0 / max(5, int(per_minute))
        self._lock = asyncio.Lock()
        self._next_at = 0.0

    async def wait(self) -> None:
        async with self._lock:
            now = time.monotonic()
            if self._next_at > now:
                await asyncio.sleep(self._next_at - now)
                now = time.monotonic()
            self._next_at = max(now, self._next_at) + self.interval


class BroadcastService:
    def __init__(
        self,
        repository: BroadcastRepository,
        bot: Bot,
        *,
        per_minute: int = 700,
        concurrency: int = 8,
        poll_seconds: float = 1.0,
    ) -> None:
        self.repository = repository
        self.bot = bot
        self.per_minute = max(5, min(5000, int(per_minute)))
        self.concurrency = max(1, min(32, int(concurrency)))
        self.poll_seconds = max(0.2, min(10.0, float(poll_seconds)))
        self._stopping = asyncio.Event()

    def stop(self) -> None:
        self._stopping.set()

    async def create_draft(
        self,
        *,
        admin_id: int,
        source_chat_id: int,
        source_message_id: int,
        content_type: str,
        preview_text: str,
    ) -> UUID:
        return await self.repository.create_draft(
            created_by=admin_id,
            source_chat_id=source_chat_id,
            source_message_id=source_message_id,
            content_type=content_type,
            preview_text=preview_text,
            per_minute=self.per_minute,
            concurrency=self.concurrency,
        )

    async def eligible_count(self) -> int:
        return await self.repository.eligible_count()

    async def confirm(
        self,
        campaign_id: UUID,
        *,
        actor_id: int,
        admin_chat_id: int,
        admin_status_message_id: int,
    ) -> dict[str, Any] | None:
        return await self.repository.confirm_campaign(
            campaign_id,
            actor_id=actor_id,
            admin_chat_id=admin_chat_id,
            admin_status_message_id=admin_status_message_id,
        )

    async def cancel_draft(self, campaign_id: UUID, *, actor_id: int) -> bool:
        return await self.repository.cancel_draft(campaign_id, actor_id=actor_id)

    async def get(self, campaign_id: UUID) -> dict[str, Any] | None:
        return await self.repository.get_campaign(campaign_id)

    async def history(self, *, page: int, page_size: int = 8) -> tuple[list[dict[str, Any]], int]:
        p = max(0, int(page))
        return await self.repository.list_campaigns(limit=page_size, offset=p * page_size)

    async def request_stop(self, campaign_id: UUID) -> bool:
        return await self.repository.request_stop(campaign_id)

    async def request_delete(self, campaign_id: UUID) -> dict[str, Any] | None:
        return await self.repository.request_delete(campaign_id)

    async def run_worker(self) -> None:
        recovered = await self.repository.recover_interrupted()
        if recovered.get("unknown_sends"):
            logger.warning(
                "Broadcast recovery marked %s in-flight delivery(s) unknown across %s campaign(s)",
                recovered["unknown_sends"], recovered["campaigns"],
            )
        logger.info("Broadcast worker started")
        while not self._stopping.is_set():
            try:
                delete_campaign = await self.repository.claim_delete_campaign()
                if delete_campaign:
                    await self._process_delete(delete_campaign)
                    continue
                campaign = await self.repository.claim_send_campaign()
                if campaign:
                    await self._process_send(campaign)
                    continue
                try:
                    await asyncio.wait_for(self._stopping.wait(), timeout=self.poll_seconds)
                except asyncio.TimeoutError:
                    pass
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Broadcast worker loop failure")
                try:
                    await asyncio.wait_for(self._stopping.wait(), timeout=min(3.0, self.poll_seconds * 2))
                except asyncio.TimeoutError:
                    pass
        logger.info("Broadcast worker stopped")

    async def _process_send(self, campaign: dict[str, Any]) -> None:
        cid = UUID(str(campaign["id"]))
        concurrency = max(1, min(32, int(campaign.get("concurrency") or self.concurrency)))
        per_minute = max(5, min(5000, int(campaign.get("per_minute") or self.per_minute)))
        pacer = _StartPacer(per_minute)
        last_status = 0.0
        try:
            await self._edit_status(campaign, self._render_status(campaign, running=True), running=True)
            while not self._stopping.is_set():
                latest = await self.repository.get_campaign(cid)
                if latest is None:
                    return
                if latest.get("stop_requested"):
                    final = await self.repository.finish_send_campaign(cid)
                    if final:
                        await self._edit_status(final, self._render_status(final), running=False)
                    return
                ids = await self.repository.claim_send_batch(cid, limit=concurrency)
                if not ids:
                    pending = await self.repository.pending_send_count(cid)
                    if pending == 0:
                        final = await self.repository.finish_send_campaign(cid)
                        if final:
                            await self._edit_status(final, self._render_status(final), running=False)
                        return
                    await asyncio.sleep(0.15)
                    continue

                async def run_one(user_id: int) -> None:
                    await pacer.wait()
                    result = await self._copy_one(campaign, user_id)
                    await self.repository.mark_send_result(
                        cid, user_id, status=result.status, message_id=result.message_id, error=result.error
                    )

                await asyncio.gather(*(run_one(uid) for uid in ids))
                now = time.monotonic()
                if now - last_status >= 4.0:
                    latest = await self.repository.get_campaign(cid)
                    if latest:
                        await self._edit_status(latest, self._render_status(latest, running=True), running=True)
                    last_status = now
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("Broadcast campaign failed campaign_id=%s", cid)
            final = await self.repository.finish_send_campaign(cid, error=f"{type(exc).__name__}: {exc}"[:500])
            if final:
                await self._edit_status(final, self._render_status(final), running=False)

    async def _copy_one(self, campaign: dict[str, Any], user_id: int) -> BroadcastSendResult:
        source_chat_id = int(campaign["source_chat_id"])
        source_message_id = int(campaign["source_message_id"])
        try:
            msg = await self.bot.copy_message(
                chat_id=int(user_id),
                from_chat_id=source_chat_id,
                message_id=source_message_id,
            )
            return BroadcastSendResult("sent", message_id=int(msg.message_id))
        except TelegramRetryAfter as exc:
            # Flood-control rejection is safe to retry once: Telegram explicitly did not accept the request yet.
            wait_for = max(0.1, min(60.0, float(exc.retry_after)))
            await asyncio.sleep(wait_for)
            try:
                msg = await self.bot.copy_message(
                    chat_id=int(user_id), from_chat_id=source_chat_id, message_id=source_message_id
                )
                return BroadcastSendResult("sent", message_id=int(msg.message_id))
            except TelegramForbiddenError as retry_exc:
                return BroadcastSendResult("blocked", error=str(retry_exc)[:500])
            except TelegramBadRequest as retry_exc:
                return self._classify_bad_request(retry_exc)
            except (TelegramNetworkError, TelegramServerError) as retry_exc:
                return BroadcastSendResult("unknown", error=f"{type(retry_exc).__name__}: {retry_exc}"[:500])
            except Exception as retry_exc:
                return BroadcastSendResult("failed", error=f"{type(retry_exc).__name__}: {retry_exc}"[:500])
        except TelegramForbiddenError as exc:
            return BroadcastSendResult("blocked", error=str(exc)[:500])
        except TelegramBadRequest as exc:
            return self._classify_bad_request(exc)
        except (TelegramNetworkError, TelegramServerError) as exc:
            # The request may have reached Telegram. Never repeat blindly and risk a duplicate message.
            return BroadcastSendResult("unknown", error=f"{type(exc).__name__}: {exc}"[:500])
        except Exception as exc:
            return BroadcastSendResult("failed", error=f"{type(exc).__name__}: {exc}"[:500])

    @staticmethod
    def _classify_bad_request(exc: TelegramBadRequest) -> BroadcastSendResult:
        text = str(exc).lower()
        blocked_markers = (
            "chat not found", "user is deactivated", "bot was blocked", "bot can't initiate conversation",
            "have no rights to send a message", "forbidden",
        )
        if any(marker in text for marker in blocked_markers):
            return BroadcastSendResult("blocked", error=str(exc)[:500])
        return BroadcastSendResult("failed", error=str(exc)[:500])

    async def _process_delete(self, campaign: dict[str, Any]) -> None:
        cid = UUID(str(campaign["id"]))
        concurrency = max(1, min(16, int(campaign.get("concurrency") or self.concurrency)))
        pacer = _StartPacer(int(campaign.get("per_minute") or self.per_minute))
        last_status = 0.0
        try:
            await self._edit_status(campaign, self._render_delete_status(campaign, running=True), running=False)
            while not self._stopping.is_set():
                pairs = await self.repository.claim_delete_batch(cid, limit=concurrency)
                if not pairs:
                    pending = await self.repository.pending_delete_count(cid)
                    if pending == 0:
                        final = await self.repository.finish_delete_campaign(cid)
                        if final:
                            await self._edit_status(final, self._render_delete_status(final), running=False)
                        return
                    await asyncio.sleep(0.15)
                    continue

                async def run_one(user_id: int, message_id: int) -> None:
                    await pacer.wait()
                    deleted, error = await self._delete_one(user_id, message_id)
                    await self.repository.mark_delete_result(cid, user_id, deleted=deleted, error=error)

                await asyncio.gather(*(run_one(uid, mid) for uid, mid in pairs))
                now = time.monotonic()
                if now - last_status >= 4.0:
                    latest = await self.repository.get_campaign(cid)
                    if latest:
                        await self._edit_status(latest, self._render_delete_status(latest, running=True), running=False)
                    last_status = now
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("Broadcast deletion failed campaign_id=%s", cid)
            final = await self.repository.finish_delete_campaign(cid, error=f"{type(exc).__name__}: {exc}"[:500])
            if final:
                await self._edit_status(final, self._render_delete_status(final), running=False)

    async def _delete_one(self, user_id: int, message_id: int) -> tuple[bool, str | None]:
        try:
            await self.bot.delete_message(chat_id=int(user_id), message_id=int(message_id))
            return True, None
        except TelegramRetryAfter as exc:
            await asyncio.sleep(max(0.1, min(60.0, float(exc.retry_after))))
            try:
                await self.bot.delete_message(chat_id=int(user_id), message_id=int(message_id))
                return True, None
            except TelegramBadRequest as retry_exc:
                text = str(retry_exc).lower()
                if "message to delete not found" in text or "message identifier is not specified" in text:
                    return True, "already_absent"
                return False, str(retry_exc)[:500]
            except TelegramForbiddenError as retry_exc:
                return False, str(retry_exc)[:500]
            except Exception as retry_exc:
                return False, f"{type(retry_exc).__name__}: {retry_exc}"[:500]
        except TelegramBadRequest as exc:
            text = str(exc).lower()
            if "message to delete not found" in text or "message identifier is not specified" in text:
                return True, "already_absent"
            return False, str(exc)[:500]
        except TelegramForbiddenError as exc:
            return False, str(exc)[:500]
        except Exception as exc:
            return False, f"{type(exc).__name__}: {exc}"[:500]

    async def _edit_status(self, campaign: dict[str, Any], text: str, *, running: bool) -> None:
        chat_id = campaign.get("admin_chat_id")
        message_id = campaign.get("admin_status_message_id")
        if not chat_id or not message_id:
            return
        cid = str(campaign["id"])
        rows: list[list[InlineKeyboardButton]] = []
        if running and not campaign.get("stop_requested"):
            rows.append([InlineKeyboardButton(text="⏹️ إيقاف الإرسال", callback_data=f"admin:bcast:stop:{cid}")])
        rows.append([InlineKeyboardButton(text="📚 تفاصيل الحملة", callback_data=f"admin:bcast:view:{cid}:0")])
        try:
            await self.bot.edit_message_text(
                chat_id=int(chat_id), message_id=int(message_id), text=text,
                reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
            )
        except TelegramBadRequest as exc:
            if "message is not modified" not in str(exc).lower():
                logger.warning("Could not edit broadcast status %s: %s", cid, exc)
        except Exception:
            logger.exception("Could not edit broadcast status campaign_id=%s", cid)

    @staticmethod
    def _render_status(c: dict[str, Any], *, running: bool = False) -> str:
        total = int(c.get("total_recipients") or 0)
        sent = int(c.get("sent_count") or 0)
        blocked = int(c.get("blocked_count") or 0)
        failed = int(c.get("failed_count") or 0)
        unknown = int(c.get("unknown_count") or 0)
        processed = sent + blocked + failed + unknown
        remaining = max(0, total - processed)
        status = str(c.get("status") or "")
        if running:
            title = "📤 <b>جاري إرسال الرسالة الجماعية...</b>"
        elif status == "stopped":
            title = "⏹️ <b>تم إيقاف الإرسال الجماعي</b>"
        elif status == "failed":
            title = "❌ <b>توقفت الحملة بسبب خطأ</b>"
        else:
            title = "✅ <b>اكتمل الإرسال الجماعي</b>"
        return (
            f"{title}\n\n"
            f"👥 الإجمالي: <b>{total:,}</b>\n"
            f"📤 ناجح: <b>{sent:,}</b>\n"
            f"🚫 محظور/غير متاح: <b>{blocked:,}</b>\n"
            f"⚠️ فشل: <b>{failed:,}</b>\n"
            f"❓ نتيجة غير مؤكدة بعد انقطاع/شبكة: <b>{unknown:,}</b>\n"
            f"⏳ المتبقي: <b>{remaining:,}</b>\n\n"
            f"🆔 <code>{c.get('id')}</code>"
        )

    @staticmethod
    def _render_delete_status(c: dict[str, Any], *, running: bool = False) -> str:
        total = int(c.get("delete_total") or 0)
        deleted = int(c.get("deleted_count") or 0)
        failed = int(c.get("delete_failed_count") or 0)
        remaining = max(0, total - deleted - failed)
        title = "🗑️ <b>جاري حذف الرسالة من المستخدمين...</b>" if running else "🗑️ <b>اكتملت محاولة الحذف</b>"
        return (
            f"{title}\n\n"
            f"📨 الرسائل المسجلة: <b>{total:,}</b>\n"
            f"✅ تم حذفها: <b>{deleted:,}</b>\n"
            f"⚠️ تعذر الحذف: <b>{failed:,}</b>\n"
            f"⏳ المتبقي: <b>{remaining:,}</b>\n\n"
            f"🆔 <code>{c.get('id')}</code>"
        )
