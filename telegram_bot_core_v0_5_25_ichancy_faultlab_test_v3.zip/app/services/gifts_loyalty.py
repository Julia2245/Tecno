from __future__ import annotations

import asyncio
import json
import logging
import secrets
from dataclasses import dataclass
from typing import Any
from uuid import UUID, uuid4

import asyncpg

from app.core.db import Database
from app.core.wallet import InsufficientFunds
from app.repositories.gifts_loyalty import GiftsLoyaltyRepository
from app.services.runtime_settings import RuntimeSettingsService
from app.services.wallet import WalletService

logger = logging.getLogger(__name__)

# Global advisory lock serializes destructive loyalty-wide resets against
# ordinary point mutations. Shared = normal mutation, exclusive = reset-all.
LOYALTY_RESET_LOCK_KEY = 52023005


@dataclass(slots=True, frozen=True)
class GiftTransferResult:
    gift_id: UUID
    sender_id: int
    recipient_id: int
    amount: int
    sender_balance: int
    recipient_balance: int
    duplicate: bool = False


class GiftService:
    def __init__(self, db: Database, repo: GiftsLoyaltyRepository, runtime: RuntimeSettingsService, wallet: WalletService) -> None:
        self.db=db; self.repo=repo; self.runtime=runtime; self.wallet=wallet

    def enabled(self) -> bool:
        return self.runtime.get_bool("gift.transfer_enabled", True)

    async def set_enabled(self, enabled: bool, actor: int) -> None:
        await self.runtime.set("gift.transfer_enabled", bool(enabled), updated_by=int(actor))

    async def transferable_balance(self, telegram_id: int) -> dict[str,int]:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            bal=await self.wallet.get_balance_in_transaction(conn,int(telegram_id))
            protected=await self.repo.protected_available(conn,int(telegram_id))
        return {"available":int(bal.available),"protected":int(protected),"transferable":max(0,int(bal.available)-int(protected))}

    async def transfer(self, sender: int, recipient: int, amount: int, request_token: UUID | str) -> GiftTransferResult:
        sender=int(sender); recipient=int(recipient); amount=int(amount); token=UUID(str(request_token))
        if amount<=0: raise ValueError("مبلغ الإهداء غير صالح.")
        if sender==recipient: raise ValueError("لا يمكن الإهداء لنفسك.")
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # Stable pair ordering prevents reciprocal gifts from deadlocking.
                for uid in sorted({sender,recipient}):
                    await conn.execute("SELECT pg_advisory_xact_lock($1)",uid)
                existing=await self.repo.gift_by_token(conn,token)
                if existing:
                    if (int(existing['from_telegram_id'])!=sender or int(existing['to_telegram_id'])!=recipient or int(existing['amount_syp'])!=amount):
                        raise ValueError("تعارض في مفتاح عملية الإهداء؛ أعد بدء العملية.")
                    return GiftTransferResult(UUID(str(existing['id'])),sender,recipient,int(existing['amount_syp']),int(existing['sender_balance_after']),int(existing['recipient_balance_after']),True)
                # Transaction-level setting check closes the admin-disable race.
                raw=await conn.fetchval("SELECT value FROM bot_core.runtime_settings WHERE key='gift.transfer_enabled' FOR UPDATE")
                enabled=self.enabled() if raw is None else (json.loads(raw) if isinstance(raw,str) else raw)
                if not bool(enabled): raise ValueError("⛔ خدمة إهداء الرصيد متوقفة حاليًا.")
                su=await self.repo.user_exists(conn,sender,for_update=True)
                ru=await self.repo.user_exists(conn,recipient,for_update=True)
                if not su or su.get('is_bot'): raise ValueError("المستخدم المرسل غير موجود.")
                if not ru or ru.get('is_bot'): raise ValueError("المستخدم المستلم غير موجود داخل البوت.")
                if ru.get('is_blocked'): raise ValueError("لا يمكن الإهداء لهذا المستخدم حاليًا.")
                sender_bal=await self.wallet.get_balance_in_transaction(conn,sender)
                protected=await self.repo.protected_available(conn,sender)
                transferable=max(0,int(sender_bal.available)-int(protected))
                if amount>transferable:
                    raise ValueError(f"الرصيد القابل للإهداء غير كافٍ.\nالرصيد القابل للإهداء: {transferable:,} SYP")
                gid=uuid4()
                debit=await self.wallet.debit_in_transaction(
                    conn,sender,amount,idempotency_key=f"gift:{token}:debit",reason="gift_transfer_sent",
                    actor_telegram_id=sender,metadata={"gift_transfer":True,"gift_id":str(gid),"recipient":recipient},
                )
                credit=await self.wallet.credit_in_transaction(
                    conn,recipient,amount,idempotency_key=f"gift:{token}:credit",reason="gift_transfer_received",
                    actor_telegram_id=sender,metadata={"gift_received":True,"gift_id":str(gid),"sender":sender,"cashback_eligible":False},
                )
                row=await self.repo.insert_gift(
                    conn,gift_id=gid,token=token,sender=sender,recipient=recipient,amount=amount,
                    sender_op=debit.operation_id,recipient_op=credit.operation_id,
                    sender_balance=debit.balance_after.available,recipient_balance=credit.balance_after.available,
                )
                return GiftTransferResult(UUID(str(row['id'])),sender,recipient,amount,int(row['sender_balance_after']),int(row['recipient_balance_after']),False)

    def _prefix(self) -> str:
        raw=str(self.runtime.get("gift.code_prefix","TECNO") or "TECNO").upper()
        clean="".join(ch for ch in raw if ch.isalnum())[:10]
        return clean or "TECNO"

    async def create_code(self, amount: int, actor: int, *, max_uses: int=1, target: int|None=None) -> str:
        amount=int(amount); max_uses=int(max_uses); actor=int(actor)
        if amount<=0: raise ValueError("قيمة الكود غير صالحة.")
        if max_uses<=0 or max_uses>100000: raise ValueError("عدد الاستخدامات غير صالح.")
        if target is not None and max_uses!=1: raise ValueError("الكود الخاص يجب أن يكون استخدامًا واحدًا.")
        if target is not None:
            pool=self.db.require_pool()
            async with pool.acquire() as conn:
                if not await self.repo.user_exists(conn,int(target)): raise ValueError("المستخدم المستهدف غير موجود.")
        alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        for _ in range(40):
            code=f"{self._prefix()}-{''.join(secrets.choice(alphabet) for _ in range(8))}"
            try:
                await self.repo.create_code(code=code,amount=amount,max_uses=max_uses,target=int(target) if target is not None else None,actor=actor)
                return code
            except asyncpg.UniqueViolationError:
                continue
        raise ValueError("تعذر إنشاء كود جديد حاليًا.")

    async def create_batch(self, amount:int, actor:int, count:int) -> list[str]:
        amount=int(amount); actor=int(actor); count=int(count)
        if amount<=0: raise ValueError("قيمة الكود غير صالحة.")
        if count<=0 or count>200: raise ValueError("عدد الأكواد يجب أن يكون بين 1 و200.")
        alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        out: list[str]=[]
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # The entire batch is one atomic unit: either all requested codes
                # are created, or none are. ON CONFLICT avoids aborting the
                # transaction on the astronomically unlikely random-code collision.
                attempts=0
                while len(out)<count and attempts<count*20:
                    attempts+=1
                    code=f"{self._prefix()}-{''.join(secrets.choice(alphabet) for _ in range(8))}"
                    if code in out:
                        continue
                    row=await conn.fetchrow(
                        "INSERT INTO bot_core.gift_codes(code,amount_syp,max_uses,target_telegram_id,created_by) VALUES($1,$2,1,NULL,$3) ON CONFLICT(code) DO NOTHING RETURNING code",
                        code,amount,actor,
                    )
                    if row is not None:
                        out.append(str(row['code']))
                if len(out)!=count:
                    raise ValueError("تعذر إنشاء كامل دفعة الأكواد بأمان.")
        return out

    async def create_fake_batch(self, actor:int, count:int) -> list[str]:
        actor=int(actor); count=int(count)
        if count<=0 or count>200: raise ValueError("عدد الأكواد يجب أن يكون بين 1 و200.")
        alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        out: list[str]=[]; pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                attempts=0
                while len(out)<count and attempts<count*20:
                    attempts+=1
                    code=f"{self._prefix()}-{''.join(secrets.choice(alphabet) for _ in range(8))}"
                    if code in out: continue
                    row=await conn.fetchrow(
                        "INSERT INTO bot_core.gift_codes(code,amount_syp,is_fake,max_uses,target_telegram_id,created_by) VALUES($1,0,TRUE,1,NULL,$2) ON CONFLICT(code) DO NOTHING RETURNING code",
                        code,actor,
                    )
                    if row is not None: out.append(str(row['code']))
                if len(out)!=count: raise ValueError("تعذر إنشاء كامل دفعة الأكواد الوهمية بأمان.")
        return out

    async def redeem_code(self, telegram_id:int, raw_code:str) -> dict[str,Any]:
        tg=int(telegram_id); code=str(raw_code or '').strip().upper()
        if not code: raise ValueError("كود غير صالح.")
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute("SELECT pg_advisory_xact_lock($1)",tg)
                user=await self.repo.user_exists(conn,tg,for_update=True)
                if not user or user.get('is_blocked') or user.get('is_bot'): raise ValueError("المستخدم غير مؤهل لاستخدام الكود.")
                row=await conn.fetchrow("SELECT * FROM bot_core.gift_codes WHERE code=$1 FOR UPDATE",code)
                if not row: raise ValueError("الكود غير صالح.")
                if row['disabled_at'] is not None: raise ValueError("انتهت صلاحية كود الهدية هذا.")
                if bool(row['is_fake']): raise ValueError("تم استخدام هذا الكود من قبل مستخدم آخر.")
                target=row['target_telegram_id']
                if target is not None and int(target)!=tg: raise ValueError("تم استخدام هذا الكود من قبل مستخدم آخر.")
                prior=await conn.fetchval("SELECT 1 FROM bot_core.gift_code_redemptions WHERE code=$1 AND telegram_id=$2",code,tg)
                if prior: raise ValueError("لقد استخدمت هذا الكود سابقًا.")
                actual=int(await conn.fetchval("SELECT COUNT(*) FROM bot_core.gift_code_redemptions WHERE code=$1",code) or 0)
                uses=max(actual,int(row['uses_count'] or 0)); max_uses=int(row['max_uses'])
                if uses>=max_uses: raise ValueError("تم استخدام هذا الكود من قبل مستخدم آخر.")
                cooldown=max(0,self.runtime.get_int("gift.code_cooldown_minutes",0))
                if cooldown:
                    last=await conn.fetchval("SELECT MAX(used_at) FROM bot_core.gift_code_redemptions WHERE telegram_id=$1",tg)
                    if last is not None:
                        remaining=int(cooldown*60-(await conn.fetchval("SELECT EXTRACT(EPOCH FROM (NOW()-$1::timestamptz))",last) or 0))
                        if remaining>0: raise ValueError(f"يرجى الانتظار {max(1,(remaining+59)//60)} دقيقة قبل استخدام كود هدية آخر.")
                amount=int(row['amount_syp'])
                before=await self.wallet.get_balance_in_transaction(conn,tg)
                mutation=await self.wallet.credit_in_transaction(
                    conn,tg,amount,idempotency_key=f"gift-code:{code}:{tg}",reason="gift_code_redeem",actor_telegram_id=tg,
                    metadata={"gift_code":code,"non_transferable_credit":True,"cashback_eligible":False},
                )
                await conn.execute(
                    "INSERT INTO bot_core.gift_code_redemptions(code,telegram_id,amount_syp,wallet_operation_id,balance_before,balance_after) VALUES($1,$2,$3,$4,$5,$6)",
                    code,tg,amount,mutation.operation_id,int(before.available),int(mutation.balance_after.available),
                )
                await conn.execute("UPDATE bot_core.gift_codes SET uses_count=GREATEST(uses_count,$2)+1 WHERE code=$1",code,actual)
                return {"code":code,"amount_syp":amount,"old_balance":int(before.available),"new_balance":int(mutation.balance_after.available),"max_uses":max_uses,"uses_count":uses+1,"target_tg_id":int(target) if target is not None else None}


class LoyaltyService:
    def __init__(self, db:Database, repo:GiftsLoyaltyRepository, runtime:RuntimeSettingsService, wallet:WalletService) -> None:
        self.db=db; self.repo=repo; self.runtime=runtime; self.wallet=wallet

    @staticmethod
    async def _lock_normal_mutation(conn: asyncpg.Connection) -> None:
        await conn.execute("SELECT pg_advisory_xact_lock_shared($1)", LOYALTY_RESET_LOCK_KEY)

    @staticmethod
    async def _lock_global_reset(conn: asyncpg.Connection) -> None:
        await conn.execute("SELECT pg_advisory_xact_lock($1)", LOYALTY_RESET_LOCK_KEY)

    def config(self)->dict[str,Any]:
        return {
            "enabled":self.runtime.get_bool("loyalty.enabled",True),
            "earn_syp_per_point":max(1,self.runtime.get_int("loyalty.earn_syp_per_point",1000)),
            "min_deposit_syp":max(0,self.runtime.get_int("loyalty.min_deposit_syp",50000)),
        }

    async def set_config(self,key:str,value:Any,actor:int)->None:
        allowed={"loyalty.enabled","loyalty.earn_syp_per_point","loyalty.min_deposit_syp"}
        if key not in allowed: raise ValueError("إعداد ولاء غير معروف")
        await self.runtime.set(key,value,updated_by=int(actor))

    async def prepare_deposit_award(self, conn:asyncpg.Connection, deposit_id:UUID, telegram_id:int, base_amount:int)->None:
        await self._lock_normal_mutation(conn)
        cfg=self.config()
        await conn.execute(
            """INSERT INTO bot_core.loyalty_deposit_awards(
                deposit_id,telegram_id,base_amount_syp,enabled_snapshot,earn_syp_per_point,min_deposit_syp
               ) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(deposit_id) DO NOTHING""",
            deposit_id,int(telegram_id),max(0,int(base_amount)),bool(cfg['enabled']),int(cfg['earn_syp_per_point']),int(cfg['min_deposit_syp']),
        )

    async def settle_deposit_award(self,conn:asyncpg.Connection,deposit_id:UUID)->dict[str,Any]:
        await self._lock_normal_mutation(conn)
        row=await conn.fetchrow("SELECT * FROM bot_core.loyalty_deposit_awards WHERE deposit_id=$1 FOR UPDATE",deposit_id)
        if not row: return {"status":"missing","points_awarded":0}
        if str(row['status']) not in {'pending','failed'}:
            return {"status":str(row['status']),"points_awarded":int(row['points_awarded'] or 0),"duplicate":True}
        tg=int(row['telegram_id']); base=int(row['base_amount_syp']); earn=int(row['earn_syp_per_point']); minimum=int(row['min_deposit_syp'])
        if not bool(row['enabled_snapshot']): points=0; status='skipped_disabled'
        elif base<minimum: points=0; status='skipped_below_minimum'
        else:
            points=max(0,base//earn); status='awarded' if points else 'skipped_zero_points'
        await conn.execute("SELECT pg_advisory_xact_lock($1)",tg)
        if points:
            acc=await conn.fetchrow("SELECT * FROM bot_core.loyalty_accounts WHERE telegram_id=$1 FOR UPDATE",tg)
            old=int(acc['points'] or 0) if acc else 0
            if acc:
                await conn.execute("UPDATE bot_core.loyalty_accounts SET points=points+$2,total_earned=total_earned+$2,updated_at=NOW() WHERE telegram_id=$1",tg,points)
            else:
                await conn.execute("INSERT INTO bot_core.loyalty_accounts(telegram_id,points,total_earned) VALUES($1,$2,$2)",tg,points)
            await conn.execute(
                "INSERT INTO bot_core.loyalty_events(telegram_id,event_type,points_delta,amount_syp,deposit_id,details) VALUES($1,'earn',$2,$3,$4,$5::jsonb)",
                tg,points,base,deposit_id,json.dumps({"earn_syp_per_point":earn,"min_deposit_syp":minimum,"old_points":old,"new_points":old+points},ensure_ascii=False),
            )
        await conn.execute("UPDATE bot_core.loyalty_deposit_awards SET status=$2,points_awarded=$3,attempts=attempts+1,last_error=NULL,updated_at=NOW(),settled_at=NOW() WHERE deposit_id=$1",deposit_id,status,points)
        return {"status":status,"points_awarded":points,"telegram_id":tg}

    async def mark_award_failed(self,conn:asyncpg.Connection,deposit_id:UUID,error:Exception)->None:
        await conn.execute("UPDATE bot_core.loyalty_deposit_awards SET status='failed',attempts=attempts+1,last_error=$2,updated_at=NOW() WHERE deposit_id=$1 AND status IN ('pending','failed')",deposit_id,str(error)[:500])

    async def reconcile_pending(self,limit:int=50)->dict[str,int]:
        pool=self.db.require_pool(); processed=failed=0
        async with pool.acquire() as conn:
            ids=await conn.fetch("SELECT deposit_id FROM bot_core.loyalty_deposit_awards WHERE status IN ('pending','failed') ORDER BY updated_at,deposit_id LIMIT $1",max(1,min(int(limit),500)))
        for item in ids:
            dep=UUID(str(item['deposit_id']))
            try:
                async with pool.acquire() as conn:
                    async with conn.transaction(): await self.settle_deposit_award(conn,dep)
                processed+=1
            except Exception as exc:
                failed+=1
                try:
                    async with pool.acquire() as conn:
                        await self.mark_award_failed(conn,dep,exc)
                except Exception: pass
        return {"processed":processed,"failed":failed}

    async def summary(self,telegram_id:int)->dict[str,Any]:
        row=await self.repo.loyalty_summary(int(telegram_id)); row['config']=self.config(); return row

    async def claim_reward(self,telegram_id:int,reward_id:int)->dict[str,Any]:
        tg=int(telegram_id); rid=int(reward_id); pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._lock_normal_mutation(conn)
                await conn.execute("SELECT pg_advisory_xact_lock($1)",tg)
                if not self.config()['enabled']: raise ValueError("نظام نقاط الولاء متوقف حاليًا.")
                reward=await self.repo.reward(rid,conn=conn,for_update=True)
                if not reward or not reward['enabled']: raise ValueError("هذه الجائزة غير متاحة حاليًا.")
                if not reward['available']: raise ValueError("نفدت كمية هذه الجائزة.")
                acc=await conn.fetchrow("SELECT * FROM bot_core.loyalty_accounts WHERE telegram_id=$1 FOR UPDATE",tg)
                points=int(acc['points'] or 0) if acc else 0; cost=int(reward['points_cost'])
                if points<cost: raise ValueError(f"تحتاج إلى {cost-points:,} نقطة إضافية.")
                claim_id=uuid4(); remaining=points-cost; rtype=str(reward['reward_type']); status='completed' if rtype=='balance' else 'pending'
                await conn.execute("UPDATE bot_core.loyalty_accounts SET points=$2,total_redeemed=total_redeemed+$3,updated_at=NOW() WHERE telegram_id=$1",tg,remaining,cost)
                wallet_op=None; new_balance=None
                if rtype=='balance':
                    amount=int(reward['balance_amount_syp'])
                    mutation=await self.wallet.credit_in_transaction(
                        conn,tg,amount,idempotency_key=f"loyalty-reward:{claim_id}",reason="loyalty_reward_balance",actor_telegram_id=tg,
                        metadata={"loyalty_reward_id":rid,"claim_id":str(claim_id),"non_transferable_credit":True,"cashback_eligible":False},
                    )
                    wallet_op=mutation.operation_id; new_balance=int(mutation.balance_after.available)
                await conn.execute(
                    """INSERT INTO bot_core.loyalty_reward_claims(id,reward_id,telegram_id,reward_name,reward_type,points_spent,balance_amount_syp,status,wallet_operation_id)
                       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)""",
                    claim_id,rid,tg,str(reward['name']),rtype,cost,int(reward['balance_amount_syp'] or 0),status,wallet_op,
                )
                await conn.execute(
                    "INSERT INTO bot_core.loyalty_events(telegram_id,event_type,points_delta,amount_syp,reward_claim_id,details) VALUES($1,$2,$3,$4,$5,$6::jsonb)",
                    tg,'reward_balance' if rtype=='balance' else 'reward_request',-cost,int(reward['balance_amount_syp'] or 0),claim_id,json.dumps({"reward_id":rid,"reward_name":str(reward['name'])},ensure_ascii=False),
                )
                return {"claim_id":claim_id,"reward_id":rid,"reward_name":str(reward['name']),"reward_type":rtype,"points_spent":cost,"remaining_points":remaining,"balance_amount_syp":int(reward['balance_amount_syp'] or 0),"new_balance":new_balance,"status":status}

    async def decide_claim(self,claim_id:UUID|str,approve:bool,actor:int)->dict[str,Any]:
        cid=UUID(str(claim_id)); pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._lock_normal_mutation(conn)
                claim=await conn.fetchrow("SELECT * FROM bot_core.loyalty_reward_claims WHERE id=$1 FOR UPDATE",cid)
                if not claim: raise ValueError("طلب الجائزة غير موجود.")
                if str(claim['status'])!='pending': raise ValueError("تمت معالجة هذا الطلب مسبقًا.")
                tg=int(claim['telegram_id']); points=int(claim['points_spent']); await conn.execute("SELECT pg_advisory_xact_lock($1)",tg)
                if approve:
                    status='delivered'; await conn.execute("UPDATE bot_core.loyalty_reward_claims SET status='delivered',decided_at=NOW(),decided_by=$2 WHERE id=$1",cid,int(actor))
                else:
                    status='rejected'
                    await conn.execute("INSERT INTO bot_core.loyalty_accounts(telegram_id,points,total_earned,total_redeemed) VALUES($1,$2,0,0) ON CONFLICT(telegram_id) DO UPDATE SET points=bot_core.loyalty_accounts.points+$2,total_redeemed=GREATEST(0,bot_core.loyalty_accounts.total_redeemed-$2),updated_at=NOW()",tg,points)
                    await conn.execute("UPDATE bot_core.loyalty_reward_claims SET status='rejected',decided_at=NOW(),decided_by=$2 WHERE id=$1",cid,int(actor))
                    await conn.execute("INSERT INTO bot_core.loyalty_events(telegram_id,event_type,points_delta,reward_claim_id,details) VALUES($1,'reward_refund',$2,$3,$4::jsonb)",tg,points,cid,json.dumps({"admin":int(actor)},ensure_ascii=False))
                return {"claim_id":cid,"telegram_id":tg,"status":status,"points":points,"reward_name":str(claim['reward_name'])}

    async def create_reward(self,name:str,reward_type:str,points_cost:int,actor:int,*,balance_amount:int=0,stock_total:int=0)->int:
        name=str(name).strip(); reward_type=str(reward_type).strip()
        if not name or len(name)>120: raise ValueError("اسم الجائزة غير صالح.")
        if reward_type not in {'balance','manual'}: raise ValueError("نوع الجائزة غير صالح.")
        if int(points_cost)<=0: raise ValueError("تكلفة النقاط غير صالحة.")
        if reward_type=='balance' and int(balance_amount)<=0: raise ValueError("قيمة رصيد الجائزة غير صالحة.")
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            return int(await conn.fetchval("INSERT INTO bot_core.loyalty_rewards(name,reward_type,points_cost,balance_amount_syp,stock_total,created_by) VALUES($1,$2,$3,$4,$5,$6) RETURNING id",name,reward_type,int(points_cost),int(balance_amount),max(0,int(stock_total)),int(actor)))

    async def toggle_reward(self,reward_id:int)->bool:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            val=await conn.fetchval("UPDATE bot_core.loyalty_rewards SET enabled=NOT enabled,updated_at=NOW() WHERE id=$1 RETURNING enabled",int(reward_id))
        if val is None: raise ValueError("الجائزة غير موجودة.")
        return bool(val)

    async def adjust_points(self,telegram_id:int,mode:str,value:int,actor:int,*,expected_old:int|None=None)->dict[str,int]:
        tg=int(telegram_id); mode=str(mode); value=int(value)
        if mode not in {'set','add','sub'} or value<0 or (mode!='set' and value<=0): raise ValueError("قيمة التعديل غير صالحة.")
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._lock_normal_mutation(conn)
                await conn.execute("SELECT pg_advisory_xact_lock($1)",tg)
                if not await self.repo.user_exists(conn,tg): raise ValueError("المستخدم غير موجود.")
                acc=await conn.fetchrow("SELECT * FROM bot_core.loyalty_accounts WHERE telegram_id=$1 FOR UPDATE",tg)
                old=int(acc['points'] or 0) if acc else 0
                if expected_old is not None and old!=int(expected_old):
                    raise ValueError(f"تغير رصيد النقاط منذ شاشة التأكيد ({int(expected_old):,} → {old:,}). أعد المحاولة.")
                new=value if mode=='set' else old+value if mode=='add' else old-value
                if new<0: raise ValueError("لا يمكن خصم نقاط أكثر من الرصيد الحالي.")
                if acc: await conn.execute("UPDATE bot_core.loyalty_accounts SET points=$2,updated_at=NOW() WHERE telegram_id=$1",tg,new)
                else: await conn.execute("INSERT INTO bot_core.loyalty_accounts(telegram_id,points) VALUES($1,$2)",tg,new)
                delta=new-old
                if delta:
                    await conn.execute("INSERT INTO bot_core.loyalty_events(telegram_id,event_type,points_delta,details) VALUES($1,'admin_adjust',$2,$3::jsonb)",tg,delta,json.dumps({"actor":int(actor),"mode":mode,"value":value,"old":old,"new":new},ensure_ascii=False))
                return {"old_points":old,"new_points":new,"delta":delta}

    async def reset_all(self,actor:int)->dict[str,int]:
        # Reconcile first without the exclusive lock so normal settlement can finish.
        rec=await self.reconcile_pending(limit=500)
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # Exclusive global lock gives reset-all one atomic position relative
                # to every deposit award, claim, refund and admin point mutation.
                await self._lock_global_reset(conn)
                pending=int(await conn.fetchval("SELECT COUNT(*) FROM bot_core.loyalty_deposit_awards WHERE status IN ('pending','failed')") or 0)
                if pending:
                    raise ValueError("توجد عمليات كسب نقاط معلقة تحتاج للمصالحة أولًا.")
                rows=await conn.fetch("SELECT telegram_id,points FROM bot_core.loyalty_accounts WHERE points>0 FOR UPDATE")
                total=sum(int(r['points']) for r in rows)
                for r in rows:
                    await conn.execute("INSERT INTO bot_core.loyalty_events(telegram_id,event_type,points_delta,details) VALUES($1,'admin_reset',$2,$3::jsonb)",int(r['telegram_id']),-int(r['points']),json.dumps({"actor":int(actor)},ensure_ascii=False))
                await conn.execute("UPDATE bot_core.loyalty_accounts SET points=0,updated_at=NOW() WHERE points>0")
                return {"affected_users":len(rows),"total_points_reset":total,"reconciled":rec['processed']}

    async def stats(self)->dict[str,int]:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            row=await conn.fetchrow("""SELECT COUNT(*) AS accounts,COUNT(*) FILTER(WHERE points>0) AS holders,COALESCE(SUM(points),0) AS outstanding,COALESCE(SUM(total_earned),0) AS earned,COALESCE(SUM(total_redeemed),0) AS redeemed FROM bot_core.loyalty_accounts""")
            pending=await conn.fetchval("SELECT COUNT(*) FROM bot_core.loyalty_deposit_awards WHERE status IN ('pending','failed')")
            claims=await conn.fetchval("SELECT COUNT(*) FROM bot_core.loyalty_reward_claims WHERE status='pending'")
        d=dict(row); d['pending_reconciliation']=int(pending or 0); d['pending_claims']=int(claims or 0); return {k:int(v or 0) for k,v in d.items()}


class LoyaltyReconciliationWorker:
    def __init__(self,service:LoyaltyService)->None: self.service=service; self._stop=asyncio.Event()
    def stop(self)->None: self._stop.set()
    async def run(self,interval:float=30.0)->None:
        while not self._stop.is_set():
            try: await self.service.reconcile_pending(limit=100)
            except asyncio.CancelledError: raise
            except Exception: logger.exception("loyalty reconciliation failed")
            try: await asyncio.wait_for(self._stop.wait(),timeout=max(10.0,float(interval)))
            except asyncio.TimeoutError: pass
