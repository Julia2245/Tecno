from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4
from zoneinfo import ZoneInfo

import asyncpg
from aiogram import Bot

from app.core.db import Database
from app.providers.ichancy import extract_player_balance_value
from app.services.wallet import WalletService
from app.services.runtime_settings import RuntimeSettingsService
from app.services.ichancy_accounts import IchancyAccountsService
from app.repositories.outbox import OutboxRepository

logger = logging.getLogger(__name__)
DAMASCUS = ZoneInfo("Asia/Damascus")
UTC = timezone.utc


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _damascus_day_bounds(day=None) -> tuple[datetime, datetime]:
    if day is None:
        day = _utcnow().astimezone(DAMASCUS).date()
    start_local = datetime.combine(day, datetime.min.time(), tzinfo=DAMASCUS)
    return start_local.astimezone(UTC), (start_local + timedelta(days=1)).astimezone(UTC)


def _fmt_local(dt: datetime | None) -> str:
    if not dt:
        return "-"
    return dt.astimezone(DAMASCUS).strftime("%Y-%m-%d %H:%M")


def _cashback_aligned_start(now_utc: datetime, cycle_days: int) -> datetime:
    """Return the Damascus-local cycle boundary that contains *now_utc*."""
    local = now_utc.astimezone(DAMASCUS)
    days = 1 if int(cycle_days or 7) <= 1 else 7
    if days == 1:
        boundary = datetime(local.year, local.month, local.day, 0, 0, 0, tzinfo=DAMASCUS)
    else:
        monday = local.date() - timedelta(days=local.weekday())
        boundary = datetime(monday.year, monday.month, monday.day, 0, 0, 0, tzinfo=DAMASCUS)
    return boundary.astimezone(UTC)


def _cashback_cycle_end_for(start_utc: datetime, cycle_days: int) -> datetime:
    """Return the next exact daily/weekly Damascus boundary after *start_utc*."""
    local = start_utc.astimezone(DAMASCUS)
    days = 1 if int(cycle_days or 7) <= 1 else 7
    if days == 1:
        boundary = datetime(local.year, local.month, local.day, 0, 0, 0, tzinfo=DAMASCUS)
        if local >= boundary:
            boundary += timedelta(days=1)
    else:
        monday = local.date() - timedelta(days=local.weekday())
        boundary = datetime(monday.year, monday.month, monday.day, 0, 0, 0, tzinfo=DAMASCUS)
        if local >= boundary:
            boundary += timedelta(days=7)
    return boundary.astimezone(UTC)


class CashbackPrincipalTracker:
    """Tracks the reference-style real-deposit principal separately from wallet cash.

    Wallet cash remains the authoritative spendable balance. This ledger only marks
    which part originated from real successful deposits and may therefore participate
    in cashback after it reaches iChancy. Every reservation is made under the same
    PostgreSQL transaction as the financial hold that consumes it.
    """

    def __init__(self, db: Database) -> None:
        self.db = db

    async def add_real_deposit(self, conn: asyncpg.Connection, telegram_id: int, amount: int) -> None:
        amount = max(0, int(amount))
        if amount <= 0:
            return
        await conn.execute(
            """
            INSERT INTO bot_core.cashback_wallet_principal(telegram_id,eligible_syp)
            VALUES($1,$2)
            ON CONFLICT(telegram_id) DO UPDATE
            SET eligible_syp=bot_core.cashback_wallet_principal.eligible_syp+EXCLUDED.eligible_syp,
                updated_at=NOW()
            """,
            telegram_id, amount,
        )

    async def eligible_wallet_principal(self, conn: asyncpg.Connection, telegram_id: int, *, lock: bool = False) -> int:
        sql = "SELECT eligible_syp FROM bot_core.cashback_wallet_principal WHERE telegram_id=$1"
        if lock:
            sql += " FOR UPDATE"
        value = await conn.fetchval(sql, telegram_id)
        return max(0, int(value or 0))

    async def reserve_wallet_spend(
        self,
        conn: asyncpg.Connection,
        *,
        source_type: str,
        source_id: UUID,
        telegram_id: int,
        amount: int,
    ) -> int:
        amount = max(0, int(amount))
        existing = await conn.fetchrow(
            "SELECT amount_syp,status FROM bot_core.cashback_wallet_holds WHERE source_type=$1 AND source_id=$2 FOR UPDATE",
            source_type, source_id,
        )
        if existing:
            return int(existing["amount_syp"] or 0)
        eligible = await self.eligible_wallet_principal(conn, telegram_id, lock=True)
        wallet = await conn.fetchrow(
            """
            SELECT available,held FROM bot_core.wallet_accounts
            WHERE telegram_id=$1 AND asset_code='SYP' AND bucket='cash' FOR UPDATE
            """,
            telegram_id,
        )
        # The financial hold is created immediately before this source reservation.
        # Existing holds already had their eligible source removed from this ledger,
        # so they must not inflate the ineligible amount available to the new spend.
        # Reconstruct only the unreserved balance that existed just before THIS hold.
        available_after_hold = int((wallet["available"] if wallet else 0) or 0)
        unreserved_before_this_hold = max(0, available_after_hold + amount)
        eligible = min(eligible, unreserved_before_this_hold)
        ineligible = max(0, unreserved_before_this_hold - eligible)
        eligible_used = min(eligible, max(0, amount - ineligible))
        if eligible_used:
            await conn.execute(
                "UPDATE bot_core.cashback_wallet_principal SET eligible_syp=eligible_syp-$2,updated_at=NOW() WHERE telegram_id=$1",
                telegram_id, eligible_used,
            )
        await conn.execute(
            """
            INSERT INTO bot_core.cashback_wallet_holds(source_type,source_id,telegram_id,amount_syp,status)
            VALUES($1,$2,$3,$4,'active')
            """,
            source_type, source_id, telegram_id, eligible_used,
        )
        return eligible_used

    async def release_wallet_spend(self, conn: asyncpg.Connection, *, source_type: str, source_id: UUID) -> int:
        row = await conn.fetchrow(
            "SELECT * FROM bot_core.cashback_wallet_holds WHERE source_type=$1 AND source_id=$2 FOR UPDATE",
            source_type, source_id,
        )
        if not row or str(row["status"]) != "active":
            return int(row["amount_syp"] or 0) if row else 0
        amount = int(row["amount_syp"] or 0)
        if amount:
            await conn.execute(
                """
                INSERT INTO bot_core.cashback_wallet_principal(telegram_id,eligible_syp)
                VALUES($1,$2)
                ON CONFLICT(telegram_id) DO UPDATE
                SET eligible_syp=bot_core.cashback_wallet_principal.eligible_syp+EXCLUDED.eligible_syp,
                    updated_at=NOW()
                """,
                int(row["telegram_id"]), amount,
            )
        await conn.execute(
            "UPDATE bot_core.cashback_wallet_holds SET status='released',closed_at=NOW() WHERE source_type=$1 AND source_id=$2 AND status='active'",
            source_type, source_id,
        )
        return amount

    async def consume_wallet_spend(self, conn: asyncpg.Connection, *, source_type: str, source_id: UUID) -> int:
        row = await conn.fetchrow(
            "SELECT * FROM bot_core.cashback_wallet_holds WHERE source_type=$1 AND source_id=$2 FOR UPDATE",
            source_type, source_id,
        )
        if not row:
            return 0
        if str(row["status"]) == "active":
            await conn.execute(
                "UPDATE bot_core.cashback_wallet_holds SET status='consumed',closed_at=NOW() WHERE source_type=$1 AND source_id=$2",
                source_type, source_id,
            )
        return int(row["amount_syp"] or 0)

    async def create_ichancy_deposit_allocation(
        self, conn: asyncpg.Connection, *, job_id: UUID, telegram_id: int, account_id: UUID, amount: int
    ) -> int:
        eligible = await self.reserve_wallet_spend(
            conn, source_type="ichancy_deposit", source_id=job_id, telegram_id=telegram_id, amount=amount
        )
        await conn.execute(
            """
            INSERT INTO bot_core.ichancy_cashback_allocations(
                job_id,telegram_id,account_id,operation_type,amount_syp,eligible_amount_syp,status
            ) VALUES($1,$2,$3,'deposit',$4,$5,'pending')
            ON CONFLICT(job_id) DO NOTHING
            """,
            job_id, telegram_id, account_id, int(amount), int(eligible),
        )
        return eligible

    async def release_ichancy_deposit(self, conn: asyncpg.Connection, job_id: UUID) -> None:
        await self.release_wallet_spend(conn, source_type="ichancy_deposit", source_id=job_id)
        await conn.execute(
            "UPDATE bot_core.ichancy_cashback_allocations SET status='released',settled_at=NOW() WHERE job_id=$1 AND status='pending'",
            job_id,
        )

    async def finalize_ichancy_deposit(self, conn: asyncpg.Connection, job_id: UUID) -> None:
        await self.consume_wallet_spend(conn, source_type="ichancy_deposit", source_id=job_id)
        await conn.execute(
            "UPDATE bot_core.ichancy_cashback_allocations SET status='success',settled_at=NOW() WHERE job_id=$1 AND status='pending'",
            job_id,
        )

    async def _outstanding_account_principal(self, conn: asyncpg.Connection, account_id: UUID) -> int:
        dep = int(await conn.fetchval(
            "SELECT COALESCE(SUM(eligible_amount_syp),0) FROM bot_core.ichancy_cashback_allocations WHERE account_id=$1 AND status='success' AND operation_type='deposit'",
            account_id,
        ) or 0)
        wd = int(await conn.fetchval(
            "SELECT COALESCE(SUM(eligible_amount_syp),0) FROM bot_core.ichancy_cashback_allocations WHERE account_id=$1 AND status='success' AND operation_type IN ('withdraw','retirement_withdraw')",
            account_id,
        ) or 0)
        settled = int(await conn.fetchval(
            "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.cashback_principal_settlements WHERE account_id=$1",
            account_id,
        ) or 0)
        held = int(await conn.fetchval(
            "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.cashback_principal_holds WHERE account_id=$1 AND status='active'",
            account_id,
        ) or 0)
        return max(0, dep - wd - settled - held)

    async def finalize_ichancy_withdraw(
        self,
        conn: asyncpg.Connection,
        *,
        job_id: UUID,
        telegram_id: int,
        account_id: UUID,
        operation_type: str,
        amount: int,
    ) -> int:
        existing = await conn.fetchrow("SELECT * FROM bot_core.ichancy_cashback_allocations WHERE job_id=$1 FOR UPDATE", job_id)
        if existing:
            return int(existing["eligible_amount_syp"] or 0)
        outstanding = await self._outstanding_account_principal(conn, account_id)
        eligible_return = min(max(0, int(amount)), outstanding)
        await conn.execute(
            """
            INSERT INTO bot_core.ichancy_cashback_allocations(
                job_id,telegram_id,account_id,operation_type,amount_syp,eligible_amount_syp,status,settled_at
            ) VALUES($1,$2,$3,$4,$5,$6,'success',NOW())
            """,
            job_id, telegram_id, account_id, operation_type, int(amount), eligible_return,
        )
        if eligible_return:
            await conn.execute(
                """
                INSERT INTO bot_core.cashback_wallet_principal(telegram_id,eligible_syp)
                VALUES($1,$2)
                ON CONFLICT(telegram_id) DO UPDATE
                SET eligible_syp=bot_core.cashback_wallet_principal.eligible_syp+EXCLUDED.eligible_syp,
                    updated_at=NOW()
                """,
                telegram_id, eligible_return,
            )
        return eligible_return


@dataclass(frozen=True, slots=True)
class WheelClaimResult:
    ok: bool
    message: str
    prize: int = 0
    balance: int = 0
    free: bool = False


class WheelService:
    def __init__(self, db: Database, runtime: RuntimeSettingsService, wallet: WalletService) -> None:
        self.db = db
        self.runtime = runtime
        self.wallet = wallet

    def settings(self) -> tuple[int, int]:
        return max(0, self.runtime.get_int("wheel.min_deposit", 50_000)), max(0, self.runtime.get_int("wheel.fixed_prize", 1_000))

    def free_settings(self) -> tuple[bool, int]:
        return self.runtime.get_bool("wheel.free_spin_enabled", False), max(0, self.runtime.get_int("wheel.free_prize", 0))

    async def grant_new_user_free_entitlement(self, conn: asyncpg.Connection, telegram_id: int) -> None:
        enabled, _ = self.free_settings()
        if not enabled:
            return
        await conn.execute(
            "INSERT INTO bot_core.wheel_free_entitlements(telegram_id) VALUES($1) ON CONFLICT(telegram_id) DO NOTHING",
            telegram_id,
        )

    async def free_eligible(self, telegram_id: int) -> bool:
        enabled, _ = self.free_settings()
        if not enabled:
            return False
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return bool(await conn.fetchval(
                "SELECT 1 FROM bot_core.wheel_free_entitlements WHERE telegram_id=$1 AND claimed_at IS NULL",
                telegram_id,
            ))

    async def _daily_total(self, conn: asyncpg.Connection, telegram_id: int, start: datetime, end: datetime) -> int:
        value = await conn.fetchval(
            """
            SELECT COALESCE(SUM(CASE
                WHEN COALESCE(bonus_source,'')='special_user' THEN base_credit_syp
                ELSE total_credit_syp END),0)
            FROM bot_core.deposit_requests
            WHERE telegram_id=$1 AND status='success' AND created_at >= $2 AND created_at < $3
            """,
            telegram_id, start, end,
        )
        return int(value or 0)

    async def eligibility(self, telegram_id: int) -> tuple[bool, str, int]:
        min_dep, prize = self.settings()
        today = _utcnow().astimezone(DAMASCUS).date()
        start, end = _damascus_day_bounds(today)
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            if await conn.fetchval("SELECT 1 FROM bot_core.wheel_claims WHERE telegram_id=$1 AND claim_day=$2", telegram_id, today):
                return False, "❌ لقد قمت بتدوير العجلة واستلام جائزتك اليوم بالفعل!\nانتظر للغد لتدويرة جديدة.", prize
            total = await self._daily_total(conn, telegram_id, start, end)
        if total < min_dep:
            return False, (
                f"⚠️ يجب أن تشحن حسابك اليوم بمبلغ {min_dep:,} ل.س على الأقل للحصول على تدويرة مجانية.\n\n"
                f"💰 مجموع شحناتك لليوم: {total:,} ل.س"
            ), prize
        return True, "", prize

    async def claim(self, telegram_id: int) -> WheelClaimResult:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute("SELECT pg_advisory_xact_lock($1)", int(telegram_id))
                free_enabled, free_prize = self.free_settings()
                ent = None
                if free_enabled:
                    ent = await conn.fetchrow(
                        "SELECT * FROM bot_core.wheel_free_entitlements WHERE telegram_id=$1 FOR UPDATE", telegram_id
                    )
                if ent and ent["claimed_at"] is None:
                    prize = free_prize
                    mutation = None
                    if prize > 0:
                        mutation = await self.wallet.credit_in_transaction(
                            conn, telegram_id, prize,
                            idempotency_key=f"wheel-free:{telegram_id}",
                            reason="wheel_free_claim", actor_telegram_id=telegram_id,
                            metadata={"reward_source": "wheel_free", "cashback_eligible": False, "non_transferable_credit": True},
                        )
                    await conn.execute(
                        "UPDATE bot_core.wheel_free_entitlements SET claimed_at=NOW(),prize_syp=$2,wallet_operation_id=$3 WHERE telegram_id=$1 AND claimed_at IS NULL",
                        telegram_id, prize, mutation.operation_id if mutation else None,
                    )
                    bal = mutation.balance_after.available if mutation else int(await conn.fetchval(
                        "SELECT COALESCE(available,0) FROM bot_core.wallet_accounts WHERE telegram_id=$1 AND asset_code='SYP' AND bucket='cash'", telegram_id
                    ) or 0)
                    return WheelClaimResult(True, "", prize, bal, True)

                min_dep, prize = self.settings()
                today = _utcnow().astimezone(DAMASCUS).date()
                start, end = _damascus_day_bounds(today)
                if await conn.fetchval("SELECT 1 FROM bot_core.wheel_claims WHERE telegram_id=$1 AND claim_day=$2", telegram_id, today):
                    return WheelClaimResult(False, "❌ لقد قمت بتدوير العجلة واستلام جائزتك اليوم بالفعل!\nانتظر للغد لتدويرة جديدة.")
                total = await self._daily_total(conn, telegram_id, start, end)
                if total < min_dep:
                    return WheelClaimResult(False, f"⚠️ يجب أن تشحن حسابك اليوم بمبلغ {min_dep:,} ل.س على الأقل للحصول على تدويرة مجانية.\n\n💰 مجموع شحناتك لليوم: {total:,} ل.س")
                mutation = None
                if prize > 0:
                    mutation = await self.wallet.credit_in_transaction(
                        conn, telegram_id, prize,
                        idempotency_key=f"wheel:{telegram_id}:{today.isoformat()}",
                        reason="wheel_claim", actor_telegram_id=telegram_id,
                        metadata={"reward_source": "wheel", "cashback_eligible": False, "non_transferable_credit": True},
                    )
                await conn.execute(
                    "INSERT INTO bot_core.wheel_claims(telegram_id,claim_day,prize_syp,wallet_operation_id) VALUES($1,$2,$3,$4)",
                    telegram_id, today, prize, mutation.operation_id if mutation else None,
                )
                bal = mutation.balance_after.available if mutation else int(await conn.fetchval(
                    "SELECT COALESCE(available,0) FROM bot_core.wallet_accounts WHERE telegram_id=$1 AND asset_code='SYP' AND bucket='cash'", telegram_id
                ) or 0)
                return WheelClaimResult(True, "", prize, bal, False)


class ReferralService:
    def __init__(
        self, db: Database, runtime: RuntimeSettingsService, wallet: WalletService, ichancy_accounts: IchancyAccountsService,
        outbox: OutboxRepository | None = None,
    ) -> None:
        self.db = db
        self.runtime = runtime
        self.wallet = wallet
        self.ichancy_accounts = ichancy_accounts
        self.outbox = outbox

    def fixed_settings(self) -> dict[str, Any]:
        return {
            "enabled": self.runtime.get_bool("referral.fixed_enabled", False),
            "amount": max(0, self.runtime.get_int("referral.fixed_amount", 500)),
            "trigger": "first_deposit" if str(self.runtime.get("referral.fixed_trigger", "verify")) == "first_deposit" else "verify",
        }

    async def attach_first_touch(self, conn: asyncpg.Connection, telegram_id: int, referrer_id: int | None) -> bool:
        """Fallback first-touch attach: reserve the relation as pending, never confirmed.

        New users are normally attributed atomically by UserRepository.  This method
        stays idempotent for older callers and deliberately does not reserve/pay any
        fixed reward until explicit referral confirmation.
        """
        if not referrer_id or int(referrer_id) == int(telegram_id):
            return False
        user = await conn.fetchrow(
            "SELECT telegram_id,referrer_telegram_id,referral_status FROM bot_core.users WHERE telegram_id=$1 FOR UPDATE",
            telegram_id,
        )
        ref = await conn.fetchrow(
            "SELECT telegram_id,is_blocked,is_bot FROM bot_core.users WHERE telegram_id=$1", int(referrer_id)
        )
        if not user or user["referrer_telegram_id"] is not None or str(user["referral_status"]) != "none":
            return False
        if not ref or bool(ref["is_blocked"]) or bool(ref["is_bot"]):
            return False
        result = await conn.execute(
            """
            UPDATE bot_core.users
            SET referrer_telegram_id=$2, referral_status='pending',
                referral_first_seen_at=COALESCE(referral_first_seen_at,NOW()), updated_at=NOW()
            WHERE telegram_id=$1 AND referrer_telegram_id IS NULL AND referral_status='none'
            """,
            telegram_id, int(referrer_id),
        )
        return result.endswith("1")

    async def is_pending(self, telegram_id: int) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return bool(await conn.fetchval(
                """SELECT 1 FROM bot_core.users
                   WHERE telegram_id=$1 AND referrer_telegram_id IS NOT NULL AND referral_status='pending'""",
                int(telegram_id),
            ))

    async def _enqueue_join_notification_locked(
        self, conn: asyncpg.Connection, referred_id: int, referrer_id: int,
        *, reward: dict[str, Any] | None = None, confirmed_count: int | None = None,
        active_count: int | None = None,
    ) -> None:
        if self.outbox is None:
            return
        referred = await conn.fetchrow(
            "SELECT first_name,username FROM bot_core.users WHERE telegram_id=$1", referred_id
        )
        name = (str(referred["first_name"] or "").strip() if referred else "") or "مستخدم جديد"
        username = str(referred["username"] or "").strip() if referred and referred["username"] else ""
        user_line = f"👤 المستخدم: {name}" + (f" (@{username})" if username else "")
        lines = [
            "🎉 <b>إحالة جديدة!</b>", "",
            "تم تأكيد إحالة جديدة عن طريق رابطك بنجاح.", "",
            user_line, f"🆔 ID: <code>{referred_id}</code>",
        ]
        if reward and int(reward.get("amount") or 0) > 0:
            lines.extend([
                "", f"🎁 حصلت على مكافأة: <code>{int(reward['amount']):,}</code> ل.س",
                "💰 تمت إضافة المكافأة إلى رصيدك بنجاح.",
            ])
        if confirmed_count is not None:
            lines.extend(["", f"👥 إجمالي إحالاتك المؤكدة: <code>{int(confirmed_count)}</code>"])
        if active_count is not None:
            lines.append(f"🟢 الإحالات النشطة خلال الدورة: <code>{int(active_count)}</code>")
        await self.outbox.enqueue(
            event_key=f"referral-join:{referred_id}", target_chat_id=int(referrer_id), conn=conn,
            text="\n".join(lines),
        )

    async def confirm_pending(self, telegram_id: int) -> dict[str, Any]:
        """Confirm one pending first-touch relation after the explicit verification gate.

        Confirmation is authoritative and survives a fixed-reward failure.  The reward
        is attempted inside a nested transaction/savepoint and remains retryable.
        """
        result: dict[str, Any] = {
            "confirmed_now": False, "referrer": None, "reward": None,
            "confirmed_count": 0, "active_count": 0, "invalid": False,
        }
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                user = await conn.fetchrow(
                    "SELECT * FROM bot_core.users WHERE telegram_id=$1 FOR UPDATE", int(telegram_id)
                )
                if not user or user["referrer_telegram_id"] is None:
                    return result
                referrer = int(user["referrer_telegram_id"])
                result["referrer"] = referrer
                status = str(user["referral_status"] or "none")
                if status == "pending":
                    if bool(user["is_blocked"]) or bool(user["is_bot"]):
                        await conn.execute(
                            "UPDATE bot_core.users SET referral_status='invalid',updated_at=NOW() WHERE telegram_id=$1 AND referral_status='pending'",
                            int(telegram_id),
                        )
                        result["invalid"] = True
                        return result
                    owner = await conn.fetchrow(
                        "SELECT telegram_id FROM bot_core.users WHERE telegram_id=$1 AND NOT is_blocked AND NOT is_bot",
                        referrer,
                    )
                    if not owner or referrer == int(telegram_id):
                        await conn.execute(
                            "UPDATE bot_core.users SET referral_status='invalid',updated_at=NOW() WHERE telegram_id=$1 AND referral_status='pending'",
                            int(telegram_id),
                        )
                        result["invalid"] = True
                        return result
                    await conn.execute(
                        """UPDATE bot_core.users
                           SET referral_status='confirmed',referral_confirmed_at=NOW(),updated_at=NOW()
                           WHERE telegram_id=$1 AND referral_status='pending'""",
                        int(telegram_id),
                    )
                    result["confirmed_now"] = True

                    cfg = self.fixed_settings()
                    if cfg["enabled"] and int(cfg["amount"]) > 0:
                        await conn.execute(
                            """INSERT INTO bot_core.referral_fixed_entitlements(
                                   referred_telegram_id,referrer_telegram_id,amount_syp,trigger_type,status
                               ) VALUES($1,$2,$3,$4,'pending')
                               ON CONFLICT(referred_telegram_id) DO NOTHING""",
                            int(telegram_id), referrer, int(cfg["amount"]), str(cfg["trigger"]),
                        )
                        if str(cfg["trigger"]) == "verify":
                            try:
                                async with conn.transaction():
                                    result["reward"] = await self._grant_fixed_locked(
                                        conn, int(telegram_id), "verify", None, notify=False
                                    )
                            except Exception as exc:
                                logger.exception("referral verify reward failed referred=%s", telegram_id)
                                await conn.execute(
                                    """UPDATE bot_core.referral_fixed_entitlements
                                       SET attempts=attempts+1,last_error=$2
                                       WHERE referred_telegram_id=$1 AND status='pending'""",
                                    int(telegram_id), str(exc)[:500],
                                )

                elif status != "confirmed":
                    return result

                result["confirmed_count"] = int(await conn.fetchval(
                    "SELECT COUNT(*) FROM bot_core.users WHERE referrer_telegram_id=$1 AND referral_status='confirmed'",
                    referrer,
                ) or 0)
                active_cycle = await conn.fetchrow(
                    "SELECT * FROM bot_core.referral_cycles WHERE status='active' ORDER BY id DESC LIMIT 1"
                )
                if active_cycle:
                    result["active_count"] = await self.active_direct_count(conn, referrer, active_cycle)
                if result["confirmed_now"]:
                    await self._enqueue_join_notification_locked(
                        conn, int(telegram_id), referrer, reward=result.get("reward"),
                        confirmed_count=int(result["confirmed_count"]), active_count=int(result["active_count"]),
                    )
        return result

    async def _grant_fixed_locked(
        self, conn: asyncpg.Connection, referred_id: int, trigger: str, deposit_id: UUID | None,
        *, notify: bool = True,
    ) -> dict[str, Any] | None:
        ent = await conn.fetchrow(
            "SELECT * FROM bot_core.referral_fixed_entitlements WHERE referred_telegram_id=$1 FOR UPDATE",
            referred_id,
        )
        if not ent or str(ent["status"]) != "pending" or str(ent["trigger_type"]) != str(trigger):
            return None
        amount = int(ent["amount_syp"] or 0)
        referrer = int(ent["referrer_telegram_id"])
        valid = await conn.fetchval(
            """
            SELECT 1 FROM bot_core.users u JOIN bot_core.users r ON r.telegram_id=$2
            WHERE u.telegram_id=$1 AND u.referral_status='confirmed' AND u.referrer_telegram_id=$2
              AND NOT u.is_blocked AND NOT r.is_blocked AND NOT u.is_bot AND NOT r.is_bot
            """,
            referred_id, referrer,
        )
        if amount <= 0 or not valid:
            await conn.execute(
                "UPDATE bot_core.referral_fixed_entitlements SET status='cancelled',cancelled_at=NOW(),cancel_reason='ineligible' WHERE referred_telegram_id=$1",
                referred_id,
            )
            return None
        if trigger == "first_deposit":
            first_id = await conn.fetchval(
                "SELECT id FROM bot_core.deposit_requests WHERE telegram_id=$1 AND status='success' ORDER BY settled_at,id LIMIT 1",
                referred_id,
            )
            if first_id is None or (deposit_id is not None and UUID(str(first_id)) != UUID(str(deposit_id))):
                return None
        mutation = await self.wallet.credit_in_transaction(
            conn, referrer, amount,
            idempotency_key=f"referral-fixed:{referred_id}",
            reason="referral_fixed_reward", actor_telegram_id=None,
            metadata={"referred_telegram_id": referred_id, "trigger": trigger, "cashback_eligible": False, "non_transferable_credit": True},
        )
        await conn.execute(
            """
            INSERT INTO bot_core.referral_fixed_rewards(
                referred_telegram_id,referrer_telegram_id,amount_syp,trigger_type,deposit_id,wallet_operation_id
            ) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(referred_telegram_id) DO NOTHING
            """,
            referred_id, referrer, amount, trigger, deposit_id, mutation.operation_id,
        )
        await conn.execute(
            "UPDATE bot_core.referral_fixed_entitlements SET status='paid',eligible_at=COALESCE(eligible_at,NOW()),paid_at=NOW(),deposit_id=COALESCE(deposit_id,$2),last_error=NULL WHERE referred_telegram_id=$1",
            referred_id, deposit_id,
        )
        if self.outbox is not None and notify:
            referred = await conn.fetchrow("SELECT first_name,username FROM bot_core.users WHERE telegram_id=$1", referred_id)
            name = (str(referred['first_name'] or '').strip() if referred else '') or 'مستخدم جديد'
            username = (str(referred['username'] or '').strip() if referred and referred['username'] else '')
            user_line = f"👤 المستخدم: {name}" + (f" (@{username})" if username else "")
            if trigger == "verify":
                text = (
                    "🎁 <b>مكافأة إحالة</b>\n\n"
                    "تمت إضافة مكافأة تأكيد الإحالة المعلقة بنجاح.\n\n"
                    f"{user_line}\n🆔 ID: <code>{referred_id}</code>\n\n"
                    f"🎁 تمت إضافة: <code>{amount:,}</code> ل.س\n"
                    f"💰 رصيدك الحالي: <code>{mutation.balance_after.available:,}</code> ل.س"
                )
            else:
                text = (
                    "🎁 <b>مكافأة إحالة</b>\n\n"
                    "أكملت إحالتك أول عملية شحن ناجحة.\n\n"
                    f"{user_line}\n🆔 ID: <code>{referred_id}</code>\n\n"
                    f"🎁 تمت إضافة: <code>{amount:,}</code> ل.س\n"
                    f"💰 رصيدك الحالي: <code>{mutation.balance_after.available:,}</code> ل.س"
                )
            await self.outbox.enqueue(
                event_key=f"referral-fixed-user:{referred_id}", target_chat_id=referrer, conn=conn, text=text
            )
        return {"referrer": referrer, "amount": amount, "balance": mutation.balance_after.available}

    async def on_successful_deposit(self, conn: asyncpg.Connection, telegram_id: int, deposit_id: UUID) -> None:
        # Optional referral side-effects must never roll back an already successful deposit.
        try:
            async with conn.transaction():
                await self._grant_fixed_locked(conn, telegram_id, "first_deposit", deposit_id)
        except Exception as exc:
            logger.exception("first-deposit referral reward failed referred=%s deposit=%s", telegram_id, deposit_id)
            await conn.execute(
                """UPDATE bot_core.referral_fixed_entitlements
                   SET attempts=attempts+1,last_error=$2
                   WHERE referred_telegram_id=$1 AND status='pending' AND trigger_type='first_deposit'""",
                int(telegram_id), str(exc)[:500],
            )

    async def retry_pending_fixed_rewards(self, limit: int = 50) -> dict[str, int]:
        paid = cancelled = waiting = failed = 0
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            ids = await conn.fetch(
                """SELECT referred_telegram_id FROM bot_core.referral_fixed_entitlements
                   WHERE status='pending' ORDER BY created_at ASC LIMIT $1""",
                max(1, min(500, int(limit))),
            )
        for item in ids:
            referred_id = int(item["referred_telegram_id"])
            try:
                async with pool.acquire() as conn:
                    async with conn.transaction():
                        ent = await conn.fetchrow(
                            "SELECT * FROM bot_core.referral_fixed_entitlements WHERE referred_telegram_id=$1 FOR UPDATE",
                            referred_id,
                        )
                        if not ent or str(ent["status"]) != "pending":
                            continue
                        trigger = str(ent["trigger_type"] or "verify")
                        deposit_id = None
                        if trigger == "first_deposit":
                            deposit_id = await conn.fetchval(
                                """SELECT id FROM bot_core.deposit_requests
                                   WHERE telegram_id=$1 AND status='success'
                                   ORDER BY settled_at ASC,id ASC LIMIT 1""",
                                referred_id,
                            )
                            if deposit_id is None:
                                waiting += 1
                                continue
                        try:
                            async with conn.transaction():
                                reward = await self._grant_fixed_locked(
                                    conn, referred_id, trigger, UUID(str(deposit_id)) if deposit_id else None
                                )
                        except Exception as exc:
                            await conn.execute(
                                """UPDATE bot_core.referral_fixed_entitlements
                                   SET attempts=attempts+1,last_error=$2
                                   WHERE referred_telegram_id=$1 AND status='pending'""",
                                referred_id, str(exc)[:500],
                            )
                            failed += 1
                            continue
                        status = await conn.fetchval(
                            "SELECT status FROM bot_core.referral_fixed_entitlements WHERE referred_telegram_id=$1", referred_id
                        )
                        if reward:
                            paid += 1
                        elif str(status) == "cancelled":
                            cancelled += 1
                        else:
                            waiting += 1
            except Exception:
                failed += 1
                logger.exception("fixed referral reward retry failed referred=%s", referred_id)
        return {"paid": paid, "cancelled": cancelled, "waiting": waiting, "failed": failed}

    async def current_cycle(self) -> asyncpg.Record | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetchrow(
                "SELECT * FROM bot_core.referral_cycles WHERE status IN ('active','preparing','ready','distributing') ORDER BY id DESC LIMIT 1"
            )

    async def start_cycle(self, *, mode: str, admin_id: int | None = None) -> asyncpg.Record:
        mode = "hierarchical" if mode == "hierarchical" else "direct"
        days = max(1, self.runtime.get_int("referral.cycle_days", 10))
        direct = self.runtime.get_decimal("referral.direct_pct", Decimal("4"))
        p1 = self.runtime.get_decimal("referral.level1_pct", direct)
        p2 = self.runtime.get_decimal("referral.level2_pct", Decimal("2"))
        p3 = self.runtime.get_decimal("referral.level3_pct", Decimal("1"))
        min_refs = max(0, self.runtime.get_int("referral.min_active_refs", 3))
        active_min = max(0, self.runtime.get_int("referral.active_min_deposit", 0))
        now = _utcnow()
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                existing = await conn.fetchrow(
                    "SELECT id FROM bot_core.referral_cycles WHERE status IN ('active','preparing','ready','distributing') FOR UPDATE"
                )
                if existing:
                    raise ValueError("REFERRAL_CYCLE_ALREADY_OPEN")
                return await conn.fetchrow(
                    """
                    INSERT INTO bot_core.referral_cycles(
                        mode,status,duration_days,cycle_start,cycle_end,direct_pct,level1_pct,level2_pct,level3_pct,
                        min_active_refs,active_min_deposit
                    ) VALUES($1,'active',$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *
                    """,
                    mode, days, now, now + timedelta(days=days), direct, p1, p2, p3, min_refs, active_min,
                )

    async def active_direct_count(self, conn: asyncpg.Connection, referrer_id: int, cycle: asyncpg.Record, cutoff: datetime | None = None) -> int:
        cutoff = cutoff or min(_utcnow(), cycle["cycle_end"])
        active_min = max(1, int(cycle["active_min_deposit"] or 0))
        return int(await conn.fetchval(
            """
            SELECT COUNT(*) FROM bot_core.users u
            WHERE u.referrer_telegram_id=$1 AND u.referral_status='confirmed' AND NOT u.is_blocked AND NOT u.is_bot
              AND COALESCE(u.referral_confirmed_at,u.created_at) < $3
              AND EXISTS (
                SELECT 1 FROM bot_core.deposit_requests d
                WHERE d.telegram_id=u.telegram_id AND d.status='success'
                  AND d.settled_at >= $2 AND d.settled_at < $3
                  AND d.settled_at >= COALESCE(u.referral_confirmed_at,u.created_at)
                  AND d.base_credit_syp >= $4
              )
            """,
            referrer_id, cycle["cycle_start"], cutoff, active_min,
        ) or 0)

    async def dashboard(self, telegram_id: int) -> dict[str, Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = int(await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.users WHERE referrer_telegram_id=$1 AND referral_status='confirmed'", telegram_id
            ) or 0)
            cycle = await conn.fetchrow(
                "SELECT * FROM bot_core.referral_cycles WHERE status IN ('active','preparing','ready','distributing') ORDER BY id DESC LIMIT 1"
            )
            active = await self.active_direct_count(conn, telegram_id, cycle) if cycle else 0
            fixed_paid = int(await conn.fetchval(
                "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_fixed_rewards WHERE referrer_telegram_id=$1", telegram_id
            ) or 0)
            pending = int(await conn.fetchval(
                "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 AND status='pending'", telegram_id
            ) or 0)
            distributed = int(await conn.fetchval(
                "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 AND status='paid'", telegram_id
            ) or 0)
        cfg = self.fixed_settings()
        out: dict[str, Any] = {
            "total": total, "active": active, "fixed": fixed_paid, "pending": pending, "distributed": distributed,
            "fixed_enabled": cfg["enabled"], "fixed_amount": cfg["amount"], "fixed_trigger": cfg["trigger"],
            "status": "none", "mode": str(self.runtime.get("referral.mode", "direct")),
        }
        if cycle:
            now = _utcnow()
            out.update(dict(cycle))
            out["remaining_seconds"] = max(0, int((cycle["cycle_end"] - now).total_seconds()))
            out["remaining_days"] = max(0, int((cycle["cycle_end"] - now).total_seconds() // 86400))
            out["cycle_days"] = int(cycle["duration_days"])
        return out

    async def my_referrals(self, telegram_id: int, limit: int = 20) -> tuple[list[dict[str, Any]], int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow(
                "SELECT * FROM bot_core.referral_cycles WHERE status IN ('active','preparing','ready','distributing') ORDER BY id DESC LIMIT 1"
            )
            rows = await conn.fetch(
                """
                SELECT telegram_id,first_name,username,COALESCE(referral_confirmed_at,created_at) AS referral_confirmed_at
                FROM bot_core.users WHERE referrer_telegram_id=$1 AND referral_status='confirmed'
                ORDER BY COALESCE(referral_confirmed_at,created_at) DESC,telegram_id DESC LIMIT $2
                """,
                telegram_id, limit,
            )
            total = int(await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.users WHERE referrer_telegram_id=$1 AND referral_status='confirmed'", telegram_id
            ) or 0)
            output = []
            for r in rows:
                active = bool(cycle and await self._is_direct_active(conn, int(r["telegram_id"]), cycle))
                output.append({**dict(r), "is_active": active})
        return output, total

    async def _is_direct_active(self, conn: asyncpg.Connection, referred_id: int, cycle: asyncpg.Record) -> bool:
        active_min = max(1, int(cycle["active_min_deposit"] or 0))
        return bool(await conn.fetchval(
            """
            SELECT 1 FROM bot_core.users u WHERE u.telegram_id=$1 AND u.referral_status='confirmed' AND NOT u.is_blocked AND NOT u.is_bot
              AND COALESCE(u.referral_confirmed_at,u.created_at) < $3
              AND EXISTS(SELECT 1 FROM bot_core.deposit_requests d WHERE d.telegram_id=u.telegram_id AND d.status='success'
                  AND d.settled_at >= $2 AND d.settled_at < $3 AND d.settled_at >= COALESCE(u.referral_confirmed_at,u.created_at) AND d.base_credit_syp >= $4)
            """,
            referred_id, cycle["cycle_start"], min(_utcnow(), cycle["cycle_end"]), active_min,
        ))

    async def earnings_report(self, telegram_id: int) -> dict[str, Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            fixed = int(await conn.fetchval("SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_fixed_rewards WHERE referrer_telegram_id=$1", telegram_id) or 0)
            distributed = int(await conn.fetchval("SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 AND status='paid'", telegram_id) or 0)
            pending = int(await conn.fetchval("SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 AND status='pending'", telegram_id) or 0)
            latest = await conn.fetch(
                "SELECT level,amount_syp,status,created_at FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 ORDER BY id DESC LIMIT 10",
                telegram_id,
            )
        return {"fixed": fixed, "distributed": distributed, "pending": pending, "latest": [dict(x) for x in latest]}

    async def _balance_for_account(self, account_id: UUID) -> tuple[int, datetime]:
        account = await self.ichancy_accounts.repository.get_account(account_id)
        if not account:
            raise RuntimeError("iChancy account missing")
        cashier = await self.ichancy_accounts.repository.get_cashier(account.cashier_id)
        if not cashier:
            raise RuntimeError("iChancy cashier missing")
        last: Exception | None = None
        for attempt in range(3):
            try:
                resp = await self.ichancy_accounts._client(cashier).get_player_balance(account.player_id)
                value = extract_player_balance_value(resp)
                if value is None:
                    raise RuntimeError("empty player balance")
                return max(0, int(value)), _utcnow()
            except Exception as exc:
                last = exc
                if attempt < 2:
                    await asyncio.sleep(0.7 * (attempt + 1))
        raise RuntimeError(str(last or "balance lookup failed"))

    async def _signed_results_for_windows(
        self, telegram_id: int, starts: list[datetime], end: datetime
    ) -> dict[datetime, tuple[int, dict[str, Any]]]:
        """Calculate all referral hierarchy windows from one authoritative end snapshot.

        Provider-success time is authoritative for financial window placement. A local
        reconciliation that finishes after the cycle must not move an operation into a
        later cycle. Post-boundary provider successes are reversed from the live
        balance, while ambiguous post-boundary POSTs fail closed until reconciled.
        """
        unique_starts = sorted(set(starts))
        if not unique_starts:
            return {}
        base_start = unique_starts[0]
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            accounts = await conn.fetch(
                """SELECT DISTINCT account_id FROM bot_core.ichancy_jobs
                   WHERE telegram_id=$1 AND status='success'
                     AND operation_type IN ('deposit','withdraw','retirement_withdraw')
                     AND COALESCE(remote_success_at,finished_at) >= $2
                     AND COALESCE(remote_success_at,finished_at) < $3
                   ORDER BY account_id""",
                telegram_id, base_start, end,
            )

        frozen: dict[UUID, dict[str, Any]] = {}
        for ar in accounts:
            account_id = ar["account_id"]
            observed, captured_at = await self._balance_for_account(account_id)
            async with pool.acquire() as conn:
                unresolved = int(await conn.fetchval(
                    """SELECT COUNT(*) FROM bot_core.ichancy_jobs
                       WHERE account_id=$1
                         AND status IN ('executing','reconciling')
                         AND financial_post_started_at IS NOT NULL
                         AND financial_post_started_at >= $2
                         AND financial_post_started_at <= $3""",
                    account_id, end, captured_at,
                ) or 0)
                if unresolved:
                    raise RuntimeError('unresolved iChancy financial operation after referral boundary')
                post = await conn.fetchrow(
                    """SELECT COALESCE(SUM(CASE WHEN operation_type='deposit' THEN amount ELSE 0 END),0) dep,
                              COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN amount ELSE 0 END),0) wd
                       FROM bot_core.ichancy_jobs
                       WHERE account_id=$1 AND status IN ('success','remote_success')
                         AND COALESCE(remote_success_at,finished_at) >= $2
                         AND COALESCE(remote_success_at,finished_at) <= $3""",
                    account_id, end, captured_at,
                )
            adjusted = max(0, observed - int(post["dep"] or 0) + int(post["wd"] or 0))
            frozen[account_id] = {
                "observed_balance": observed, "adjusted_end_balance": adjusted,
                "post_deposits": int(post["dep"] or 0), "post_withdrawals": int(post["wd"] or 0),
                "captured_at": captured_at.isoformat(),
            }

        results: dict[datetime, tuple[int, dict[str, Any]]] = {}
        for start in unique_starts:
            total = 0
            details: list[dict[str, Any]] = []
            for account_id, snap in frozen.items():
                async with pool.acquire() as conn:
                    sums = await conn.fetchrow(
                        """SELECT COALESCE(SUM(CASE WHEN operation_type='deposit' THEN amount ELSE 0 END),0) dep,
                                  COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN amount ELSE 0 END),0) wd
                           FROM bot_core.ichancy_jobs
                           WHERE telegram_id=$1 AND account_id=$2 AND status='success'
                             AND COALESCE(remote_success_at,finished_at) >= $3
                             AND COALESCE(remote_success_at,finished_at) < $4""",
                        telegram_id, account_id, start, end,
                    )
                dep, wd = int(sums["dep"] or 0), int(sums["wd"] or 0)
                if dep == 0 and wd == 0:
                    continue
                cash_net = dep - wd
                signed = cash_net if cash_net < 0 else max(0, cash_net - int(snap["adjusted_end_balance"]))
                total += signed
                details.append({
                    "account_id": str(account_id), "deposits": dep, "withdrawals": wd,
                    **snap, "signed_result": signed,
                })
            results[start] = (int(total), {"accounts": details})
        return results

    async def _signed_result_for_user(
        self, telegram_id: int, start: datetime, end: datetime
    ) -> tuple[int, dict[str, Any]]:
        return (await self._signed_results_for_windows(telegram_id, [start], end))[start]

    async def _network_chain(self, conn: asyncpg.Connection, referred_id: int, cycle: asyncpg.Record) -> list[dict[str, Any]]:
        mode = str(cycle["mode"])
        max_level = 1 if mode == "direct" else 3
        pcts = [Decimal(str(cycle["direct_pct"] if mode == "direct" else cycle["level1_pct"])), Decimal(str(cycle["level2_pct"])), Decimal(str(cycle["level3_pct"]))]
        chain: list[dict[str, Any]] = []
        current = referred_id
        seen = {int(referred_id)}
        effective = cycle["cycle_start"]
        for level in range(1, max_level + 1):
            u = await conn.fetchrow(
                "SELECT referrer_telegram_id,referral_status,COALESCE(referral_confirmed_at,created_at) AS confirmed_at FROM bot_core.users WHERE telegram_id=$1", current
            )
            if not u or str(u["referral_status"]) != "confirmed" or not u["referrer_telegram_id"]:
                break
            referrer = int(u["referrer_telegram_id"])
            if referrer in seen:
                break
            seen.add(referrer)
            owner = await conn.fetchrow(
                "SELECT is_blocked,is_bot FROM bot_core.users WHERE telegram_id=$1", referrer
            )
            confirmed_at = u["confirmed_at"]
            if confirmed_at is None or confirmed_at >= cycle["cycle_end"]:
                break
            effective = max(effective, confirmed_at)
            owner_valid = bool(owner and not bool(owner["is_blocked"]) and not bool(owner["is_bot"]))
            active_count = await self.active_direct_count(conn, referrer, cycle, cutoff=cycle["cycle_end"]) if owner_valid else 0
            qualifies = owner_valid and active_count >= int(cycle["min_active_refs"] or 0) and pcts[level-1] > 0
            chain.append({"referrer": referrer, "level": level, "pct": pcts[level-1], "window_start": effective, "qualifies": qualifies})
            current = referrer
        return chain

    async def _unresolved_referral_financial_jobs(self, cycle_end: datetime) -> int:
        """Block referral freezing while a referred user's pre-boundary POST is ambiguous."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return int(await conn.fetchval(
                """
                SELECT COUNT(*)
                FROM bot_core.ichancy_jobs j
                JOIN bot_core.users u ON u.telegram_id=j.telegram_id
                WHERE u.referral_status='confirmed'
                  AND COALESCE(u.referral_confirmed_at,u.created_at) < $1
                  AND j.operation_type IN ('deposit','withdraw','retirement_withdraw')
                  AND j.status IN ('executing','remote_success','reconciling')
                  AND COALESCE(j.financial_post_started_at,j.remote_success_at,j.reconcile_started_at) IS NOT NULL
                  AND COALESCE(j.financial_post_started_at,j.remote_success_at,j.reconcile_started_at) < $1
                """,
                cycle_end,
            ) or 0)

    async def prepare_ended_cycle(self, cycle_id: int) -> dict[str, Any]:
        """Freeze an ended referral cycle without guessing missing iChancy balances.

        Successful player snapshots are reused on retries.  A failed authoritative
        balance lookup is persisted and keeps the cycle in ``preparing``; therefore
        neither admin distribution nor a later retry can silently treat it as zero.
        """
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow(
                "SELECT * FROM bot_core.referral_cycles WHERE id=$1", cycle_id
            )
        if not cycle or str(cycle["status"]) not in {"active", "preparing"}:
            return {"done": False}
        if cycle["cycle_end"] > _utcnow():
            return {"done": False}

        unresolved = await self._unresolved_referral_financial_jobs(cycle["cycle_end"])
        if unresolved > 0:
            async with pool.acquire() as conn:
                await conn.execute(
                    "UPDATE bot_core.referral_cycles SET status='preparing',updated_at=NOW() WHERE id=$1",
                    cycle_id,
                )
            return {
                "done": False,
                "status": "preparing",
                "blocked": "unresolved_ichancy_jobs",
                "unresolved_jobs": unresolved,
            }

        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle = await conn.fetchrow(
                    "SELECT * FROM bot_core.referral_cycles WHERE id=$1 FOR UPDATE", cycle_id
                )
                if not cycle or str(cycle["status"]) not in {"active", "preparing"}:
                    return {"done": False}
                if cycle["cycle_end"] > _utcnow():
                    return {"done": False}
                await conn.execute(
                    "UPDATE bot_core.referral_cycles SET status='preparing',updated_at=NOW() WHERE id=$1", cycle_id
                )
                # Rebuild only never-paid preparation rows. Paid history is never touched.
                await conn.execute(
                    "DELETE FROM bot_core.referral_earnings WHERE cycle_id=$1 AND status='pending'", cycle_id
                )
                await conn.execute(
                    "DELETE FROM bot_core.referral_cycle_payouts WHERE cycle_id=$1 AND status='pending'", cycle_id
                )
                cycle = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1", cycle_id)
                referred_rows = await conn.fetch(
                    """SELECT telegram_id FROM bot_core.users
                       WHERE referral_status='confirmed' AND COALESCE(referral_confirmed_at,created_at) < $1
                         AND NOT is_blocked AND NOT is_bot ORDER BY telegram_id""",
                    cycle["cycle_end"],
                )

        aggregated: dict[tuple[int, int, Decimal], int] = {}
        failed_count = 0

        def merge_levels(raw_details: Any) -> None:
            details = raw_details
            if isinstance(details, str):
                try:
                    details = json.loads(details)
                except Exception:
                    details = {}
            if not isinstance(details, dict):
                return
            for item in details.get("levels") or []:
                try:
                    key = (int(item["referrer_tg"]), int(item["level"]), Decimal(str(item["pct"])))
                    aggregated[key] = aggregated.get(key, 0) + int(item.get("net_loss") or 0)
                except Exception:
                    logger.exception("invalid frozen referral snapshot level cycle=%s", cycle_id)

        for rr in referred_rows:
            referred = int(rr["telegram_id"])
            async with pool.acquire() as conn:
                frozen = await conn.fetchrow(
                    "SELECT * FROM bot_core.referral_loss_snapshots WHERE cycle_id=$1 AND referred_telegram_id=$2",
                    cycle_id, referred,
                )
            if frozen and str(frozen["status"]) in {"ready", "not_eligible"}:
                # Even a profitable/not-eligible referred player must keep its signed
                # level result, because that profit offsets losses elsewhere in the
                # same referral network.  "not_eligible" only means this user did not
                # create a positive base loss; it does not erase the frozen level data.
                merge_levels(frozen["details"])
                continue

            async with pool.acquire() as conn:
                chain = await self._network_chain(conn, referred, cycle)
            qualified = [item for item in chain if item["qualifies"]]
            if not qualified:
                window_start = chain[0]["window_start"] if chain else cycle["cycle_start"]
                async with pool.acquire() as conn:
                    await conn.execute(
                        """INSERT INTO bot_core.referral_loss_snapshots(
                               cycle_id,referred_telegram_id,window_start,window_end,net_result_syp,details,status,attempts,error_message
                           ) VALUES($1,$2,$3,$4,0,$5::jsonb,'not_eligible',1,NULL)
                           ON CONFLICT(cycle_id,referred_telegram_id) DO UPDATE SET
                               window_start=EXCLUDED.window_start,window_end=EXCLUDED.window_end,net_result_syp=0,
                               details=EXCLUDED.details,status='not_eligible',attempts=bot_core.referral_loss_snapshots.attempts+1,
                               error_code=NULL,error_message=NULL,prepared_at=NOW()""",
                        cycle_id, referred, window_start, cycle["cycle_end"],
                        json.dumps({"levels": [], "reason": "no_qualified_referrer"}, ensure_ascii=False),
                    )
                continue

            local_levels: list[dict[str, Any]] = []
            local_contributions: list[tuple[tuple[int, int, Decimal], int]] = []
            base_signed = 0
            base_details: dict[str, Any] = {}
            failure: Exception | None = None
            window_start = chain[0]["window_start"]
            starts = [window_start] + [item["window_start"] for item in qualified]
            try:
                frozen_results = await self._signed_results_for_windows(referred, starts, cycle["cycle_end"])
                base_signed, base_details = frozen_results[window_start]
                for item in chain:
                    if not item["qualifies"]:
                        continue
                    signed, _details = frozen_results[item["window_start"]]
                    key = (int(item["referrer"]), int(item["level"]), Decimal(item["pct"]))
                    local_contributions.append((key, int(signed)))
                    local_levels.append({
                        "referrer_tg": key[0], "level": key[1], "pct": str(key[2]),
                        "window_start": item["window_start"].isoformat(), "net_loss": int(signed),
                    })
            except Exception as exc:
                failure = exc

            if failure is not None:
                failed_count += 1
                async with pool.acquire() as conn:
                    await conn.execute(
                        """INSERT INTO bot_core.referral_loss_snapshots(
                               cycle_id,referred_telegram_id,window_start,window_end,net_result_syp,details,status,attempts,error_code,error_message
                           ) VALUES($1,$2,$3,$4,0,$5::jsonb,'failed',1,'balance_lookup_failed',$6)
                           ON CONFLICT(cycle_id,referred_telegram_id) DO UPDATE SET
                               window_start=EXCLUDED.window_start,window_end=EXCLUDED.window_end,net_result_syp=0,
                               details=EXCLUDED.details,status='failed',attempts=bot_core.referral_loss_snapshots.attempts+1,
                               error_code=EXCLUDED.error_code,error_message=EXCLUDED.error_message,prepared_at=NOW()""",
                        cycle_id, referred, window_start, cycle["cycle_end"],
                        json.dumps({"levels": local_levels, "error": str(failure)[:1200]}, ensure_ascii=False),
                        str(failure)[:1200],
                    )
                async with pool.acquire() as conn:
                    remaining_failed = int(await conn.fetchval(
                        "SELECT COUNT(*) FROM bot_core.referral_loss_snapshots WHERE cycle_id=$1 AND status='failed'", cycle_id
                    ) or 0)
                    await conn.execute(
                        "UPDATE bot_core.referral_cycles SET status='preparing',failed_count=$2,updated_at=NOW() WHERE id=$1",
                        cycle_id, remaining_failed,
                    )
                return {"done": False, "status": "preparing", "failed_count": remaining_failed, "failed_telegram_id": referred}

            frozen_details = {**base_details, "levels": local_levels}
            async with pool.acquire() as conn:
                snapshot_status = "ready" if int(base_signed) > 0 else "not_eligible"
                await conn.execute(
                    """INSERT INTO bot_core.referral_loss_snapshots(
                           cycle_id,referred_telegram_id,window_start,window_end,net_result_syp,details,status,attempts,error_code,error_message
                       ) VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,1,NULL,NULL)
                       ON CONFLICT(cycle_id,referred_telegram_id) DO UPDATE SET
                           window_start=EXCLUDED.window_start,window_end=EXCLUDED.window_end,
                           net_result_syp=EXCLUDED.net_result_syp,details=EXCLUDED.details,status=EXCLUDED.status,
                           attempts=bot_core.referral_loss_snapshots.attempts+1,error_code=NULL,error_message=NULL,prepared_at=NOW()""",
                    cycle_id, referred, window_start, cycle["cycle_end"], base_signed,
                    json.dumps(frozen_details, ensure_ascii=False), snapshot_status,
                )
            for key, signed in local_contributions:
                aggregated[key] = aggregated.get(key, 0) + int(signed)

        # Count persisted failures as the authority, including failures from earlier ticks.
        async with pool.acquire() as conn:
            failed_count = int(await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.referral_loss_snapshots WHERE cycle_id=$1 AND status='failed'", cycle_id
            ) or 0)
            if failed_count > 0:
                await conn.execute(
                    """UPDATE bot_core.referral_cycles
                       SET status='preparing',failed_count=$2,updated_at=NOW() WHERE id=$1""",
                    cycle_id, failed_count,
                )
                return {"done": False, "status": "preparing", "failed_count": failed_count}

        async with pool.acquire() as conn:
            async with conn.transaction():
                own = await conn.fetchrow(
                    "SELECT * FROM bot_core.referral_cycles WHERE id=$1 FOR UPDATE", cycle_id
                )
                if not own or str(own["status"]) != "preparing":
                    return {"done": False}
                for (referrer, level, pct), network_result in aggregated.items():
                    if network_result <= 0:
                        continue
                    amount = int((Decimal(network_result) * pct / Decimal(100)).quantize(Decimal("1")))
                    if amount <= 0:
                        continue
                    await conn.execute(
                        """INSERT INTO bot_core.referral_earnings(
                               cycle_id,referrer_telegram_id,level,pct,base_net_loss_syp,amount_syp,status
                           ) VALUES($1,$2,$3,$4,$5,$6,'pending')
                           ON CONFLICT(cycle_id,referrer_telegram_id,level) DO UPDATE SET
                               pct=EXCLUDED.pct,base_net_loss_syp=EXCLUDED.base_net_loss_syp,amount_syp=EXCLUDED.amount_syp""",
                        cycle_id, referrer, level, pct, network_result, amount,
                    )
                due = await conn.fetch(
                    """SELECT referrer_telegram_id,COALESCE(SUM(amount_syp),0) amount
                       FROM bot_core.referral_earnings WHERE cycle_id=$1 AND status='pending'
                       GROUP BY referrer_telegram_id HAVING COALESCE(SUM(amount_syp),0)>0""",
                    cycle_id,
                )
                total = 0
                for d in due:
                    referrer, amount = int(d["referrer_telegram_id"]), int(d["amount"] or 0)
                    total += amount
                    active = await self.active_direct_count(conn, referrer, own, cutoff=own["cycle_end"])
                    await conn.execute(
                        """INSERT INTO bot_core.referral_cycle_payouts(
                               cycle_id,referrer_telegram_id,amount_syp,active_referrals,status
                           ) VALUES($1,$2,$3,$4,'pending')
                           ON CONFLICT(cycle_id,referrer_telegram_id) DO NOTHING""",
                        cycle_id, referrer, amount, active,
                    )
                status = "ready" if due else "empty"
                await conn.execute(
                    """UPDATE bot_core.referral_cycles
                       SET status=$2,prepared_at=NOW(),eligible_count=$3,total_amount_syp=$4,
                           failed_count=0,updated_at=NOW() WHERE id=$1""",
                    cycle_id, status, len(due), total,
                )
        return {"done": True, "status": status, "count": len(due), "total": total, "failed_count": 0}

    async def distribute(self, cycle_id: int, admin_id: int) -> dict[str, Any]:
        pool = self.db.require_pool()
        paid = total = skipped = 0
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1 FOR UPDATE", cycle_id)
                if not cycle or str(cycle["status"]) not in {"ready", "distributing"}:
                    raise ValueError("REFERRAL_CYCLE_NOT_READY")
                await conn.execute("UPDATE bot_core.referral_cycles SET status='distributing',updated_at=NOW() WHERE id=$1", cycle_id)
                rows = await conn.fetch("SELECT * FROM bot_core.referral_cycle_payouts WHERE cycle_id=$1 AND status='pending' ORDER BY referrer_telegram_id FOR UPDATE", cycle_id)
                for row in rows:
                    amount = int(row["amount_syp"] or 0)
                    tg = int(row["referrer_telegram_id"])
                    valid = bool(await conn.fetchval(
                        "SELECT 1 FROM bot_core.users WHERE telegram_id=$1 AND NOT is_blocked AND NOT is_bot", tg
                    ))
                    if amount <= 0 or not valid:
                        await conn.execute(
                            "UPDATE bot_core.referral_cycle_payouts SET status='skipped',paid_at=NOW() WHERE cycle_id=$1 AND referrer_telegram_id=$2 AND status='pending'",
                            cycle_id, tg,
                        )
                        await conn.execute(
                            "UPDATE bot_core.referral_earnings SET status='skipped',distributed_at=NOW() WHERE cycle_id=$1 AND referrer_telegram_id=$2 AND status='pending'",
                            cycle_id, tg,
                        )
                        skipped += 1
                        continue
                    mutation = await self.wallet.credit_in_transaction(
                        conn, tg, amount,
                        idempotency_key=f"referral-cycle:{cycle_id}:{tg}", reason="referral_distribution",
                        actor_telegram_id=admin_id, metadata={"cycle_id": cycle_id, "cashback_eligible": False, "non_transferable_credit": True},
                    )
                    await conn.execute(
                        "UPDATE bot_core.referral_cycle_payouts SET status='paid',paid_at=NOW(),wallet_operation_id=$3 WHERE cycle_id=$1 AND referrer_telegram_id=$2",
                        cycle_id, tg, mutation.operation_id,
                    )
                    await conn.execute(
                        "UPDATE bot_core.referral_earnings SET status='paid',distributed_at=NOW() WHERE cycle_id=$1 AND referrer_telegram_id=$2 AND status='pending'",
                        cycle_id, tg,
                    )
                    if self.outbox is not None:
                        await self.outbox.enqueue(
                            event_key=f"referral-cycle-user:{cycle_id}:{tg}", target_chat_id=tg, conn=conn,
                            text=(
                                "🎉 <b>تم توزيع أرباح الإحالات</b>\n\n"
                                f"💰 أرباح هذه الدورة: <code>{amount:,}</code> ل.س\n"
                                f"👛 رصيدك الحالي: <code>{mutation.balance_after.available:,}</code> ل.س"
                            ),
                        )
                    paid += 1; total += amount
                await conn.execute(
                    "UPDATE bot_core.referral_cycles SET status='distributed',distributed_at=NOW(),distributed_by=$2,paid_count=$3,total_paid_syp=$4,skipped_count=$5,updated_at=NOW() WHERE id=$1",
                    cycle_id, admin_id, paid, total, skipped,
                )
        return {"paid_count": paid, "total": total, "skipped_count": skipped}

    async def skip(self, cycle_id: int, admin_id: int) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1 FOR UPDATE", cycle_id)
                if not cycle or str(cycle["status"]) not in {"ready", "empty"}:
                    raise ValueError("REFERRAL_CYCLE_NOT_SKIPPABLE")
                stats = await conn.fetchrow(
                    "SELECT COUNT(*) cnt,COALESCE(SUM(amount_syp),0) amount FROM bot_core.referral_cycle_payouts WHERE cycle_id=$1 AND status='pending'",
                    cycle_id,
                )
                await conn.execute("UPDATE bot_core.referral_cycle_payouts SET status='skipped',paid_at=NOW() WHERE cycle_id=$1 AND status='pending'", cycle_id)
                await conn.execute("UPDATE bot_core.referral_earnings SET status='skipped',distributed_at=NOW() WHERE cycle_id=$1 AND status='pending'", cycle_id)
                await conn.execute(
                    "UPDATE bot_core.referral_cycles SET status='skipped',skipped_at=NOW(),skipped_by=$2,skipped_eligible_count=$3,skipped_amount_syp=$4,updated_at=NOW() WHERE id=$1",
                    cycle_id, admin_id, int(stats['cnt'] or 0), int(stats['amount'] or 0),
                )

    async def history(self, limit: int = 8, offset: int = 0) -> list[asyncpg.Record]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(
                "SELECT * FROM bot_core.referral_cycles ORDER BY id DESC LIMIT $1 OFFSET $2",
                max(1, min(50, int(limit))), max(0, int(offset)),
            )

    async def cycle_detail(self, cycle_id: int) -> tuple[asyncpg.Record | None, list[asyncpg.Record]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1", int(cycle_id))
            if not cycle:
                return None, []
            payouts = await conn.fetch(
                "SELECT * FROM bot_core.referral_cycle_payouts WHERE cycle_id=$1 ORDER BY amount_syp DESC,referrer_telegram_id",
                int(cycle_id),
            )
            return cycle, payouts

    async def cycle_referrer_activity(
        self, cycle_id: int, referrer_id: int, limit: int = 5, offset: int = 0
    ) -> dict[str, Any]:
        """Read-only audit for one beneficiary inside a referral cycle.

        This deliberately reuses the frozen referral snapshots.  It never calls iChancy,
        recalculates a payout, or writes accounting rows, so opening the admin screen cannot
        change a financial result.
        """
        cycle_id = int(cycle_id)
        referrer_id = int(referrer_id)
        limit = max(1, min(20, int(limit)))
        offset = max(0, int(offset))
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow(
                "SELECT * FROM bot_core.referral_cycles WHERE id=$1", cycle_id
            )
            if not cycle:
                return {"cycle": None, "rows": [], "count": 0}

            now = _utcnow()
            cutoff = min(now, cycle["cycle_end"]) if str(cycle["status"]) == "active" else cycle["cycle_end"]
            active_min = max(1, int(cycle["active_min_deposit"] or 0))
            active_sql = """
                FROM bot_core.users u
                WHERE u.referrer_telegram_id=$1
                  AND u.referral_status='confirmed' AND NOT u.is_blocked AND NOT u.is_bot
                  AND COALESCE(u.referral_confirmed_at,u.created_at) < $3
                  AND EXISTS (
                    SELECT 1 FROM bot_core.deposit_requests d
                    WHERE d.telegram_id=u.telegram_id AND d.status='success'
                      AND d.settled_at >= $2 AND d.settled_at < $3
                      AND d.settled_at >= COALESCE(u.referral_confirmed_at,u.created_at)
                      AND d.base_credit_syp >= $4
                  )
            """
            args = (referrer_id, cycle["cycle_start"], cutoff, active_min)
            count = int(await conn.fetchval("SELECT COUNT(*) " + active_sql, *args) or 0)
            users = await conn.fetch(
                "SELECT u.telegram_id,u.first_name,u.username,COALESCE(u.referral_confirmed_at,u.created_at) AS confirmed_at "
                + active_sql
                + " ORDER BY COALESCE(u.referral_confirmed_at,u.created_at),u.telegram_id LIMIT $5 OFFSET $6",
                *args, limit, offset,
            )

            payout = await conn.fetchrow(
                "SELECT amount_syp,active_referrals,status FROM bot_core.referral_cycle_payouts "
                "WHERE cycle_id=$1 AND referrer_telegram_id=$2",
                cycle_id, referrer_id,
            )
            direct = await conn.fetchrow(
                "SELECT COALESCE(SUM(base_net_loss_syp),0) loss,COALESCE(SUM(amount_syp),0) earning "
                "FROM bot_core.referral_earnings WHERE cycle_id=$1 AND referrer_telegram_id=$2 AND level=1",
                cycle_id, referrer_id,
            )

            all_active = await conn.fetch(
                "SELECT u.telegram_id,COALESCE(u.referral_confirmed_at,u.created_at) AS confirmed_at "
                + active_sql, *args
            )
            total_dep = total_wd = 0
            for u in all_active:
                window_start = max(cycle["cycle_start"], u["confirmed_at"] or cycle["cycle_start"])
                sums = await conn.fetchrow(
                    """SELECT
                         COALESCE(SUM(CASE WHEN operation_type='deposit' THEN amount ELSE 0 END),0) dep,
                         COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN amount ELSE 0 END),0) wd
                       FROM bot_core.ichancy_jobs
                       WHERE telegram_id=$1 AND status='success'
                         AND operation_type IN ('deposit','withdraw','retirement_withdraw')
                         AND finished_at >= $2 AND finished_at < $3""",
                    int(u["telegram_id"]), window_start, cutoff,
                )
                total_dep += int(sums["dep"] or 0)
                total_wd += int(sums["wd"] or 0)

            rows: list[dict[str, Any]] = []
            for u in users:
                referred = int(u["telegram_id"])
                window_start = max(cycle["cycle_start"], u["confirmed_at"] or cycle["cycle_start"])
                sums = await conn.fetchrow(
                    """SELECT
                         COALESCE(SUM(CASE WHEN operation_type='deposit' THEN amount ELSE 0 END),0) dep,
                         COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN amount ELSE 0 END),0) wd
                       FROM bot_core.ichancy_jobs
                       WHERE telegram_id=$1 AND status='success'
                         AND operation_type IN ('deposit','withdraw','retirement_withdraw')
                         AND finished_at >= $2 AND finished_at < $3""",
                    referred, window_start, cutoff,
                )
                snap = await conn.fetchrow(
                    "SELECT net_result_syp,status,details FROM bot_core.referral_loss_snapshots "
                    "WHERE cycle_id=$1 AND referred_telegram_id=$2", cycle_id, referred
                )
                level_net: int | None = None
                if snap:
                    details = snap["details"] or {}
                    if isinstance(details, str):
                        try:
                            details = json.loads(details)
                        except Exception:
                            details = {}
                    if isinstance(details, dict):
                        for item in details.get("levels") or []:
                            try:
                                if int(item.get("referrer_tg") or 0) == referrer_id and int(item.get("level") or 0) == 1:
                                    level_net = int(item.get("net_loss") or 0)
                                    break
                            except Exception:
                                continue
                rows.append({
                    "telegram_id": referred,
                    "first_name": str(u["first_name"] or ""),
                    "username": str(u["username"] or ""),
                    "window_start": window_start,
                    "deposits_syp": int(sums["dep"] or 0),
                    "withdrawals_syp": int(sums["wd"] or 0),
                    "snapshot_available": bool(snap),
                    "snapshot_status": str(snap["status"] or "") if snap else "",
                    "net_loss_syp": level_net if level_net is not None else (int(snap["net_result_syp"] or 0) if snap else 0),
                })

        return {
            "cycle": cycle, "referrer_telegram_id": referrer_id, "count": count, "rows": rows,
            "offset": offset, "limit": limit, "total_deposits_syp": total_dep,
            "total_withdrawals_syp": total_wd,
            "recorded_active_referrals": int(payout["active_referrals"] or 0) if payout else count,
            "payout_amount_syp": int(payout["amount_syp"] or 0) if payout else 0,
            "payout_status": str(payout["status"] or "") if payout else "",
            "direct_net_loss_syp": int(direct["loss"] or 0) if direct else 0,
            "direct_earning_syp": int(direct["earning"] or 0) if direct else 0,
            "cutoff": cutoff,
        }


class CashbackService:
    def __init__(
        self, db: Database, runtime: RuntimeSettingsService, wallet: WalletService,
        ichancy_accounts: IchancyAccountsService, tracker: CashbackPrincipalTracker,
        outbox: OutboxRepository | None = None,
    ) -> None:
        self.db = db
        self.runtime = runtime
        self.wallet = wallet
        self.ichancy_accounts = ichancy_accounts
        self.tracker = tracker
        self.outbox = outbox

    def default_pct(self) -> Decimal:
        return max(Decimal(0), self.runtime.get_decimal("cashback.default_pct", Decimal(0)))

    async def ensure_cycle(self) -> asyncpg.Record:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow("SELECT * FROM bot_core.cashback_cycles WHERE status IN ('open','preparing') ORDER BY id DESC LIMIT 1 FOR UPDATE")
                if row:
                    return row
                days = self.runtime.get_int("cashback.next_cycle_days", 0) or self.runtime.get_int("cashback.cycle_days", 7)
                days = 1 if days <= 1 else 7
                if self.runtime.get_int("cashback.next_cycle_days", 0):
                    await self.runtime.set("cashback.cycle_days", days, updated_by=None)
                    await self.runtime.set("cashback.next_cycle_days", 0, updated_by=None)
                now = _utcnow()
                # Exact reference boundaries: daily cycles are Damascus 00:00→00:00
                # and weekly cycles are Monday 00:00→next Monday 00:00.  Once a
                # chain exists, every new cycle starts at the exact prior boundary.
                previous_end = await conn.fetchval(
                    "SELECT cycle_end FROM bot_core.cashback_cycles ORDER BY cycle_end DESC,id DESC LIMIT 1"
                )
                start = (
                    previous_end
                    if previous_end is not None and previous_end <= now
                    else _cashback_aligned_start(now, days)
                )
                end = _cashback_cycle_end_for(start, days)
                return await conn.fetchrow(
                    """
                    INSERT INTO bot_core.cashback_cycles(status,cycle_days,cycle_start,cycle_end,pct,min_turnover,calc_version)
                    VALUES('open',$1,$2,$3,$4,$5,2) RETURNING *
                    """,
                    days, start, end, self.default_pct(), max(0,self.runtime.get_int("cashback.min_turnover",200_000)),
                )

    async def current_info(self) -> dict[str, Any]:
        cycle = await self.ensure_cycle()
        now = _utcnow()
        return {**dict(cycle), "start_local": _fmt_local(cycle["cycle_start"]),
                "end_local": _fmt_local(cycle["cycle_end"] - timedelta(minutes=1)),
                "remaining_seconds": max(0,int((cycle["cycle_end"]-now).total_seconds())), "is_finished": cycle["cycle_end"] <= now}

    async def set_mode(self, days: int, admin_id: int) -> dict[str, Any]:
        days = 1 if int(days) <= 1 else 7
        cycle = await self.ensure_cycle()
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            used = int(await conn.fetchval(
                """
                SELECT COUNT(*)
                FROM bot_core.ichancy_cashback_allocations a
                JOIN bot_core.ichancy_jobs j ON j.id=a.job_id
                WHERE a.eligible_amount_syp>0
                  AND (
                    (a.status='success'
                     AND COALESCE(j.remote_success_at,j.finished_at,a.settled_at) >= $1
                     AND COALESCE(j.remote_success_at,j.finished_at,a.settled_at) < $2)
                    OR
                    (a.status='pending'
                     AND j.financial_post_started_at IS NOT NULL
                     AND j.financial_post_started_at >= $1
                     AND j.financial_post_started_at < $2)
                  )
                """, cycle["cycle_start"], cycle["cycle_end"]
            ) or 0)
            if str(cycle["status"]) == "open" and used == 0:
                new_end = _cashback_cycle_end_for(cycle["cycle_start"], days)
                # Never rewrite the current period to a boundary already in the past.
                if new_end > _utcnow():
                    await conn.execute(
                        "UPDATE bot_core.cashback_cycles SET cycle_days=$2,cycle_end=$3,updated_at=NOW() WHERE id=$1 AND status='open'",
                        cycle["id"], days, new_end,
                    )
                    await self.runtime.set("cashback.cycle_days", days, updated_by=admin_id)
                    return {"scheduled": False}
        await self.runtime.set("cashback.next_cycle_days", days, updated_by=admin_id)
        return {"scheduled": True}

    async def set_pct(self, pct: Decimal, admin_id: int) -> None:
        pct = min(Decimal(100), max(Decimal(0), Decimal(str(pct))))
        await self.runtime.set("cashback.default_pct", str(pct), updated_by=admin_id)
        cycle = await self.ensure_cycle()
        if str(cycle["status"]) == "open":
            pool = self.db.require_pool();
            async with pool.acquire() as conn:
                await conn.execute("UPDATE bot_core.cashback_cycles SET pct=$2,updated_at=NOW() WHERE id=$1 AND status='open'", cycle["id"], pct)

    async def set_min_turnover(self, amount: int, admin_id: int) -> None:
        amount = max(0,int(amount))
        await self.runtime.set("cashback.min_turnover", amount, updated_by=admin_id)
        cycle = await self.ensure_cycle()
        if str(cycle["status"]) == "open":
            pool=self.db.require_pool();
            async with pool.acquire() as conn:
                await conn.execute("UPDATE bot_core.cashback_cycles SET min_turnover=$2,updated_at=NOW() WHERE id=$1 AND status='open'", cycle["id"], amount)

    async def _account_principal(self, conn: asyncpg.Connection, account_id: UUID, start: datetime, end: datetime, tg: int) -> dict[str,int]:
        before = await conn.fetchrow(
            """
            SELECT COALESCE(SUM(CASE WHEN operation_type='deposit' THEN eligible_amount_syp ELSE 0 END),0) dep,
                   COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN eligible_amount_syp ELSE 0 END),0) wd
            FROM bot_core.ichancy_cashback_allocations WHERE account_id=$1 AND telegram_id=$2 AND status='success' AND settled_at < $3
            """, account_id,tg,start
        )
        during = await conn.fetchrow(
            """
            SELECT COALESCE(SUM(CASE WHEN operation_type='deposit' THEN eligible_amount_syp ELSE 0 END),0) dep,
                   COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN eligible_amount_syp ELSE 0 END),0) wd
            FROM bot_core.ichancy_cashback_allocations WHERE account_id=$1 AND telegram_id=$2 AND status='success' AND settled_at >= $3 AND settled_at < $4
            """, account_id,tg,start,end
        )
        settled = int(await conn.fetchval(
            """SELECT COALESCE(SUM(s.amount_syp),0) FROM bot_core.cashback_principal_settlements s
               JOIN bot_core.cashback_cycles c ON c.id=s.cycle_id
               WHERE s.account_id=$1 AND s.telegram_id=$2 AND c.cycle_end <= $3""", account_id,tg,start
        ) or 0)
        held = int(await conn.fetchval(
            """SELECT COALESCE(SUM(h.amount_syp),0) FROM bot_core.cashback_principal_holds h
               JOIN bot_core.cashback_cycles c ON c.id=h.cycle_id
               WHERE h.account_id=$1 AND h.telegram_id=$2 AND h.status='active' AND c.cycle_end <= $3""", account_id,tg,start
        ) or 0)
        start_principal=max(0,int(before['dep'] or 0)-int(before['wd'] or 0)-settled-held)
        dep=int(during['dep'] or 0); wd=int(during['wd'] or 0)
        return {'start':start_principal,'dep':dep,'wd':wd,'end_principal':max(0,start_principal+dep-wd)}

    async def _balance_account_at_end(self, account_id: UUID, end: datetime) -> tuple[int,dict[str,int]]:
        account = await self.ichancy_accounts.repository.get_account(account_id)
        if not account:
            raise RuntimeError('iChancy account missing')
        cashier = await self.ichancy_accounts.repository.get_cashier(account.cashier_id)
        if not cashier:
            raise RuntimeError('iChancy cashier missing')
        last = None
        for attempt in range(3):
            try:
                response = await self.ichancy_accounts._client(cashier).get_player_balance(account.player_id)
                observed = extract_player_balance_value(response)
                if observed is None:
                    raise RuntimeError('empty player balance')
                captured = _utcnow()
                pool = self.db.require_pool()
                async with pool.acquire() as conn:
                    # If an uncertain provider POST happened after the cycle boundary
                    # but before this live read, the observed balance cannot be safely
                    # reversed yet. Fail this user and retry after reconciliation.
                    unresolved = int(await conn.fetchval(
                        """
                        SELECT COUNT(*)
                        FROM bot_core.ichancy_jobs
                        WHERE account_id=$1
                          AND status IN ('executing','reconciling')
                          AND financial_post_started_at IS NOT NULL
                          AND financial_post_started_at >= $2
                          AND financial_post_started_at <= $3
                        """,
                        account_id, end, captured,
                    ) or 0)
                    if unresolved:
                        raise RuntimeError('unresolved iChancy financial operation after cashback boundary')

                    post = await conn.fetchrow(
                        """
                        SELECT
                            COALESCE(SUM(CASE WHEN operation_type='deposit' THEN amount ELSE 0 END),0) dep,
                            COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN amount ELSE 0 END),0) wd
                        FROM bot_core.ichancy_jobs
                        WHERE account_id=$1
                          AND status IN ('success','remote_success')
                          AND COALESCE(remote_success_at,finished_at) >= $2
                          AND COALESCE(remote_success_at,finished_at) <= $3
                        """,
                        account_id, end, captured,
                    )
                adjusted = max(0, int(observed) - int(post['dep'] or 0) + int(post['wd'] or 0))
                return adjusted, {
                    'observed': int(observed),
                    'post_deposits': int(post['dep'] or 0),
                    'post_withdrawals': int(post['wd'] or 0),
                    'captured_at': captured.isoformat(),
                }
            except Exception as exc:
                last = exc
                if attempt < 2:
                    await asyncio.sleep(.7 * (attempt + 1))
        raise RuntimeError(str(last or 'balance lookup failed'))

    async def _cashback_principal_accounts(
        self, telegram_id: int, cycle: asyncpg.Record
    ) -> tuple[list[dict[str, Any]], dict[str, int]]:
        """Freeze the complete eligible-principal set before any live balance call.

        If one iChancy balance lookup fails, every principal-bearing account in this
        set is quarantined.  This mirrors the reference behavior and prevents an
        unvisited later account from leaking uncertain principal into a newer cycle.
        """
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            accounts = await conn.fetch(
                """SELECT DISTINCT account_id FROM bot_core.ichancy_cashback_allocations
                   WHERE telegram_id=$1 AND status='success' AND eligible_amount_syp>0 AND settled_at < $2
                   ORDER BY account_id""",
                int(telegram_id), cycle["cycle_end"],
            )
        relevant: list[dict[str, Any]] = []
        totals = {"start": 0, "dep": 0, "wd": 0}
        for row in accounts:
            account_id = row["account_id"]
            async with pool.acquire() as conn:
                principal = await self._account_principal(
                    conn, account_id, cycle["cycle_start"], cycle["cycle_end"], int(telegram_id)
                )
            totals["start"] += int(principal["start"] or 0)
            totals["dep"] += int(principal["dep"] or 0)
            totals["wd"] += int(principal["wd"] or 0)
            if int(principal["end_principal"] or 0) > 0:
                relevant.append({"account_id": account_id, **principal})
        return relevant, totals

    async def _v2_unresolved_before_cycle_end(self, cycle: asyncpg.Record) -> int:
        """Count ambiguous iChancy financial POSTs that can still change this cycle.

        A job with no financial POST timestamp cannot have moved provider money yet, so
        queued/pre-POST work does not block the cycle.  Once a POST may have happened,
        we fail closed until reconciliation reaches a terminal state.
        """
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return int(await conn.fetchval(
                """
                SELECT COUNT(*)
                FROM bot_core.ichancy_jobs
                WHERE status IN ('executing','remote_success','reconciling')
                  AND COALESCE(financial_post_started_at,remote_success_at,reconcile_started_at) IS NOT NULL
                  AND COALESCE(financial_post_started_at,remote_success_at,reconcile_started_at) < $1
                """,
                cycle['cycle_end'],
            ) or 0)

    async def _v2_candidate_users(self, cycle: asyncpg.Record) -> list[int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT a.telegram_id
                FROM bot_core.ichancy_cashback_allocations a
                JOIN bot_core.ichancy_jobs j ON j.id=a.job_id
                JOIN bot_core.users u ON u.telegram_id=a.telegram_id
                WHERE a.status='success'
                  AND a.operation_type='deposit'
                  AND a.eligible_amount_syp>0
                  AND COALESCE(j.remote_success_at,j.finished_at,a.settled_at) >= $1
                  AND COALESCE(j.remote_success_at,j.finished_at,a.settled_at) < $2
                  AND NOT u.is_bot
                GROUP BY a.telegram_id
                ORDER BY a.telegram_id
                """,
                cycle['cycle_start'], cycle['cycle_end'],
            )
        return [int(row['telegram_id']) for row in rows]

    async def _v2_user_inputs(self, telegram_id: int, cycle: asyncpg.Record) -> dict[str, Any]:
        """Return the exact cycle-scoped inputs used by Cashback V2."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            accounts = await conn.fetch(
                """
                SELECT a.account_id,
                       COALESCE(SUM(a.eligible_amount_syp),0)::BIGINT AS eligible_deposits,
                       COALESCE(SUM(a.amount_syp),0)::BIGINT AS deposited_amount
                FROM bot_core.ichancy_cashback_allocations a
                JOIN bot_core.ichancy_jobs j ON j.id=a.job_id
                WHERE a.telegram_id=$1
                  AND a.status='success'
                  AND a.operation_type='deposit'
                  AND a.eligible_amount_syp>0
                  AND COALESCE(j.remote_success_at,j.finished_at,a.settled_at) >= $2
                  AND COALESCE(j.remote_success_at,j.finished_at,a.settled_at) < $3
                GROUP BY a.account_id
                ORDER BY a.account_id
                """,
                int(telegram_id), cycle['cycle_start'], cycle['cycle_end'],
            )
            withdrawals = int(await conn.fetchval(
                """
                SELECT COALESCE(SUM(amount),0)::BIGINT
                FROM bot_core.ichancy_jobs
                WHERE telegram_id=$1
                  AND status='success'
                  AND operation_type IN ('withdraw','retirement_withdraw')
                  AND COALESCE(remote_success_at,finished_at) >= $2
                  AND COALESCE(remote_success_at,finished_at) < $3
                """,
                int(telegram_id), cycle['cycle_start'], cycle['cycle_end'],
            ) or 0)
            actual_deposits = int(await conn.fetchval(
                """
                SELECT COALESCE(SUM(amount),0)::BIGINT
                FROM bot_core.ichancy_jobs
                WHERE telegram_id=$1
                  AND status='success'
                  AND operation_type='deposit'
                  AND COALESCE(remote_success_at,finished_at) >= $2
                  AND COALESCE(remote_success_at,finished_at) < $3
                """,
                int(telegram_id), cycle['cycle_start'], cycle['cycle_end'],
            ) or 0)
        account_rows = [
            {
                'account_id': row['account_id'],
                'eligible_deposits': int(row['eligible_deposits'] or 0),
                'deposited_amount': int(row['deposited_amount'] or 0),
            }
            for row in accounts
        ]
        return {
            'accounts': account_rows,
            'eligible_deposits': sum(int(x['eligible_deposits']) for x in account_rows),
            'actual_deposits': actual_deposits,
            'withdrawals': withdrawals,
        }

    @staticmethod
    def _v2_settlement_plan(player_details: list[dict[str, Any]], total_loss: int) -> list[tuple[UUID, int]]:
        """Allocate the already-computed global V2 loss across real account UUIDs.

        The payout formula remains user-global by design. This allocation is
        only for Tecno's internal source-accounting ledger, whose settlement table is
        account-scoped.  Prefer accounts with an actual deposit-vs-balance shortfall,
        then use remaining eligible deposit capacity deterministically if needed.
        """
        remaining = max(0, int(total_loss))
        assigned: dict[UUID, int] = {}
        ordered = sorted(
            (d for d in player_details if d.get('account_id')),
            key=lambda d: str(d.get('account_id')),
        )
        for row in ordered:
            if remaining <= 0:
                break
            aid = UUID(str(row['account_id']))
            eligible = max(0, int(row.get('eligible_deposits') or 0))
            end_balance = max(0, int(row.get('end_balance') or 0))
            cap = max(0, eligible - end_balance)
            take = min(remaining, cap)
            if take:
                assigned[aid] = assigned.get(aid, 0) + take
                remaining -= take
        if remaining > 0:
            for row in ordered:
                if remaining <= 0:
                    break
                aid = UUID(str(row['account_id']))
                eligible = max(0, int(row.get('eligible_deposits') or 0))
                already = assigned.get(aid, 0)
                take = min(remaining, max(0, eligible - already))
                if take:
                    assigned[aid] = already + take
                    remaining -= take
        if remaining > 0:
            raise RuntimeError('cashback v2 settlement allocation mismatch')
        return [(aid, amount) for aid, amount in assigned.items() if amount > 0]

    async def _store_v2_user_result(
        self,
        cycle: asyncpg.Record,
        telegram_id: int,
        *,
        inputs: dict[str, Any],
        player_details: list[dict[str, Any]],
        end_balance: int,
        net_loss: int,
        cashback: int,
        status: str,
        error_code: str | None = None,
        error_message: str | None = None,
    ) -> None:
        pool = self.db.require_pool()
        payload = {
            'calculation_version': 2,
            'rule': 'cycle_eligible_deposits_minus_all_withdrawals_minus_end_balance',
            'eligible_deposits': int(inputs.get('eligible_deposits') or 0),
            'actual_deposits': int(inputs.get('actual_deposits') or 0),
            'all_withdrawals': int(inputs.get('withdrawals') or 0),
            'end_balance': int(end_balance),
            'net_loss': int(net_loss),
            'players': player_details,
        }
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    """
                    INSERT INTO bot_core.cashback_cycle_users(
                        cycle_id,telegram_id,start_principal_syp,eligible_deposits_syp,
                        eligible_withdrawals_syp,end_balance_syp,net_loss_syp,cashback_syp,
                        status,error_code,error_message,details,attempts,prepared_at
                    ) VALUES($1,$2,0,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,1,NOW())
                    ON CONFLICT(cycle_id,telegram_id) DO UPDATE SET
                        start_principal_syp=0,
                        eligible_deposits_syp=EXCLUDED.eligible_deposits_syp,
                        eligible_withdrawals_syp=EXCLUDED.eligible_withdrawals_syp,
                        end_balance_syp=EXCLUDED.end_balance_syp,
                        net_loss_syp=EXCLUDED.net_loss_syp,
                        cashback_syp=EXCLUDED.cashback_syp,
                        status=EXCLUDED.status,
                        error_code=EXCLUDED.error_code,
                        error_message=EXCLUDED.error_message,
                        details=EXCLUDED.details,
                        attempts=bot_core.cashback_cycle_users.attempts+1,
                        prepared_at=NOW()
                    """,
                    int(cycle['id']), int(telegram_id),
                    int(inputs.get('eligible_deposits') or 0),
                    int(inputs.get('withdrawals') or 0),
                    int(end_balance), int(net_loss), int(cashback), status,
                    error_code, (error_message[:1200] if error_message else None),
                    json.dumps(payload, ensure_ascii=False),
                )

                # V2 source-accounting rows are rebuilt atomically for this user/cycle.
                await conn.execute(
                    'DELETE FROM bot_core.cashback_principal_settlements WHERE cycle_id=$1 AND telegram_id=$2',
                    int(cycle['id']), int(telegram_id),
                )
                await conn.execute(
                    "UPDATE bot_core.cashback_principal_holds SET status='resolved',resolved_at=NOW() "
                    "WHERE cycle_id=$1 AND telegram_id=$2 AND status='active'",
                    int(cycle['id']), int(telegram_id),
                )

                if status == 'failed':
                    for row in inputs.get('accounts') or []:
                        amount = max(0, int(row.get('eligible_deposits') or 0))
                        if amount <= 0:
                            continue
                        await conn.execute(
                            """
                            INSERT INTO bot_core.cashback_principal_holds(
                                cycle_id,telegram_id,account_id,amount_syp,status
                            ) VALUES($1,$2,$3,$4,'active')
                            ON CONFLICT(cycle_id,telegram_id,account_id) DO UPDATE SET
                                amount_syp=EXCLUDED.amount_syp,status='active',resolved_at=NULL
                            """,
                            int(cycle['id']), int(telegram_id), row['account_id'], amount,
                        )
                elif int(net_loss) > 0:
                    for account_id, amount in self._v2_settlement_plan(player_details, int(net_loss)):
                        await conn.execute(
                            """
                            INSERT INTO bot_core.cashback_principal_settlements(
                                cycle_id,telegram_id,account_id,amount_syp
                            ) VALUES($1,$2,$3,$4)
                            ON CONFLICT(cycle_id,telegram_id,account_id) DO UPDATE SET
                                amount_syp=EXCLUDED.amount_syp
                            """,
                            int(cycle['id']), int(telegram_id), account_id, int(amount),
                        )

    async def _prepare_user_v2(self, cycle: asyncpg.Record, telegram_id: int) -> dict[str, Any]:
        inputs = await self._v2_user_inputs(int(telegram_id), cycle)
        eligible_deposits = int(inputs['eligible_deposits'] or 0)
        withdrawals = int(inputs['withdrawals'] or 0)
        if eligible_deposits <= 0:
            await self._store_v2_user_result(
                cycle, telegram_id, inputs=inputs, player_details=[], end_balance=0,
                net_loss=0, cashback=0, status='not_eligible',
            )
            return {'status': 'not_eligible', 'cashback': 0, 'net_loss': 0}

        player_details: list[dict[str, Any]] = []
        end_balance_total = 0
        residual_before_balance = max(0, eligible_deposits - withdrawals)
        failure: str | None = None

        if residual_before_balance <= 0:
            for row in inputs['accounts']:
                player_details.append({
                    **row,
                    'account_id': str(row['account_id']),
                    'end_balance': 0,
                    'snapshot_status': 'not_required',
                    'reason': 'cycle_withdrawals_cover_eligible_deposits',
                })
        else:
            for index, row in enumerate(inputs['accounts']):
                aid = row['account_id']
                try:
                    bal, adj = await self._balance_account_at_end(aid, cycle['cycle_end'])
                except Exception as exc:
                    failure = str(exc) or type(exc).__name__
                    player_details.append({
                        **row,
                        'account_id': str(aid),
                        'snapshot_status': 'failed',
                        'error': failure[:1200],
                    })
                    for pending in inputs['accounts'][index + 1:]:
                        player_details.append({
                            **pending,
                            'account_id': str(pending['account_id']),
                            'snapshot_status': 'not_checked_after_failure',
                        })
                    break
                end_balance_total += int(bal)
                player_details.append({
                    **row,
                    'account_id': str(aid),
                    'end_balance': int(bal),
                    'snapshot_status': 'ok',
                    'raw_shortfall_before_global_withdrawals': max(
                        0, int(row.get('eligible_deposits') or 0) - int(bal)
                    ),
                    **adj,
                })

        if failure:
            await self._store_v2_user_result(
                cycle, telegram_id, inputs=inputs, player_details=player_details,
                end_balance=0, net_loss=0, cashback=0, status='failed',
                error_code='balance_lookup_failed', error_message=failure,
            )
            return {'status': 'failed', 'cashback': 0, 'net_loss': 0}

        net_loss = max(0, eligible_deposits - withdrawals - int(end_balance_total))
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            user_valid = bool(await conn.fetchval(
                'SELECT 1 FROM bot_core.users WHERE telegram_id=$1 AND NOT is_blocked AND NOT is_bot',
                int(telegram_id),
            ))
        cashback = (
            int(Decimal(net_loss) * Decimal(str(cycle['pct'])) / Decimal(100))
            if user_valid
            and net_loss >= int(cycle['min_turnover'])
            and Decimal(str(cycle['pct'])) > 0
            else 0
        )
        status = 'eligible' if cashback > 0 else ('not_eligible' if user_valid else 'banned')
        await self._store_v2_user_result(
            cycle, telegram_id, inputs=inputs, player_details=player_details,
            end_balance=end_balance_total, net_loss=net_loss, cashback=cashback, status=status,
        )
        return {'status': status, 'cashback': cashback, 'net_loss': net_loss}

    async def _refresh_v2_cycle_totals(self, cycle_id: int) -> dict[str, int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT
                    COUNT(*) FILTER (WHERE status='eligible' AND cashback_syp>0) AS eligible,
                    COUNT(*) FILTER (WHERE status='failed') AS failed,
                    COALESCE(SUM(net_loss_syp) FILTER (WHERE status IN ('eligible','paid','not_eligible')),0) AS total_loss,
                    COALESCE(SUM(cashback_syp) FILTER (WHERE status IN ('eligible','paid')),0) AS total_due
                FROM bot_core.cashback_cycle_users
                WHERE cycle_id=$1
                """,
                int(cycle_id),
            )
        return {
            'eligible_count': int(row['eligible'] or 0),
            'failed_count': int(row['failed'] or 0),
            'total_loss': int(row['total_loss'] or 0),
            'total_due': int(row['total_due'] or 0),
        }

    async def prepare(self, cycle_id: int) -> dict[str,Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle = await conn.fetchrow(
                    'SELECT * FROM bot_core.cashback_cycles WHERE id=$1 FOR UPDATE',
                    int(cycle_id),
                )
                if (
                    not cycle
                    or str(cycle['status']) not in {'open','preparing'}
                    or cycle['cycle_end'] > _utcnow()
                ):
                    return {'done': False}

        unresolved = await self._v2_unresolved_before_cycle_end(cycle)
        if unresolved > 0:
            async with pool.acquire() as conn:
                await conn.execute(
                    "UPDATE bot_core.cashback_cycles SET status='preparing',last_error=$2,updated_at=NOW() WHERE id=$1",
                    int(cycle_id),
                    f'cashback v2 blocked by {unresolved} unresolved iChancy financial job(s)',
                )
            return {
                'done': False,
                'status': 'preparing',
                'blocked': 'unresolved_ichancy_jobs',
                'unresolved_jobs': unresolved,
            }

        # A partially prepared legacy cycle can be rebuilt safely because payout has
        # not started while status is open/preparing.  Clear only cycle-local snapshots.
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle = await conn.fetchrow(
                    'SELECT * FROM bot_core.cashback_cycles WHERE id=$1 FOR UPDATE', int(cycle_id)
                )
                if not cycle or str(cycle['status']) not in {'open','preparing'}:
                    return {'done': False}
                if int(cycle['calc_version'] or 1) < 2:
                    await conn.execute(
                        'DELETE FROM bot_core.cashback_principal_settlements WHERE cycle_id=$1',
                        int(cycle_id),
                    )
                    await conn.execute(
                        "UPDATE bot_core.cashback_principal_holds SET status='resolved',resolved_at=NOW() "
                        "WHERE cycle_id=$1 AND status='active'",
                        int(cycle_id),
                    )
                    await conn.execute(
                        'DELETE FROM bot_core.cashback_cycle_users WHERE cycle_id=$1', int(cycle_id)
                    )
                cycle = await conn.fetchrow(
                    """
                    UPDATE bot_core.cashback_cycles
                    SET status='preparing',calc_version=2,last_error=NULL,updated_at=NOW()
                    WHERE id=$1 RETURNING *
                    """,
                    int(cycle_id),
                )

        users = await self._v2_candidate_users(cycle)
        for tg in users:
            await self._prepare_user_v2(cycle, int(tg))

        totals = await self._refresh_v2_cycle_totals(int(cycle_id))
        status = 'ready' if totals['eligible_count'] > 0 or totals['failed_count'] > 0 else 'empty'
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow(
                """
                UPDATE bot_core.cashback_cycles
                SET status=$2,calc_version=2,eligible_count=$3,failed_count=$4,
                    total_loss_syp=$5,total_due_syp=$6,prepared_at=NOW(),last_error=NULL,updated_at=NOW()
                WHERE id=$1 RETURNING *
                """,
                int(cycle_id), status, totals['eligible_count'], totals['failed_count'],
                totals['total_loss'], totals['total_due'],
            )
        return {
            'done': True,
            'status': status,
            'eligible_count': totals['eligible_count'],
            'failed_count': totals['failed_count'],
            'total_loss': totals['total_loss'],
            'total_due': totals['total_due'],
            'calc_version': 2,
            'cycle': dict(cycle),
        }

    @staticmethod
    def _legacy_v1_snapshot_map(details: object) -> dict[str, dict[str, Any]]:
        if isinstance(details, str):
            try:
                details = json.loads(details)
            except Exception:
                details = {}
        if not isinstance(details, dict):
            return {}
        out: dict[str, dict[str, Any]] = {}
        for row in details.get('players') or []:
            if not isinstance(row, dict):
                continue
            aid = str(row.get('account_id') or '').strip()
            if not aid or row.get('end_balance') is None:
                continue
            if str(row.get('status') or '').lower() == 'failed':
                continue
            out[aid] = dict(row)
        return out

    async def _recalculate_legacy_cycle_v2(self, cycle_id: int) -> dict[str, Any]:
        """Repair an ended, unpaid V1 cycle from its saved historical balances only."""
        pool = self.db.require_pool()
        token = uuid4()
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle = await conn.fetchrow(
                    'SELECT * FROM bot_core.cashback_cycles WHERE id=$1 FOR UPDATE', int(cycle_id)
                )
                if not cycle:
                    raise ValueError('CASHBACK_CYCLE_NOT_FOUND')
                if int(cycle['calc_version'] or 1) >= 2:
                    return {'cycle': dict(cycle), 'already_v2': True}
                status = str(cycle['status'])
                if status not in {'ready','empty'}:
                    # Payout-started/final cycles are intentionally never rewritten.
                    return {'cycle': dict(cycle), 'legacy_locked': True}
                paid_or_skipped = int(await conn.fetchval(
                    """
                    SELECT COUNT(*) FROM bot_core.cashback_cycle_users
                    WHERE cycle_id=$1 AND status IN ('paid','skipped')
                    """,
                    int(cycle_id),
                ) or 0)
                if paid_or_skipped or int(cycle['paid_count'] or 0) > 0:
                    raise ValueError('CASHBACK_V2_RECALC_AFTER_PAYOUT_FORBIDDEN')
                started = cycle['v2_recalc_started_at']
                existing_token = cycle['v2_recalc_token']
                if existing_token and started and (_utcnow() - started).total_seconds() < 600:
                    raise RuntimeError('cashback v2 recalculation already running')
                cycle = await conn.fetchrow(
                    """
                    UPDATE bot_core.cashback_cycles
                    SET v2_recalc_token=$2,v2_recalc_started_at=NOW(),last_error=NULL,updated_at=NOW()
                    WHERE id=$1 RETURNING *
                    """,
                    int(cycle_id), token,
                )
                rows = await conn.fetch(
                    'SELECT * FROM bot_core.cashback_cycle_users WHERE cycle_id=$1 ORDER BY telegram_id',
                    int(cycle_id),
                )

        try:
            unresolved = await self._v2_unresolved_before_cycle_end(cycle)
            if unresolved:
                raise RuntimeError(
                    f'cashback v2 legacy repair blocked by {unresolved} unresolved iChancy job(s)'
                )

            candidates = set(await self._v2_candidate_users(cycle))
            existing_ids = {int(row['telegram_id']) for row in rows}
            missing_users = sorted(candidates - existing_ids)
            if missing_users:
                raise RuntimeError(
                    'historical cashback snapshot incomplete for users: '
                    + ','.join(str(x) for x in missing_users[:10])
                )

            for row in rows:
                tg = int(row['telegram_id'])
                inputs = await self._v2_user_inputs(tg, cycle)
                eligible_deposits = int(inputs['eligible_deposits'] or 0)
                withdrawals = int(inputs['withdrawals'] or 0)
                old_status = str(row['status'] or '')
                snapshot_map = self._legacy_v1_snapshot_map(row['details'])
                player_details: list[dict[str, Any]] = []
                end_balance = 0
                net_loss = 0
                cashback = 0
                error_code = None
                error_message = None

                if eligible_deposits <= 0 or tg not in candidates:
                    new_status = 'banned' if old_status == 'banned' else 'not_eligible'
                elif max(0, eligible_deposits - withdrawals) <= 0:
                    for acc in inputs['accounts']:
                        player_details.append({
                            **acc,
                            'account_id': str(acc['account_id']),
                            'end_balance': 0,
                            'snapshot_status': 'not_required',
                            'reason': 'cycle_withdrawals_cover_eligible_deposits',
                            'recalculated_from_legacy_snapshot': True,
                        })
                    new_status = 'banned' if old_status == 'banned' else 'not_eligible'
                else:
                    missing_accounts: list[str] = []
                    for acc in inputs['accounts']:
                        aid = str(acc['account_id'])
                        snap = snapshot_map.get(aid)
                        if not snap:
                            missing_accounts.append(aid)
                            player_details.append({
                                **acc,
                                'account_id': aid,
                                'snapshot_status': 'missing_historical_snapshot',
                            })
                            continue
                        bal = max(0, int(snap.get('end_balance') or 0))
                        end_balance += bal
                        player_details.append({
                            **snap,
                            **acc,
                            'account_id': aid,
                            'end_balance': bal,
                            'snapshot_status': 'ok',
                            'recalculated_from_legacy_snapshot': True,
                        })
                    if missing_accounts:
                        new_status = 'failed'
                        error_code = 'historical_snapshot_incomplete_v2'
                        error_message = (
                            'تعذر إعادة احتساب الدورة القديمة بأمان لعدم اكتمال لقطة رصيد الإغلاق'
                        )
                    else:
                        net_loss = max(0, eligible_deposits - withdrawals - end_balance)
                        cashback = (
                            int(Decimal(net_loss) * Decimal(str(cycle['pct'])) / Decimal(100))
                            if old_status != 'banned'
                            and net_loss >= int(cycle['min_turnover'])
                            and Decimal(str(cycle['pct'])) > 0
                            else 0
                        )
                        new_status = (
                            'banned' if old_status == 'banned'
                            else ('eligible' if cashback > 0 else 'not_eligible')
                        )

                await self._store_v2_user_result(
                    cycle, tg, inputs=inputs, player_details=player_details,
                    end_balance=end_balance, net_loss=net_loss, cashback=cashback,
                    status=new_status, error_code=error_code, error_message=error_message,
                )

            totals = await self._refresh_v2_cycle_totals(int(cycle_id))
            new_cycle_status = (
                'ready' if totals['eligible_count'] > 0 or totals['failed_count'] > 0 else 'empty'
            )
            async with pool.acquire() as conn:
                updated = await conn.fetchrow(
                    """
                    UPDATE bot_core.cashback_cycles
                    SET status=$3,calc_version=2,eligible_count=$4,failed_count=$5,
                        total_loss_syp=$6,total_due_syp=$7,last_error=NULL,
                        v2_recalc_token=NULL,v2_recalc_started_at=NULL,updated_at=NOW()
                    WHERE id=$1 AND v2_recalc_token=$2 RETURNING *
                    """,
                    int(cycle_id), token, new_cycle_status, totals['eligible_count'],
                    totals['failed_count'], totals['total_loss'], totals['total_due'],
                )
            if not updated:
                raise RuntimeError('cashback v2 recalculation ownership lost')
            return {
                'cycle': dict(updated),
                **totals,
                'recalculated_v2': True,
            }
        except Exception as exc:
            async with pool.acquire() as conn:
                await conn.execute(
                    """
                    UPDATE bot_core.cashback_cycles
                    SET last_error=$3,v2_recalc_token=NULL,v2_recalc_started_at=NULL,updated_at=NOW()
                    WHERE id=$1 AND v2_recalc_token=$2
                    """,
                    int(cycle_id), token, str(exc)[:1200],
                )
            raise

    async def _ensure_cycle_v2(self, cycle_id: int) -> asyncpg.Record | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow(
                'SELECT * FROM bot_core.cashback_cycles WHERE id=$1', int(cycle_id)
            )
        if not cycle:
            return None
        if int(cycle['calc_version'] or 1) < 2 and str(cycle['status']) in {'ready','empty'}:
            await self._recalculate_legacy_cycle_v2(int(cycle_id))
            async with pool.acquire() as conn:
                cycle = await conn.fetchrow(
                    'SELECT * FROM bot_core.cashback_cycles WHERE id=$1', int(cycle_id)
                )
        return cycle

    async def recalculate_pending_legacy(self, limit: int = 3) -> list[dict[str, Any]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT id FROM bot_core.cashback_cycles
                WHERE calc_version<2 AND status IN ('ready','empty')
                ORDER BY cycle_end ASC,id ASC LIMIT $1
                """,
                max(1, min(20, int(limit))),
            )
        results: list[dict[str, Any]] = []
        for row in rows:
            try:
                results.append(await self._recalculate_legacy_cycle_v2(int(row['id'])))
            except Exception:
                logger.exception('cashback v2 legacy-cycle recalculation failed cycle=%s', row['id'])
        return results

    async def due(self, cycle_id: int|None=None, limit:int=100, offset:int=0) -> tuple[asyncpg.Record|None,list[asyncpg.Record]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            if cycle_id is None:
                cycle = await conn.fetchrow(
                    "SELECT * FROM bot_core.cashback_cycles WHERE status IN ('ready','distributing') ORDER BY id DESC LIMIT 1"
                )
            else:
                cycle = await conn.fetchrow(
                    'SELECT * FROM bot_core.cashback_cycles WHERE id=$1', int(cycle_id)
                )
        if not cycle:
            return None, []
        cycle = await self._ensure_cycle_v2(int(cycle['id'])) or cycle
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM bot_core.cashback_cycle_users WHERE cycle_id=$1 "
                "AND status IN ('eligible','paid') AND cashback_syp>0 "
                "ORDER BY cashback_syp DESC,telegram_id LIMIT $2 OFFSET $3",
                int(cycle['id']), limit, offset,
            )
        return cycle, rows

    async def ready_cycle(self) -> asyncpg.Record | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow(
                "SELECT * FROM bot_core.cashback_cycles WHERE status IN ('ready','empty','distributing') ORDER BY id DESC LIMIT 1"
            )
        if not cycle:
            return None
        return await self._ensure_cycle_v2(int(cycle['id'])) or cycle

    async def cycle_detail(self, cycle_id: int) -> asyncpg.Record | None:
        return await self._ensure_cycle_v2(int(cycle_id))

    async def failed_users(self, cycle_id: int, limit: int = 10, offset: int = 0) -> list[asyncpg.Record]:
        await self._ensure_cycle_v2(int(cycle_id))
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(
                """
                SELECT cu.*,u.first_name,u.username
                FROM bot_core.cashback_cycle_users cu
                JOIN bot_core.users u ON u.telegram_id=cu.telegram_id
                WHERE cu.cycle_id=$1 AND cu.status='failed'
                ORDER BY cu.telegram_id LIMIT $2 OFFSET $3
                """,
                int(cycle_id), max(1,min(50,int(limit))), max(0,int(offset)),
            )

    async def retry_failed(self, cycle_id: int) -> dict[str, Any]:
        """Retry only V2 failed closing-balance snapshots.

        Already-finalized users are not recalculated.  The same exact cycle-scoped
        deposits/withdrawals are reused, while only the failed live closing balance
        lookup is attempted again.
        """
        cycle = await self._ensure_cycle_v2(int(cycle_id))
        if not cycle or str(cycle['status']) in {'distributing','distributed'}:
            raise ValueError('CASHBACK_NOT_RETRYABLE')

        unresolved = await self._v2_unresolved_before_cycle_end(cycle)
        if unresolved > 0:
            raise ValueError('CASHBACK_HAS_UNRESOLVED_ICHANCY_JOBS')

        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            failed_rows = await conn.fetch(
                "SELECT telegram_id FROM bot_core.cashback_cycle_users "
                "WHERE cycle_id=$1 AND status='failed' ORDER BY telegram_id",
                int(cycle_id),
            )

        for row in failed_rows:
            await self._prepare_user_v2(cycle, int(row['telegram_id']))

        totals = await self._refresh_v2_cycle_totals(int(cycle_id))
        status = 'ready' if totals['eligible_count'] > 0 or totals['failed_count'] > 0 else 'empty'
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow(
                """
                UPDATE bot_core.cashback_cycles
                SET status=$2,calc_version=2,eligible_count=$3,failed_count=$4,
                    total_loss_syp=$5,total_due_syp=$6,last_error=NULL,updated_at=NOW()
                WHERE id=$1 RETURNING *
                """,
                int(cycle_id), status, totals['eligible_count'], totals['failed_count'],
                totals['total_loss'], totals['total_due'],
            )
        return {
            'cycle': dict(cycle),
            'retried': len(failed_rows),
            'remaining_failed': totals['failed_count'],
            'calc_version': 2,
        }

    async def distribute(self,cycle_id:int,admin_id:int)->dict[str,int]:
        # A legacy READY cycle must be upgraded from its historical closing snapshots
        # before any payout can begin. A legacy DISTRIBUTING cycle is intentionally
        # left frozen because payout has already started and rewriting it would be
        # financially unsafe.
        cycle = await self._ensure_cycle_v2(int(cycle_id))
        if not cycle:
            raise ValueError('CASHBACK_NOT_READY')
        pool=self.db.require_pool(); paid=total=0
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle=await conn.fetchrow('SELECT * FROM bot_core.cashback_cycles WHERE id=$1 FOR UPDATE',cycle_id)
                if not cycle or str(cycle['status']) not in {'ready','distributing'}: raise ValueError('CASHBACK_NOT_READY')
                if int(cycle['failed_count'] or 0)>0: raise ValueError('CASHBACK_HAS_FAILED_SNAPSHOTS')
                await conn.execute("UPDATE bot_core.cashback_cycles SET status='distributing' WHERE id=$1",cycle_id)
                rows=await conn.fetch("SELECT * FROM bot_core.cashback_cycle_users WHERE cycle_id=$1 AND status='eligible' AND cashback_syp>0 FOR UPDATE",cycle_id)
                for row in rows:
                    tg=int(row['telegram_id']); amount=int(row['cashback_syp'])
                    valid=bool(await conn.fetchval(
                        "SELECT 1 FROM bot_core.users WHERE telegram_id=$1 AND NOT is_blocked AND NOT is_bot", tg
                    ))
                    if amount<=0 or not valid:
                        await conn.execute(
                            "UPDATE bot_core.cashback_cycle_users SET status='banned',error_code='banned_before_payout',error_message='المستخدم محظور وقت التوزيع' WHERE cycle_id=$1 AND telegram_id=$2 AND status='eligible'",
                            cycle_id,tg,
                        )
                        continue
                    mutation=await self.wallet.credit_in_transaction(conn,tg,amount,idempotency_key=f'cashback:{cycle_id}:{tg}',reason='cashback_distribution',actor_telegram_id=admin_id,metadata={'cycle_id':cycle_id,'cashback_eligible':False})
                    await conn.execute("UPDATE bot_core.cashback_cycle_users SET status='paid',paid_at=NOW(),wallet_operation_id=$3 WHERE cycle_id=$1 AND telegram_id=$2",cycle_id,tg,mutation.operation_id)
                    if self.outbox is not None:
                        await self.outbox.enqueue(
                            event_key=f"cashback-user:{cycle_id}:{tg}", target_chat_id=tg, conn=conn,
                            text=(
                                "🎁 <b>تم توزيع الاسترداد</b>\n\n"
                                f"💰 قيمة الاسترداد: <code>{amount:,}</code> ل.س\n"
                                f"👛 رصيدك الحالي: <code>{mutation.balance_after.available:,}</code> ل.س"
                            ),
                        )
                    paid+=1; total+=amount
                await conn.execute(
                    "UPDATE bot_core.cashback_cycles SET status='distributed',distributed_at=NOW(),distributed_by=$2,paid_count=$3,total_paid_syp=$4,updated_at=NOW() WHERE id=$1",
                    cycle_id,admin_id,paid,total,
                )
        return {'paid_count':paid,'total':total}

    async def skip(self,cycle_id:int,admin_id:int)->None:
        # Skipping is also a financial finalization. Upgrade a safe legacy READY/EMPTY
        # cycle first so an old V1 entitlement can never be finalized after V2 exists.
        cycle = await self._ensure_cycle_v2(int(cycle_id))
        if not cycle:
            raise ValueError('CASHBACK_NOT_SKIPPABLE')
        pool=self.db.require_pool();
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle=await conn.fetchrow('SELECT * FROM bot_core.cashback_cycles WHERE id=$1 FOR UPDATE',cycle_id)
                if not cycle or str(cycle['status']) not in {'ready','empty'}: raise ValueError('CASHBACK_NOT_SKIPPABLE')
                skipped=await conn.fetchrow(
                    "SELECT COUNT(*) cnt,COALESCE(SUM(cashback_syp),0) amount FROM bot_core.cashback_cycle_users WHERE cycle_id=$1 AND status='eligible'",
                    cycle_id,
                )
                await conn.execute("UPDATE bot_core.cashback_cycle_users SET status='skipped' WHERE cycle_id=$1 AND status='eligible'",cycle_id)
                await conn.execute(
                    "UPDATE bot_core.cashback_cycles SET status='skipped',skipped_at=NOW(),skipped_by=$2,skipped_eligible_count=$3,skipped_amount_syp=$4,updated_at=NOW() WHERE id=$1",
                    cycle_id,admin_id,int(skipped['cnt'] or 0),int(skipped['amount'] or 0),
                )

    async def history(self,limit:int=10,offset:int=0)->list[asyncpg.Record]:
        pool=self.db.require_pool();
        async with pool.acquire() as conn:
            return await conn.fetch("SELECT * FROM bot_core.cashback_cycles ORDER BY id DESC LIMIT $1 OFFSET $2",limit,offset)


class RewardsMaintenanceService:
    def __init__(self, cashback: CashbackService, referrals: ReferralService, bot: Bot, admin_ids: set[int]) -> None:
        self.cashback=cashback; self.referrals=referrals; self.bot=bot; self.admin_ids={int(x) for x in admin_ids}; self._stop=asyncio.Event()

    def stop(self)->None: self._stop.set()

    async def run(self,interval:float=30.0)->None:
        while not self._stop.is_set():
            try:
                await self._tick()
            except asyncio.CancelledError: raise
            except Exception: logger.exception('rewards maintenance tick failed')
            try: await asyncio.wait_for(self._stop.wait(),timeout=max(10.0,float(interval)))
            except asyncio.TimeoutError: pass

    async def _notify_admins(self,text:str)->None:
        for admin in self.admin_ids:
            try: await self.bot.send_message(admin,text)
            except Exception: logger.exception('reward admin notification failed admin=%s',admin)

    async def _tick(self)->None:
        await self.referrals.retry_pending_fixed_rewards(limit=50)
        # Repair a few untouched legacy cashback cycles on every maintenance tick.
        # The repair itself is claimed/idempotent and uses only saved historical
        # closing snapshots; it never substitutes today's live balance.
        await self.cashback.recalculate_pending_legacy(limit=3)
        cycle=await self.cashback.ensure_cycle()
        if str(cycle['status']) in {'open','preparing'} and cycle['cycle_end']<=_utcnow():
            result=await self.cashback.prepare(int(cycle['id']))
            if result.get('done'):
                await self._notify_admins(
                    '✅ انتهت دورة الاسترداد وتم تثبيت نتائجها\n\n'
                    f"👥 المستحقون: {int(result.get('eligible_count') or 0)}\n"
                    f"📉 إجمالي الخسائر المعتمدة: {int(result.get('total_loss') or 0):,} SYP\n"
                    f"🎁 إجمالي الاسترداد: {int(result.get('total_due') or 0):,} SYP\n"
                    f"⚠️ تعذر الاحتساب: {int(result.get('failed_count') or 0)}"
                )
                await self.cashback.ensure_cycle()
        ref=await self.referrals.current_cycle()
        if ref and str(ref['status']) in {'active','preparing'} and ref['cycle_end']<=_utcnow():
            result=await self.referrals.prepare_ended_cycle(int(ref['id']))
            if result.get('done'):
                await self._notify_admins(
                    '✅ انتهت دورة الإحالات وتم تثبيت نتائجها\n\n'
                    f"📅 الدورة: #{int(ref['id'])}\n👥 المستحقون: {int(result.get('count') or 0)}\n"
                    f"💰 إجمالي الأرباح: {int(result.get('total') or 0):,} SYP"
                )
