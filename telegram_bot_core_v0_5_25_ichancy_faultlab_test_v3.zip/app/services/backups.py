from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import shutil
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

from aiogram import Bot
from aiogram.types import FSInputFile

from app.repositories.admin_ops import AdminOpsRepository
from app.services.runtime_settings import RuntimeSettingsService

logger = logging.getLogger(__name__)
DAMASCUS = ZoneInfo("Asia/Damascus")


@dataclass(frozen=True)
class BackupArtifact:
    path: Path
    sha256: str
    size_bytes: int


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _db_label(dsn: str) -> str:
    try:
        return (urlparse(dsn).path or "/postgresql").strip("/") or "postgresql"
    except Exception:
        return "postgresql"


def _require_binary(name: str) -> str:
    path = shutil.which(name)
    if not path:
        raise RuntimeError(f"{name} غير مثبت على السيرفر. ثبّت postgresql-client أولاً.")
    return path


def _dump_sync(dsn: str, out_path: Path) -> BackupArtifact:
    pg_dump = _require_binary("pg_dump")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        pg_dump,
        "--dbname", dsn,
        "--format=custom",
        "--schema=bot_core",
        "--no-owner",
        "--no-privileges",
        "--file", str(out_path),
    ]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=900)
    if proc.returncode != 0:
        out_path.unlink(missing_ok=True)
        raise RuntimeError((proc.stderr or b"pg_dump failed").decode("utf-8", "ignore")[-2500:])
    return BackupArtifact(path=out_path, sha256=_sha256(out_path), size_bytes=out_path.stat().st_size)


def _validate_dump_sync(path: Path) -> None:
    pg_restore = _require_binary("pg_restore")
    proc = subprocess.run([pg_restore, "--list", str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    if proc.returncode != 0:
        raise RuntimeError("ملف النسخة غير صالح أو ليس PostgreSQL custom dump: " + (proc.stderr or b"").decode("utf-8", "ignore")[-1200:])
    listing = (proc.stdout or b"").decode("utf-8", "ignore")
    if "bot_core" not in listing:
        raise RuntimeError("النسخة لا تحتوي مخطط bot_core المطلوب.")


def _restore_sync(dsn: str, path: Path) -> None:
    pg_restore = _require_binary("pg_restore")
    _validate_dump_sync(path)
    cmd = [
        pg_restore,
        "--dbname", dsn,
        "--clean",
        "--if-exists",
        "--single-transaction",
        "--no-owner",
        "--no-privileges",
        str(path),
    ]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=1800)
    if proc.returncode != 0:
        raise RuntimeError(((proc.stderr or b"") + (proc.stdout or b"")).decode("utf-8", "ignore")[-4000:])


def process_pending_restore(dsn: str, project_root: Path) -> dict | None:
    """Run before opening the asyncpg pool/workers.

    The requested restore is a custom pg_dump archive and pg_restore is executed
    in a single transaction. A result marker is left for the normal startup path
    to force maintenance and record the immutable audit row after migrations load.
    """
    runtime_dir = Path(project_root) / ".runtime"
    marker = runtime_dir / "pending_restore.json"
    result_path = runtime_dir / "restore_result.json"
    if not marker.exists():
        return None
    runtime_dir.mkdir(parents=True, exist_ok=True)
    try:
        payload = json.loads(marker.read_text(encoding="utf-8"))
        path = Path(str(payload["path"]))
        expected = str(payload["sha256"])
        actor = int(payload["actor"])
        if not path.exists():
            raise RuntimeError("ملف الاستعادة المجدول غير موجود.")
        actual = _sha256(path)
        if actual != expected:
            raise RuntimeError("بصمة ملف الاستعادة تغيرت بعد التأكيد؛ تم إلغاء الاستعادة.")
        _restore_sync(dsn, path)
        result = {"status": "success", "actor": actor, "sha256": actual, "file_name": path.name}
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass
    except Exception as exc:
        logger.exception("Deferred PostgreSQL restore failed")
        result = {
            "status": "failed",
            "actor": int(payload.get("actor", 0)) if isinstance(locals().get("payload"), dict) else 0,
            "sha256": str(payload.get("sha256", "")) if isinstance(locals().get("payload"), dict) else "",
            "file_name": Path(str(payload.get("path", "restore.dump"))).name if isinstance(locals().get("payload"), dict) else "restore.dump",
            "error": str(exc)[:3500],
        }
    result_path.write_text(json.dumps(result, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    marker.unlink(missing_ok=True)
    return result


class BackupService:
    def __init__(
        self, repository: AdminOpsRepository, runtime_settings: RuntimeSettingsService,
        bot: Bot, *, dsn: str, project_root: Path,
    ) -> None:
        self.repository = repository
        self.runtime_settings = runtime_settings
        self.bot = bot
        self.dsn = dsn
        self.project_root = Path(project_root)
        self.runtime_dir = self.project_root / ".runtime"
        self.backup_dir = self.runtime_dir / "backups"
        self.restore_dir = self.runtime_dir / "restores"
        self._stop = asyncio.Event()
        self._backup_lock = asyncio.Lock()

    @property
    def result_marker(self) -> Path:
        return self.runtime_dir / "restore_result.json"

    def stop(self) -> None:
        self._stop.set()

    async def consume_restore_result(self) -> dict | None:
        path = self.result_marker
        if not path.exists():
            return None
        try:
            payload = json.loads(await asyncio.to_thread(path.read_text, encoding="utf-8"))
        except Exception:
            logger.exception("Could not read restore result marker")
            return None
        try:
            # A restored database may contain either maintenance/restore-lock value.
            # Force maintenance on for review, but release the short-lived restore
            # lock before polling begins so the owner can reach the admin panel.
            await self.runtime_settings.set("system.restore_lock", False, updated_by=payload.get("actor") or None)
            await self.runtime_settings.set("maintenance.enabled", True, updated_by=payload.get("actor") or None)
            await self.repository.record_backup(
                actor=(int(payload.get("actor") or 0) or None), kind="restore",
                status="success" if payload.get("status") == "success" else "failed",
                file_name=str(payload.get("file_name") or "restore.dump"),
                file_sha256=(str(payload.get("sha256")) if len(str(payload.get("sha256") or "")) == 64 else None),
                details={"error": str(payload.get("error") or "")[:3500]},
            )
            if payload.get("actor"):
                await self.repository.log_security_event(
                    actor=int(payload["actor"]), action="database_restore_result",
                    details={"status": payload.get("status"), "file": payload.get("file_name"), "error": payload.get("error")},
                )
        finally:
            path.unlink(missing_ok=True)
        return payload

    async def recover_stale_restore_lock(self) -> bool:
        """Release a lock left by a crash before a restore marker was persisted."""
        if not self.runtime_settings.get_bool("system.restore_lock", False):
            return False
        pending = self.runtime_dir / "pending_restore.json"
        result = self.runtime_dir / "restore_result.json"
        if pending.exists() or result.exists():
            return False
        await self.runtime_settings.set("system.restore_lock", False, updated_by=None)
        logger.warning("Recovered stale restore lock without a pending restore marker")
        return True

    async def create_backup(self, *, actor: int | None, kind: str) -> BackupArtifact:
        async with self._backup_lock:
            stamp = datetime.now(DAMASCUS).strftime("%Y%m%d_%H%M%S")
            name = f"{_db_label(self.dsn)}_bot_core_{stamp}.dump"
            path = self.backup_dir / name
            try:
                artifact = await asyncio.to_thread(_dump_sync, self.dsn, path)
                await self.repository.record_backup(
                    actor=actor, kind=kind, status="success", file_name=artifact.path.name,
                    file_sha256=artifact.sha256, size_bytes=artifact.size_bytes,
                )
                await self.runtime_settings.set("backup.last_ok_at", datetime.now(DAMASCUS).isoformat(), updated_by=actor)
                await self.runtime_settings.set("backup.last_error", "", updated_by=actor)
                await self._cleanup_old_backups()
                return artifact
            except Exception as exc:
                await self.repository.record_backup(actor=actor, kind=kind, status="failed", details={"error": str(exc)[:3500]})
                await self.runtime_settings.set("backup.last_error", str(exc)[:3500], updated_by=actor)
                raise

    async def send_backup(self, artifact: BackupArtifact, target: int | str) -> None:
        size_mb = artifact.size_bytes / (1024 * 1024)
        caption = (
            "🧰 نسخة احتياطية PostgreSQL ✅\n\n"
            f"📅 {datetime.now(DAMASCUS).strftime('%d/%m/%Y - %I:%M %p')}\n"
            f"📦 {size_mb:.2f} MB\n"
            f"🔐 SHA-256: <code>{artifact.sha256}</code>"
        )
        await self.bot.send_document(chat_id=target, document=FSInputFile(artifact.path), caption=caption)

    async def validate_uploaded_restore(self, path: Path) -> BackupArtifact:
        if path.suffix.lower() != ".dump":
            raise RuntimeError("صيغة الاستعادة المدعومة هي .dump المنشأة من البوت فقط.")
        if path.stat().st_size <= 0 or path.stat().st_size > 1024 * 1024 * 1024:
            raise RuntimeError("حجم ملف النسخة غير صالح.")
        await asyncio.to_thread(_validate_dump_sync, path)
        return BackupArtifact(path=path, sha256=await asyncio.to_thread(_sha256, path), size_bytes=path.stat().st_size)

    async def save_restore_upload(self, document) -> BackupArtifact:
        self.restore_dir.mkdir(parents=True, exist_ok=True)
        name = str(document.file_name or "restore.dump")
        if not name.lower().endswith(".dump"):
            raise RuntimeError("أرسل ملف .dump تم إنشاؤه من قسم النسخ الاحتياطي في البوت.")
        safe = "restore_" + datetime.now(DAMASCUS).strftime("%Y%m%d_%H%M%S") + ".dump"
        path = self.restore_dir / safe
        tg_file = await self.bot.get_file(document.file_id)
        await self.bot.download_file(tg_file.file_path, destination=path)
        return await self.validate_uploaded_restore(path)

    async def schedule_restore(self, artifact: BackupArtifact, *, actor: int) -> BackupArtifact:
        # Maintenance blocks users; restore_lock additionally blocks every *new*
        # admin update during the short quiescence / restart window. The current
        # confirmation handler already passed middleware and can finish safely.
        await self.runtime_settings.set("maintenance.enabled", True, updated_by=actor)
        await self.runtime_settings.set("system.restore_lock", True, updated_by=actor)
        try:
            await asyncio.sleep(2.0)
            unresolved = await self.repository.unresolved_financial_count()
            if unresolved:
                raise RuntimeError(f"لا يمكن الاستعادة الآن: توجد {unresolved} عملية مالية غير محسومة.")

            safety = await self.create_backup(actor=actor, kind="pre_restore")
            self.runtime_dir.mkdir(parents=True, exist_ok=True)
            marker = self.runtime_dir / "pending_restore.json"
            payload = {
                "path": str(artifact.path.resolve()),
                "sha256": artifact.sha256,
                "actor": int(actor),
                "scheduled_at": datetime.now(DAMASCUS).isoformat(),
                "safety_backup": str(safety.path.resolve()),
                "safety_sha256": safety.sha256,
            }
            tmp = marker.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            os.replace(tmp, marker)
            await self.repository.record_backup(
                actor=actor, kind="restore", status="scheduled", file_name=artifact.path.name,
                file_sha256=artifact.sha256, size_bytes=artifact.size_bytes,
                details={"safety_backup": safety.path.name, "safety_sha256": safety.sha256},
            )
            await self.repository.log_security_event(
                actor=actor, action="database_restore_scheduled",
                details={"file": artifact.path.name, "sha256": artifact.sha256, "safety_backup": safety.path.name},
            )
            return safety
        except Exception:
            # Scheduling never reached a restart marker. Let the owner back into
            # the panel while maintenance remains on for deliberate review.
            await self.runtime_settings.set("system.restore_lock", False, updated_by=actor)
            raise

    async def run_auto_worker(self) -> None:
        while not self._stop.is_set():
            try:
                if self.runtime_settings.get_bool("backup.auto_enabled", True):
                    target = self._backup_target(self.runtime_settings.get("backup.channel", ""))
                    now = datetime.now(DAMASCUS)
                    today = now.strftime("%Y-%m-%d")
                    if target is not None and now.hour == 3 and str(self.runtime_settings.get("backup.last_auto_day", "") or "") != today:
                        # Persist the claim before dump creation to prevent duplicate
                        # hourly attempts if Telegram delivery itself is slow.
                        await self.runtime_settings.set("backup.last_auto_day", today, updated_by=None)
                        artifact = await self.create_backup(actor=None, kind="automatic")
                        await self.send_backup(artifact, target)
                await asyncio.wait_for(self._stop.wait(), timeout=60.0)
            except asyncio.TimeoutError:
                continue
            except Exception as exc:
                logger.exception("Automatic backup failed")
                try:
                    await self.runtime_settings.set("backup.last_error", str(exc)[:3500], updated_by=None)
                except Exception:
                    pass
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=60.0)
                except asyncio.TimeoutError:
                    pass

    async def _cleanup_old_backups(self) -> None:
        def cleanup() -> None:
            if not self.backup_dir.exists():
                return
            files = sorted(self.backup_dir.glob("*.dump"), key=lambda p: p.stat().st_mtime, reverse=True)
            for path in files[14:]:
                try:
                    path.unlink()
                except Exception:
                    pass
        await asyncio.to_thread(cleanup)

    @staticmethod
    def _backup_target(raw) -> int | str | None:
        text = str(raw or "").strip()
        if not text:
            return None
        if text.startswith("@"):
            return text
        try:
            return int(text)
        except ValueError:
            return None
