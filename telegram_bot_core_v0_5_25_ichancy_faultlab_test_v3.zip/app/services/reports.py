from __future__ import annotations

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from typing import Any

from app.core.db import Database

DAMASCUS = ZoneInfo("Asia/Damascus")
UTC = timezone.utc


class ReportsService:
    """Read-only financial/user reporting using Damascus calendar boundaries.

    This service never mutates financial tables and never calls payment providers.
    Real deposits are base_credit_syp only; deposit bonuses and other internal credits
    are shown separately. Net cash flow is real deposits minus net successful payouts,
    not profit.
    """

    def __init__(self, db: Database) -> None:
        self.db = db

    @staticmethod
    def period_bounds(period: str, start_date: str | None = None, end_date: str | None = None) -> tuple[datetime, datetime, str]:
        p = (period or "today").strip().lower()
        now = datetime.now(DAMASCUS)
        if p == "today":
            start = datetime(now.year, now.month, now.day, tzinfo=DAMASCUS); end = now; label = "اليوم"
        elif p == "yesterday":
            day = now - timedelta(days=1)
            start = datetime(day.year, day.month, day.day, tzinfo=DAMASCUS); end = start + timedelta(days=1); label = "أمس"
        elif p == "week":
            day = now - timedelta(days=now.weekday())
            start = datetime(day.year, day.month, day.day, tzinfo=DAMASCUS); end = now; label = "هذا الأسبوع"
        elif p == "month":
            start = datetime(now.year, now.month, 1, tzinfo=DAMASCUS); end = now; label = "هذا الشهر"
        elif p == "year":
            start = datetime(now.year, 1, 1, tzinfo=DAMASCUS); end = now; label = "هذه السنة"
        elif p == "custom":
            try:
                sd = datetime.strptime(str(start_date), "%Y-%m-%d")
                ed = datetime.strptime(str(end_date), "%Y-%m-%d")
            except Exception as exc:
                raise ValueError("صيغة التاريخ يجب أن تكون YYYY-MM-DD") from exc
            if ed < sd:
                raise ValueError("تاريخ النهاية يجب ألا يسبق تاريخ البداية")
            if (ed - sd).days > 3660:
                raise ValueError("الفترة المخصصة طويلة جداً")
            start = datetime(sd.year, sd.month, sd.day, tzinfo=DAMASCUS)
            end = datetime(ed.year, ed.month, ed.day, tzinfo=DAMASCUS) + timedelta(days=1)
            label = f"{sd:%Y-%m-%d} → {ed:%Y-%m-%d}"
        else:
            raise ValueError("فترة غير مدعومة")
        return start.astimezone(UTC), end.astimezone(UTC), label

    async def financial_report(self, period: str, start_date: str | None = None, end_date: str | None = None) -> dict[str, Any]:
        start, end, label = self.period_bounds(period, start_date, end_date)
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            dep_rows = await conn.fetch(
                """SELECT method,COUNT(*)::BIGINT AS count,
                          COALESCE(SUM(base_credit_syp),0)::BIGINT AS base,
                          COALESCE(SUM(bonus_credit_syp),0)::BIGINT AS bonus,
                          COALESCE(SUM(total_credit_syp),0)::BIGINT AS credited
                   FROM bot_core.deposit_requests
                   WHERE status='success' AND settled_at >= $1 AND settled_at < $2
                   GROUP BY method ORDER BY method""", start, end)
            wd_rows = await conn.fetch(
                """SELECT method,COUNT(*)::BIGINT AS count,
                          COALESCE(SUM(amount_wallet),0)::BIGINT AS amount,
                          COALESCE(SUM(net_wallet),0)::BIGINT AS net,
                          COALESCE(SUM(fee_wallet),0)::BIGINT AS fee
                   FROM bot_core.withdraw_requests
                   WHERE status='success' AND finished_at >= $1 AND finished_at < $2
                   GROUP BY method ORDER BY method""", start, end)
            ich = await conn.fetchrow(
                """SELECT COUNT(*)::BIGINT AS count,
                          COALESCE(SUM(amount) FILTER (WHERE operation_type='deposit'),0)::BIGINT AS deposits,
                          COALESCE(SUM(wallet_amount_syp) FILTER (WHERE operation_type='deposit'),0)::BIGINT AS deposit_wallet,
                          COALESCE(SUM(promo_amount_syp) FILTER (WHERE operation_type='deposit'),0)::BIGINT AS deposit_promo,
                          COALESCE(SUM(amount) FILTER (WHERE operation_type IN ('withdraw','retirement_withdraw')),0)::BIGINT AS withdrawals
                   FROM bot_core.ichancy_jobs
                   WHERE status='success' AND finished_at >= $1 AND finished_at < $2""", start, end)
            rewards = await conn.fetchrow(
                """SELECT
                  COALESCE((SELECT SUM(prize_syp) FROM bot_core.wheel_claims WHERE claimed_at >= $1 AND claimed_at < $2),0)::BIGINT AS wheel,
                  COALESCE((SELECT SUM(prize_syp) FROM bot_core.wheel_free_entitlements WHERE claimed_at >= $1 AND claimed_at < $2),0)::BIGINT AS wheel_free,
                  COALESCE((SELECT SUM(cashback_syp) FROM bot_core.cashback_cycle_users WHERE status='paid' AND paid_at >= $1 AND paid_at < $2),0)::BIGINT AS cashback,
                  COALESCE((SELECT SUM(amount_syp) FROM bot_core.referral_fixed_rewards WHERE paid_at >= $1 AND paid_at < $2),0)::BIGINT AS referral_fixed,
                  COALESCE((SELECT SUM(amount_syp) FROM bot_core.referral_cycle_payouts WHERE status='paid' AND paid_at >= $1 AND paid_at < $2),0)::BIGINT AS referral_cycle,
                  COALESCE((SELECT SUM(amount_syp) FROM bot_core.welcome_bonus_claims WHERE claim_type='instant' AND status='used' AND granted_at >= $1 AND granted_at < $2),0)::BIGINT AS welcome_instant,
                  COALESCE((SELECT SUM(amount_syp) FROM bot_core.welcome_bonus_claims WHERE claim_type='first_deposit' AND status='used' AND used_at >= $1 AND used_at < $2),0)::BIGINT AS welcome_first_deposit,
                  COALESCE((SELECT SUM(amount_syp) FROM bot_core.gift_code_redemptions WHERE used_at >= $1 AND used_at < $2),0)::BIGINT AS gift_codes,
                  COALESCE((SELECT SUM(balance_amount_syp) FROM bot_core.loyalty_reward_claims WHERE reward_type='balance' AND status='completed' AND created_at >= $1 AND created_at < $2),0)::BIGINT AS loyalty_balance,
                  COALESCE((SELECT SUM(amount_syp) FROM bot_core.promo_rewards WHERE source_type='contest' AND created_at >= $1 AND created_at < $2),0)::BIGINT AS contest_promo_awarded,
                  COALESCE((SELECT SUM(amount_syp) FROM bot_core.promo_rewards WHERE source_type='roulette' AND created_at >= $1 AND created_at < $2),0)::BIGINT AS roulette_promo_awarded,
                  COALESCE((SELECT SUM(bonus_syp) FROM bot_core.contest_bonus_rewards WHERE status='consumed' AND consumed_at >= $1 AND consumed_at < $2),0)::BIGINT AS contest_bonus_used,
                  COALESCE((SELECT SUM(bonus_syp) FROM bot_core.roulette_bonus_rewards WHERE status='consumed' AND consumed_at >= $1 AND consumed_at < $2),0)::BIGINT AS roulette_bonus_used,
                  COALESCE((SELECT SUM(l.available_delta) FROM bot_core.wallet_ledger l JOIN bot_core.wallet_operations o ON o.id=l.operation_id WHERE l.reason='admin user balance credit' AND l.created_at >= $1 AND l.created_at < $2),0)::BIGINT AS admin_added,
                  COALESCE((SELECT SUM(-l.available_delta) FROM bot_core.wallet_ledger l JOIN bot_core.wallet_operations o ON o.id=l.operation_id WHERE l.reason='admin user balance debit' AND l.available_delta<0 AND l.created_at >= $1 AND l.created_at < $2),0)::BIGINT AS admin_deducted
                """, start, end)
            users = await conn.fetchrow(
                """SELECT
                   (SELECT COUNT(*) FROM bot_core.users WHERE NOT is_bot AND created_at >= $1 AND created_at < $2)::BIGINT AS new_users,
                   (SELECT COUNT(*) FROM bot_core.users WHERE NOT is_bot AND last_active_at >= $1 AND last_active_at < $2)::BIGINT AS active_users,
                   (SELECT COUNT(*) FROM bot_core.users WHERE NOT is_bot)::BIGINT AS total_users,
                   (SELECT COUNT(*) FROM bot_core.users WHERE is_blocked)::BIGINT AS blocked_users""", start, end)
            wallet = await conn.fetchrow(
                """SELECT COALESCE(SUM(available),0)::BIGINT AS available,COALESCE(SUM(held),0)::BIGINT AS held
                   FROM bot_core.wallet_accounts WHERE asset_code='SYP' AND bucket='cash'""")
            pending = await conn.fetchrow(
                """SELECT
                   (SELECT COUNT(*) FROM bot_core.deposit_requests WHERE status IN ('verifying','manual_pending'))::BIGINT AS deposits,
                   (SELECT COUNT(*) FROM bot_core.withdraw_requests WHERE status IN ('pending','processing','provider_success','needs_review'))::BIGINT AS withdrawals,
                   (SELECT COUNT(*) FROM bot_core.ichancy_jobs WHERE status IN ('queued','executing','remote_success','reconciling'))::BIGINT AS ichancy""")
            top = await conn.fetch(
                """SELECT d.telegram_id,COUNT(*)::BIGINT AS deposits_count,COALESCE(SUM(d.base_credit_syp),0)::BIGINT AS total_base,
                          u.first_name,u.username
                   FROM bot_core.deposit_requests d JOIN bot_core.users u ON u.telegram_id=d.telegram_id
                   WHERE d.status='success' AND d.settled_at >= $1 AND d.settled_at < $2 AND d.base_credit_syp>0
                   GROUP BY d.telegram_id,u.first_name,u.username ORDER BY total_base DESC,d.telegram_id LIMIT 10""", start, end)

        deposits = [dict(x) for x in dep_rows]; withdrawals = [dict(x) for x in wd_rows]
        total_real = sum(int(x["base"] or 0) for x in dep_rows)
        total_bonus = sum(int(x["bonus"] or 0) for x in dep_rows)
        total_credited = sum(int(x["credited"] or 0) for x in dep_rows)
        total_wd_amount = sum(int(x["amount"] or 0) for x in wd_rows)
        total_wd_net = sum(int(x["net"] or 0) for x in wd_rows)
        total_wd_fee = sum(int(x["fee"] or 0) for x in wd_rows)
        rew = dict(rewards or {})
        ordinary_internal = total_bonus + int(rew.get("welcome_instant") or 0) + int(rew.get("wheel") or 0) + int(rew.get("wheel_free") or 0) + int(rew.get("cashback") or 0) + int(rew.get("referral_fixed") or 0) + int(rew.get("referral_cycle") or 0) + int(rew.get("gift_codes") or 0) + int(rew.get("loyalty_balance") or 0) + int(rew.get("admin_added") or 0)
        return {
            "period": period,"label": label,"start": start,"end": end,
            "deposits": deposits,"withdrawals": withdrawals,
            "total_real_deposits": total_real,"total_deposit_bonuses": total_bonus,"total_credited_deposits": total_credited,
            "total_withdraw_amount": total_wd_amount,"total_withdraw_net": total_wd_net,"total_withdraw_fees": total_wd_fee,
            "net_cash_flow": total_real-total_wd_net,"rewards": rew,"total_internal_credits": ordinary_internal,
            "ichancy": dict(ich or {}),"users": dict(users or {}),"wallet": dict(wallet or {}),"pending": dict(pending or {}),
            "top_users": [dict(x) for x in top],"timezone": "Asia/Damascus",
        }
