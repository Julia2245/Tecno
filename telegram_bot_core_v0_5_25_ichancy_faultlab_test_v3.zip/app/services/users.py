from __future__ import annotations

import time
from typing import Any

from aiogram.types import User as TelegramUser

from app.repositories.users import UserRecord, UserRepository


class UserService:
    def __init__(self, repository: UserRepository) -> None:
        self.repository = repository
        self._blocked_cache: dict[int, tuple[bool, float]] = {}
        self._touch_after: dict[int, float] = {}
        self._terms_cache: dict[int, tuple[bool, float]] = {}
        self._block_ttl_seconds = 15.0
        self._terms_ttl_seconds = 30.0
        self._touch_interval_seconds = 60.0

    async def sync_profile(self, telegram_user: TelegramUser) -> UserRecord:
        record = await self.repository.upsert_from_telegram(telegram_user)
        self._blocked_cache[int(telegram_user.id)] = (bool(record.is_blocked), time.monotonic() + self._block_ttl_seconds)
        self._touch_after[int(telegram_user.id)] = time.monotonic() + self._touch_interval_seconds
        return record

    async def sync_profile_with_created(
        self, telegram_user: TelegramUser, referrer_id: int | None = None
    ) -> tuple[UserRecord, bool]:
        record, created = await self.repository.upsert_from_telegram_with_created(
            telegram_user, referrer_id=referrer_id
        )
        now = time.monotonic()
        self._blocked_cache[int(telegram_user.id)] = (bool(record.is_blocked), now + self._block_ttl_seconds)
        self._touch_after[int(telegram_user.id)] = now + self._touch_interval_seconds
        if created:
            self._terms_cache[int(telegram_user.id)] = (True, now + self._terms_ttl_seconds)
        return record, created

    async def needs_terms_cached(self, telegram_id: int) -> bool:
        user_id = int(telegram_id)
        now = time.monotonic()
        cached = self._terms_cache.get(user_id)
        if cached and cached[1] > now:
            return bool(cached[0])
        required = await self.repository.needs_terms(user_id)
        self._terms_cache[user_id] = (bool(required), now + self._terms_ttl_seconds)
        return bool(required)

    async def accept_terms(self, telegram_id: int) -> bool:
        user_id = int(telegram_id)
        ok = await self.repository.accept_terms(user_id)
        if ok:
            self._terms_cache[user_id] = (False, time.monotonic() + 86400.0)
        return ok

    async def set_pending_start_action(self, telegram_id: int, action: str | None) -> None:
        await self.repository.set_pending_start_action(int(telegram_id), action)

    async def pending_start_action(self, telegram_id: int) -> str | None:
        return await self.repository.pending_start_action(int(telegram_id))

    async def clear_pending_start_action(self, telegram_id: int, expected: str) -> bool:
        return await self.repository.clear_pending_start_action(int(telegram_id), expected)

    async def is_blocked_cached(self, telegram_id: int) -> bool:
        user_id = int(telegram_id)
        now = time.monotonic()
        cached = self._blocked_cache.get(user_id)
        if cached and cached[1] > now:
            return bool(cached[0])
        status = await self.repository.is_blocked(user_id)
        blocked = bool(status) if status is not None else False
        self._blocked_cache[user_id] = (blocked, now + self._block_ttl_seconds)
        return blocked

    async def touch_existing(self, telegram_user: TelegramUser) -> None:
        user_id = int(telegram_user.id)
        now = time.monotonic()
        if self._touch_after.get(user_id, 0.0) > now:
            return
        touched = await self.repository.touch_existing_from_telegram(telegram_user)
        if touched:
            self._touch_after[user_id] = now + self._touch_interval_seconds

    async def set_blocked(self, target_id: int, blocked: bool, *, actor_id: int) -> None:
        await self.repository.set_blocked(int(target_id), bool(blocked), actor_id=int(actor_id))
        self._blocked_cache[int(target_id)] = (bool(blocked), time.monotonic() + 86400.0)

    async def search(self, query: str, *, limit: int = 12) -> list[dict[str, Any]]:
        return await self.repository.search_admin_users(query, limit=limit)

    async def admin_card(self, telegram_id: int) -> dict[str, Any] | None:
        return await self.repository.admin_user_card(int(telegram_id))

    async def ranked(self, kind: str, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        return await self.repository.ranked_users(kind, limit=limit, offset=offset)

    async def blocked_users(self, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        return await self.repository.list_blocked(limit=limit, offset=offset)

    async def log_admin_action(
        self, actor_id: int, target_id: int, action: str, details: dict[str, Any] | None = None
    ) -> None:
        await self.repository.log_admin_action(actor_id, target_id, action, details)

    async def overview(self) -> dict[str, Any]:
        return await self.repository.admin_overview()

    async def public_history(
        self, telegram_id: int, kind: str, *, limit: int = 15, offset: int = 0
    ) -> tuple[list[dict[str, Any]], int]:
        return await self.repository.public_history(telegram_id, kind, limit=limit, offset=offset)

    async def history(
        self, telegram_id: int, kind: str, *, limit: int = 8, offset: int = 0
    ) -> tuple[list[dict[str, Any]], int]:
        return await self.repository.user_history(telegram_id, kind, limit=limit, offset=offset)

