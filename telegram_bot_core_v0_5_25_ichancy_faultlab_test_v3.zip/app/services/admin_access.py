from __future__ import annotations

from app.config import Settings
from app.repositories.admin_ops import AdminOpsRepository


class AdminAccessService:
    def __init__(self, repository: AdminOpsRepository, settings: Settings) -> None:
        self.repository = repository
        self.settings = settings

    async def load(self) -> None:
        ids = await self.repository.assistant_ids()
        self.settings.replace_runtime_assistants(ids)

    def is_owner(self, telegram_id: int) -> bool:
        return int(telegram_id) in self.settings.owner_admin_ids

    def is_admin(self, telegram_id: int) -> bool:
        return int(telegram_id) in self.settings.super_admin_ids

    async def list_assistants(self):
        return await self.repository.list_assistants()

    async def add(self, telegram_id: int, *, actor: int) -> tuple[bool, str]:
        if not self.is_owner(actor):
            return False, "not_owner"
        target = int(telegram_id)
        if target in self.settings.owner_admin_ids:
            return False, "is_owner"
        ok, reason = await self.repository.add_assistant(target, added_by=int(actor))
        if ok:
            ids = await self.repository.assistant_ids()
            self.settings.replace_runtime_assistants(ids)
        return ok, reason

    async def remove(self, telegram_id: int, *, actor: int) -> bool:
        if not self.is_owner(actor):
            return False
        target = int(telegram_id)
        if target == int(actor) or target in self.settings.owner_admin_ids:
            return False
        ok = await self.repository.remove_assistant(target, removed_by=int(actor))
        if ok:
            ids = await self.repository.assistant_ids()
            self.settings.replace_runtime_assistants(ids)
        return ok
