from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from zoneinfo import ZoneInfo

import aiohttp

from app.services.runtime_settings import RuntimeSettingsService

logger = logging.getLogger(__name__)
DAMASCUS = ZoneInfo("Asia/Damascus")
CACHE_VERSION = 4
CACHE_SOURCE = "api-football"
CACHE_PREFIX = "football.matches.daily."

LEAGUES: dict[str, tuple[str, int | None]] = {
    "laliga": ("🇪🇸 الدوري الإسباني", 140),
    "epl": ("🏴 الدوري الإنجليزي", 39),
    "ucl": ("🏆 دوري أبطال أوروبا", 2),
    "uel": ("🏆 الدوري الأوروبي", 3),
    "seriea": ("🇮🇹 الدوري الإيطالي", 135),
    "bundesliga": ("🇩🇪 الدوري الألماني", 78),
    "ligue1": ("🇫🇷 الدوري الفرنسي", 61),
    "mixed": ("🌍 مباريات متنوعة اليوم", None),
}
ORDER = tuple(LEAGUES)
KNOWN_LEAGUE_IDS = {int(v[1]) for v in LEAGUES.values() if v[1] is not None}


class MatchesService:
    """Persisted once-per-day football cache.

    User callbacks never perform HTTP. Only the background refresher can contact
    API-Football. A successful cache for the Damascus-local day suppresses all
    further provider requests for that day, including after process restarts.
    """

    def __init__(
        self,
        session: aiohttp.ClientSession,
        runtime: RuntimeSettingsService,
        *,
        api_key: str,
        base_url: str,
        cache_minutes: int = 10,  # compatibility only; daily cache no longer expires intra-day
    ) -> None:
        self.session = session
        self.runtime = runtime
        self.api_key = str(api_key or "").strip()
        self.base_url = str(base_url or "").strip()
        self._lock = asyncio.Lock()
        self._stop = asyncio.Event()

    @staticmethod
    def today_key() -> str:
        return datetime.now(DAMASCUS).date().isoformat()

    @staticmethod
    def _cache_key(day: str) -> str:
        # runtime_settings keys permit [a-z0-9_.] only; keep ISO dashes in the
        # value shown to users, not in the PostgreSQL setting key.
        return f"{CACHE_PREFIX}{str(day).replace('-', '')}"

    def _cache(self, day: str | None = None) -> dict | None:
        day = day or self.today_key()
        raw = self.runtime.get(self._cache_key(day))
        return raw if isinstance(raw, dict) else None

    @staticmethod
    def _valid(cache: dict | None, day: str) -> bool:
        if not isinstance(cache, dict):
            return False
        if str(cache.get("day") or "") != day:
            return False
        if str(cache.get("source") or "") != CACHE_SOURCE:
            return False
        if int(cache.get("version") or 0) < CACHE_VERSION:
            return False
        leagues = cache.get("leagues")
        return isinstance(leagues, dict) and all(isinstance(leagues.get(k), list) for k in ORDER)

    async def refresh_today_if_needed(self) -> bool:
        """Fetch at most once after a valid cache exists for today's Damascus date."""
        day = self.today_key()
        if self._valid(self._cache(day), day):
            return False
        async with self._lock:
            if self._valid(self._cache(day), day):
                return False
            if not self.api_key or not self.base_url:
                await self.runtime.set("football.matches.last_error", "football api is not configured", updated_by=None)
                return False
            try:
                timeout = aiohttp.ClientTimeout(total=25, connect=5, sock_read=20)
                async with self.session.get(
                    self.base_url,
                    params={"date": day, "timezone": "Asia/Damascus"},
                    headers={"x-apisports-key": self.api_key},
                    timeout=timeout,
                ) as resp:
                    if resp.status != 200:
                        raise RuntimeError(f"football_http_{resp.status}")
                    payload = await resp.json(content_type=None)
                by_league: dict[str, list[dict]] = {key: [] for key in ORDER}
                for item in list((payload or {}).get("response") or []):
                    row = self._normalize(item, day)
                    if row is None:
                        continue
                    by_league[str(row["league_key"])].append(row)
                for key in ORDER:
                    by_league[key].sort(key=lambda r: (str(r.get("time") or "99:99"), str(r.get("home") or "")))
                    if key == "mixed":
                        by_league[key] = by_league[key][:50]
                cache = {
                    "day": day,
                    "updated_at": datetime.now(DAMASCUS).strftime("%Y-%m-%d %H:%M:%S"),
                    "source": CACHE_SOURCE,
                    "version": CACHE_VERSION,
                    "leagues": by_league,
                }
                await self.runtime.set(self._cache_key(day), cache, updated_by=None)
                await self.runtime.set("football.matches.latest_day", day, updated_by=None)
                await self.runtime.set("football.matches.last_error", "", updated_by=None)
                return True
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("Daily football refresh failed for %s", day, exc_info=True)
                await self.runtime.set(
                    "football.matches.last_error", f"{type(exc).__name__}: {exc}"[:500], updated_by=None
                )
                return False

    async def run_daily_worker(self, retry_seconds: int = 300) -> None:
        """Ensure one persisted dataset per day; failures may retry until one succeeds."""
        while not self._stop.is_set():
            try:
                await self.refresh_today_if_needed()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Unexpected football daily worker error")
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=max(60, int(retry_seconds)))
            except asyncio.TimeoutError:
                pass

    def stop(self) -> None:
        self._stop.set()

    def cache_info(self) -> dict:
        day = self.today_key()
        cache = self._cache(day)
        if self._valid(cache, day):
            return {"day": day, "updated_at": str(cache.get("updated_at") or "-"), "ready": True}
        return {"day": day, "updated_at": "قيد التحديث", "ready": False}

    async def today(self, league_key: str = "mixed") -> tuple[list[dict], str | None]:
        """Read persisted cache only. This method never contacts the provider."""
        if league_key not in LEAGUES:
            league_key = "mixed"
        day = self.today_key()
        cache = self._cache(day)
        if not self._valid(cache, day):
            return [], "بيانات مباريات اليوم قيد التحديث. حاول بعد قليل."
        rows = list((cache.get("leagues") or {}).get(league_key) or [])
        return rows, None

    @staticmethod
    def _normalize(item: dict, day: str) -> dict | None:
        if not isinstance(item, dict):
            return None
        fixture = item.get("fixture") or {}
        teams = item.get("teams") or {}
        league = item.get("league") or {}
        status = fixture.get("status") or {}
        try:
            league_id = int(league.get("id"))
        except Exception:
            return None
        date_raw = str(fixture.get("date") or "")
        try:
            dt = datetime.fromisoformat(date_raw.replace("Z", "+00:00")).astimezone(DAMASCUS)
        except Exception:
            return None
        if dt.date().isoformat() != day:
            return None
        league_key = next((k for k, (_title, lid) in LEAGUES.items() if lid == league_id), "mixed")
        short = str(status.get("short") or "").strip().upper()
        note = "" if short in {"NS", "TBD"} else str(status.get("long") or "").strip()
        return {
            "id": fixture.get("id"),
            "league_key": league_key,
            "league_id": league_id,
            "league": str(league.get("name") or "-").strip(),
            "round": str(league.get("round") or "").strip(),
            "date": day,
            "time": dt.strftime("%H:%M"),
            "home": str((teams.get("home") or {}).get("name") or "-").strip(),
            "away": str((teams.get("away") or {}).get("name") or "-").strip(),
            "note": note,
        }

    @staticmethod
    def format_fixture(row: dict) -> str:
        round_text = f" • {row.get('round')}" if row.get("round") else ""
        note_text = f" • {row.get('note')}" if row.get("note") else ""
        return (
            f"🕒 {row.get('time') or '--:--'}{round_text}{note_text}\n"
            f"{row.get('home') or '-'} × {row.get('away') or '-'}\n"
            "────────────"
        )
