from __future__ import annotations

import asyncio
import logging
import json
import secrets
import re
from urllib.parse import urlparse
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID

import asyncpg
from aiogram import Bot

from app.repositories.competitions import CompetitionRepository
from app.services.runtime_settings import RuntimeSettingsService

logger = logging.getLogger(__name__)
PROMO_HOURS = 24


class CompetitionError(RuntimeError):
    pass


class CompetitionService:
    def __init__(self, repository: CompetitionRepository, runtime: RuntimeSettingsService) -> None:
        self.repository = repository
        self.db = repository.db
        self.runtime = runtime

    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)

    @staticmethod
    def _json_list(value: Any) -> list[Any]:
        if isinstance(value, list): return value
        if isinstance(value, str):
            try:
                parsed=json.loads(value); return parsed if isinstance(parsed,list) else []
            except Exception: return []
        return []

    async def create_contest(self, **kwargs):
        template = str(kwargs.get('template_type') or '')
        if template not in {'match_prediction','cash_luck','top_depositors','deposit_raffle'}:
            raise CompetitionError('نوع المسابقة غير صالح')
        prize_type = str(kwargs.get('prize_type') or '')
        if prize_type not in {'balance','deposit_bonus'}:
            raise CompetitionError('نوع الجائزة غير صالح')
        prize_value = Decimal(str(kwargs.get('prize_value') or 0))
        if prize_value <= 0 or (prize_type == 'deposit_bonus' and prize_value > 100):
            raise CompetitionError('قيمة الجائزة غير صالحة')
        start_at = kwargs.get('start_at') or self._now()
        end_at = kwargs.get('end_at')
        if not isinstance(end_at, datetime) or end_at <= start_at or end_at-start_at > timedelta(days=90):
            raise CompetitionError('مدة المسابقة غير صالحة')
        if template == 'match_prediction' and kwargs.get('prediction_type') not in {'score','corners','cards'}:
            raise CompetitionError('نوع التوقع غير صالح')
        if template == 'cash_luck' and not kwargs.get('suffixes'):
            raise CompetitionError('يجب تحديد نهايات أرقام العمليات')
        return await self.repository.create_contest(**kwargs)

    async def create_roulette(self, **kwargs):
        mode = str(kwargs.get('participation_mode') or '')
        if mode not in {'free','deposit'}:
            raise CompetitionError('طريقة المشاركة غير صالحة')
        prizes = list(kwargs.get('prizes') or [])
        winners = int(kwargs.get('winners_count') or 0)
        if winners <= 0 or len(prizes) != winners:
            raise CompetitionError('عدد الجوائز يجب أن يطابق عدد الفائزين')
        for p in prizes:
            ptype = str(p.get('prize_type') or '')
            if ptype not in {'balance','deposit_bonus','custom'}:
                raise CompetitionError('نوع جائزة غير صالح')
            if ptype == 'custom' and not str(p.get('custom_text') or '').strip():
                raise CompetitionError('وصف الجائزة اليدوية مطلوب')
            if ptype != 'custom':
                pvalue=Decimal(str(p.get('prize_value') or 0))
                if pvalue <= 0 or (ptype == 'deposit_bonus' and pvalue > 100):
                    raise CompetitionError('قيمة الجائزة غير صالحة')
        return await self.repository.create_roulette(**kwargs)

    async def submit_prediction(self, contest_id: int, telegram_id: int, value1: int, value2: int) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                contest = await conn.fetchrow('SELECT * FROM bot_core.contests WHERE id=$1 FOR UPDATE', int(contest_id))
                if not contest or contest['template_type'] != 'match_prediction' or contest['status'] != 'active':
                    raise CompetitionError('المسابقة غير متاحة للتوقع الآن')
                if contest['end_at'] <= self._now():
                    raise CompetitionError('انتهى وقت استقبال التوقعات')
                banned = await conn.fetchval('SELECT is_blocked FROM bot_core.users WHERE telegram_id=$1', int(telegram_id))
                if banned:
                    raise CompetitionError('الحساب غير مؤهل للمشاركة')
                try:
                    await conn.execute(
                        """INSERT INTO bot_core.contest_entries(contest_id,telegram_id,entry_kind,value1,value2,dedupe_key,confirmed_at)
                           VALUES($1,$2,'prediction',$3,$4,$5,NOW())""",
                        int(contest_id), int(telegram_id), int(value1), int(value2), f'pred:{int(telegram_id)}')
                except asyncpg.UniqueViolationError as exc:
                    raise CompetitionError('تم تسجيل توقعك مسبقاً') from exc

    async def join_free_roulette(self, roulette_id: int, telegram_id: int) -> int:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                r = await conn.fetchrow('SELECT * FROM bot_core.roulettes WHERE id=$1 FOR UPDATE', int(roulette_id))
                if not r or r['status'] != 'active' or r['participation_mode'] != 'free' or r['end_at'] <= self._now():
                    raise CompetitionError('الروليت غير متاحة للمشاركة المجانية')
                if await conn.fetchval('SELECT is_blocked FROM bot_core.users WHERE telegram_id=$1', int(telegram_id)):
                    raise CompetitionError('الحساب غير مؤهل للمشاركة')
                if int(r['max_participants'] or 0) > 0:
                    users = int(await conn.fetchval('SELECT COUNT(DISTINCT telegram_id) FROM bot_core.roulette_entries WHERE roulette_id=$1', int(roulette_id)) or 0)
                    if users >= int(r['max_participants']):
                        raise CompetitionError('اكتمل عدد المشاركين')
                await conn.execute(
                    """INSERT INTO bot_core.roulette_entries(roulette_id,telegram_id,entry_kind,dedupe_key)
                       VALUES($1,$2,'free',$3) ON CONFLICT(roulette_id,dedupe_key) DO NOTHING""",
                    int(roulette_id), int(telegram_id), f'free:{int(telegram_id)}')
                return int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.roulette_entries WHERE roulette_id=$1 AND telegram_id=$2', int(roulette_id), int(telegram_id)) or 0)

    async def prepare_deposit_effect(self, conn: asyncpg.Connection, deposit: Any) -> None:
        """Persist a retryable snapshot without making deposit success depend on contests."""
        await conn.execute(
            """INSERT INTO bot_core.competition_deposit_effects(
                   deposit_id,telegram_id,provider_tx,base_amount_syp,settled_at,status)
               VALUES($1,$2,$3,$4,COALESCE($5,NOW()),'pending')
               ON CONFLICT(deposit_id) DO NOTHING""",
            deposit.id, int(deposit.telegram_id), deposit.provider_tx, int(deposit.base_credit_syp or 0), deposit.settled_at)

    async def settle_deposit_effect(self, conn: asyncpg.Connection, deposit_id: UUID) -> None:
        effect = await conn.fetchrow(
            "SELECT * FROM bot_core.competition_deposit_effects WHERE deposit_id=$1 FOR UPDATE", deposit_id)
        if not effect or effect['status'] == 'settled':
            return
        settled_at = effect['settled_at']
        contests = await conn.fetch(
            """SELECT * FROM bot_core.contests
               WHERE status IN ('active','ready_for_draw') AND start_at <= $1 AND end_at >= $1
                 AND template_type IN ('cash_luck','top_depositors','deposit_raffle')
                 AND NOT (template_type='cash_luck' AND status<>'active')
               ORDER BY id FOR UPDATE""", settled_at)
        for c in contests:
            tid = int(effect['telegram_id'])
            base = int(effect['base_amount_syp'])
            tx = str(effect['provider_tx'] or '')
            if c['template_type'] == 'top_depositors':
                await conn.execute(
                    """INSERT INTO bot_core.contest_entries(contest_id,telegram_id,entry_kind,provider_tx,deposit_id,dedupe_key,base_amount_syp,confirmed_at)
                       VALUES($1,$2,'top_deposit',$3,$4,$5,$6,NOW()) ON CONFLICT(contest_id,dedupe_key) DO NOTHING""",
                    c['id'], tid, tx or None, deposit_id, f'dep:{deposit_id}', base)
            elif c['template_type'] == 'deposit_raffle':
                key = f'user:{tid}' if c['raffle_entry_mode'] == 'user_once' else f'dep:{deposit_id}'
                await conn.execute(
                    """INSERT INTO bot_core.contest_entries(contest_id,telegram_id,entry_kind,provider_tx,deposit_id,dedupe_key,base_amount_syp,confirmed_at)
                       VALUES($1,$2,'deposit_raffle',$3,$4,$5,$6,NOW()) ON CONFLICT(contest_id,dedupe_key) DO NOTHING""",
                    c['id'], tid, tx or None, deposit_id, key, base)
            elif c['template_type'] == 'cash_luck' and tx:
                suffixes = self._json_list(c['suffixes'])
                if any(tx.endswith(str(s)) for s in suffixes):
                    entry = await conn.fetchrow(
                        """INSERT INTO bot_core.contest_entries(contest_id,telegram_id,entry_kind,provider_tx,deposit_id,dedupe_key,base_amount_syp,confirmed_at)
                           VALUES($1,$2,'cash_luck',$3,$4,$5,$6,NOW()) ON CONFLICT(contest_id,dedupe_key) DO UPDATE SET confirmed_at=bot_core.contest_entries.confirmed_at RETURNING *""",
                        c['id'], tid, tx, deposit_id, f'dep:{deposit_id}', base)
                    existing_user = await conn.fetchval('SELECT 1 FROM bot_core.contest_awards WHERE contest_id=$1 AND telegram_id=$2', c['id'], tid)
                    has_active_contest_promo = await conn.fetchval("SELECT 1 FROM bot_core.promo_rewards WHERE telegram_id=$1 AND source_type='contest' AND status='active' AND remaining_syp>0 AND expires_at>NOW() LIMIT 1", tid) if c['prize_type']=='balance' else None
                    awarded = int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.contest_awards WHERE contest_id=$1', c['id']) or 0)
                    if not existing_user and not has_active_contest_promo and awarded < int(c['winners_count']):
                        await self._award_contest(conn, c, entry, awarded + 1, 'auto', None)
                        if awarded + 1 >= int(c['winners_count']):
                            await conn.execute("UPDATE bot_core.contests SET status='completed',completed_at=NOW(),updated_at=NOW() WHERE id=$1", c['id'])

        roulettes = await conn.fetch(
            """SELECT * FROM bot_core.roulettes
               WHERE status IN ('active','ready_for_draw') AND participation_mode='deposit'
                 AND start_at <= $1 AND end_at >= $1 AND min_deposit_syp <= $2
               ORDER BY id FOR UPDATE""", settled_at, int(effect['base_amount_syp']))
        for r in roulettes:
            tid = int(effect['telegram_id'])
            max_chances = int(r['max_chances_per_user'] or 0)
            if max_chances and int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.roulette_entries WHERE roulette_id=$1 AND telegram_id=$2', r['id'], tid) or 0) >= max_chances:
                continue
            if int(r['max_participants'] or 0) > 0:
                users = int(await conn.fetchval('SELECT COUNT(DISTINCT telegram_id) FROM bot_core.roulette_entries WHERE roulette_id=$1', r['id']) or 0)
                exists = await conn.fetchval('SELECT 1 FROM bot_core.roulette_entries WHERE roulette_id=$1 AND telegram_id=$2', r['id'], tid)
                if not exists and users >= int(r['max_participants']):
                    continue
            await conn.execute(
                """INSERT INTO bot_core.roulette_entries(roulette_id,telegram_id,entry_kind,deposit_id,dedupe_key,base_amount_syp)
                   VALUES($1,$2,'deposit',$3,$4,$5) ON CONFLICT(roulette_id,dedupe_key) DO NOTHING""",
                r['id'], tid, deposit_id, f'dep:{deposit_id}', int(effect['base_amount_syp']))
        await conn.execute(
            "UPDATE bot_core.competition_deposit_effects SET status='settled',attempts=attempts+1,last_error=NULL,updated_at=NOW() WHERE deposit_id=$1", deposit_id)

    async def mark_deposit_effect_failed(self, conn: asyncpg.Connection, deposit_id: UUID, exc: Exception) -> None:
        await conn.execute(
            """UPDATE bot_core.competition_deposit_effects SET status='failed',attempts=attempts+1,last_error=$2,updated_at=NOW()
               WHERE deposit_id=$1""", deposit_id, f'{type(exc).__name__}: {exc}'[:700])

    async def _create_promo_reward(self, conn: asyncpg.Connection, *, telegram_id: int, source_type: str,
                                   source_ref: str, amount_syp: int) -> int:
        row = await conn.fetchrow(
            """INSERT INTO bot_core.promo_rewards(telegram_id,source_type,source_ref,amount_syp,remaining_syp,expires_at)
               VALUES($1,$2,$3,$4,$4,NOW()+INTERVAL '24 hours')
               ON CONFLICT(telegram_id,source_type,source_ref) DO UPDATE SET source_ref=EXCLUDED.source_ref
               RETURNING id""", int(telegram_id), source_type, source_ref, int(amount_syp))
        return int(row['id'])

    async def _award_contest(self, conn: asyncpg.Connection, contest: Any, entry: Any, position: int,
                             mode: str, actor: int | None) -> Any:
        award = await conn.fetchrow(
            """INSERT INTO bot_core.contest_awards(contest_id,entry_id,telegram_id,position,prize_type,prize_value,selected_mode,selected_by)
               VALUES($1,$2,$3,$4,$5,$6,$7,$8)
               ON CONFLICT(contest_id,position) DO UPDATE SET position=bot_core.contest_awards.position RETURNING *""",
            contest['id'], entry['id'], entry['telegram_id'], int(position), contest['prize_type'], contest['prize_value'], mode, actor)
        if str(contest['prize_type']) == 'balance':
            rid = await self._create_promo_reward(conn, telegram_id=int(award['telegram_id']), source_type='contest',
                                                  source_ref=f"contest:{contest['id']}:award:{award['id']}", amount_syp=int(Decimal(str(contest['prize_value']))))
            await conn.execute('UPDATE bot_core.contest_awards SET promo_reward_id=$2 WHERE id=$1 AND promo_reward_id IS NULL', award['id'], rid)
        else:
            bonus = await conn.fetchrow(
                """INSERT INTO bot_core.contest_bonus_rewards(contest_id,award_id,telegram_id,pct,expires_at)
                   VALUES($1,$2,$3,$4,NOW()+INTERVAL '24 hours') ON CONFLICT(award_id) DO UPDATE SET award_id=EXCLUDED.award_id RETURNING id""",
                contest['id'], award['id'], award['telegram_id'], contest['prize_value'])
            await conn.execute('UPDATE bot_core.contest_awards SET bonus_reward_id=$2 WHERE id=$1 AND bonus_reward_id IS NULL', award['id'], bonus['id'])
        return await conn.fetchrow('SELECT * FROM bot_core.contest_awards WHERE id=$1', award['id'])

    async def _award_roulette(self, conn: asyncpg.Connection, roulette: Any, prize: Any, entry: Any,
                              position: int, mode: str, actor: int | None) -> Any:
        ptype = str(prize['prize_type'])
        fulfillment = 'pending' if ptype == 'custom' else 'completed'
        award = await conn.fetchrow(
            """INSERT INTO bot_core.roulette_awards(roulette_id,position,entry_id,telegram_id,prize_type,prize_value,custom_text,fulfillment_status,selected_mode,awarded_by)
               VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
               ON CONFLICT(roulette_id,position) DO UPDATE SET position=bot_core.roulette_awards.position RETURNING *""",
            roulette['id'], int(position), entry['id'], entry['telegram_id'], ptype, prize['prize_value'], prize['custom_text'], fulfillment, mode, actor)
        if ptype == 'balance':
            rid = await self._create_promo_reward(conn, telegram_id=int(award['telegram_id']), source_type='roulette',
                                                  source_ref=f"roulette:{roulette['id']}:award:{award['id']}", amount_syp=int(Decimal(str(prize['prize_value']))))
            await conn.execute('UPDATE bot_core.roulette_awards SET promo_reward_id=$2 WHERE id=$1 AND promo_reward_id IS NULL', award['id'], rid)
        elif ptype == 'deposit_bonus':
            bonus = await conn.fetchrow(
                """INSERT INTO bot_core.roulette_bonus_rewards(roulette_id,award_id,telegram_id,pct,expires_at)
                   VALUES($1,$2,$3,$4,NOW()+INTERVAL '24 hours') ON CONFLICT(award_id) DO UPDATE SET award_id=EXCLUDED.award_id RETURNING id""",
                roulette['id'], award['id'], award['telegram_id'], prize['prize_value'])
            await conn.execute('UPDATE bot_core.roulette_awards SET bonus_reward_id=$2 WHERE id=$1 AND bonus_reward_id IS NULL', award['id'], bonus['id'])
        return await conn.fetchrow('SELECT * FROM bot_core.roulette_awards WHERE id=$1', award['id'])

    async def delete_contest_permanently(self, contest_id: int, actor: int) -> dict[str, Any]:
        """Delete an unpaid contest and its entries only after an explicit UI confirmation."""
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                c=await conn.fetchrow('SELECT * FROM bot_core.contests WHERE id=$1 FOR UPDATE',int(contest_id))
                if not c:
                    raise CompetitionError('المسابقة غير موجودة')
                if await conn.fetchval('SELECT 1 FROM bot_core.contest_awards WHERE contest_id=$1 LIMIT 1',c['id']):
                    raise CompetitionError('لا يمكن حذف مسابقة تم اعتماد أو صرف جائزة فيها')
                count=int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.contest_entries WHERE contest_id=$1',c['id']) or 0)
                snapshot=dict(c)
                await conn.execute('DELETE FROM bot_core.contests WHERE id=$1',c['id'])
                return {'contest_id':int(c['id']),'entry_count':count,'channel_chat_ref':snapshot.get('channel_chat_ref'),'channel_message_id':snapshot.get('channel_message_id'),'deleted_by':int(actor)}

    async def set_match_result_and_draw(self, contest_id: int, value1: int, value2: int, actor: int) -> list[Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                c = await conn.fetchrow('SELECT * FROM bot_core.contests WHERE id=$1 FOR UPDATE', int(contest_id))
                if not c or c['template_type'] != 'match_prediction':
                    raise CompetitionError('المسابقة ليست بانتظار نتيجة')
                if c['status'] == 'active' and c['end_at'] > self._now():
                    raise CompetitionError('لم ينته وقت استقبال التوقعات بعد')
                if c['status'] not in {'active','waiting_result'}:
                    raise CompetitionError('المسابقة ليست بانتظار نتيجة')
                await conn.execute("UPDATE bot_core.contests SET status='ready_for_draw',result_value1=$2,result_value2=$3,result_set_by=$4,result_set_at=NOW(),snapshot_at=COALESCE(snapshot_at,NOW()),updated_at=NOW() WHERE id=$1", c['id'], int(value1), int(value2), int(actor))
                return await self._draw_contest_locked(conn, c['id'], actor)

    async def draw_contest(self, contest_id: int, actor: int | None) -> list[Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                return await self._draw_contest_locked(conn, int(contest_id), actor)

    async def _draw_contest_locked(self, conn: asyncpg.Connection, contest_id: int, actor: int | None) -> list[Any]:
        c = await conn.fetchrow('SELECT * FROM bot_core.contests WHERE id=$1 FOR UPDATE', int(contest_id))
        if not c or c['status'] == 'completed':
            return await conn.fetch('SELECT * FROM bot_core.contest_awards WHERE contest_id=$1 ORDER BY position', int(contest_id)) if c else []
        if c['status'] == 'cancelled':
            raise CompetitionError('المسابقة ملغاة')
        template = str(c['template_type'])
        if template != 'cash_luck' and c['status'] != 'ready_for_draw':
            raise CompetitionError('المسابقة ليست جاهزة للسحب بعد')
        if template == 'cash_luck':
            return await conn.fetch('SELECT * FROM bot_core.contest_awards WHERE contest_id=$1 ORDER BY position', int(contest_id))
        if template == 'match_prediction':
            if c['result_value1'] is None or c['result_value2'] is None:
                raise CompetitionError('يجب إدخال النتيجة أولاً')
            entries = list(await conn.fetch(
                """SELECT e.* FROM bot_core.contest_entries e JOIN bot_core.users u ON u.telegram_id=e.telegram_id
                   WHERE e.contest_id=$1 AND e.eligible AND NOT u.is_blocked AND e.value1=$2 AND e.value2=$3""",
                c['id'], c['result_value1'], c['result_value2']))
            secrets.SystemRandom().shuffle(entries)
            selected = entries[:int(c['winners_count'])]
        elif template == 'top_depositors':
            entries = list(await conn.fetch(
                """SELECT MIN(e.id) AS id,e.contest_id,e.telegram_id,'top_deposit'::text AS entry_kind,
                          NULL::integer value1,NULL::integer value2,NULL::text provider_tx,NULL::uuid deposit_id,
                          ('rank:'||e.telegram_id)::text dedupe_key,SUM(e.base_amount_syp)::bigint base_amount_syp,
                          TRUE eligible,1 weight,MIN(e.created_at) created_at,MIN(e.confirmed_at) confirmed_at
                   FROM bot_core.contest_entries e JOIN bot_core.users u ON u.telegram_id=e.telegram_id
                   WHERE e.contest_id=$1 AND e.entry_kind='top_deposit' AND e.eligible AND NOT u.is_blocked
                   GROUP BY e.contest_id,e.telegram_id ORDER BY SUM(e.base_amount_syp) DESC,e.telegram_id LIMIT $2""",
                c['id'], int(c['winners_count'])))
            # awards FK requires a real entry id; MIN(id) above provides one.
            selected = entries
        else:
            raw = list(await conn.fetch(
                """SELECT e.* FROM bot_core.contest_entries e JOIN bot_core.users u ON u.telegram_id=e.telegram_id
                   WHERE e.contest_id=$1 AND e.entry_kind='deposit_raffle' AND e.eligible AND NOT u.is_blocked ORDER BY e.id""", c['id']))
            selected = self._weighted_unique(raw, int(c['winners_count']))
        existing = {int(x['telegram_id']) for x in await conn.fetch('SELECT telegram_id FROM bot_core.contest_awards WHERE contest_id=$1', c['id'])}
        awards=[]
        pos = int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.contest_awards WHERE contest_id=$1', c['id']) or 0)
        for entry in selected:
            if int(entry['telegram_id']) in existing or pos >= int(c['winners_count']):
                continue
            pos += 1
            awards.append(await self._award_contest(conn, c, entry, pos, 'auto', actor))
            existing.add(int(entry['telegram_id']))
        final_count = int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.contest_awards WHERE contest_id=$1', c['id']) or 0)
        if final_count >= int(c['winners_count']):
            await conn.execute("UPDATE bot_core.contests SET status='completed',snapshot_at=COALESCE(snapshot_at,NOW()),draw_at=NOW(),draw_by=$2,completed_at=NOW(),updated_at=NOW() WHERE id=$1", c['id'], actor)
        else:
            await conn.execute("UPDATE bot_core.contests SET status='ready_for_draw',snapshot_at=COALESCE(snapshot_at,NOW()),draw_at=COALESCE(draw_at,NOW()),draw_by=COALESCE(draw_by,$2),updated_at=NOW() WHERE id=$1", c['id'], actor)
        return awards

    @staticmethod
    def _weighted_unique(entries: list[Any], count: int) -> list[Any]:
        by_user: dict[int,list[Any]] = {}
        for e in entries:
            by_user.setdefault(int(e['telegram_id']), []).append(e)
        rng = secrets.SystemRandom()
        chosen=[]
        while by_user and len(chosen) < count:
            users=list(by_user)
            weights=[len(by_user[u]) for u in users]
            u=rng.choices(users,weights=weights,k=1)[0]
            chosen.append(rng.choice(by_user.pop(u)))
        return chosen


    async def force_roulette_ready(self, roulette_id: int, actor: int) -> Any:
        """Close participation early without dropping an already-successful deposit chance."""
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                r=await conn.fetchrow('SELECT * FROM bot_core.roulettes WHERE id=$1 FOR UPDATE',int(roulette_id))
                if not r:
                    raise CompetitionError('الروليت غير موجودة')
                if r['status']=='cancelled':
                    raise CompetitionError('الروليت ملغاة')
                if r['status'] in {'ready_for_draw','completed'}:
                    return r
                if r['status']!='active':
                    raise CompetitionError('لا يمكن إغلاق الروليت في حالتها الحالية')
                if r['participation_mode']=='deposit':
                    unresolved=await conn.fetchval(
                        """SELECT 1 FROM bot_core.competition_deposit_effects e
                           WHERE e.status IN ('pending','failed')
                             AND e.settled_at BETWEEN $1 AND NOW()
                             AND e.base_amount_syp >= $2
                           LIMIT 1""",
                        r['start_at'],int(r['min_deposit_syp']))
                    if unresolved:
                        raise CompetitionError('توجد عمليات شحن قيد تسوية فرصها. حاول الإغلاق بعد قليل.')
                await conn.execute(
                    "UPDATE bot_core.roulettes SET status='ready_for_draw',end_at=LEAST(end_at,NOW()),snapshot_at=COALESCE(snapshot_at,NOW()),draw_by=COALESCE(draw_by,$2),updated_at=NOW() WHERE id=$1 AND status='active'",
                    r['id'],int(actor))
                return await conn.fetchrow('SELECT * FROM bot_core.roulettes WHERE id=$1',r['id'])

    async def draw_roulette(self, roulette_id: int, actor: int | None = None) -> list[Any]:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                r=await conn.fetchrow('SELECT * FROM bot_core.roulettes WHERE id=$1 FOR UPDATE',int(roulette_id))
                if not r: raise CompetitionError('الروليت غير موجودة')
                if r['status']=='completed':
                    return await conn.fetch('SELECT * FROM bot_core.roulette_awards WHERE roulette_id=$1 ORDER BY position',r['id'])
                if r['status']=='cancelled': raise CompetitionError('الروليت ملغاة')
                if r['status']!='ready_for_draw': raise CompetitionError('الروليت ليست جاهزة للسحب بعد')
                entries=list(await conn.fetch(
                    """SELECT e.* FROM bot_core.roulette_entries e JOIN bot_core.users u ON u.telegram_id=e.telegram_id
                       WHERE e.roulette_id=$1 AND NOT u.is_blocked
                         AND NOT EXISTS (SELECT 1 FROM bot_core.promo_rewards p WHERE p.telegram_id=e.telegram_id AND p.source_type='roulette' AND p.status='active' AND p.remaining_syp>0 AND p.expires_at>NOW())
                       ORDER BY e.id""",r['id']))
                existing_users={int(x['telegram_id']) for x in await conn.fetch('SELECT telegram_id FROM bot_core.roulette_awards WHERE roulette_id=$1',r['id'])}
                entries=[e for e in entries if int(e['telegram_id']) not in existing_users]
                already=int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.roulette_awards WHERE roulette_id=$1',r['id']) or 0)
                selected=self._weighted_unique(entries,max(0,int(r['winners_count'])-already))
                prizes=await conn.fetch('SELECT * FROM bot_core.roulette_prizes WHERE roulette_id=$1 ORDER BY position',r['id'])
                awards=[]
                for offset,entry in enumerate(selected,start=already):
                    pos=offset+1; prize=prizes[pos-1]
                    awards.append(await self._award_roulette(conn,r,prize,entry,pos,'auto',actor))
                final_count=int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.roulette_awards WHERE roulette_id=$1',r['id']) or 0)
                if final_count>=int(r['winners_count']):
                    await conn.execute("UPDATE bot_core.roulettes SET status='completed',snapshot_at=COALESCE(snapshot_at,NOW()),draw_at=NOW(),draw_by=$2,completed_at=NOW(),updated_at=NOW() WHERE id=$1",r['id'],actor)
                else:
                    await conn.execute("UPDATE bot_core.roulettes SET status='ready_for_draw',snapshot_at=COALESCE(snapshot_at,NOW()),draw_at=COALESCE(draw_at,NOW()),draw_by=COALESCE(draw_by,$2),updated_at=NOW() WHERE id=$1",r['id'],actor)
                return awards

    async def manual_contest_winner(self, contest_id: int, telegram_id: int, actor: int) -> Any:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                c=await conn.fetchrow('SELECT * FROM bot_core.contests WHERE id=$1 FOR UPDATE',int(contest_id))
                if not c or c['status'] != 'ready_for_draw': raise CompetitionError('المسابقة ليست بمرحلة اختيار الفائزين')
                if await conn.fetchval('SELECT is_blocked FROM bot_core.users WHERE telegram_id=$1',int(telegram_id)): raise CompetitionError('المستخدم محظور')
                if await conn.fetchval('SELECT 1 FROM bot_core.contest_awards WHERE contest_id=$1 AND telegram_id=$2',c['id'],int(telegram_id)): raise CompetitionError('المستخدم فائز مسبقًا')
                entry=await conn.fetchrow('SELECT * FROM bot_core.contest_entries WHERE contest_id=$1 AND telegram_id=$2 AND eligible ORDER BY id LIMIT 1',c['id'],int(telegram_id))
                if not entry: raise CompetitionError('المستخدم ليس مشاركًا مؤهلًا في المسابقة')
                pos=int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.contest_awards WHERE contest_id=$1',c['id']) or 0)+1
                if pos>int(c['winners_count']): raise CompetitionError('اكتمل عدد الفائزين')
                award=await self._award_contest(conn,c,entry,pos,'manual',actor)
                if pos>=int(c['winners_count']): await conn.execute("UPDATE bot_core.contests SET status='completed',completed_at=NOW(),updated_at=NOW() WHERE id=$1",c['id'])
                return award

    async def manual_roulette_winner(self, roulette_id: int, telegram_id: int, actor: int) -> Any:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                r=await conn.fetchrow('SELECT * FROM bot_core.roulettes WHERE id=$1 FOR UPDATE',int(roulette_id))
                if not r or r['status']!='ready_for_draw': raise CompetitionError('الروليت ليست بمرحلة اختيار الفائزين')
                if await conn.fetchval('SELECT is_blocked FROM bot_core.users WHERE telegram_id=$1',int(telegram_id)): raise CompetitionError('المستخدم محظور')
                if await conn.fetchval('SELECT 1 FROM bot_core.roulette_awards WHERE roulette_id=$1 AND telegram_id=$2',r['id'],int(telegram_id)): raise CompetitionError('المستخدم فائز مسبقًا')
                entry=await conn.fetchrow('SELECT * FROM bot_core.roulette_entries WHERE roulette_id=$1 AND telegram_id=$2 ORDER BY id LIMIT 1',r['id'],int(telegram_id))
                if not entry: raise CompetitionError('المستخدم ليس مشاركًا في الروليت')
                pos=int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.roulette_awards WHERE roulette_id=$1',r['id']) or 0)+1
                if pos>int(r['winners_count']): raise CompetitionError('اكتمل عدد الفائزين')
                prize=await conn.fetchrow('SELECT * FROM bot_core.roulette_prizes WHERE roulette_id=$1 AND position=$2',r['id'],pos)
                award=await self._award_roulette(conn,r,prize,entry,pos,'manual',actor)
                if pos>=int(r['winners_count']): await conn.execute("UPDATE bot_core.roulettes SET status='completed',completed_at=NOW(),updated_at=NOW() WHERE id=$1",r['id'])
                return award

    async def fulfill_custom_roulette_prize(self, award_id: int, actor: int) -> None:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row=await conn.fetchrow('SELECT * FROM bot_core.roulette_awards WHERE id=$1 FOR UPDATE',int(award_id))
                if not row or row['prize_type']!='custom': raise CompetitionError('الجائزة اليدوية غير موجودة')
                await conn.execute("UPDATE bot_core.roulette_awards SET fulfillment_status='completed',awarded_by=COALESCE(awarded_by,$2) WHERE id=$1",int(award_id),int(actor))

    async def active_promo_summary(self, telegram_id: int) -> dict[str,int]:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self.expire_promos(conn, telegram_id)
                rows=await conn.fetch("SELECT * FROM bot_core.promo_rewards WHERE telegram_id=$1 AND status='active' AND remaining_syp>0 AND expires_at>NOW() ORDER BY created_at,id",int(telegram_id))
                amounts=[int(r['remaining_syp']) for r in rows]
                return {'count':len(rows),'max_single':max(amounts,default=0),'total':sum(amounts)}

    async def expire_promos(self, conn: asyncpg.Connection, telegram_id: int | None = None) -> None:
        if telegram_id is None:
            await conn.execute("UPDATE bot_core.promo_rewards SET status='expired' WHERE status='active' AND expires_at<=NOW()")
            await conn.execute("UPDATE bot_core.contest_bonus_rewards SET status='expired' WHERE status='active' AND expires_at<=NOW()")
            await conn.execute("UPDATE bot_core.roulette_bonus_rewards SET status='expired' WHERE status='active' AND expires_at<=NOW()")
        else:
            await conn.execute("UPDATE bot_core.promo_rewards SET status='expired' WHERE telegram_id=$1 AND status='active' AND expires_at<=NOW()",int(telegram_id))

    async def select_promo_for_spend(self, conn: asyncpg.Connection, telegram_id: int, total_amount: int, wallet_available: int):
        await self.expire_promos(conn, telegram_id)
        rows=list(await conn.fetch("SELECT * FROM bot_core.promo_rewards WHERE telegram_id=$1 AND status='active' AND remaining_syp>0 AND expires_at>NOW() ORDER BY created_at,id FOR UPDATE",int(telegram_id)))
        if not rows: return None
        needed=max(0,int(total_amount)-int(wallet_available))
        if needed>0:
            for r in rows:
                if int(r['remaining_syp'])>=needed: return r
            return None
        return rows[0]

    async def reserve_promo_spend(self, conn: asyncpg.Connection, reward_id: int, telegram_id: int, job_id: UUID, amount: int) -> None:
        row=await conn.fetchrow('SELECT * FROM bot_core.promo_rewards WHERE id=$1 FOR UPDATE',int(reward_id))
        if not row or row['status']!='active' or row['expires_at']<=self._now() or int(row['remaining_syp'])<int(amount):
            raise CompetitionError('الجائزة الترويجية لم تعد متاحة')
        await conn.execute("UPDATE bot_core.promo_rewards SET remaining_syp=remaining_syp-$2,status=CASE WHEN remaining_syp-$2=0 THEN 'used' ELSE status END,used_at=CASE WHEN remaining_syp-$2=0 THEN NOW() ELSE used_at END WHERE id=$1",int(reward_id),int(amount))
        await conn.execute("INSERT INTO bot_core.promo_reward_spends(reward_id,telegram_id,amount_syp,ichancy_job_id,status) VALUES($1,$2,$3,$4,'reserved')",int(reward_id),int(telegram_id),int(amount),job_id)

    async def release_promo_spend(self, conn: asyncpg.Connection, job_id: UUID) -> None:
        spend=await conn.fetchrow("SELECT * FROM bot_core.promo_reward_spends WHERE ichancy_job_id=$1 FOR UPDATE",job_id)
        if not spend or spend['status']!='reserved': return
        await conn.execute("UPDATE bot_core.promo_rewards SET remaining_syp=LEAST(amount_syp,remaining_syp+$2),status='active',used_at=NULL WHERE id=$1",spend['reward_id'],int(spend['amount_syp']))
        await conn.execute("UPDATE bot_core.promo_reward_spends SET status='released',closed_at=NOW() WHERE id=$1",spend['id'])

    async def consume_promo_spend(self, conn: asyncpg.Connection, job_id: UUID) -> None:
        await conn.execute("UPDATE bot_core.promo_reward_spends SET status='consumed',closed_at=NOW() WHERE ichancy_job_id=$1 AND status='reserved'",job_id)

    @staticmethod
    def channel_ref(raw: str | None):
        value=str(raw or '').strip()
        if not value: return None
        if re.fullmatch(r'-?\d+',value): return int(value)
        if value.lower().startswith(('t.me/','www.t.me/','telegram.me/','www.telegram.me/')): value='https://'+value
        if value.startswith(('https://','http://')):
            parsed=urlparse(value); path=parsed.path.strip('/')
            if (parsed.hostname or '').lower() not in {'t.me','www.t.me','telegram.me','www.telegram.me'} or not path or path.startswith('+') or path.lower().startswith('joinchat/'):
                return None
            value=path.split('/',1)[0]
        user=value.lstrip('@').strip()
        return f'@{user}' if re.fullmatch(r'[A-Za-z0-9_]{1,64}',user or '') else None

    async def publish_contest(self, bot: Bot, contest_id: int, channel_raw: str | None) -> bool:
        chat=self.channel_ref(channel_raw)
        if chat is None: return False
        c=await self.repository.get_contest(contest_id)
        if not c: return False
        me=await bot.get_me(); link=f"https://t.me/{me.username}?start=contest_{int(contest_id)}" if me.username else None
        text=f"🏆 <b>مسابقة جديدة #{int(contest_id)}</b>\n\n🎁 الجائزة: <code>{c['prize_value']}</code>\n👥 الفائزون: <code>{int(c['winners_count'])}</code>\n⏳ النهاية: <code>{c['end_at']}</code>"
        markup=None
        if link:
            from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
            markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='شارك الآن 🚀',url=link)]])
        if c['media_type']=='photo' and c['media_file_id']:
            msg=await bot.send_photo(chat,c['media_file_id'],caption=text,reply_markup=markup)
        elif c['media_type']=='animation' and c['media_file_id']:
            msg=await bot.send_animation(chat,c['media_file_id'],caption=text,reply_markup=markup)
        elif c['media_type']=='video' and c['media_file_id']:
            msg=await bot.send_video(chat,c['media_file_id'],caption=text,reply_markup=markup)
        else:
            msg=await bot.send_message(chat,text,reply_markup=markup)
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute('UPDATE bot_core.contests SET channel_chat_ref=$2,channel_message_id=$3,last_channel_sync_at=NOW() WHERE id=$1',int(contest_id),str(chat),int(msg.message_id))
        return True

    async def publish_roulette(self, bot: Bot, roulette_id: int, channel_raw: str | None) -> bool:
        chat=self.channel_ref(channel_raw)
        if chat is None: return False
        r=await self.repository.get_roulette(roulette_id)
        if not r: return False
        me=await bot.get_me(); link=f"https://t.me/{me.username}?start=roulette_{int(roulette_id)}" if me.username else None
        mode='مجانية' if r['participation_mode']=='free' else f"شحن لا يقل عن {int(r['min_deposit_syp']):,} SYP لكل فرصة"
        text=f"🎲 <b>روليت جديدة #{int(roulette_id)}</b>\n\n🎟 المشاركة: {mode}\n🏆 عدد الفائزين: <code>{int(r['winners_count'])}</code>\n⏳ النهاية: <code>{r['end_at']}</code>"
        markup=None
        if link:
            from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
            markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='شارك الآن 🚀',url=link)]])
        if r['media_type']=='photo' and r['media_file_id']:
            msg=await bot.send_photo(chat,r['media_file_id'],caption=text,reply_markup=markup)
        elif r['media_type']=='animation' and r['media_file_id']:
            msg=await bot.send_animation(chat,r['media_file_id'],caption=text,reply_markup=markup)
        elif r['media_type']=='video' and r['media_file_id']:
            msg=await bot.send_video(chat,r['media_file_id'],caption=text,reply_markup=markup)
        else:
            msg=await bot.send_message(chat,text,reply_markup=markup)
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute('UPDATE bot_core.roulettes SET channel_chat_ref=$2,channel_message_id=$3,last_channel_sync_at=NOW() WHERE id=$1',int(roulette_id),str(chat),int(msg.message_id))
        return True

    async def retry_pending_deposit_effects(self, limit: int = 25) -> int:
        pool=self.db.require_pool(); done=0
        async with pool.acquire() as conn:
            rows=await conn.fetch("SELECT deposit_id FROM bot_core.competition_deposit_effects WHERE status IN ('pending','failed') ORDER BY updated_at LIMIT $1",max(1,min(100,int(limit))))
        for row in rows:
            try:
                async with pool.acquire() as conn:
                    async with conn.transaction(): await self.settle_deposit_effect(conn,row['deposit_id'])
                done+=1
            except Exception as exc:
                async with pool.acquire() as conn:
                    async with conn.transaction(): await self.mark_deposit_effect_failed(conn,row['deposit_id'],exc)
        return done

    async def maintenance_tick(self) -> None:
        # Reconcile deposit side-effects *before* closing event windows. A deposit
        # that was already successful inside the window must not lose its entry
        # merely because its contest side-effect needed a retry near end_at.
        await self.retry_pending_deposit_effects()
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self.expire_promos(conn)
                await conn.execute("""
                    UPDATE bot_core.contests c
                    SET status=CASE WHEN template_type='match_prediction' THEN 'waiting_result'
                                    WHEN template_type='cash_luck' THEN 'completed'
                                    ELSE 'ready_for_draw' END,
                        snapshot_at=COALESCE(snapshot_at,NOW()),
                        completed_at=CASE WHEN template_type='cash_luck' THEN NOW() ELSE completed_at END,
                        updated_at=NOW()
                    WHERE c.status='active' AND c.end_at<=NOW()
                      AND (c.template_type='match_prediction' OR NOT EXISTS (
                          SELECT 1 FROM bot_core.competition_deposit_effects e
                          WHERE e.status IN ('pending','failed')
                            AND e.settled_at BETWEEN c.start_at AND c.end_at
                      ))
                """)
                await conn.execute("""
                    UPDATE bot_core.roulettes r
                    SET status='ready_for_draw',snapshot_at=COALESCE(snapshot_at,NOW()),updated_at=NOW()
                    WHERE r.status='active' AND r.end_at<=NOW()
                      AND (r.participation_mode='free' OR NOT EXISTS (
                          SELECT 1 FROM bot_core.competition_deposit_effects e
                          WHERE e.status IN ('pending','failed')
                            AND e.settled_at BETWEEN r.start_at AND r.end_at
                            AND e.base_amount_syp >= r.min_deposit_syp
                      ))
                """)
        # auto draw is intentionally outside the transition transaction.
        async with pool.acquire() as conn:
            ids=await conn.fetch("SELECT id FROM bot_core.roulettes WHERE status='ready_for_draw' AND auto_draw ORDER BY id LIMIT 10")
        for row in ids:
            try: await self.draw_roulette(int(row['id']),None)
            except Exception: logger.exception('Auto roulette draw failed roulette=%s',row['id'])


class CompetitionMaintenanceWorker:
    def __init__(self, service: CompetitionService, bot: Bot | None = None, admin_ids: set[int] | frozenset[int] = frozenset(), channel_raw: str | None = None) -> None:
        self.service=service; self.bot=bot; self.admin_ids=frozenset(int(x) for x in admin_ids); self.channel_raw=channel_raw; self._stop=asyncio.Event()
    def stop(self): self._stop.set()

    async def _notify(self):
        if self.bot is None: return
        pool=self.service.db.require_pool()
        # Initial channel publication is durable: a temporary Telegram failure during
        # creation is retried while the event still has no channel_message_id.
        if self.channel_raw:
            async with pool.acquire() as conn:
                pending_c=await conn.fetch("SELECT id FROM bot_core.contests WHERE publish_to_channel AND channel_message_id IS NULL AND status<>'cancelled' ORDER BY id LIMIT 5")
                pending_r=await conn.fetch("SELECT id FROM bot_core.roulettes WHERE channel_message_id IS NULL AND status<>'cancelled' ORDER BY id LIMIT 5")
            for row in pending_c:
                try: await self.service.publish_contest(self.bot,int(row['id']),self.channel_raw)
                except Exception: logger.exception('Contest channel publish retry failed contest=%s',row['id'])
            for row in pending_r:
                try: await self.service.publish_roulette(self.bot,int(row['id']),self.channel_raw)
                except Exception: logger.exception('Roulette channel publish retry failed roulette=%s',row['id'])
        # User notifications are idempotent through notified_at. A Telegram network
        # ambiguity is intentionally not retried in the same tick; a later tick may retry.
        async with pool.acquire() as conn:
            contest_rows=await conn.fetch("SELECT * FROM bot_core.contest_awards WHERE notified_at IS NULL ORDER BY id LIMIT 25")
            roulette_rows=await conn.fetch("SELECT * FROM bot_core.roulette_awards WHERE notified_at IS NULL ORDER BY id LIMIT 25")
        for a in contest_rows:
            try:
                kind='رصيد ترويجي صالح 24 ساعة لشحن iChancy' if a['prize_type']=='balance' else 'بونص على أول شحن ناجح خلال 24 ساعة'
                await self.bot.send_message(int(a['telegram_id']),f"🏆 <b>مبروك! ربحت بالمسابقة</b>\n\n🥇 المركز: <code>{int(a['position'])}</code>\n🎁 {kind}: <code>{a['prize_value']}</code>")
                async with pool.acquire() as conn: await conn.execute('UPDATE bot_core.contest_awards SET notified_at=NOW() WHERE id=$1 AND notified_at IS NULL',a['id'])
            except Exception: pass
        for a in roulette_rows:
            try:
                if a['prize_type']=='custom': prize=f"جائزة: {a['custom_text']}"
                elif a['prize_type']=='balance': prize=f"رصيد ترويجي iChancy لمدة 24 ساعة: {a['prize_value']}"
                else: prize=f"بونص أول شحن خلال 24 ساعة: {a['prize_value']}%"
                await self.bot.send_message(int(a['telegram_id']),f"🎲 <b>مبروك! ربحت بالروليت</b>\n\n🥇 المركز: <code>{int(a['position'])}</code>\n🎁 {prize}")
                async with pool.acquire() as conn: await conn.execute('UPDATE bot_core.roulette_awards SET notified_at=NOW() WHERE id=$1 AND notified_at IS NULL',a['id'])
            except Exception: pass
        # Notify admins once for manual-ready events.
        async with pool.acquire() as conn:
            ready_c=await conn.fetch("SELECT id,template_type FROM bot_core.contests WHERE status IN ('waiting_result','ready_for_draw') AND admin_notified_at IS NULL ORDER BY id LIMIT 10")
            ready_r=await conn.fetch("SELECT id FROM bot_core.roulettes WHERE status='ready_for_draw' AND NOT auto_draw AND admin_notified_at IS NULL ORDER BY id LIMIT 10")
        for row in ready_c:
            ok=False
            for admin in self.admin_ids:
                try: await self.bot.send_message(admin,f"🏆 المسابقة #{int(row['id'])} أصبحت جاهزة للمتابعة من لوحة الإدارة."); ok=True
                except Exception: pass
            if ok:
                async with pool.acquire() as conn: await conn.execute('UPDATE bot_core.contests SET admin_notified_at=NOW() WHERE id=$1 AND admin_notified_at IS NULL',row['id'])
        for row in ready_r:
            ok=False
            for admin in self.admin_ids:
                try: await self.bot.send_message(admin,f"🎲 الروليت #{int(row['id'])} جاهزة للسحب اليدوي."); ok=True
                except Exception: pass
            if ok:
                async with pool.acquire() as conn: await conn.execute('UPDATE bot_core.roulettes SET admin_notified_at=NOW() WHERE id=$1 AND admin_notified_at IS NULL',row['id'])
        # Publish result once to the same channel used by the original post.
        async with pool.acquire() as conn:
            done_c=await conn.fetch("SELECT id,channel_chat_ref FROM bot_core.contests WHERE status='completed' AND channel_chat_ref IS NOT NULL AND result_message_id IS NULL ORDER BY id LIMIT 10")
            done_r=await conn.fetch("SELECT id,channel_chat_ref FROM bot_core.roulettes WHERE status='completed' AND channel_chat_ref IS NOT NULL AND result_message_id IS NULL ORDER BY id LIMIT 10")
        for row in done_c:
            try:
                awards=await self.service.repository.contest_awards(int(row['id'])); winners=', '.join(str(int(x['telegram_id'])) for x in awards) or 'لا يوجد فائزون'
                msg=await self.bot.send_message(row['channel_chat_ref'],f"🏆 <b>نتيجة المسابقة #{int(row['id'])}</b>\n\nالفائزون: <code>{winners}</code>")
                async with pool.acquire() as conn: await conn.execute('UPDATE bot_core.contests SET result_message_id=$2,last_channel_sync_at=NOW() WHERE id=$1 AND result_message_id IS NULL',row['id'],msg.message_id)
            except Exception: pass
        for row in done_r:
            try:
                awards=await self.service.repository.roulette_awards(int(row['id'])); winners=', '.join(str(int(x['telegram_id'])) for x in awards) or 'لا يوجد فائزون'; me=await self.bot.get_me(); link=f"https://t.me/{me.username}?start=roulette_result_{int(row['id'])}" if me.username else None
                markup=None
                if link:
                    from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup
                    markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='عرض النتيجة',url=link)]])
                msg=await self.bot.send_message(row['channel_chat_ref'],f"🎲 <b>نتيجة الروليت #{int(row['id'])}</b>\n\nالفائزون: <code>{winners}</code>",reply_markup=markup)
                async with pool.acquire() as conn: await conn.execute('UPDATE bot_core.roulettes SET result_message_id=$2,last_channel_sync_at=NOW() WHERE id=$1 AND result_message_id IS NULL',row['id'],msg.message_id)
            except Exception: pass

    async def run(self,poll_seconds:float=2.0):
        while not self._stop.is_set():
            try:
                await self.service.maintenance_tick()
                await self._notify()
            except asyncio.CancelledError: raise
            except Exception: logger.exception('Competition maintenance failed')
            try: await asyncio.wait_for(self._stop.wait(),timeout=max(0.5,float(poll_seconds)))
            except asyncio.TimeoutError: pass
