from __future__ import annotations

import re
from urllib.parse import urlparse

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

TERMS_TEXT = """🎰
عند الضغط على زر موافقة فأنت توافق على الشروط القائمة ضمن البوت ويحق لك الإعتراض في حال مواجهة أي مشكلة خارجة عن شروط وقوانين البوت 
يرجى قراءة هذه الشّروط قبل استخدام البوت لضمان تجربة آمنة ومريحه :

البوت مخصّص لإنشاء الحسابات، والسّحب، والتعبئة الفورية لحسابات موقع Ichancy 

1_  الحسابات المتعدّدة ممنوعه:
إنشاء أكثر من حساب للشّخص الواحد مخالف للقوانين، وقد يؤدّي إلى حظر الحسابات المرتبطة وتجميد أرصدتها، وذلك بناءاً على سياسة اللّعب النظيف .

2_تبديل طرق الدفع غير مسموح:
لا يُسمح بشحن رصيد وسحبه بغرض التبديل بين وسائل الدفع المختلفة. في حال اكتشاف عملية كهذه، يتم سحب الرّصيد والتّحفظ عليه دون إشعار مسبق مع تجميد الحساب

3_شروط أرباح الإحالات:
تُحتسب أرباح الإحالة فقط بعد تسجيل 3 إحالات نشطة أو أكثر (أي قاموا بالتعبئة الفعلية).

⛔️تنبيه:
أي محاولة للتّحايل أو مخالفة الشروط ستؤدي إلى إيقاف الحساب وتجميد الأرصدة.

اللعب للتسلية وليست مصدراً للدخل"""


def terms_accept_keyboard(accept_callback: str = "terms:accept") -> InlineKeyboardMarkup:
    callback = str(accept_callback or "terms:accept")
    if callback not in {"terms:accept", "terms:accept:wheel"}:
        callback = "terms:accept"
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ موافقة", callback_data=callback),
        InlineKeyboardButton(text="❌ رفض", callback_data="terms:reject"),
    ]])


def terms_read_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ رجوع", callback_data="core:home")]])


def _http_url(raw: str) -> str | None:
    text = str(raw or "").strip()
    if not text or re.search(r"\s", text):
        return None
    if not re.match(r"^https?://", text, flags=re.I):
        text = "https://" + text.lstrip("/")
    try:
        parsed = urlparse(text)
    except Exception:
        return None
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None
    return text


def normalize_support_contact(kind: str, raw: str) -> tuple[str | None, str | None]:
    text = str(raw or "").strip()
    if kind == "telegram":
        if text.startswith("@"):
            username = text[1:].strip()
            if re.fullmatch(r"[A-Za-z0-9_]{5,32}", username):
                return f"https://t.me/{username}", None
            return None, "معرف Telegram غير صحيح. مثال: @username"
        if re.fullmatch(r"[A-Za-z0-9_]{5,32}", text):
            return f"https://t.me/{text}", None
        url = _http_url(text)
        if not url:
            return None, "رابط Telegram غير صحيح."
        host = (urlparse(url).hostname or "").lower()
        if host not in {"t.me", "telegram.me", "telegram.dog", "www.t.me"}:
            return None, "استخدم رابط Telegram من t.me أو أرسل @username."
        return url, None
    if kind == "whatsapp":
        if text and not re.search(r"[A-Za-z]", text) and not text.lower().startswith(("http://", "https://")):
            digits = re.sub(r"\D", "", text)
            if digits.startswith("00"):
                digits = digits[2:]
            if len(digits) == 10 and digits.startswith("09"):
                digits = "963" + digits[1:]
            if 7 <= len(digits) <= 15:
                return f"https://wa.me/{digits}", None
            return None, "رقم WhatsApp غير صحيح. استخدم الرقم بصيغة دولية."
        url = _http_url(text)
        if not url:
            return None, "رابط WhatsApp غير صحيح."
        host = (urlparse(url).hostname or "").lower()
        if host not in {"wa.me", "www.wa.me", "api.whatsapp.com", "www.api.whatsapp.com", "whatsapp.com", "www.whatsapp.com"}:
            return None, "استخدم رقم WhatsApp أو رابط wa.me / whatsapp.com صحيح."
        return url, None
    if kind == "facebook":
        url = _http_url(text)
        if not url:
            return None, "رابط Facebook غير صحيح."
        host = (urlparse(url).hostname or "").lower()
        if host not in {"facebook.com", "www.facebook.com", "m.facebook.com", "fb.com", "www.fb.com", "m.me", "www.m.me", "fb.me", "www.fb.me"} and not host.endswith(".facebook.com"):
            return None, "استخدم رابط Facebook أو m.me صحيح."
        return url, None
    if kind == "ichancy":
        url = _http_url(text)
        if not url:
            return None, "أرسل رابط دعم iChancy صحيح يبدأ بـ https://"
        return url, None
    return None, "نوع وسيلة التواصل غير معروف."


def support_keyboard(runtime, *, include_back: bool = True) -> InlineKeyboardMarkup:
    specs = [
        ("telegram", "support_telegram", "✈️ Telegram"),
        ("whatsapp", "support_whatsapp", "🟢 WhatsApp"),
        ("facebook", "support_facebook", "🔵 Facebook"),
        ("ichancy", "support_ichancy", "🎰 دعم iChancy"),
    ]
    rows: list[list[InlineKeyboardButton]] = []
    for kind, ui_key, default_label in specs:
        if not runtime.get_bool(f"support.{kind}_visible", True):
            continue
        url = str(runtime.get(f"support.{kind}_url", "") or "").strip()
        if not url:
            continue
        label = str(runtime.get(f"ui.button_label.{ui_key}", default_label) or default_label).strip()[:64] or default_label
        icon = str(runtime.get(f"ui.button_icon.{ui_key}", "") or "").strip() or None
        rows.append([InlineKeyboardButton(text=label, url=url, icon_custom_emoji_id=icon)])
    if include_back:
        rows.append([InlineKeyboardButton(text="⬅️ رجوع", callback_data="core:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def support_available(runtime) -> bool:
    for kind in ("telegram", "whatsapp", "facebook", "ichancy"):
        if runtime.get_bool(f"support.{kind}_visible", True) and str(runtime.get(f"support.{kind}_url", "") or "").strip():
            return True
    return False
