from __future__ import annotations

import html
import re
import string
from dataclasses import dataclass
from typing import Any

from app.core.emojis import BOT_DEPOSIT_EMOJI_ID, BOT_WITHDRAW_EMOJI_ID, ICHANCY_EMOJI_ID
from app.services.runtime_settings import RuntimeSettingsService
from app.core.user_experience import TERMS_TEXT


@dataclass(frozen=True)
class ButtonSpec:
    title: str
    label: str
    callback: str
    icon: str | None = None
    group: str = "القائمة الرئيسية"


BUTTONS: dict[str, ButtonSpec] = {
    "home_deposit": ButtonSpec("شحن رصيد", "شحن رصيد", "deposit:methods", BOT_DEPOSIT_EMOJI_ID),
    "home_withdraw": ButtonSpec("سحب رصيد", "سحب رصيد", "withdraw:methods", BOT_WITHDRAW_EMOJI_ID),
    "home_ichancy": ButtonSpec("iChancy", "iChancy", "ichancy:menu", ICHANCY_EMOJI_ID),
    "home_referral": ButtonSpec("الإحالات", "🤝 الإحالات", "ref:home"),
    "home_gift_balance": ButtonSpec("إهداء رصيد", "🎁 إهداء رصيد", "gift:send"),
    "home_offers": ButtonSpec("عروضنا الحالية", "🎁 عروضنا الحالية", "cashback:home"),
    "home_loyalty": ButtonSpec("نقاط الولاء", "🏆 نقاط الولاء", "loyalty:home"),
    "home_gift_code": ButtonSpec("كود هدية", "🎟 كود هدية", "gift:code"),
    "home_gift_history": ButtonSpec("سجل الهدايا", "🧾 سجل الهدايا", "gift:history"),
    "home_wheel": ButtonSpec("عجلة الحظ", "🎡 عجلة الحظ", "wheel:open"),
    "home_contests": ButtonSpec("المسابقات", "🏆 المسابقات", "contest:home"),
    "home_matches": ButtonSpec("مباريات اليوم", "⚽ مباريات اليوم", "menu:matches"),
    "home_refund": ButtonSpec("استرداد آخر طلب سحب", "↩️ استرداد آخر طلب سحب", "withdraw:cancel_last"),
    "home_history": ButtonSpec("سجل العمليات", "🧾 سجل العمليات", "history:home"),
    "home_support": ButtonSpec("تواصل مع الدعم", "💬 تواصل مع الدعم", "support:home"),
    "home_terms": ButtonSpec("الشروط والأحكام", "📜 الشروط والأحكام", "menu:terms"),
    "home_refresh": ButtonSpec("تحديث القائمة", "🔄 تحديث القائمة", "core:home"),
    "deposit_syriatel": ButtonSpec("سيرياتيل كاش", "سيرياتيل كاش", "deposit:method:syriatel", None, "وسائل الشحن"),
    "deposit_sham_syp": ButtonSpec("شام كاش – ليرة", "شام كاش – ليرة", "deposit:method:sham_syp", None, "وسائل الشحن"),
    "deposit_sham_usd": ButtonSpec("شام كاش – دولار", "شام كاش – دولار", "deposit:method:sham_usd", None, "وسائل الشحن"),
    "deposit_whish_money": ButtonSpec("Whish Money", "💸 Whish Money", "deposit:method:whish_money", None, "وسائل الشحن"),
    "deposit_binance_trc20": ButtonSpec("Binance USDT TRC20", "🪙 Binance USDT TRC20", "deposit:method:binance_trc20", None, "وسائل الشحن"),
    "deposit_binance_bep20": ButtonSpec("Binance USDT BEP20", "🪙 Binance USDT BEP20", "deposit:method:binance_bep20", None, "وسائل الشحن"),
    "withdraw_syriatel": ButtonSpec("سحب سيرياتيل كاش", "سيرياتيل كاش", "withdraw:method:syriatel", None, "وسائل السحب"),
    "withdraw_shamcash": ButtonSpec("سحب شام كاش", "شام كاش", "withdraw:method:shamcash", None, "وسائل السحب"),
    "withdraw_hawala": ButtonSpec("سحب حوالة", "حوالة", "withdraw:method:hawala", None, "وسائل السحب"),
    "withdraw_usdt": ButtonSpec("سحب USDT", "سحب USDT", "withdraw:method:usdt", None, "وسائل السحب"),
    "ichancy_create": ButtonSpec("إنشاء حساب iChancy", "إنشاء حساب iChancy", "ichancy:create", ICHANCY_EMOJI_ID, "قائمة iChancy"),
    "ichancy_website": ButtonSpec("دخول فوري إلى iChancy", "دخول فوري إلى أيشانسي", "ichancy:website", ICHANCY_EMOJI_ID, "قائمة iChancy"),
    "ichancy_deposit": ButtonSpec("شحن رصيد iChancy", "شحن رصيد حسابك", "ichancy:deposit", BOT_DEPOSIT_EMOJI_ID, "قائمة iChancy"),
    "ichancy_withdraw": ButtonSpec("سحب رصيد iChancy", "سحب رصيد حسابك", "ichancy:withdraw", BOT_WITHDRAW_EMOJI_ID, "قائمة iChancy"),
    "ichancy_deposit_all": ButtonSpec("شحن كامل الرصيد", "⚡ شحن كامل الرصيد", "ichancy:deposit_all", None, "قائمة iChancy"),
    "ichancy_account": ButtonSpec("معلومات حساب iChancy", "ℹ️ معلومات حسابك", "ichancy:account", None, "قائمة iChancy"),
    "ichancy_manage": ButtonSpec("حذف / نقل حساب iChancy", "🔄 حذف / نقل حساب iChancy", "ichancy:manage_account", None, "قائمة iChancy"),
    "support_telegram": ButtonSpec("دعم Telegram", "✈️ Telegram", "url", None, "الدعم"),
    "support_whatsapp": ButtonSpec("دعم WhatsApp", "🟢 WhatsApp", "url", None, "الدعم"),
    "support_facebook": ButtonSpec("دعم Facebook", "🔵 Facebook", "url", None, "الدعم"),
    "support_ichancy": ButtonSpec("دعم iChancy", "🎰 دعم iChancy", "url", None, "الدعم"),
}

MAIN_MENU_BUTTON_KEYS: tuple[str, ...] = tuple(k for k,v in BUTTONS.items() if v.group == "القائمة الرئيسية")
DEFAULT_MAIN_MENU_LAYOUT: tuple[tuple[str, ...], ...] = (
    ("home_deposit", "home_withdraw"),
    ("home_ichancy",),
    ("home_referral", "home_gift_balance"),
    ("home_offers", "home_loyalty"),
    ("home_gift_code", "home_gift_history"),
    ("home_wheel",),
    ("home_contests", "home_matches"),
    ("home_refund",),
    ("home_history", "home_support"),
    ("home_terms",),
    ("home_refresh",),
)


def _k(prefix: str, key: str) -> str:
    return f"ui.{prefix}.{key}"


def button_label(rt: RuntimeSettingsService, key: str) -> str:
    spec = BUTTONS[key]
    raw = str(rt.get(_k("button_label", key), spec.label) or spec.label).strip()
    return (raw or spec.label)[:64]


def button_icon(rt: RuntimeSettingsService, key: str) -> str | None:
    spec = BUTTONS[key]
    raw = rt.get(_k("button_icon", key), spec.icon)
    text = str(raw or "").strip()
    return text or None


def button_visible(rt: RuntimeSettingsService, key: str) -> bool:
    return rt.get_bool(_k("button_visible", key), True)


async def set_button_label(rt: RuntimeSettingsService, key: str, value: str, actor: int) -> str:
    if key not in BUTTONS:
        raise KeyError(key)
    clean = str(value or "").strip()
    if not clean:
        raise ValueError("اسم الزر لا يمكن أن يكون فارغاً")
    if len(clean) > 64:
        raise ValueError("اسم الزر طويل جداً")
    await rt.set(_k("button_label", key), clean, updated_by=actor)
    return clean


async def set_button_icon(rt: RuntimeSettingsService, key: str, value: str | None, actor: int) -> str | None:
    if key not in BUTTONS:
        raise KeyError(key)
    clean = str(value or "").strip()
    if clean and not re.fullmatch(r"\d{5,30}", clean):
        raise ValueError("Custom Emoji ID غير صالح")
    await rt.set(_k("button_icon", key), clean or None, updated_by=actor)
    return clean or None


async def set_button_visible(rt: RuntimeSettingsService, key: str, value: bool, actor: int) -> bool:
    if key not in BUTTONS:
        raise KeyError(key)
    await rt.set(_k("button_visible", key), bool(value), updated_by=actor)
    return bool(value)


async def reset_button(rt: RuntimeSettingsService, key: str, actor: int) -> None:
    spec = BUTTONS[key]
    await rt.set(_k("button_label", key), spec.label, updated_by=actor)
    await rt.set(_k("button_icon", key), spec.icon, updated_by=actor)
    await rt.set(_k("button_visible", key), True, updated_by=actor)


def _normalize_layout(value: Any) -> list[list[str]]:
    valid = set(MAIN_MENU_BUTTON_KEYS)
    seen: set[str] = set()
    rows: list[list[str]] = []
    if isinstance(value, (list, tuple)):
        for raw_row in value:
            if not isinstance(raw_row, (list, tuple)):
                continue
            row: list[str] = []
            for raw_key in raw_row:
                key = str(raw_key or "").strip()
                if key in valid and key not in seen and len(row) < 2:
                    row.append(key)
                    seen.add(key)
            if row:
                rows.append(row)
    for default_row in DEFAULT_MAIN_MENU_LAYOUT:
        missing = [x for x in default_row if x not in seen]
        if missing:
            rows.append(missing[:2])
            seen.update(missing[:2])
    for key in MAIN_MENU_BUTTON_KEYS:
        if key not in seen:
            rows.append([key])
    return rows


def main_menu_layout(rt: RuntimeSettingsService) -> list[list[str]]:
    return _normalize_layout(rt.get("ui.main_menu_layout", [list(r) for r in DEFAULT_MAIN_MENU_LAYOUT]))


async def set_main_menu_layout(rt: RuntimeSettingsService, rows: Any, actor: int) -> list[list[str]]:
    normalized = _normalize_layout(rows)
    await rt.set("ui.main_menu_layout", normalized, updated_by=actor)
    return normalized


@dataclass(frozen=True)
class MessageSpec:
    title: str
    group: str
    default: str
    fields: frozenset[str] = frozenset()


MESSAGES: dict[str, MessageSpec] = {
    "home": MessageSpec("رسالة القائمة الرئيسية", "الرئيسية", "<b>{bot_name}</b>\n\nأهلاً بك 👋\nاختر الخدمة التي تريدها من القائمة أدناه.", frozenset({"bot_name"})),
    "support_home": MessageSpec("رسالة التواصل مع الدعم", "الدعم", "💬 <b>تواصل مع الدعم</b>\n\nاختر وسيلة التواصل المناسبة:"),
    "support_empty": MessageSpec("رسالة عدم توفر الدعم", "الدعم", "💬 <b>تواصل مع الدعم</b>\n\n⚠️ لا توجد وسيلة دعم مفعلة حاليًا. يرجى المحاولة لاحقًا."),
    "history_home": MessageSpec("رسالة سجل العمليات", "السجلات", "🧾 اختر نوع السجل الذي تريد عرضه 👇"),
    "terms": MessageSpec("الشروط والأحكام", "الشروط", TERMS_TEXT),
    "deposit_verifying": MessageSpec("جاري التحقق من الشحن", "الشحن", "⏳ <b>جاري التحقق من بيانات العملية...</b>"),
    "deposit_processing_previous": MessageSpec("وجود شحن قيد التحقق", "الشحن", "⏳ <b>لديك عملية شحن قيد التحقق حالياً</b>\n\nانتظر نتيجة العملية الحالية قبل إرسال رقم عملية آخر."),
    "deposit_api_failed": MessageSpec("تعذر التحقق عبر مزود الدفع", "الشحن", "⚠️ <b>تعذر التأكد من العملية حالياً.</b>\n\nيرجى المحاولة بنفس رقم العملية بعد قليل."),
    "deposit_not_found": MessageSpec("عملية الشحن غير موجودة", "الشحن", "❌ لم يتم العثور على العملية."),
    "deposit_mismatch": MessageSpec("بيانات عملية الشحن غير متطابقة", "الشحن", "❌ بيانات العملية لا تطابق طريقة الشحن أو المبلغ المطلوب."),
    "withdraw_refund_success": MessageSpec("نجاح استرداد طلب السحب", "السحب", "✅ <b>تم استرداد طلب السحب</b>\n\n🧾 رقم الطلب: <code>{withdraw_id}</code>\n💰 المبلغ المعاد من الحجز: <code>{amount} SYP</code>\n👛 رصيدك المتاح الآن: <code>{balance} SYP</code>", frozenset({"withdraw_id", "amount", "balance"})),
    "wheel_win": MessageSpec("رسالة ربح عجلة الحظ", "عجلة الحظ", "🎉 <b>مبروك!</b>\n\nربحت <code>{prize}</code> ل.س من عجلة الحظ.\n👛 رصيدك الحالي: <code>{balance}</code> ل.س", frozenset({"prize", "balance"})),
    "wheel_lose": MessageSpec("رسالة الخسارة في عجلة الحظ", "عجلة الحظ", "😔 للأسف، لم تربح جائزة في هذه اللفة.\nحظاً أوفر في المرة القادمة 🍀"),
    "ichancy_create_prompt": MessageSpec("طلب اسم حساب iChancy", "iChancy", "👤 <b>إنشاء حساب iChancy</b>\n\nأرسل اسمك فقط. يمكن كتابته بالعربي أو الإنكليزي.\nسيقوم البوت بتحويل الاسم وتجهيز اسم الحساب وكلمة المرور تلقائياً."),
    "ichancy_deposit_success": MessageSpec("نجاح شحن iChancy", "iChancy", "✅ <b>تم شحن حسابك بنجاح.</b>\n\n💰 المبلغ: <code>{amount}</code> ل.س", frozenset({"amount"})),
    "ichancy_withdraw_success": MessageSpec("نجاح سحب iChancy", "iChancy", "✅ <b>تم سحب رصيد حسابك بنجاح.</b>\n\n💰 المبلغ: <code>{amount}</code> ل.س", frozenset({"amount"})),
    "gift_send_prompt": MessageSpec("طلب مستلم الإهداء", "الهدايا", "🎁 <b>إهداء رصيد</b>\n\nأرسل Telegram ID للمستخدم الذي تريد إهداءه.\n\n👛 رصيدك: <code>{available}</code> SYP\n🔓 القابل للإهداء: <code>{transferable}</code> SYP\n🔒 مكافآت غير قابلة للإهداء: <code>{protected}</code> SYP", frozenset({"available", "transferable", "protected"})),
    "gift_amount_prompt": MessageSpec("طلب مبلغ الإهداء", "الهدايا", "💰 أرسل مبلغ الإهداء إلى <code>{recipient}</code> بالليرة السورية.", frozenset({"recipient"})),
    "gift_confirm": MessageSpec("تأكيد إهداء الرصيد", "الهدايا", "⚠️ <b>تأكيد الإهداء</b>\n\n📥 المستلم: <code>{recipient}</code>\n💰 المبلغ: <code>{amount}</code> SYP\n\nبعد التأكيد سيتم نقل الرصيد مباشرة.", frozenset({"recipient", "amount"})),
    "gift_send_success": MessageSpec("نجاح إهداء الرصيد", "الهدايا", "✅ <b>تم إهداء الرصيد بنجاح</b>\n\n📥 المستلم: <code>{recipient}</code>\n💰 المبلغ: <code>{amount}</code> SYP\n👛 رصيدك الآن: <code>{balance}</code> SYP", frozenset({"recipient", "amount", "balance"})),
    "gift_received": MessageSpec("استلام هدية رصيد", "الهدايا", "🎁 <b>وصلتك هدية رصيد</b>\n\n📤 من: <code>{sender}</code>\n💰 المبلغ: <code>{amount}</code> SYP\n👛 رصيدك الآن: <code>{balance}</code> SYP", frozenset({"sender", "amount", "balance"})),
    "gift_code_prompt": MessageSpec("طلب كود الهدية", "الهدايا", "🎟 <b>استخدام كود هدية</b>\n\nأرسل كود الهدية كما هو:"),
    "gift_code_success": MessageSpec("نجاح استخدام كود هدية", "الهدايا", "✅ <b>تم استخدام كود الهدية</b>\n\n🎟 الكود: <code>{code}</code>\n💰 القيمة: <code>{amount}</code> SYP\n👛 رصيدك الآن: <code>{balance}</code> SYP", frozenset({"code", "amount", "balance"})),
    "loyalty_home": MessageSpec("واجهة نقاط الولاء", "نقاط الولاء", "🏆 <b>نقاط الولاء</b>\n\n⭐ رصيد نقاطك: <b>{points}</b>\n📈 إجمالي المكتسب: <code>{total_earned}</code>\n🎁 إجمالي المستبدل: <code>{total_redeemed}</code>\n\nكل <code>{earn_syp_per_point}</code> SYP من <b>أصل الشحن الحقيقي</b> = نقطة واحدة.\nالحد الأدنى للشحن المحتسب: <code>{min_deposit_syp}</code> SYP{status_note}", frozenset({"points", "total_earned", "total_redeemed", "earn_syp_per_point", "min_deposit_syp", "status_note"})),
    "loyalty_balance_success": MessageSpec("نجاح استبدال نقاط برصيد", "نقاط الولاء", "✅ <b>تم استبدال النقاط</b>\n\n🎁 {reward_name}\n⭐ تم خصم: <code>{points_spent}</code> نقطة\n💰 أضيف: <code>{balance_amount}</code> SYP\n👛 الرصيد الآن: <code>{balance}</code> SYP", frozenset({"reward_name", "points_spent", "balance_amount", "balance"})),
    "loyalty_manual_success": MessageSpec("إرسال طلب جائزة ولاء", "نقاط الولاء", "✅ <b>تم إرسال طلب الجائزة للإدارة</b>\n\n🎁 {reward_name}\n⭐ تم خصم: <code>{points_spent}</code> نقطة\n🧾 الطلب: <code>{claim_id}</code>", frozenset({"reward_name", "points_spent", "claim_id"})),
}


def get_message_template(rt: RuntimeSettingsService, key: str) -> str:
    spec = MESSAGES[key]
    raw = str(rt.get(_k("message", key), spec.default) or spec.default)
    ok, _ = validate_message_template(key, raw)
    return raw if ok else spec.default


def _fields(template: str) -> list[str]:
    out: list[str] = []
    try:
        for _, field_name, _, _ in string.Formatter().parse(template):
            if field_name:
                out.append(field_name)
    except Exception:
        return ["__invalid__"]
    return out


def validate_message_template(key: str, template: str) -> tuple[bool, str]:
    if key not in MESSAGES:
        return False, "الرسالة غير معروفة"
    text = str(template or "").strip()
    if not text:
        return False, "النص لا يمكن أن يكون فارغاً"
    if len(text) > 3900:
        return False, "النص طويل جداً"
    found = _fields(text)
    if "__invalid__" in found:
        return False, "صيغة المتغيرات غير صحيحة"
    allowed = set(MESSAGES[key].fields)
    unknown = set(found) - allowed
    if unknown:
        return False, "متغير غير مسموح: " + ", ".join(sorted(unknown))
    for field in allowed:
        if found.count(field) != 1:
            return False, f"يجب إبقاء المتغير {{{field}}} مرة واحدة بالضبط"
    return True, ""


async def set_message_template(rt: RuntimeSettingsService, key: str, template: str, actor: int) -> str:
    ok, err = validate_message_template(key, template)
    if not ok:
        raise ValueError(err)
    clean = str(template).strip()
    await rt.set(_k("message", key), clean, updated_by=actor)
    return clean


async def reset_message(rt: RuntimeSettingsService, key: str, actor: int) -> None:
    await rt.set(_k("message", key), MESSAGES[key].default, updated_by=actor)


def render_message(rt: RuntimeSettingsService, key: str, **values: Any) -> str:
    spec = MESSAGES[key]
    template = get_message_template(rt, key)
    safe: dict[str, Any] = {}
    for field in spec.fields:
        value = values.get(field, f"[{field}]")
        # Callers may explicitly pass SafeHtml by using a string that already contains
        # markup; current catalog values are controlled by application code.
        safe[field] = value
    try:
        return template.format(**safe)
    except Exception:
        return spec.default.format(**safe)


def message_preview(rt: RuntimeSettingsService, key: str, template: str | None = None) -> str:
    samples = {
        "bot_name": "Tecno",
        "amount": "100,000",
        "balance": "250,000",
        "prize": "5,000",
        "withdraw_id": "00000000-0000-0000-0000-000000000000",
        "available": "250,000", "transferable": "200,000", "protected": "50,000",
        "recipient": "123456789", "sender": "987654321", "code": "TECNO-ABCDEFGH",
        "points": "120", "total_earned": "300", "total_redeemed": "180",
        "earn_syp_per_point": "1,000", "min_deposit_syp": "50,000", "status_note": "",
        "reward_name": "جائزة تجريبية", "points_spent": "50", "balance_amount": "25,000",
        "claim_id": "00000000-0000-0000-0000-000000000000",
    }
    spec = MESSAGES[key]
    tpl = template if template is not None else get_message_template(rt, key)
    vals = {name: samples.get(name, f"[{name}]") for name in spec.fields}
    return tpl.format(**vals)


_MESSAGE_PLACEHOLDER_RE = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)\}")
_MESSAGE_HTML_TAG_RE = re.compile(r"<[^>]+>")
_MESSAGE_HTML_TOKEN_RE = re.compile(r"(<[^>]+>)")
_MESSAGE_TAG_PARSE_RE = re.compile(r"^<\s*(/?)\s*([A-Za-z0-9-]+)(?:\s[^>]*)?>$")


def message_template_visible_text(template: str) -> str:
    raw = str(template or "").replace("\r\n", "\n").replace("\r", "\n")
    return html.unescape(_MESSAGE_HTML_TAG_RE.sub("", raw))


def _flexible_static_regex(text: str) -> str:
    chunks = re.split(r"(\s+)", str(text or ""))
    return "".join(r"\s+" if chunk.isspace() else re.escape(chunk) for chunk in chunks if chunk)


def _template_search_pattern(template: str) -> tuple[re.Pattern[str], int]:
    visible = message_template_visible_text(template).strip()
    pieces: list[str] = [r"^\s*"]
    score = 0
    last = 0
    for match in _MESSAGE_PLACEHOLDER_RE.finditer(visible):
        static = visible[last:match.start()]
        pieces.append(_flexible_static_regex(static))
        score += len(re.sub(r"\s+", "", static))
        pieces.append(r"[\s\S]*?")
        last = match.end()
    static = visible[last:]
    pieces.append(_flexible_static_regex(static))
    score += len(re.sub(r"\s+", "", static))
    pieces.append(r"\s*$")
    return re.compile("".join(pieces), re.IGNORECASE), score


def find_message_templates_by_rendered_text(rt: RuntimeSettingsService, copied_text: str) -> list[str]:
    """Match a real copied bot message while treating protected placeholders as wildcards."""
    pasted = str(copied_text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    if not pasted:
        return []
    hits: list[tuple[int, str]] = []
    for key, spec in MESSAGES.items():
        try:
            current = get_message_template(rt, key)
            rx, score = _template_search_pattern(current)
            if rx.match(pasted):
                hits.append((score, key))
                continue
            if current != spec.default:
                rx, score = _template_search_pattern(spec.default)
                if rx.match(pasted):
                    hits.append((score, key))
        except Exception:
            continue
    if not hits:
        return []
    best = max(score for score, _ in hits)
    selected = {key for score, key in hits if score == best}
    return [key for key in MESSAGES if key in selected]


def _fragment_unmatched_tag_indexes(fragment: str) -> set[int]:
    tokens = _MESSAGE_HTML_TOKEN_RE.split(fragment)
    stack: list[tuple[str, int]] = []
    unmatched: set[int] = set()
    for idx, token in enumerate(tokens):
        if not token.startswith("<"):
            continue
        match = _MESSAGE_TAG_PARSE_RE.match(token.strip())
        if not match:
            continue
        closing, name = match.group(1), match.group(2).lower()
        if token.rstrip().endswith("/>"):
            continue
        if not closing:
            stack.append((name, idx))
        elif stack and stack[-1][0] == name:
            stack.pop()
        else:
            unmatched.add(idx)
    unmatched.update(idx for _, idx in stack)
    return unmatched


def _replace_static_fragment(fragment: str, replacement_html: str) -> str:
    fragment = str(fragment or "")
    replacement_html = str(replacement_html or "")
    unmatched = _fragment_unmatched_tag_indexes(fragment)
    if not unmatched:
        leading = re.match(r"^\s*", fragment).group(0)
        trailing = re.search(r"\s*$", fragment).group(0)
        core_end = len(fragment) - len(trailing) if trailing else len(fragment)
        core = fragment[len(leading):core_end]
        if not message_template_visible_text(core).strip():
            return fragment
        return leading + replacement_html + trailing
    tokens = _MESSAGE_HTML_TOKEN_RE.split(fragment)
    inserted = False
    out: list[str] = []
    for idx, token in enumerate(tokens):
        if token.startswith("<"):
            if idx in unmatched:
                out.append(token)
            continue
        if not token:
            continue
        if token.strip():
            leading = re.match(r"^\s*", token).group(0)
            trailing = re.search(r"\s*$", token).group(0)
            if not inserted:
                out.append(leading + replacement_html + trailing)
                inserted = True
            else:
                out.append(leading + trailing)
        else:
            out.append(token)
    return "".join(out) if inserted else fragment


def message_editable_parts(template: str) -> list[dict[str, Any]]:
    """Expose only static visible fragments; placeholders are never editable."""
    raw = str(template or "")
    result: list[dict[str, Any]] = []
    offset = 0
    for line in raw.splitlines(keepends=True):
        content = line.rstrip("\r\n")
        newline_len = len(line) - len(content)
        placeholders = list(_MESSAGE_PLACEHOLDER_RE.finditer(content))
        if not placeholders:
            visible = message_template_visible_text(content).strip()
            if visible:
                result.append({"start": offset, "end": offset + len(content), "display": visible, "mode": "whole"})
        else:
            cursor = 0
            for match in placeholders:
                fragment = content[cursor:match.start()]
                visible = message_template_visible_text(fragment).strip()
                if visible:
                    result.append({"start": offset + cursor, "end": offset + match.start(), "display": visible, "mode": "fragment"})
                cursor = match.end()
            fragment = content[cursor:]
            visible = message_template_visible_text(fragment).strip()
            if visible:
                result.append({"start": offset + cursor, "end": offset + len(content), "display": visible, "mode": "fragment"})
        offset += len(content) + newline_len
    return result


def replace_message_editable_part(template: str, part_index: int, replacement_html: str) -> str:
    parts = message_editable_parts(template)
    try:
        part = parts[int(part_index)]
    except Exception as exc:
        raise ValueError("الجزء المحدد لم يعد موجوداً. أعد البحث عن الرسالة.") from exc
    start, end = int(part["start"]), int(part["end"])
    old = str(template or "")[start:end]
    if str(part.get("mode")) == "whole":
        leading = re.match(r"^\s*", old).group(0)
        trailing = re.search(r"\s*$", old).group(0)
        new_piece = leading + str(replacement_html or "") + trailing
    else:
        new_piece = _replace_static_fragment(old, str(replacement_html or ""))
    return str(template or "")[:start] + new_piece + str(template or "")[end:]


def find_messages(rt: RuntimeSettingsService, text: str) -> list[str]:
    needle = re.sub(r"\s+", " ", html.unescape(str(text or ""))).strip().lower()
    if not needle:
        return []
    exact: list[str] = []
    partial: list[str] = []
    for key, spec in MESSAGES.items():
        tpl = get_message_template(rt, key)
        hay = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", html.unescape(tpl))).strip().lower()
        title = spec.title.lower()
        if needle == hay or needle == title:
            exact.append(key)
        elif needle in hay or needle in title or hay in needle:
            partial.append(key)
    return exact + [x for x in partial if x not in exact]
