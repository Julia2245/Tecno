from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from app.core.emojis import SUCCESS_EMOJI_ID, ICHANCY_EMOJI_ID, BOT_DEPOSIT_EMOJI_ID, BOT_WITHDRAW_EMOJI_ID
from app.services.runtime_settings import RuntimeSettingsService
from app.core.ui_customization import button_icon, button_label


def ichancy_menu(*, has_account: bool, runtime_settings: RuntimeSettingsService | None = None) -> InlineKeyboardMarkup:
    def b(key: str, fallback: str, callback: str, fallback_icon: str | None = None) -> InlineKeyboardButton:
        label = button_label(runtime_settings, key) if runtime_settings is not None else fallback
        icon = (button_icon(runtime_settings, key) if runtime_settings is not None else None) or fallback_icon
        return InlineKeyboardButton(text=label, callback_data=callback, icon_custom_emoji_id=icon)
    if not has_account:
        rows = [
            [b("ichancy_create", "إنشاء حساب iChancy", "ichancy:create", ICHANCY_EMOJI_ID)],
            [InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")],
        ]
    else:
        rows = [
            [b("ichancy_website", "دخول فوري إلى أيشانسي", "ichancy:website", ICHANCY_EMOJI_ID)],
            [
                b("ichancy_deposit", "شحن رصيد حسابك", "ichancy:deposit", BOT_DEPOSIT_EMOJI_ID),
                b("ichancy_withdraw", "سحب رصيد حسابك", "ichancy:withdraw", BOT_WITHDRAW_EMOJI_ID),
            ],
            [b("ichancy_deposit_all", "⚡ شحن كامل الرصيد", "ichancy:deposit_all")],
            [b("ichancy_account", "ℹ️ معلومات حسابك", "ichancy:account")],
            [b("ichancy_manage", "🔄 حذف / نقل حساب iChancy", "ichancy:manage_account")],
            [InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")],
        ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back_to_ichancy() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="ichancy:menu")]
    ])


def cancel_to_ichancy() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ إلغاء", callback_data="ichancy:cancel")]
    ])


def full_deposit_confirm() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="تأكيد", callback_data="ichancy:deposit_all:confirm", icon_custom_emoji_id=SUCCESS_EMOJI_ID),
            InlineKeyboardButton(text="❌ إلغاء", callback_data="ichancy:cancel"),
        ],
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="ichancy:menu")],
    ])


def website_open(url: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="افتح الحساب 🚀", web_app=WebAppInfo(url=url))],
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="ichancy:menu")],
    ])


def replacement_wait_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")],
    ])
