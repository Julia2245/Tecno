from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.core.emojis import ICHANCY_EMOJI_ID
from app.core.ui_customization import BUTTONS, button_icon, button_label, button_visible, main_menu_layout
from app.services.runtime_settings import RuntimeSettingsService


def main_menu(*, is_admin: bool = False, runtime_settings: RuntimeSettingsService | None = None) -> InlineKeyboardMarkup:
    if runtime_settings is None:
        # Safe compatibility fallback used by tests/old call sites.
        rows = [
            [InlineKeyboardButton(text="شحن رصيد", callback_data="deposit:methods"), InlineKeyboardButton(text="سحب رصيد", callback_data="withdraw:methods")],
            [InlineKeyboardButton(text="iChancy", callback_data="ichancy:menu", icon_custom_emoji_id=ICHANCY_EMOJI_ID)],
            [InlineKeyboardButton(text="🤝 الإحالات", callback_data="ref:home"), InlineKeyboardButton(text="🎁 إهداء رصيد", callback_data="gift:send")],
            [InlineKeyboardButton(text="🎁 عروضنا الحالية", callback_data="cashback:home"), InlineKeyboardButton(text="🏆 نقاط الولاء", callback_data="loyalty:home")],
            [InlineKeyboardButton(text="🎟 كود هدية", callback_data="gift:code"), InlineKeyboardButton(text="🧾 سجل الهدايا", callback_data="gift:history")],
            [InlineKeyboardButton(text="🎡 عجلة الحظ", callback_data="wheel:open")],
            [InlineKeyboardButton(text="🏆 المسابقات", callback_data="contest:home"), InlineKeyboardButton(text="⚽ مباريات اليوم", callback_data="menu:matches")],
            [InlineKeyboardButton(text="↩️ استرداد آخر طلب سحب", callback_data="withdraw:cancel_last")],
            [InlineKeyboardButton(text="🧾 سجل العمليات", callback_data="history:home"), InlineKeyboardButton(text="💬 تواصل مع الدعم", callback_data="support:home")],
            [InlineKeyboardButton(text="📜 الشروط والأحكام", callback_data="menu:terms")],
            [InlineKeyboardButton(text="🔄 تحديث القائمة", callback_data="core:home")],
        ]
    else:
        rows: list[list[InlineKeyboardButton]] = []
        for row_keys in main_menu_layout(runtime_settings):
            row: list[InlineKeyboardButton] = []
            for key in row_keys:
                if key not in BUTTONS or not button_visible(runtime_settings, key):
                    continue
                spec = BUTTONS[key]
                row.append(InlineKeyboardButton(
                    text=button_label(runtime_settings, key),
                    callback_data=spec.callback,
                    icon_custom_emoji_id=button_icon(runtime_settings, key),
                ))
            if row:
                rows.append(row)
    if is_admin:
        rows.append([InlineKeyboardButton(text="🛠 لوحة الإدارة", callback_data="admin:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="💳 إدارة الشحن والسحب", callback_data="admin:finance"), InlineKeyboardButton(text="👛 محفظة الأدمن", callback_data="admin:wallet")],
            [InlineKeyboardButton(text="إدارة iChancy", callback_data="admin:ichancy", icon_custom_emoji_id=ICHANCY_EMOJI_ID)],
            [InlineKeyboardButton(text="🎁 إدارة الاسترداد", callback_data="admin:cashback"), InlineKeyboardButton(text="🤝 إدارة الإحالات", callback_data="admin:referrals")],
            [InlineKeyboardButton(text="🎡 إدارة عجلة الحظ", callback_data="admin:wheel_manage"), InlineKeyboardButton(text="🎁 الهدايا والولاء", callback_data="admin:benefits")],
            [InlineKeyboardButton(text="🏆 المسابقات والروليت", callback_data="admin:competitions")],
            [InlineKeyboardButton(text="👥 إدارة المستخدمين", callback_data="admin:users"), InlineKeyboardButton(text="📊 التقارير الكاملة", callback_data="admin:reports")],
            [InlineKeyboardButton(text="📝 النصوص والأزرار", callback_data="admin:ui_content")],
            [InlineKeyboardButton(text="💬 إدارة التواصل والرسائل الجماعية", callback_data="admin:communications")],
            [InlineKeyboardButton(text="🛡 الإدارة والحماية", callback_data="admin:ops"), InlineKeyboardButton(text="🛠 وضع الصيانة", callback_data="admin:maintenance")],
            [InlineKeyboardButton(text="📊 حالة النواة", callback_data="admin:status")],
            [InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")],
        ]
    )
