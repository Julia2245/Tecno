from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.core.emojis import (
    SUCCESS_EMOJI_ID, BOT_WITHDRAW_EMOJI_ID, SHAM_CASH_EMOJI_ID, SYRIATEL_CASH_EMOJI_ID,
)
from app.services.withdrawals import WithdrawService
from app.services.runtime_settings import RuntimeSettingsService
from app.core.ui_customization import button_icon, button_label


def methods_menu(service: WithdrawService, runtime_settings: RuntimeSettingsService | None = None) -> InlineKeyboardMarkup:
    labels = [
        ("syriatel", "سيرياتيل كاش", SYRIATEL_CASH_EMOJI_ID),
        ("shamcash", "شام كاش", SHAM_CASH_EMOJI_ID),
        ("hawala", "حوالة", BOT_WITHDRAW_EMOJI_ID),
        ("usdt", "سحب USDT", BOT_WITHDRAW_EMOJI_ID),
    ]
    rows = []
    for method, label, icon_id in labels:
        key = {"syriatel":"withdraw_syriatel","shamcash":"withdraw_shamcash","hawala":"withdraw_hawala","usdt":"withdraw_usdt"}.get(method)
        if runtime_settings is not None and key:
            label = button_label(runtime_settings, key)
            icon_id = button_icon(runtime_settings, key) or icon_id
        text = label if service.method_enabled(method) else f"{label} (متوقف)"
        rows.append([InlineKeyboardButton(text=text, callback_data=f"withdraw:method:{method}", icon_custom_emoji_id=icon_id)])
    rows.append([InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def hawala_companies() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="حوالة هرم", callback_data="withdraw:hawala:harm")],
        [InlineKeyboardButton(text="حوالة الفؤاد", callback_data="withdraw:hawala:fouad")],
        [InlineKeyboardButton(text="❌ إلغاء", callback_data="withdraw:cancel")],
    ])


def usdt_networks(service: WithdrawService) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    networks = []
    for network in ("TRC20", "BEP20"):
        enabled = service.network_enabled(network)
        label = network if enabled else f"{network} (متوقفة)"
        networks.append(InlineKeyboardButton(text=label, callback_data=f"withdraw:network:{network}"))
    rows.append(networks)
    rows.append([InlineKeyboardButton(text="❌ إلغاء", callback_data="withdraw:cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def cancel_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ إلغاء", callback_data="withdraw:cancel")],
    ])


def confirm_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="تأكيد الطلب", callback_data="withdraw:confirm", icon_custom_emoji_id=SUCCESS_EMOJI_ID),
            InlineKeyboardButton(text="❌ إلغاء", callback_data="withdraw:cancel"),
        ],
    ])
