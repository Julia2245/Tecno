from __future__ import annotations

import html
import math
from uuid import uuid4

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.ui_customization import render_message
from app.keyboards.common import main_menu
from app.services.gifts_loyalty import GiftService, LoyaltyService
from app.services.runtime_settings import RuntimeSettingsService
from app.services.outbox import NotificationOutboxWorker

router = Router(name="gifts_loyalty")
PAGE=10

class GiftStates(StatesGroup):
    recipient=State(); amount=State(); confirm=State(); code=State()


def _back(data="core:home"): return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ رجوع",callback_data=data)]])

async def _notify_admin(outbox_worker: NotificationOutboxWorker, event_key: str, text: str) -> None:
    """Durable admin-events notice; never changes the committed user operation."""
    try:
        await outbox_worker.repository.enqueue(
            event_key=event_key, target_key="notify.admin_events", text=text, parse_mode="HTML"
        )
        outbox_worker.wake()
    except Exception:
        # The operation is already committed. Notification transport is strictly side-effect only.
        return

@router.callback_query(F.data=="gift:send")
async def gift_start(callback:CallbackQuery,state:FSMContext,gift_service:GiftService,runtime_settings:RuntimeSettingsService)->None:
    await state.clear()
    if not gift_service.enabled():
        await safe_edit(callback,"⛔ خدمة إهداء الرصيد متوقفة حاليًا.",reply_markup=_back()); return
    info=await gift_service.transferable_balance(callback.from_user.id)
    await state.set_state(GiftStates.recipient)
    await state.update_data(request_token=str(uuid4()))
    await safe_edit(callback, render_message(runtime_settings,"gift_send_prompt",
        available=f"{info['available']:,}",transferable=f"{info['transferable']:,}",protected=f"{info['protected']:,}"),
        reply_markup=_back())

@router.message(GiftStates.recipient)
async def gift_recipient(message:Message,state:FSMContext,gift_service:GiftService,runtime_settings:RuntimeSettingsService)->None:
    raw=(message.text or '').strip()
    if not raw.isdigit(): await message.answer("❌ أرسل Telegram ID رقميًا فقط."); return
    target=int(raw)
    if target==message.from_user.id: await message.answer("❌ لا يمكن الإهداء لنفسك."); return
    # Existence is finally re-checked in the financial transaction.
    await state.update_data(recipient=target)
    await state.set_state(GiftStates.amount)
    await message.answer(render_message(runtime_settings,"gift_amount_prompt",recipient=str(target)),reply_markup=_back())

@router.message(GiftStates.amount)
async def gift_amount(message:Message,state:FSMContext,gift_service:GiftService,runtime_settings:RuntimeSettingsService)->None:
    raw=(message.text or '').translate(str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹","01234567890123456789")).replace(',','').strip()
    if not raw.isdigit() or int(raw)<=0: await message.answer("❌ أرسل مبلغًا صحيحًا أكبر من صفر."); return
    amount=int(raw); info=await gift_service.transferable_balance(message.from_user.id)
    if amount>info['transferable']:
        await message.answer(f"❌ الرصيد القابل للإهداء غير كافٍ.\nالمتاح للإهداء: <code>{info['transferable']:,}</code> SYP"); return
    data=await state.get_data(); recipient=int(data['recipient'])
    await state.update_data(amount=amount); await state.set_state(GiftStates.confirm)
    await message.answer(
        render_message(runtime_settings,"gift_confirm",recipient=str(recipient),amount=f"{amount:,}"),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ تأكيد",callback_data="gift:confirm"),InlineKeyboardButton(text="❌ إلغاء",callback_data="gift:cancel")]
        ]))

@router.callback_query(GiftStates.confirm,F.data.in_({"gift:confirm","gift:cancel"}))
async def gift_confirm(callback:CallbackQuery,state:FSMContext,gift_service:GiftService,runtime_settings:RuntimeSettingsService,bot:Bot,outbox_worker:NotificationOutboxWorker)->None:
    if callback.data=="gift:cancel":
        await state.clear(); await safe_edit(callback,"❌ تم إلغاء الإهداء.",reply_markup=_back()); return
    data=await state.get_data()
    try:
        result=await gift_service.transfer(callback.from_user.id,int(data['recipient']),int(data['amount']),data['request_token'])
    except Exception as exc:
        await state.clear(); await safe_edit(callback,f"❌ {html.escape(str(exc) or 'تعذر تنفيذ الإهداء.')}",reply_markup=_back()); return
    await state.clear()
    await safe_edit(callback, render_message(runtime_settings,"gift_send_success",recipient=str(result.recipient_id),amount=f"{result.amount:,}",balance=f"{result.sender_balance:,}"),reply_markup=_back())
    try:
        await bot.send_message(result.recipient_id, render_message(runtime_settings,"gift_received",sender=str(result.sender_id),amount=f"{result.amount:,}",balance=f"{result.recipient_balance:,}"))
    except Exception: pass
    await _notify_admin(outbox_worker, f"admin-event:gift-transfer:{result.gift_id}",
        "🎁 <b>عملية إهداء رصيد</b>\n\n"
        f"📤 <code>{result.sender_id}</code> → 📥 <code>{result.recipient_id}</code>\n"
        f"💰 <code>{result.amount:,}</code> SYP")

@router.callback_query(F.data=="gift:code")
async def code_start(callback:CallbackQuery,state:FSMContext,runtime_settings:RuntimeSettingsService)->None:
    await state.clear(); await state.set_state(GiftStates.code)
    await safe_edit(callback,render_message(runtime_settings,"gift_code_prompt"),reply_markup=_back())

@router.message(GiftStates.code)
async def code_enter(message:Message,state:FSMContext,gift_service:GiftService,runtime_settings:RuntimeSettingsService,outbox_worker:NotificationOutboxWorker)->None:
    code=(message.text or '').strip()
    try: result=await gift_service.redeem_code(message.from_user.id,code)
    except Exception as exc:
        await message.answer(f"❌ {html.escape(str(exc) or 'الكود غير صالح.')}",reply_markup=_back()); return
    await state.clear()
    await message.answer(render_message(runtime_settings,"gift_code_success",code=html.escape(result['code']),amount=f"{result['amount_syp']:,}",balance=f"{result['new_balance']:,}"),reply_markup=_back())
    await _notify_admin(outbox_worker, f"admin-event:gift-code:{result['code']}:{message.from_user.id}",
        "🎁 <b>تم استخدام كود هدية</b>\n\n"
        f"🎟 <code>{html.escape(result['code'])}</code>\n👤 <code>{message.from_user.id}</code>\n"
        f"💰 <code>{result['amount_syp']:,}</code> SYP\n📊 {result['uses_count']}/{result['max_uses']}")

@router.callback_query(F.data=="gift:history")
async def gift_history_home(callback:CallbackQuery)->None:
    kb=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎁 سجل الإهداء",callback_data="gift:history:transfers:0")],
        [InlineKeyboardButton(text="🎟 سجل أكواد الهدايا",callback_data="gift:history:codes:0")],
        [InlineKeyboardButton(text="⬅️ الرئيسية",callback_data="core:home")],
    ])
    await safe_edit(callback,"🧾 <b>سجل الهدايا</b>\n\nاختر السجل:",reply_markup=kb)

@router.callback_query(F.data.startswith("gift:history:transfers:"))
async def gift_history_transfers(callback:CallbackQuery,gift_service:GiftService)->None:
    page=max(0,int(callback.data.rsplit(':',1)[-1])); rows,total=await gift_service.repo.gift_history(callback.from_user.id,limit=PAGE,offset=page*PAGE)
    lines=["🎁 <b>سجل الإهداء</b>",""]
    for r in rows:
        sent=int(r['from_telegram_id'])==callback.from_user.id
        other=int(r['to_telegram_id'] if sent else r['from_telegram_id'])
        lines.append(f"{'📤 أرسلت إلى' if sent else '📥 استلمت من'} <code>{other}</code> — <code>{int(r['amount_syp']):,}</code> SYP\n🕒 <code>{r['created_at']}</code>")
    if not rows: lines.append("لا توجد عمليات إهداء حتى الآن.")
    pages=max(1,math.ceil(total/PAGE)); nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️",callback_data=f"gift:history:transfers:{page-1}"))
    nav.append(InlineKeyboardButton(text=f"{page+1}/{pages}",callback_data="noop"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="➡️",callback_data=f"gift:history:transfers:{page+1}"))
    await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=[nav,[InlineKeyboardButton(text="⬅️ سجل الهدايا",callback_data="gift:history")]]))

@router.callback_query(F.data.startswith("gift:history:codes:"))
async def gift_history_codes(callback:CallbackQuery,gift_service:GiftService)->None:
    page=max(0,int(callback.data.rsplit(':',1)[-1])); rows,total=await gift_service.repo.code_history(callback.from_user.id,limit=PAGE,offset=page*PAGE)
    lines=["🎟 <b>سجل أكواد الهدايا</b>",""]
    for r in rows: lines.append(f"<code>{html.escape(str(r['code']))}</code> — <b>{int(r['amount_syp']):,} SYP</b>\n🕒 <code>{r['used_at']}</code>")
    if not rows: lines.append("لم تستخدم أكواد هدايا بعد.")
    pages=max(1,math.ceil(total/PAGE)); nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️",callback_data=f"gift:history:codes:{page-1}"))
    nav.append(InlineKeyboardButton(text=f"{page+1}/{pages}",callback_data="noop"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="➡️",callback_data=f"gift:history:codes:{page+1}"))
    await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=[nav,[InlineKeyboardButton(text="⬅️ سجل الهدايا",callback_data="gift:history")]]))

# ---------------- loyalty ----------------

@router.callback_query(F.data=="loyalty:home")
async def loyalty_home(callback:CallbackQuery,loyalty_service:LoyaltyService,runtime_settings:RuntimeSettingsService)->None:
    s=await loyalty_service.summary(callback.from_user.id); cfg=s['config']
    text=render_message(runtime_settings,"loyalty_home",points=f"{int(s['points']):,}",total_earned=f"{int(s['total_earned']):,}",total_redeemed=f"{int(s['total_redeemed']):,}",earn_syp_per_point=f"{int(cfg['earn_syp_per_point']):,}",min_deposit_syp=f"{int(cfg['min_deposit_syp']):,}",status_note=("\n\n⛔ النظام متوقف مؤقتًا من الإدارة." if not cfg['enabled'] else ""))
    rows=[]
    if cfg['enabled']: rows.append([InlineKeyboardButton(text="🎁 الجوائز",callback_data="loyalty:rewards:0")])
    rows += [[InlineKeyboardButton(text="📋 سجل النقاط",callback_data="loyalty:history:0")],[InlineKeyboardButton(text="⬅️ الرئيسية",callback_data="core:home")]]
    await safe_edit(callback,text,reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))

@router.callback_query(F.data.startswith("loyalty:rewards:"))
async def loyalty_rewards(callback:CallbackQuery,loyalty_service:LoyaltyService)->None:
    page=max(0,int(callback.data.rsplit(':',1)[-1])); summary=await loyalty_service.summary(callback.from_user.id)
    if not summary['config']['enabled']: await callback.answer("نظام نقاط الولاء متوقف حاليًا.",show_alert=True); return
    rewards,total=await loyalty_service.repo.rewards(limit=6,offset=page*6)
    rows=[]
    for r in rewards:
        lock="✅" if int(summary['points'])>=int(r['points_cost']) and r['available'] else "🔒"
        rows.append([InlineKeyboardButton(text=f"{lock} {str(r['name'])[:28]} — {int(r['points_cost']):,} نقطة",callback_data=f"loyalty:reward:{r['id']}:{page}")])
    pages=max(1,math.ceil(total/6)); nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️",callback_data=f"loyalty:rewards:{page-1}"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="➡️",callback_data=f"loyalty:rewards:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="⬅️ نقاط الولاء",callback_data="loyalty:home")])
    await safe_edit(callback,f"🎁 <b>جوائز نقاط الولاء</b>\n\nرصيدك: <b>{int(summary['points']):,} نقطة</b>"+("\n\nلا توجد جوائز متاحة." if not rewards else ""),reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))

@router.callback_query(F.data.startswith("loyalty:reward:"))
async def loyalty_reward_detail(callback:CallbackQuery,loyalty_service:LoyaltyService)->None:
    p=callback.data.split(':'); rid=int(p[2]); page=int(p[3]); reward=await loyalty_service.repo.reward(rid); summary=await loyalty_service.summary(callback.from_user.id)
    if not reward or not reward['enabled']: await callback.answer("الجائزة غير متاحة.",show_alert=True); return
    cost=int(reward['points_cost']); points=int(summary['points']); rtype=str(reward['reward_type'])
    lines=[f"🎁 <b>{html.escape(str(reward['name']))}</b>","",f"التكلفة: <b>{cost:,} نقطة</b>",f"رصيدك: <b>{points:,} نقطة</b>"]
    if rtype=='balance': lines += [f"💰 رصيد البوت: <b>{int(reward['balance_amount_syp']):,} SYP</b>","🔒 الرصيد الناتج غير قابل للإهداء لمستخدم آخر."]
    elif reward['remaining_stock'] is not None: lines.append(f"📦 المتبقي: <b>{int(reward['remaining_stock']):,}</b>")
    if not reward['available']: lines.append("\n❌ نفدت هذه الجائزة.")
    elif points<cost: lines.append(f"\n🔒 تحتاج {cost-points:,} نقطة إضافية.")
    rows=[]
    if reward['available'] and points>=cost: rows.append([InlineKeyboardButton(text="✅ تأكيد الاستبدال",callback_data=f"loyalty:claim:{rid}:{page}")])
    rows.append([InlineKeyboardButton(text="⬅️ الجوائز",callback_data=f"loyalty:rewards:{page}")])
    await safe_edit(callback,"\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))

@router.callback_query(F.data.startswith("loyalty:claim:"))
async def loyalty_claim(callback:CallbackQuery,loyalty_service:LoyaltyService,runtime_settings:RuntimeSettingsService,outbox_worker:NotificationOutboxWorker)->None:
    p=callback.data.split(':'); rid=int(p[2])
    try: result=await loyalty_service.claim_reward(callback.from_user.id,rid)
    except Exception as exc: await callback.answer(str(exc)[:180],show_alert=True); return
    if result['reward_type']=='balance':
        text=render_message(runtime_settings,"loyalty_balance_success",reward_name=html.escape(result['reward_name']),points_spent=f"{result['points_spent']:,}",balance_amount=f"{result['balance_amount_syp']:,}",balance=f"{int(result['new_balance'] or 0):,}")
    else:
        text=render_message(runtime_settings,"loyalty_manual_success",reward_name=html.escape(result['reward_name']),points_spent=f"{result['points_spent']:,}",claim_id=str(result['claim_id']))
    await safe_edit(callback,text,reply_markup=_back("loyalty:home"))
    await _notify_admin(outbox_worker, f"admin-event:loyalty-claim:{result['claim_id']}",
        "⭐ <b>استبدال نقاط الولاء</b>\n\n"
        f"👤 <code>{callback.from_user.id}</code>\n🎁 {html.escape(result['reward_name'])}\n"
        f"⭐ <code>{result['points_spent']:,}</code> نقطة\n🧾 <code>{result['claim_id']}</code>")

@router.callback_query(F.data.startswith("loyalty:history:"))
async def loyalty_history(callback:CallbackQuery,loyalty_service:LoyaltyService)->None:
    page=max(0,int(callback.data.rsplit(':',1)[-1])); rows,total=await loyalty_service.repo.loyalty_history(callback.from_user.id,limit=PAGE,offset=page*PAGE)
    names={'earn':'اكتساب من شحن','reward_balance':'جائزة رصيد','reward_request':'طلب جائزة','reward_refund':'إرجاع نقاط','admin_adjust':'تعديل إداري','admin_reset':'تصفير إداري'}
    lines=["📋 <b>سجل نقاط الولاء</b>",""]
    for r in rows:
        delta=int(r['points_delta']); lines.append(f"{names.get(str(r['event_type']),str(r['event_type']))}: <code>{delta:+,}</code> نقطة\n🕒 <code>{r['created_at']}</code>")
    if not rows: lines.append("لا توجد عمليات نقاط حتى الآن.")
    pages=max(1,math.ceil(total/PAGE)); nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️",callback_data=f"loyalty:history:{page-1}"))
    nav.append(InlineKeyboardButton(text=f"{page+1}/{pages}",callback_data="noop"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="➡️",callback_data=f"loyalty:history:{page+1}"))
    await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=[nav,[InlineKeyboardButton(text="⬅️ نقاط الولاء",callback_data="loyalty:home")]]))
