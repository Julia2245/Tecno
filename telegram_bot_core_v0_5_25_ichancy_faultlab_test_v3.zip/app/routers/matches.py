from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from app.core.ui import safe_edit
from app.services.matches import LEAGUES, ORDER, MatchesService

router = Router(name="matches")


def _menu_keyboard() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=LEAGUES[key][0], callback_data=f"menu:matches:{key}")] for key in ORDER]
    rows.append([InlineKeyboardButton(text="⬅️ رجوع", callback_data="core:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _league_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="menu:matches")],
    ])


@router.callback_query(F.data == "menu:matches")
async def matches_home(callback: CallbackQuery, matches_service: MatchesService) -> None:
    info = matches_service.cache_info()
    await safe_edit(
        callback,
        "⚽ <b>مباريات اليوم</b>\n\n"
        "اختر البطولة التي تريد عرض مبارياتها اليوم 👇\n\n"
        f"🗓 التاريخ: <code>{info['day']}</code>\n"
        f"🔄 آخر تحديث: <code>{info['updated_at']}</code>",
        reply_markup=_menu_keyboard(),
    )


@router.callback_query(F.data.regexp(r"^menu:matches:(laliga|epl|ucl|uel|seriea|bundesliga|ligue1|mixed)$"))
@router.callback_query(F.data.regexp(r"^matches:(laliga|epl|ucl|uel|seriea|bundesliga|ligue1|mixed)$"))
async def matches_league(callback: CallbackQuery, matches_service: MatchesService) -> None:
    key = str(callback.data).rsplit(":", 1)[-1]
    rows, note = await matches_service.today(key)
    info = matches_service.cache_info()
    lines = [f"{LEAGUES[key][0]}", ""]
    if note:
        lines.extend([f"ℹ️ {note}", ""])
    if rows:
        for row in rows[:20]:
            lines.append(matches_service.format_fixture(row))
    else:
        lines.append("لا توجد مباريات اليوم في هذه البطولة حالياً.")
    lines.extend(["", f"🗓 التاريخ: {info['day']}", f"🔄 آخر تحديث: {info['updated_at']}"])
    await safe_edit(callback, "\n".join(lines)[:3900], reply_markup=_league_keyboard())
