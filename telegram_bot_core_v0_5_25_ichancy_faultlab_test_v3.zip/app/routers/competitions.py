from __future__ import annotations

import html
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.core.ui import safe_edit
from app.services.competitions import CompetitionError, CompetitionService

router=Router(name='competitions')

class PredictionStates(StatesGroup):
    first=State(); second=State(); confirm=State()

def _back(data='contest:home'):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='⬅️ رجوع',callback_data=data)]])

def _contest_title(c)->str:
    t=str(c['template_type'])
    if t=='match_prediction': return f"⚽ {c['team1_name'] or 'الفريق الأول'} × {c['team2_name'] or 'الفريق الثاني'}"
    return {'cash_luck':'💸 مسابقة الحظ النقدي','top_depositors':'🏆 أعلى الشاحنين','deposit_raffle':'🎟 سحب الشاحنين'}.get(t,'🏆 مسابقة')

def _contest_text(c,entry=None)->str:
    prize='رصيد ترويجي لاستخدام iChancy' if c['prize_type']=='balance' else 'بونص على أول شحن ناجح'
    lines=[_contest_title(c), '', f"🎁 الجائزة لكل فائز: <b>{c['prize_value']}</b> — {prize}", f"👥 عدد الفائزين: <code>{int(c['winners_count'])}</code>", f"⏳ تنتهي: <code>{c['end_at']}</code>"]
    t=str(c['template_type'])
    if t=='match_prediction':
        names={'score':'النتيجة','corners':'الركنيات','cards':'البطاقات'}
        lines.append(f"🎯 نوع التوقع: <b>{names.get(str(c['prediction_type']),str(c['prediction_type']))}</b>")
        if entry: lines.append(f"✅ توقعك المسجل: <code>{entry['value1']} - {entry['value2']}</code>")
    elif t=='cash_luck': lines.append('🔢 الفوز فوري إذا انتهى رقم عملية الشحن بإحدى النهايات الفائزة.')
    elif t=='top_depositors': lines.append('📈 الترتيب حسب مجموع أصل الشحن الحقيقي خلال فترة المسابقة.')
    else: lines.append('🎟 كل شحن ناجح يدخل السحب حسب إعداد المسابقة.')
    if c['status']=='completed': lines.append('✅ <b>المسابقة منتهية</b>')
    elif c['status']=='waiting_result': lines.append('⏳ <b>بانتظار إدخال النتيجة</b>')
    return '\n'.join(lines)

@router.callback_query(F.data=='contest:home')
async def contest_home(callback:CallbackQuery,competition_service:CompetitionService,state:FSMContext)->None:
    await state.clear(); rows=await competition_service.repository.active_contests(20); roulettes=await competition_service.repository.active_roulettes(20)
    kb=[]
    for c in rows: kb.append([InlineKeyboardButton(text=_contest_title(c)[:60],callback_data=f"contest:view:{int(c['id'])}")])
    if roulettes: kb.append([InlineKeyboardButton(text=f"🎲 الروليت النشطة ({len(roulettes)})",callback_data='roulette:home')])
    kb.append([InlineKeyboardButton(text='🏆 الفائزون',callback_data='contest:winners:all')])
    kb.append([InlineKeyboardButton(text='⬅️ الرئيسية',callback_data='core:home')])
    text='🏆 <b>المسابقات</b>\n\nاختر المسابقة التي تريد عرضها.' if rows or roulettes else '🏆 <b>المسابقات</b>\n\nلا توجد مسابقات أو روليت نشطة حاليًا.'
    await safe_edit(callback,text,reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith('contest:view:'))
async def contest_view(callback:CallbackQuery,competition_service:CompetitionService)->None:
    try: cid=int(callback.data.rsplit(':',1)[-1])
    except Exception: return
    c=await competition_service.repository.get_contest(cid)
    if not c: await safe_edit(callback,'❌ المسابقة غير موجودة.',reply_markup=_back()); return
    entry=await competition_service.repository.user_contest_entry(cid,callback.from_user.id)
    kb=[]
    if c['status']=='active' and c['template_type']=='match_prediction' and entry is None:
        kb.append([InlineKeyboardButton(text='🎯 سجل توقعك',callback_data=f'contest:predict:{cid}')])
    if c['template_type'] in {'cash_luck','top_depositors','deposit_raffle'} and c['status']=='active':
        kb.append([InlineKeyboardButton(text='💳 شحن للمشاركة',callback_data='deposit:methods')])
    if c['template_type']=='top_depositors':
        kb.append([InlineKeyboardButton(text='👑 ترتيب أعلى الشاحنين',callback_data=f'contest:ranking:{cid}')])
    awards=await competition_service.repository.contest_awards(cid)
    if awards:
        kb.append([InlineKeyboardButton(text='🏅 الفائزون',callback_data=f'contest:winners:{cid}')])
    kb.append([InlineKeyboardButton(text='⬅️ المسابقات',callback_data='contest:home')])
    await safe_edit(callback,_contest_text(c,entry),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith('contest:winners:'))
async def contest_winners(callback:CallbackQuery,competition_service:CompetitionService)->None:
    token=callback.data.rsplit(':',1)[-1]
    pool=competition_service.db.require_pool()
    async with pool.acquire() as conn:
        if token=='all':
            rows=await conn.fetch("""SELECT a.*,u.first_name,u.username FROM bot_core.contest_awards a LEFT JOIN bot_core.users u ON u.telegram_id=a.telegram_id ORDER BY a.awarded_at DESC,a.id DESC LIMIT 20""")
            cid=None
        else:
            cid=int(token)
            rows=await conn.fetch("""SELECT a.*,u.first_name,u.username FROM bot_core.contest_awards a LEFT JOIN bot_core.users u ON u.telegram_id=a.telegram_id WHERE a.contest_id=$1 ORDER BY a.position""",cid)
    lines=['🏆 <b>الفائزون</b>','']
    for r in rows:
        name=str(r['first_name'] or (f"@{r['username']}" if r['username'] else f"ID {int(r['telegram_id'])}"))
        prize=(f"بونص {r['prize_value']}%" if r['prize_type']=='deposit_bonus' else f"{r['prize_value']} SYP")
        prefix=f"مسابقة #{int(r['contest_id'])} • " if cid is None else f"#{int(r['position'])} — "
        lines.append(f"🏆 {prefix}<b>{html.escape(name)}</b> — {html.escape(prize)}")
    if not rows: lines.append('لا يوجد فائزون معلنون حتى الآن.')
    back='contest:home' if cid is None else f'contest:view:{cid}'
    await safe_edit(callback,'\n'.join(lines),reply_markup=_back(back))

@router.callback_query(F.data.startswith('contest:ranking:'))
async def contest_ranking(callback:CallbackQuery,competition_service:CompetitionService)->None:
    cid=int(callback.data.rsplit(':',1)[-1]); pool=competition_service.db.require_pool()
    async with pool.acquire() as conn:
        rows=await conn.fetch("""SELECT e.telegram_id,COALESCE(u.first_name,'') AS first_name,u.username,SUM(e.base_amount_syp)::bigint AS total_syp
                                 FROM bot_core.contest_entries e LEFT JOIN bot_core.users u ON u.telegram_id=e.telegram_id
                                 WHERE e.contest_id=$1 AND e.entry_kind='top_deposit' AND e.eligible
                                 GROUP BY e.telegram_id,u.first_name,u.username ORDER BY total_syp DESC,e.telegram_id LIMIT 5""",cid)
    medals=['🥇','🥈','🥉','4️⃣','5️⃣']; lines=['👑 <b>ترتيب أعلى الشاحنين</b>','']
    for i,r in enumerate(rows):
        name=str(r['first_name'] or (f"@{r['username']}" if r['username'] else f"ID {int(r['telegram_id'])}"))
        lines.append(f"{medals[i]} <b>{html.escape(name)}</b> — <code>{int(r['total_syp']):,}</code> SYP")
    if not rows: lines.append('لا يوجد شحن مؤهل حتى الآن.')
    await safe_edit(callback,'\n'.join(lines),reply_markup=_back(f'contest:view:{cid}'))

@router.callback_query(F.data.startswith('contest:predict:'))
async def predict_start(callback:CallbackQuery,state:FSMContext,competition_service:CompetitionService)->None:
    cid=int(callback.data.rsplit(':',1)[-1]); c=await competition_service.repository.get_contest(cid)
    if not c or c['template_type']!='match_prediction' or c['status']!='active':
        await callback.answer('التوقع غير متاح الآن.',show_alert=True); return
    if await competition_service.repository.user_contest_entry(cid,callback.from_user.id):
        await callback.answer('تم تسجيل توقعك مسبقًا.',show_alert=True); return
    await state.set_state(PredictionStates.first); await state.update_data(contest_id=cid,prediction_type=str(c['prediction_type']),team1=str(c['team1_name'] or 'الفريق الأول'),team2=str(c['team2_name'] or 'الفريق الثاني'))
    label={'score':'أهداف','corners':'ركنيات','cards':'بطاقات'}.get(str(c['prediction_type']),'قيمة')
    await safe_edit(callback,f"🎯 أرسل عدد {label} <b>{html.escape(str(c['team1_name'] or 'الفريق الأول'))}</b>:",reply_markup=_back(f'contest:view:{cid}'))

@router.message(PredictionStates.first)
async def predict_first(message:Message,state:FSMContext)->None:
    raw=(message.text or '').strip()
    if not raw.isdigit() or not (0<=int(raw)<=99): await message.answer('❌ أرسل رقمًا من 0 إلى 99.'); return
    await state.update_data(value1=int(raw)); data=await state.get_data(); await state.set_state(PredictionStates.second)
    label={'score':'أهداف','corners':'ركنيات','cards':'بطاقات'}.get(data.get('prediction_type'),'قيمة')
    await message.answer(f"🎯 أرسل عدد {label} <b>{html.escape(data.get('team2','الفريق الثاني'))}</b>:")

@router.message(PredictionStates.second)
async def predict_second(message:Message,state:FSMContext)->None:
    raw=(message.text or '').strip()
    if not raw.isdigit() or not (0<=int(raw)<=99): await message.answer('❌ أرسل رقمًا من 0 إلى 99.'); return
    await state.update_data(value2=int(raw)); data=await state.get_data(); await state.set_state(PredictionStates.confirm)
    await message.answer(f"🎯 توقعك:\n<b>{html.escape(data['team1'])}</b> {data['value1']} - {int(raw)} <b>{html.escape(data['team2'])}</b>",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='✅ تأكيد',callback_data='contest:predict:confirm'),InlineKeyboardButton(text='❌ إلغاء',callback_data=f"contest:view:{data['contest_id']}")]]))

@router.callback_query(PredictionStates.confirm,F.data=='contest:predict:confirm')
async def predict_confirm(callback:CallbackQuery,state:FSMContext,competition_service:CompetitionService)->None:
    data=await state.get_data()
    try: await competition_service.submit_prediction(int(data['contest_id']),callback.from_user.id,int(data['value1']),int(data['value2']))
    except CompetitionError as exc:
        await state.clear(); await safe_edit(callback,f"❌ {html.escape(str(exc))}",reply_markup=_back('contest:home')); return
    cid=int(data['contest_id']); await state.clear(); await safe_edit(callback,'✅ تم تسجيل توقعك بنجاح. لا يمكن تعديله بعد التأكيد.',reply_markup=_back(f'contest:view:{cid}'))

@router.callback_query(F.data=='roulette:home')
async def roulette_home(callback:CallbackQuery,competition_service:CompetitionService)->None:
    rows=await competition_service.repository.active_roulettes(20); kb=[]
    for r in rows: kb.append([InlineKeyboardButton(text=f"🎲 روليت #{int(r['id'])}",callback_data=f"roulette:view:{int(r['id'])}")])
    kb.append([InlineKeyboardButton(text='⬅️ المسابقات',callback_data='contest:home')])
    await safe_edit(callback,'🎲 <b>الروليت</b>\n\nاختر الجولة:' if rows else '🎲 لا توجد جولة روليت نشطة حاليًا.',reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith('roulette:view:'))
async def roulette_view(callback:CallbackQuery,competition_service:CompetitionService)->None:
    rid=int(callback.data.rsplit(':',1)[-1]); r=await competition_service.repository.get_roulette(rid)
    if not r: await safe_edit(callback,'❌ الروليت غير موجودة.',reply_markup=_back('roulette:home')); return
    chances=await competition_service.repository.user_roulette_chances(rid,callback.from_user.id)
    mode='مجانية' if r['participation_mode']=='free' else f"بالشحن — الحد الأدنى {int(r['min_deposit_syp']):,} SYP لكل فرصة"
    text=f"🎲 <b>روليت #{rid}</b>\n\n🎟 المشاركة: {mode}\n🏆 الفائزون: <code>{int(r['winners_count'])}</code>\n🎫 فرصك: <code>{chances}</code>\n⏳ النهاية: <code>{r['end_at']}</code>\n📌 الحالة: <b>{r['status']}</b>"
    kb=[]
    if r['status']=='active' and r['participation_mode']=='free' and chances==0: kb.append([InlineKeyboardButton(text='🎟 مشاركة مجانية',callback_data=f'roulette:join:{rid}')])
    if r['status']=='active' and r['participation_mode']=='deposit': kb.append([InlineKeyboardButton(text='💳 اشحن لتحصل على فرصة',callback_data='deposit:methods')])
    if r['status']=='completed': kb.append([InlineKeyboardButton(text='🏅 النتيجة',callback_data=f'roulette:result:{rid}')])
    kb.append([InlineKeyboardButton(text='⬅️ الروليت',callback_data='roulette:home')])
    await safe_edit(callback,text,reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith('roulette:join:'))
async def roulette_join(callback:CallbackQuery,competition_service:CompetitionService)->None:
    rid=int(callback.data.rsplit(':',1)[-1])
    try: chances=await competition_service.join_free_roulette(rid,callback.from_user.id)
    except CompetitionError as exc: await callback.answer(str(exc),show_alert=True); return
    await callback.answer(f'✅ تم تسجيل مشاركتك. فرصك: {chances}',show_alert=True); await roulette_view(callback,competition_service)

@router.callback_query(F.data.startswith('roulette:result:'))
async def roulette_result(callback:CallbackQuery,competition_service:CompetitionService)->None:
    rid=int(callback.data.rsplit(':',1)[-1]); pool=competition_service.db.require_pool()
    async with pool.acquire() as conn:
        rows=await conn.fetch("""SELECT a.*,u.first_name,u.username FROM bot_core.roulette_awards a LEFT JOIN bot_core.users u ON u.telegram_id=a.telegram_id WHERE a.roulette_id=$1 ORDER BY a.position""",rid)
    lines=[f'🏅 <b>نتيجة الروليت #{rid}</b>','']
    for r in rows:
        prize=(html.escape(str(r['custom_text'])) if r['prize_type']=='custom' else html.escape(str(r['prize_value'])))
        name=str(r['first_name'] or (f"@{r['username']}" if r['username'] else f"ID {int(r['telegram_id'])}"))
        lines.append(f"#{int(r['position'])} — <b>{html.escape(name)}</b> • {prize}")
    if not rows: lines.append('لم تُسحب النتيجة بعد.')
    await safe_edit(callback,'\n'.join(lines),reply_markup=_back(f'roulette:view:{rid}'))
