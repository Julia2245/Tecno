from __future__ import annotations

import html
from datetime import datetime

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.services.reports import ReportsService

router = Router(name="admin_reports")


class ReportState(StatesGroup):
    custom_start = State()
    custom_end = State()


def _is_admin(uid: int, settings: Settings) -> bool:
    return int(uid) in settings.super_admin_ids


def _menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📅 اليوم",callback_data="admin:report:today"),InlineKeyboardButton(text="⏮ أمس",callback_data="admin:report:yesterday")],
        [InlineKeyboardButton(text="📆 هذا الأسبوع",callback_data="admin:report:week"),InlineKeyboardButton(text="🗓 هذا الشهر",callback_data="admin:report:month")],
        [InlineKeyboardButton(text="📚 هذه السنة",callback_data="admin:report:year"),InlineKeyboardButton(text="🔎 فترة مخصصة",callback_data="admin:report:custom")],
        [InlineKeyboardButton(text="📊 ملخص 24 ساعة",callback_data="admin:users:overview")],
        [InlineKeyboardButton(text="⬅️ لوحة الإدارة",callback_data="admin:home")],
    ])


@router.callback_query(F.data == "admin:reports")
async def reports_home(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    await state.clear()
    await safe_edit(callback,"📈 <b>التقارير المالية</b>\n\nاختر الفترة المطلوبة.\n\nالأرقام تعتمد على وقت نجاح العملية، وتفصل أصل الشحن الحقيقي عن البونص والائتمانات الداخلية. صافي التدفق النقدي ليس ربحاً.",reply_markup=_menu())


def _money(v: object) -> str:
    try: return f"{int(v or 0):,}"
    except Exception: return "0"


def _method_label(key: str) -> str:
    return {"syriatel":"سيرياتيل كاش","sham_syp":"شام كاش — SYP","sham_usd":"شام كاش — USD","whish_money":"Whish Money","binance_trc20":"USDT TRC20","binance_bep20":"USDT BEP20","shamcash":"شام كاش","hawala":"حوالة","usdt":"USDT"}.get(key,key)


def _report_actions(period: str) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="💳 تفاصيل الشحن", callback_data=f"admin:report_detail:deposits:{period}"), InlineKeyboardButton(text="💸 تفاصيل السحب", callback_data=f"admin:report_detail:withdrawals:{period}")],
        [InlineKeyboardButton(text="🎁 تفاصيل المكافآت", callback_data=f"admin:report_detail:rewards:{period}"), InlineKeyboardButton(text="🎰 iChancy", callback_data=f"admin:report_detail:ichancy:{period}")],
        [InlineKeyboardButton(text="👛 المحافظ", callback_data=f"admin:report_detail:wallet:{period}"), InlineKeyboardButton(text="👥 المستخدمون", callback_data=f"admin:report_detail:users:{period}")],
        [InlineKeyboardButton(text="🏆 أعلى الشاحنين", callback_data=f"admin:report_detail:top:{period}")],
        [InlineKeyboardButton(text="🔄 تحديث", callback_data=f"admin:report:{period}"), InlineKeyboardButton(text="📈 فترات أخرى", callback_data="admin:reports")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _detail_text(r: dict, section: str) -> str:
    head = f"📊 <b>تفاصيل التقرير — {html.escape(str(r['label']))}</b>\n\n"
    if section == "deposits":
        lines = [head + "💳 <b>الشحن الحقيقي حسب الوسيلة</b>"]
        for x in r["deposits"]:
            lines.append(
                f"\n<b>{html.escape(_method_label(str(x['method'])))}</b>\n"
                f"• العمليات: {int(x['count'])}\n"
                f"• الأصل الحقيقي: <code>{_money(x['base'])}</code>\n"
                f"• البونص: <code>{_money(x['bonus'])}</code>\n"
                f"• الإجمالي المضاف: <code>{_money(x['credited'])}</code>"
            )
        if not r["deposits"]: lines.append("\nلا توجد عمليات ناجحة خلال الفترة.")
        lines += ["", f"إجمالي الأصل: <b>{_money(r['total_real_deposits'])}</b>", f"إجمالي البونص: <b>{_money(r['total_deposit_bonuses'])}</b>"]
        return "\n".join(lines)
    if section == "withdrawals":
        lines = [head + "💸 <b>السحب حسب الوسيلة</b>"]
        for x in r["withdrawals"]:
            lines.append(
                f"\n<b>{html.escape(_method_label(str(x['method'])))}</b>\n"
                f"• العمليات: {int(x['count'])}\n"
                f"• المطلوب: <code>{_money(x['amount'])}</code>\n"
                f"• الصافي: <code>{_money(x['net'])}</code>\n"
                f"• العمولة: <code>{_money(x['fee'])}</code>"
            )
        if not r["withdrawals"]: lines.append("\nلا توجد عمليات ناجحة خلال الفترة.")
        lines += ["", f"إجمالي الصافي: <b>{_money(r['total_withdraw_net'])}</b>", f"إجمالي العمولات: <b>{_money(r['total_withdraw_fees'])}</b>"]
        return "\n".join(lines)
    if section == "rewards":
        rw=r["rewards"]
        referral=int(rw.get("referral_fixed") or 0)+int(rw.get("referral_cycle") or 0)
        wheel=int(rw.get("wheel") or 0)+int(rw.get("wheel_free") or 0)
        return head + (
            "🎁 <b>الأرصدة والمكافآت الداخلية</b>\n\n"
            f"• بونصات الشحن: <code>{_money(r['total_deposit_bonuses'])}</code>\n"
            f"• بونص دخول مباشر: <code>{_money(rw.get('welcome_instant'))}</code>\n"
            f"• عجلة الحظ: <code>{_money(wheel)}</code>\n"
            f"• الاسترداد: <code>{_money(rw.get('cashback'))}</code>\n"
            f"• الإحالات: <code>{_money(referral)}</code>\n"
            f"• أكواد الهدايا: <code>{_money(rw.get('gift_codes'))}</code>\n"
            f"• جوائز الولاء (رصيد): <code>{_money(rw.get('loyalty_balance'))}</code>\n"
            f"• جوائز مسابقات Promo iChancy الممنوحة: <code>{_money(rw.get('contest_promo_awarded'))}</code>\n"
            f"• جوائز روليت Promo iChancy الممنوحة: <code>{_money(rw.get('roulette_promo_awarded'))}</code>\n"
            f"• من بونصات الشحن — مسابقات: <code>{_money(rw.get('contest_bonus_used'))}</code>\n"
            f"• من بونصات الشحن — روليت: <code>{_money(rw.get('roulette_bonus_used'))}</code>\n"
            f"• إضافات الأدمن: <code>{_money(rw.get('admin_added'))}</code>\n"
            f"• خصومات الأدمن: <code>{_money(rw.get('admin_deducted'))}</code>\n\n"
            f"إجمالي الائتمانات الداخلية: <b>{_money(r['total_internal_credits'])}</b>"
        )
    if section == "ichancy":
        x=r["ichancy"]; dep=int(x.get("deposits") or 0); wd=int(x.get("withdrawals") or 0)
        return head + ("🎰 <b>حركة iChancy</b>\n\n" f"• عدد العمليات: <b>{int(x.get('count') or 0)}</b>\n" f"• الشحن الكلي: <code>{dep:,}</code>\n" f"  ├ من المحفظة: <code>{int(x.get('deposit_wallet') or 0):,}</code>\n" f"  └ Promo مسابقات/روليت: <code>{int(x.get('deposit_promo') or 0):,}</code>\n" f"• السحب: <code>{wd:,}</code>\n" f"• الصافي: <code>{dep-wd:+,}</code>")
    if section == "wallet":
        w=r["wallet"]; p=r["pending"]
        return head + ("👛 <b>لقطة المحفظة الحالية</b>\n\n" f"• المتاح: <code>{_money(w.get('available'))}</code>\n" f"• المحجوز: <code>{_money(w.get('held'))}</code>\n\n" "⏳ <b>عمليات غير محسومة الآن</b>\n" f"• شحن: <b>{int(p.get('deposits') or 0)}</b>\n" f"• سحب: <b>{int(p.get('withdrawals') or 0)}</b>\n" f"• iChancy: <b>{int(p.get('ichancy') or 0)}</b>")
    if section == "users":
        u=r["users"]
        return head + ("👥 <b>المستخدمون</b>\n\n" f"• جدد خلال الفترة: <b>{int(u.get('new_users') or 0)}</b>\n" f"• نشطون خلال الفترة: <b>{int(u.get('active_users') or 0)}</b>\n" f"• إجمالي المستخدمين: <b>{int(u.get('total_users') or 0)}</b>\n" f"• المحظورون حاليًا: <b>{int(u.get('blocked_users') or 0)}</b>")
    if section == "top":
        lines=[head + "🏆 <b>أعلى الشاحنين خلال الفترة</b>"]
        for i,x in enumerate(r["top_users"],1):
            name=x.get("first_name") or ("@"+str(x.get("username")) if x.get("username") else str(x.get("telegram_id")))
            lines.append(f"\n{i}. <b>{html.escape(str(name))}</b> — <code>{_money(x.get('total_base'))}</code>\n   {int(x.get('deposits_count') or 0)} عملية")
        if not r["top_users"]: lines.append("\nلا توجد نتائج خلال الفترة.")
        return "\n".join(lines)
    return head + "لا توجد تفاصيل لهذا القسم."


def _report_text(r: dict) -> str:
    start=r["start"].astimezone(__import__('zoneinfo').ZoneInfo("Asia/Damascus")); end=r["end"].astimezone(__import__('zoneinfo').ZoneInfo("Asia/Damascus"))
    lines=["📈 <b>التقرير المالي</b>","",f"📅 الفترة: <b>{html.escape(str(r['label']))}</b>",f"🕒 {start:%Y-%m-%d %H:%M} → {end:%Y-%m-%d %H:%M}","", "<b>💰 الشحن الحقيقي</b>"]
    if r["deposits"]:
        for x in r["deposits"]: lines.append(f"• {_method_label(str(x['method']))}: <code>{_money(x['base'])}</code> ({int(x['count'])} عملية) • بونص <code>{_money(x['bonus'])}</code>")
    else: lines.append("• لا توجد عمليات شحن ناجحة")
    lines += [f"إجمالي الأصل الحقيقي: <b>{_money(r['total_real_deposits'])} SYP</b>",f"إجمالي بونص الشحن: <code>{_money(r['total_deposit_bonuses'])}</code>","", "<b>💸 السحب</b>"]
    if r["withdrawals"]:
        for x in r["withdrawals"]: lines.append(f"• {_method_label(str(x['method']))}: <code>{_money(x['net'])}</code> صافي ({int(x['count'])} عملية) • رسوم <code>{_money(x['fee'])}</code>")
    else: lines.append("• لا توجد عمليات سحب ناجحة")
    lines += [f"إجمالي المبلغ المطلوب: <code>{_money(r['total_withdraw_amount'])}</code>",f"إجمالي الصافي المدفوع: <b>{_money(r['total_withdraw_net'])}</b>",f"إجمالي العمولات: <code>{_money(r['total_withdraw_fees'])}</code>","",f"💵 <b>صافي التدفق النقدي:</b> <code>{int(r['net_cash_flow']):+,} SYP</code>","", "<b>🎁 الائتمانات الداخلية</b>"]
    rw=r["rewards"]
    lines += [f"• بونصات الشحن: <code>{_money(r['total_deposit_bonuses'])}</code>",f"• بونص أول دخول: <code>{_money(rw.get('welcome_instant'))}</code>",f"• عجلة الحظ: <code>{_money(int(rw.get('wheel') or 0)+int(rw.get('wheel_free') or 0))}</code>",f"• الاسترداد: <code>{_money(rw.get('cashback'))}</code>",f"• الإحالات: <code>{_money(int(rw.get('referral_fixed') or 0)+int(rw.get('referral_cycle') or 0))}</code>",f"• أكواد الهدايا: <code>{_money(rw.get('gift_codes'))}</code>",f"• جوائز الولاء (رصيد): <code>{_money(rw.get('loyalty_balance'))}</code>",f"• Promo مسابقات iChancy الممنوح: <code>{_money(rw.get('contest_promo_awarded'))}</code>",f"• Promo روليت iChancy الممنوح: <code>{_money(rw.get('roulette_promo_awarded'))}</code>",f"• إضافات الأدمن: <code>{_money(rw.get('admin_added'))}</code>",f"• خصومات الأدمن: <code>{_money(rw.get('admin_deducted'))}</code>",f"إجمالي الائتمانات الداخلية: <b>{_money(r['total_internal_credits'])}</b>","", "<b>🎰 iChancy</b>"]
    ich=r["ichancy"]; idep=int(ich.get("deposits") or 0); iwd=int(ich.get("withdrawals") or 0)
    lines += [f"• شحن كلي: <code>{idep:,}</code>",f"  ├ من المحفظة: <code>{int(ich.get('deposit_wallet') or 0):,}</code>",f"  └ Promo مسابقات/روليت: <code>{int(ich.get('deposit_promo') or 0):,}</code>",f"• سحب: <code>{iwd:,}</code>",f"• الصافي: <code>{idep-iwd:+,}</code>",f"• عدد العمليات: <b>{int(ich.get('count') or 0)}</b>","", "<b>👥 المستخدمون</b>"]
    us=r["users"]; lines += [f"• جدد خلال الفترة: <b>{int(us.get('new_users') or 0)}</b>",f"• نشطون خلال الفترة: <b>{int(us.get('active_users') or 0)}</b>",f"• الإجمالي: <b>{int(us.get('total_users') or 0)}</b>",f"• المحظورون: <b>{int(us.get('blocked_users') or 0)}</b>","", "<b>👛 المحفظة الآن</b>"]
    wa=r["wallet"]; lines += [f"• متاح: <code>{_money(wa.get('available'))}</code>",f"• محجوز: <code>{_money(wa.get('held'))}</code>","", "<b>⏳ غير محسوم الآن</b>"]
    pe=r["pending"]; lines += [f"• شحن: <b>{int(pe.get('deposits') or 0)}</b>",f"• سحب: <b>{int(pe.get('withdrawals') or 0)}</b>",f"• iChancy: <b>{int(pe.get('ichancy') or 0)}</b>"]
    if r["top_users"]:
        lines += ["", "<b>🏆 أعلى الشاحنين خلال الفترة</b>"]
        for i,x in enumerate(r["top_users"][:5],1):
            name=(x.get("first_name") or x.get("username") or x.get("telegram_id")); lines.append(f"{i}. {html.escape(str(name))} — <code>{_money(x.get('total_base'))}</code>")
    return "\n".join(lines)


@router.callback_query(F.data.regexp(r"^admin:report:(today|yesterday|week|month|year)$"))
async def report_period(callback: CallbackQuery, settings: Settings, reports_service: ReportsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    period=str(callback.data).rsplit(":",1)[-1]; r=await reports_service.financial_report(period)
    await safe_edit(callback, _report_text(r), reply_markup=_report_actions(period))


@router.callback_query(F.data.regexp(r"^admin:report_detail:(deposits|withdrawals|rewards|ichancy|wallet|users|top):(today|yesterday|week|month|year)$"))
async def report_detail(callback: CallbackQuery, settings: Settings, reports_service: ReportsService) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    parts=str(callback.data).split(":")
    section, period=parts[-2], parts[-1]
    r=await reports_service.financial_report(period)
    await safe_edit(
        callback, _detail_text(r, section),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ الكشف", callback_data=f"admin:report:{period}")],
            [InlineKeyboardButton(text="📈 فترات أخرى", callback_data="admin:reports")],
        ]),
    )


@router.callback_query(F.data == "admin:report:custom")
async def custom_start(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    await state.set_state(ReportState.custom_start)
    await safe_edit(callback,"🔎 <b>فترة مخصصة</b>\n\nأرسل تاريخ البداية بصيغة <code>YYYY-MM-DD</code>\nمثال: <code>2026-08-01</code>",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء",callback_data="admin:reports")]]))


@router.message(ReportState.custom_start)
async def custom_start_msg(message: Message, settings: Settings, state: FSMContext) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings): return
    raw=(message.text or "").strip()
    try: datetime.strptime(raw,"%Y-%m-%d")
    except Exception: await message.answer("❌ الصيغة غير صحيحة. أرسل YYYY-MM-DD."); return
    await state.update_data(start=raw); await state.set_state(ReportState.custom_end); await message.answer("📅 أرسل تاريخ النهاية بصيغة <code>YYYY-MM-DD</code>.")


@router.message(ReportState.custom_end)
async def custom_end_msg(message: Message, settings: Settings, reports_service: ReportsService, state: FSMContext) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings): return
    raw=(message.text or "").strip(); data=await state.get_data(); start=str(data.get("start") or "")
    try: r=await reports_service.financial_report("custom",start,raw)
    except Exception as exc: await message.answer(f"❌ {html.escape(str(exc))}"); return
    await state.clear(); await message.answer(_report_text(r),reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ التقارير",callback_data="admin:reports")]]))
