from __future__ import annotations

from html import escape

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.db import Database
from app.core.ui import safe_edit
from app.keyboards.common import admin_menu
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin")


class MaintenanceAdminState(StatesGroup):
    waiting_message = State()


def _maintenance_keyboard(enabled: bool) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=("🔴 إيقاف وضع الصيانة" if enabled else "🟢 تفعيل وضع الصيانة"),
                    callback_data="admin:maintenance:toggle",
                )
            ],
            [InlineKeyboardButton(text="✏️ تعديل رسالة الصيانة", callback_data="admin:maintenance:message")],
            [InlineKeyboardButton(text="⬅️ لوحة الإدارة", callback_data="admin:home")],
        ]
    )


def _maintenance_text(runtime_settings: RuntimeSettingsService) -> str:
    enabled = runtime_settings.get_bool("maintenance.enabled", False)
    message = str(
        runtime_settings.get(
            "maintenance.message",
            "🛠 البوت في وضع الصيانة حاليًا\n\nنعمل على بعض التحسينات. يرجى المحاولة مرة أخرى بعد انتهاء الصيانة.",
        )
        or ""
    )
    state = "🔴 مفعّل" if enabled else "🟢 متوقف"
    return (
        "🛠 <b>وضع الصيانة</b>\n\n"
        f"الحالة الحالية: <b>{state}</b>\n\n"
        "عند التفعيل يتم حظر كل تفاعلات المستخدمين قبل وصولها إلى أي مسار في البوت، "
        "بما فيها الأزرار الموجودة في الرسائل والقوائم القديمة.\n"
        "الأدمن يبقى مستثنى حتى يستطيع إدارة البوت وإيقاف الصيانة.\n\n"
        "العمليات المالية التي بدأت قبل التفعيل لا يتم إلغاؤها؛ عمال التسوية يكملونها بأمان.\n\n"
        f"<b>رسالة المستخدم الحالية:</b>\n<pre>{escape(message)}</pre>"
    )


def _is_admin(user_id: int, settings: Settings) -> bool:
    return user_id in settings.super_admin_ids


@router.message(Command("admin"))
async def admin_command(message: Message, settings: Settings) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings):
        return
    await message.answer("🛠 <b>لوحة الإدارة</b>\n\nالنواة المالية: Wallet + Deposits + Withdrawals + iChancy.\nإدارة المستخدمين والحماية المتزامنة: ✅", reply_markup=admin_menu())


@router.callback_query(F.data == "admin:home")
async def admin_home(callback: CallbackQuery, settings: Settings) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    await safe_edit(callback, "🛠 <b>لوحة الإدارة</b>\n\nالنواة المالية: Wallet + Deposits + Withdrawals + iChancy.\nإدارة المستخدمين والحماية المتزامنة: ✅", reply_markup=admin_menu())


@router.callback_query(F.data == "admin:status")
async def admin_status(callback: CallbackQuery, settings: Settings, db: Database) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    db_ok = await db.ping()
    await safe_edit(
        callback,
        "📊 <b>حالة النواة</b>\n\n"
        f"Telegram: ✅\nPostgreSQL: {'✅' if db_ok else '❌'}\n"
        "Wallet Core: ✅\nDeposits Core: ✅\nWithdrawals Core: ✅\niChancy Core: ✅",
        reply_markup=admin_menu(),
    )


@router.callback_query(F.data == "admin:maintenance")
async def admin_maintenance(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    await state.clear()
    enabled = runtime_settings.get_bool("maintenance.enabled", False)
    await safe_edit(callback, _maintenance_text(runtime_settings), reply_markup=_maintenance_keyboard(enabled))


@router.callback_query(F.data == "admin:maintenance:toggle")
async def admin_maintenance_toggle(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    await state.clear()
    new_value = not runtime_settings.get_bool("maintenance.enabled", False)
    await runtime_settings.set("maintenance.enabled", new_value, updated_by=callback.from_user.id)
    await safe_edit(callback, _maintenance_text(runtime_settings), reply_markup=_maintenance_keyboard(new_value))


@router.callback_query(F.data == "admin:maintenance:message")
async def admin_maintenance_message(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    await state.set_state(MaintenanceAdminState.waiting_message)
    current = str(runtime_settings.get("maintenance.message", "") or "")
    await safe_edit(
        callback,
        "✏️ <b>تعديل رسالة الصيانة</b>\n\n"
        "أرسل الرسالة الجديدة كنص عادي.\n"
        "الحد الأقصى 700 حرف.\n\n"
        f"<b>الحالية:</b>\n<pre>{escape(current)}</pre>",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="⬅️ إلغاء", callback_data="admin:maintenance")]]
        ),
    )


@router.message(MaintenanceAdminState.waiting_message)
async def admin_maintenance_message_save(
    message: Message, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings):
        return
    text = (message.text or "").strip()
    if not text:
        await message.answer("❌ أرسل نص رسالة الصيانة.")
        return
    if len(text) > 700:
        await message.answer("❌ رسالة الصيانة طويلة جدًا. الحد الأقصى 700 حرف.")
        return
    await runtime_settings.set("maintenance.message", text, updated_by=message.from_user.id)
    await state.clear()
    enabled = runtime_settings.get_bool("maintenance.enabled", False)
    await message.answer(
        "✅ تم حفظ رسالة الصيانة.\n\n" + _maintenance_text(runtime_settings),
        reply_markup=_maintenance_keyboard(enabled),
    )
