from __future__ import annotations

import html

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.user_experience import normalize_support_contact
from app.services.outbox import NotificationOutboxWorker
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin_support")


class SupportAdminStates(StatesGroup):
    waiting_value = State()
    waiting_channel = State()


_LABELS = {
    "telegram": "✈️ Telegram",
    "whatsapp": "🟢 WhatsApp",
    "facebook": "🔵 Facebook",
    "ichancy": "🎰 دعم iChancy",
}

# Keep the same seven destinations used by the reference bot.  Runtime keys are
# deliberately stable so financial producers never depend on UI labels.
_CHANNELS: tuple[tuple[str, str], ...] = (
    ("notify.ichancy_accounts", "🎰 قناة حسابات iChancy"),
    ("notify.ichancy_operations", "💱 قناة عمليات iChancy"),
    ("notify.admin_events", "🔔 إشعارات الأدمن"),
    ("notify.bot_deposits", "💰 قناة شحن البوت"),
    ("notify.manual_deposit_requests", "📦 قناة طلبات الشحن اليدوي"),
    ("notify.bot_withdrawals", "💸 قناة طلبات السحب"),
    ("backup.channel", "🧰 قناة النسخ الاحتياطي"),
)
_CHANNEL_LABEL = dict(_CHANNELS)
_CHANNEL_TOKEN = {key: f"c{i}" for i, (key, _label) in enumerate(_CHANNELS, 1)}
_TOKEN_CHANNEL = {token: key for key, token in _CHANNEL_TOKEN.items()}


def _admin(user_id: int, settings: Settings) -> bool:
    return user_id in settings.super_admin_ids


def _communications_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📣 الرسائل الجماعية", callback_data="admin:bcast")],
        [InlineKeyboardButton(text="☎️ إعدادات الدعم", callback_data="admin:support")],
        [InlineKeyboardButton(text="📡 قنوات الإشعارات", callback_data="admin:notify_channels")],
        [InlineKeyboardButton(text="⬅️ لوحة الإدارة", callback_data="admin:home")],
    ])


def _menu(runtime: RuntimeSettingsService) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for kind, label in _LABELS.items():
        visible = runtime.get_bool(f"support.{kind}_visible", True)
        rows.append([
            InlineKeyboardButton(text=f"✏️ {label}", callback_data=f"admin:support:edit:{kind}"),
            InlineKeyboardButton(
                text="👁️ ظاهر" if visible else "🙈 مخفي",
                callback_data=f"admin:support:toggle:{kind}",
            ),
        ])
    rows.append([InlineKeyboardButton(text="⬅️ إدارة التواصل والرسائل الجماعية", callback_data="admin:communications")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _text(runtime: RuntimeSettingsService) -> str:
    lines = ["📞 <b>إعدادات التواصل</b>", "", "يمكن تعديل الرابط وإظهار/إخفاء كل وسيلة بشكل مستقل.", ""]
    for kind, label in _LABELS.items():
        url = str(runtime.get(f"support.{kind}_url", "") or "").strip()
        visible = runtime.get_bool(f"support.{kind}_visible", True)
        lines.append(f"{label}: {'👁️' if visible else '🙈'} <code>{html.escape(url or 'غير مضبوط')}</code>")
    return "\n".join(lines)


def _shown_channel(runtime: RuntimeSettingsService, key: str) -> str:
    value = runtime.get(key, "")
    return "غير مضبوط" if value in (None, "", 0, "0") else str(value)


def _channels_text(runtime: RuntimeSettingsService) -> str:
    lines = [
        "📡 <b>قنوات الإشعارات</b>", "",
        "تم توحيد وجهات الإشعارات في مركز واحد. فشل Telegram لا يغيّر نتيجة أي عملية مالية.", "",
    ]
    for key, label in _CHANNELS:
        lines.extend([f"{label}:", f"<code>{html.escape(_shown_channel(runtime, key))}</code>", ""])
    return "\n".join(lines).rstrip()


def _channels_keyboard() -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for key, label in _CHANNELS:
        token = _CHANNEL_TOKEN[key]
        rows.append([InlineKeyboardButton(text=label, callback_data=f"admin:notify:edit:{token}")])
    rows.append([
        InlineKeyboardButton(text="🧪 اختبار قناة", callback_data="admin:notify:test_menu"),
    ])
    rows.append([InlineKeyboardButton(text="⬅️ إدارة التواصل والرسائل الجماعية", callback_data="admin:communications")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _test_menu() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=label, callback_data=f"admin:notify:test:{_CHANNEL_TOKEN[key]}")] for key, label in _CHANNELS]
    rows.append([InlineKeyboardButton(text="⬅️ قنوات الإشعارات", callback_data="admin:notify_channels")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _normalize_chat_target(raw: str) -> str:
    value = str(raw or "").strip()
    if value == "-":
        return ""
    if value.startswith("@") and len(value) >= 3 and all(ch.isalnum() or ch == "_" for ch in value[1:]):
        return value
    if value.startswith("-100") and value[1:].isdigit() and len(value) >= 10:
        return value
    raise ValueError("أرسل معرف قناة بصيغة -100... أو @channel، أو - لتعطيل القناة.")


@router.callback_query(F.data == "admin:communications")
async def communications_home(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await state.clear()
    await safe_edit(
        callback,
        "💬 <b>إدارة التواصل والرسائل الجماعية</b>\n\n"
        "من هنا تتم إدارة الدعم، الحملات الجماعية، وجميع قنوات الإشعارات.",
        reply_markup=_communications_menu(),
    )


@router.callback_query(F.data == "admin:support")
async def support_home(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await state.clear()
    await safe_edit(callback, _text(runtime_settings), reply_markup=_menu(runtime_settings))


@router.callback_query(F.data.regexp(r"^admin:support:toggle:(telegram|whatsapp|facebook|ichancy)$"))
async def support_toggle(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    kind = str(callback.data).rsplit(":", 1)[-1]
    new_value = not runtime_settings.get_bool(f"support.{kind}_visible", True)
    await runtime_settings.set(f"support.{kind}_visible", new_value, updated_by=callback.from_user.id)
    await safe_edit(callback, _text(runtime_settings), reply_markup=_menu(runtime_settings))


@router.callback_query(F.data.regexp(r"^admin:support:edit:(telegram|whatsapp|facebook|ichancy)$"))
async def support_edit(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    kind = str(callback.data).rsplit(":", 1)[-1]
    current = str(runtime_settings.get(f"support.{kind}_url", "") or "")
    await state.set_state(SupportAdminStates.waiting_value)
    await state.update_data(support_kind=kind)
    extra = {
        "telegram": "أرسل @username أو رابط t.me.",
        "whatsapp": "أرسل رقمًا دوليًا أو رابط wa.me.",
        "facebook": "أرسل رابط Facebook أو m.me.",
        "ichancy": "أرسل رابط صفحة/دردشة دعم iChancy.",
    }[kind]
    await safe_edit(
        callback,
        f"✏️ <b>{_LABELS[kind]}</b>\n\nالحالي: <code>{html.escape(current or 'غير مضبوط')}</code>\n\n{extra}\nأرسل <code>-</code> لمسح الرابط.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:support")]]),
    )


@router.message(SupportAdminStates.waiting_value, F.text)
async def support_edit_value(
    message: Message, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings):
        return
    data = await state.get_data()
    kind = str(data.get("support_kind") or "")
    if kind not in _LABELS:
        await state.clear()
        return
    raw = str(message.text or "").strip()
    if raw == "-":
        value = ""
    else:
        value, error = normalize_support_contact(kind, raw)
        if error or not value:
            await message.answer(f"❌ {html.escape(error or 'القيمة غير صحيحة.')}\nأرسل القيمة من جديد أو <code>-</code> للمسح.")
            return
    await runtime_settings.set(f"support.{kind}_url", value, updated_by=message.from_user.id)
    await state.clear()
    await message.answer("✅ تم حفظ وسيلة التواصل.\n\n" + _text(runtime_settings), reply_markup=_menu(runtime_settings))


@router.callback_query(F.data == "admin:notify_channels")
async def notification_channels_home(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await state.clear()
    await safe_edit(callback, _channels_text(runtime_settings), reply_markup=_channels_keyboard())


@router.callback_query(F.data.regexp(r"^admin:notify:edit:c[1-7]$"))
async def notification_channel_edit(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    token = str(callback.data).rsplit(":", 1)[-1]
    key = _TOKEN_CHANNEL.get(token)
    if not key:
        return
    await state.set_state(SupportAdminStates.waiting_channel)
    await state.update_data(notification_key=key)
    current = _shown_channel(runtime_settings, key)
    await safe_edit(
        callback,
        f"✏️ <b>{_CHANNEL_LABEL[key]}</b>\n\n"
        f"الحالي: <code>{html.escape(current)}</code>\n\n"
        "أرسل <code>-100...</code> أو <code>@channel</code>.\n"
        "أرسل <code>-</code> لتعطيل هذه القناة.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:notify_channels")
        ]]),
    )


@router.message(SupportAdminStates.waiting_channel, F.text)
async def notification_channel_save(
    message: Message,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    outbox_worker: NotificationOutboxWorker,
    state: FSMContext,
) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings):
        return
    data = await state.get_data()
    key = str(data.get("notification_key") or "")
    if key not in _CHANNEL_LABEL:
        await state.clear()
        return
    try:
        value = _normalize_chat_target(message.text or "")
    except ValueError as exc:
        await message.answer(f"❌ {html.escape(str(exc))}")
        return
    await runtime_settings.set(key, value, updated_by=message.from_user.id)
    if value and key.startswith("notify."):
        await outbox_worker.repository.resume_target(key)
        outbox_worker.wake()
    await state.clear()
    await message.answer("✅ تم حفظ القناة.\n\n" + _channels_text(runtime_settings), reply_markup=_channels_keyboard())


@router.callback_query(F.data == "admin:notify:test_menu")
async def notification_test_menu(callback: CallbackQuery, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await safe_edit(callback, "🧪 <b>اختبار قناة إشعارات</b>\n\nاختر القناة التي تريد اختبارها:", reply_markup=_test_menu())


@router.callback_query(F.data.regexp(r"^admin:notify:test:c[1-7]$"))
async def notification_test(
    callback: CallbackQuery, bot: Bot, settings: Settings, runtime_settings: RuntimeSettingsService
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    token = str(callback.data).rsplit(":", 1)[-1]
    key = _TOKEN_CHANNEL.get(token)
    if not key:
        return
    raw = runtime_settings.get(key, "")
    if raw in (None, "", 0, "0"):
        await callback.answer("القناة غير مضبوطة.", show_alert=True)
        return
    target_raw = str(raw).strip()
    target = int(target_raw) if target_raw.lstrip("-").isdigit() else target_raw
    try:
        await bot.send_message(target, f"🧪 <b>اختبار إشعارات ناجح</b>\n\n{_CHANNEL_LABEL[key]}")
    except Exception as exc:
        await callback.answer(f"فشل الاختبار: {type(exc).__name__}", show_alert=True)
        return
    await callback.answer("✅ تم إرسال رسالة الاختبار.", show_alert=True)
