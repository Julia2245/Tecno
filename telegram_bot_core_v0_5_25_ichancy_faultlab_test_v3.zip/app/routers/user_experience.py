from __future__ import annotations

import html
import math
from datetime import datetime

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from app.config import Settings
from app.core.ui import safe_edit
from app.core.user_experience import TERMS_TEXT, support_available, support_keyboard, terms_accept_keyboard, terms_read_keyboard
from app.keyboards.common import main_menu
from app.services.runtime_settings import RuntimeSettingsService
from app.services.competitions import CompetitionService
from app.services.users import UserService
from app.services.finance_rules import FinanceRulesService
from app.services.rewards import WheelService
from app.core.ui_customization import render_message

router = Router(name="user_experience")
HISTORY_PAGE_SIZE = 15


def _fmt_amount(value: object) -> str:
    try:
        return f"{int(value or 0):,}"
    except Exception:
        return html.escape(str(value or "-"))


def _fmt_dt(value: object) -> str:
    if value is None:
        return "-"
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    return html.escape(str(value))


def _history_home() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💰 سجل شحن البوت", callback_data="history:deposits:0")],
        [InlineKeyboardButton(text="💸 سجل سحب البوت", callback_data="history:withdrawals:0")],
        [InlineKeyboardButton(text="🎰 سجل iChancy", callback_data="history:ichancy:0")],
        [InlineKeyboardButton(text="🎁 سجل الإهداء", callback_data="gift:history:transfers:0"), InlineKeyboardButton(text="🎟 أكواد الهدايا", callback_data="gift:history:codes:0")],
        [InlineKeyboardButton(text="⭐ سجل نقاط الولاء", callback_data="loyalty:history:0")],
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="core:home")],
    ])


def _history_keyboard(kind: str, page: int, total: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    pages = max(1, math.ceil(total / HISTORY_PAGE_SIZE))
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ السابق", callback_data=f"history:{kind}:{page-1}"))
    nav.append(InlineKeyboardButton(text=f"📄 {page+1}/{pages}", callback_data="history:noop"))
    if page + 1 < pages:
        nav.append(InlineKeyboardButton(text="التالي ➡️", callback_data=f"history:{kind}:{page+1}"))
    rows.append(nav)
    for other, label in (("deposits", "💰 شحن البوت"), ("withdrawals", "💸 سحب البوت"), ("ichancy", "🎰 iChancy")):
        if other != kind:
            rows.append([InlineKeyboardButton(text=label, callback_data=f"history:{other}:0")])
    rows.append([InlineKeyboardButton(text="⬅️ سجل العمليات", callback_data="history:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _render_history(kind: str, items: list[dict], page: int) -> str:
    titles = {"deposits": "💰 سجل شحن البوت", "withdrawals": "💸 سجل سحب البوت", "ichancy": "🎰 سجل iChancy"}
    lines = [f"<b>{titles.get(kind, 'سجل العمليات')}</b>", ""]
    if not items:
        lines.append("لا توجد عمليات ناجحة في هذا السجل بعد.")
        return "\n".join(lines)
    for idx, item in enumerate(items, page * HISTORY_PAGE_SIZE + 1):
        if kind == "deposits":
            lines += [
                f"{idx}. <b>{html.escape(str(item.get('method') or '-'))}</b>",
                f"   المبلغ: <code>{_fmt_amount(item.get('amount'))} SYP</code>" + (f" • بونص <code>{_fmt_amount(item.get('bonus'))}</code>" if int(item.get('bonus') or 0) else ""),
                f"   رقم العملية: <code>{html.escape(str(item.get('provider_tx') or '-'))}</code>",
                f"   التاريخ: <code>{_fmt_dt(item.get('settled_at') or item.get('created_at'))}</code>",
            ]
        elif kind == "withdrawals":
            lines += [
                f"{idx}. <b>{html.escape(str(item.get('method') or '-'))}</b>",
                f"   المبلغ: <code>{_fmt_amount(item.get('amount'))} SYP</code> • العمولة <code>{_fmt_amount(item.get('fee'))}</code>",
                f"   رقم التنفيذ: <code>{html.escape(str(item.get('provider_reference') or '-'))}</code>",
                f"   المستلم: <code>{html.escape(str(item.get('receiver') or '-'))}</code>",
                f"   التاريخ: <code>{_fmt_dt(item.get('finished_at') or item.get('created_at'))}</code>",
            ]
        else:
            op = "شحن حساب iChancy" if str(item.get("operation_type")) == "deposit" else "سحب من حساب iChancy"
            lines += [
                f"{idx}. <b>{op}</b>",
                f"   المبلغ: <code>{_fmt_amount(item.get('amount'))} SYP</code>",
                f"   التاريخ: <code>{_fmt_dt(item.get('finished_at') or item.get('created_at'))}</code>",
            ]
        lines.append("------------------------------")
    return "\n".join(lines)



async def _grant_welcome_after_terms(callback: CallbackQuery, user_id: int, finance_rules: FinanceRulesService) -> None:
    if callback.message is None:
        return
    try:
        welcome = await finance_rules.grant_welcome_if_eligible(user_id)
    except Exception:
        welcome = {"granted": False}
    if not welcome.get("granted"):
        return
    if welcome.get("mode") == "first_deposit":
        pct = welcome.get("bonus_pct", 0)
        await callback.message.answer(
            "🎁 مبروك\n"
            f"حصلت على بونص بقيمة {pct:g}%، سيتم إضافته تلقائياً على أول عملية شحن ناجحة تقوم بها."
        )
    else:
        await callback.message.answer(
            "🎁 مبروك\n"
            f"تمت إضافة بونص أول دخول إلى رصيدك بقيمة {int(welcome.get('amount') or 0):,} SYP\n"
            f"👛 رصيدك الحالي: {int(welcome.get('balance') or 0):,} SYP"
        )


def _wheel_claim_text(result, runtime_settings: RuntimeSettingsService) -> str:
    if result.ok:
        if result.prize > 0:
            return render_message(runtime_settings, "wheel_win", prize=f"{result.prize:,}", balance=f"{result.balance:,}")
        return render_message(runtime_settings, "wheel_lose")
    return result.message or "❌ تعذر استلام نتيجة عجلة الحظ."

@router.callback_query(F.data == "menu:terms")
async def terms_read(callback: CallbackQuery, user_service: UserService, runtime_settings: RuntimeSettingsService) -> None:
    needs = await user_service.needs_terms_cached(callback.from_user.id)
    if needs:
        await safe_edit(callback, render_message(runtime_settings, "terms"), reply_markup=terms_accept_keyboard())
    else:
        await safe_edit(callback, render_message(runtime_settings, "terms") + "\n\n✅ لقد وافقت على هذه الشروط سابقًا", reply_markup=terms_read_keyboard())


@router.callback_query(F.data.startswith("terms:accept"))
async def terms_accept(
    callback: CallbackQuery, user_service: UserService, settings: Settings,
    finance_rules: FinanceRulesService, wheel_service: WheelService, runtime_settings: RuntimeSettingsService,
    competition_service: CompetitionService,
) -> None:
    user_id = int(callback.from_user.id)
    await user_service.accept_terms(user_id)
    await callback.answer("✅ تم حفظ موافقتك")
    await _grant_welcome_after_terms(callback, user_id, finance_rules)

    # A wheel deep-link may have been parked before required-channel/terms gates.
    if await user_service.pending_start_action(user_id) == "claim_wheel":
        try:
            result = await wheel_service.claim(user_id)
        except Exception:
            # Keep the pending action so a later /start can retry safely.
            await safe_edit(
                callback,
                "❌ حدث خطأ أثناء استلام جائزة عجلة الحظ. يرجى المحاولة لاحقاً.",
                reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids, runtime_settings=runtime_settings),
            )
            return
        await user_service.clear_pending_start_action(user_id, "claim_wheel")
        await safe_edit(
            callback, _wheel_claim_text(result, runtime_settings),
            reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids, runtime_settings=runtime_settings),
        )
        return

    pending = await user_service.pending_start_action(user_id)
    if pending and pending != "claim_wheel":
        try:
            kind, raw_id = pending.split(":",1); item_id=int(raw_id)
            if kind == "contest":
                row=await competition_service.repository.get_contest(item_id); cb=f"contest:view:{item_id}" if row else "contest:home"; text=f"🏆 <b>المسابقة #{item_id}</b>\n\nاضغط الزر لفتح التفاصيل." if row else "❌ المسابقة غير موجودة أو انتهت."
            elif kind == "roulette":
                row=await competition_service.repository.get_roulette(item_id); cb=f"roulette:view:{item_id}" if row else "roulette:home"; text=f"🎲 <b>الروليت #{item_id}</b>\n\nاضغط الزر لفتح الجولة." if row else "❌ الروليت غير موجودة أو انتهت."
            else:
                row=await competition_service.repository.get_roulette(item_id); cb=f"roulette:result:{item_id}" if row else "roulette:home"; text=f"🏅 <b>نتيجة الروليت #{item_id}</b>\n\nاضغط الزر لعرض النتيجة." if row else "❌ الروليت غير موجودة."
            await user_service.clear_pending_start_action(user_id,pending)
            await safe_edit(callback,text,reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="فتح",callback_data=cb)]])); return
        except Exception:
            pass

    await safe_edit(callback, render_message(runtime_settings, "home", bot_name=html.escape(settings.bot_display_name or "البوت")), reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids, runtime_settings=runtime_settings))


@router.callback_query(F.data == "terms:reject")
async def terms_reject(callback: CallbackQuery, runtime_settings: RuntimeSettingsService) -> None:
    await callback.answer("يجب الموافقة على الشروط لاستخدام البوت", show_alert=True)
    await safe_edit(callback, "⚠️ يجب الموافقة على الشروط والأحكام لاستخدام البوت.\n\n" + render_message(runtime_settings, "terms"), reply_markup=terms_accept_keyboard())


@router.callback_query(F.data == "history:home")
async def history_home(callback: CallbackQuery, runtime_settings: RuntimeSettingsService) -> None:
    await safe_edit(callback, render_message(runtime_settings, "history_home"), reply_markup=_history_home())


@router.callback_query(F.data == "history:noop")
async def history_noop(callback: CallbackQuery) -> None:
    await callback.answer()


@router.callback_query(F.data.regexp(r"^history:(deposits|withdrawals|ichancy):\d+$"))
async def history_page(callback: CallbackQuery, user_service: UserService) -> None:
    try:
        _, kind, page_raw = str(callback.data).split(":", 2)
        page = max(0, int(page_raw))
    except Exception:
        return
    items, total = await user_service.public_history(callback.from_user.id, kind, limit=HISTORY_PAGE_SIZE, offset=page * HISTORY_PAGE_SIZE)
    pages = max(1, math.ceil(total / HISTORY_PAGE_SIZE))
    if page >= pages:
        page = pages - 1
        items, total = await user_service.public_history(callback.from_user.id, kind, limit=HISTORY_PAGE_SIZE, offset=page * HISTORY_PAGE_SIZE)
    await safe_edit(callback, _render_history(kind, items, page), reply_markup=_history_keyboard(kind, page, total))


@router.callback_query(F.data == "support:home")
async def support_home(callback: CallbackQuery, runtime_settings: RuntimeSettingsService) -> None:
    available = support_available(runtime_settings)
    text = render_message(runtime_settings, "support_home" if available else "support_empty")
    await safe_edit(callback, text, reply_markup=support_keyboard(runtime_settings))
