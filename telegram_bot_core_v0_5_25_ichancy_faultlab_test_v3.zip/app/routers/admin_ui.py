from __future__ import annotations

import html
import math

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.ui_customization import (
    BUTTONS, MESSAGES, MAIN_MENU_BUTTON_KEYS, button_icon, button_label, button_visible,
    find_messages, find_message_templates_by_rendered_text, get_message_template, main_menu_layout,
    message_editable_parts, message_preview, replace_message_editable_part, reset_button,
    reset_message, set_button_icon, set_button_label, set_button_visible,
    set_main_menu_layout, set_message_template, validate_message_template,
)
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin_ui")
PAGE = 8


class UiAdminState(StatesGroup):
    button_label = State()
    button_icon = State()
    message_text = State()
    message_search = State()
    message_part_text = State()
    message_part_confirm = State()


def _is_admin(user_id: int, settings: Settings) -> bool:
    return int(user_id) in settings.super_admin_ids


def _home_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔘 أسماء وإيموجي الأزرار", callback_data="admin:ui:buttons:0")],
        [InlineKeyboardButton(text="👁️ إظهار/إخفاء أزرار القائمة", callback_data="admin:ui:visibility:0")],
        [InlineKeyboardButton(text="↕️ ترتيب أزرار القائمة", callback_data="admin:ui:layout")],
        [InlineKeyboardButton(text="📝 نصوص الرسائل", callback_data="admin:ui:messages:0")],
        [InlineKeyboardButton(text="🔎 بحث عن رسالة", callback_data="admin:ui:search")],
        [InlineKeyboardButton(text="⬅️ لوحة الإدارة", callback_data="admin:home")],
    ])


@router.callback_query(F.data == "admin:ui_content")
async def ui_home(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    await state.clear()
    await safe_edit(callback,
        "📝 <b>إدارة النصوص والأزرار</b>\n\n"
        "• يتم تعديل المظهر فقط؛ وظيفة الزر وcallback ثابتان.\n"
        "• Custom Emoji لا يغيّر وظيفة الزر.\n"
        "• الإخفاء يزيل الزر من القائمة فقط ولا يعطّل المسار.\n"
        "• ترتيب القائمة قابل للتعديل بدون تغيير أي callback.\n"
        "• قوالب الرسائل تحمي المتغيرات البرمجية من الحذف أو التكرار.\n"
        "• أي قالب غير صالح يرجع تلقائياً إلى النص الافتراضي.",
        reply_markup=_home_kb())


def _paged(items: list, page: int) -> tuple[list, int, int]:
    pages = max(1, math.ceil(len(items) / PAGE))
    p = min(max(0, page), pages - 1)
    return items[p*PAGE:(p+1)*PAGE], p, pages


async def _show_buttons(callback: CallbackQuery, rt: RuntimeSettingsService, page: int) -> None:
    items = list(BUTTONS.items())
    chunk, page, pages = _paged(items, page)
    rows = [[InlineKeyboardButton(text=f"🔘 {button_label(rt,key)[:40]}", callback_data=f"admin:ui:button:{key}:{page}")] for key,_ in chunk]
    nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️ السابق", callback_data=f"admin:ui:buttons:{page-1}"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="التالي ➡️", callback_data=f"admin:ui:buttons:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="⬅️ إدارة النصوص والأزرار", callback_data="admin:ui_content")])
    await safe_edit(callback, f"🔘 <b>أسماء وإيموجي الأزرار</b>\n\nالصفحة {page+1}/{pages}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:ui:buttons:\d+$"))
async def ui_buttons(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    await _show_buttons(callback, runtime_settings, int(str(callback.data).rsplit(":",1)[-1]))


async def _show_button(callback: CallbackQuery, rt: RuntimeSettingsService, key: str, page: int) -> None:
    spec = BUTTONS.get(key)
    if not spec: return
    icon = button_icon(rt,key)
    await safe_edit(callback,
        "🔘 <b>تعديل مظهر الزر</b>\n\n"
        f"الزر: <b>{html.escape(spec.title)}</b>\n"
        f"الاسم الحالي: <b>{html.escape(button_label(rt,key))}</b>\n"
        f"Custom Emoji: {('<code>'+html.escape(icon)+'</code>') if icon else 'غير مضبوط'}\n"
        f"الحالة: <b>{'ظاهر' if button_visible(rt,key) else 'مخفي'}</b>\n\n"
        "⚠️ callback ووظيفة الزر لا يتم تعديلهما من هنا.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✏️ تغيير الاسم", callback_data=f"admin:ui:button_label:{key}:{page}")],
            [InlineKeyboardButton(text="😀 تغيير Custom Emoji", callback_data=f"admin:ui:button_icon:{key}:{page}")],
            [InlineKeyboardButton(text="🚫 إزالة Custom Emoji", callback_data=f"admin:ui:button_icon_clear:{key}:{page}")],
            [InlineKeyboardButton(text="↩️ استعادة الافتراضي", callback_data=f"admin:ui:button_reset:{key}:{page}")],
            [InlineKeyboardButton(text="⬅️ رجوع", callback_data=f"admin:ui:buttons:{page}")],
        ]))


@router.callback_query(F.data.regexp(r"^admin:ui:button:[a-z0-9_]+:\d+$"))
async def ui_button_detail(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    await state.clear()
    _,_,_,key,page = str(callback.data).split(":")
    await _show_button(callback,runtime_settings,key,int(page))


@router.callback_query(F.data.regexp(r"^admin:ui:button_label:[a-z0-9_]+:\d+$"))
async def ui_button_label_start(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    _,_,_,key,page = str(callback.data).split(":")
    await state.set_state(UiAdminState.button_label); await state.update_data(key=key,page=int(page))
    await safe_edit(callback,"✏️ أرسل الاسم الجديد للزر.\n\nلن يتم تغيير callback أو وظيفة الزر.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء",callback_data=f"admin:ui:button:{key}:{page}")]]))


@router.message(UiAdminState.button_label)
async def ui_button_label_save(message: Message, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings): return
    data=await state.get_data(); key=str(data.get("key") or ""); page=int(data.get("page") or 0)
    try:
        await set_button_label(runtime_settings,key,message.text or "",message.from_user.id)
    except Exception as exc:
        await message.answer(f"❌ {html.escape(str(exc))}\nأرسل اسماً آخر."); return
    await state.clear(); await message.answer("✅ تم حفظ اسم الزر.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ العودة للزر",callback_data=f"admin:ui:button:{key}:{page}")]]))


@router.callback_query(F.data.regexp(r"^admin:ui:button_icon:[a-z0-9_]+:\d+$"))
async def ui_button_icon_start(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    _,_,_,key,page = str(callback.data).split(":")
    await state.set_state(UiAdminState.button_icon); await state.update_data(key=key,page=int(page))
    await safe_edit(callback,"😀 أرسل Custom Emoji نفسه أو أرسل رقم الـEmoji ID.\n\nإذا أرسلت الإيموجي المتحرك نفسه سألتقط الـID تلقائياً.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء",callback_data=f"admin:ui:button:{key}:{page}")]]))


@router.message(UiAdminState.button_icon)
async def ui_button_icon_save(message: Message, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings): return
    data=await state.get_data(); key=str(data.get("key") or ""); page=int(data.get("page") or 0)
    value=(message.text or "").strip()
    for ent in list(message.entities or []):
        emoji_id=getattr(ent,"custom_emoji_id",None)
        if emoji_id:
            value=str(emoji_id); break
    try: await set_button_icon(runtime_settings,key,value,message.from_user.id)
    except Exception as exc:
        await message.answer(f"❌ {html.escape(str(exc))}\nأرسل Custom Emoji أو ID صالح."); return
    await state.clear(); await message.answer("✅ تم حفظ Custom Emoji.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ العودة للزر",callback_data=f"admin:ui:button:{key}:{page}")]]))


@router.callback_query(F.data.regexp(r"^admin:ui:button_icon_clear:[a-z0-9_]+:\d+$"))
async def ui_button_icon_clear(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    _,_,_,key,page = str(callback.data).split(":")
    await set_button_icon(runtime_settings,key,None,callback.from_user.id); await _show_button(callback,runtime_settings,key,int(page))


@router.callback_query(F.data.regexp(r"^admin:ui:button_reset:[a-z0-9_]+:\d+$"))
async def ui_button_reset_cb(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    _,_,_,key,page = str(callback.data).split(":")
    await reset_button(runtime_settings,key,callback.from_user.id); await _show_button(callback,runtime_settings,key,int(page))


async def _show_visibility(callback: CallbackQuery, rt: RuntimeSettingsService, page: int) -> None:
    items=list(MAIN_MENU_BUTTON_KEYS); chunk,page,pages=_paged(items,page); rows=[]
    for key in chunk:
        vis=button_visible(rt,key)
        rows.append([InlineKeyboardButton(text=f"{'🟢' if vis else '🔴'} {button_label(rt,key)[:36]}",callback_data=f"admin:ui:visibility_toggle:{key}:{page}")])
    nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️ السابق",callback_data=f"admin:ui:visibility:{page-1}"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="التالي ➡️",callback_data=f"admin:ui:visibility:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="⬅️ إدارة النصوص والأزرار",callback_data="admin:ui_content")])
    await safe_edit(callback,f"👁️ <b>إظهار/إخفاء أزرار القائمة</b>\n\nالإخفاء لا يعطل callback أو يحذف بيانات.\nالصفحة {page+1}/{pages}",reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:ui:visibility:\d+$"))
async def ui_visibility(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    await _show_visibility(callback,runtime_settings,int(str(callback.data).rsplit(":",1)[-1]))


@router.callback_query(F.data.regexp(r"^admin:ui:visibility_toggle:[a-z0-9_]+:\d+$"))
async def ui_visibility_toggle(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    _,_,_,key,page=str(callback.data).split(":")
    new=not button_visible(runtime_settings,key); await set_button_visible(runtime_settings,key,new,callback.from_user.id)
    await callback.answer("تم إظهار الزر ✅" if new else "تم إخفاء الزر")
    await _show_visibility(callback,runtime_settings,int(page))


def _layout_text(rt: RuntimeSettingsService) -> tuple[str,InlineKeyboardMarkup]:
    layout=main_menu_layout(rt); lines=["↕️ <b>ترتيب أزرار القائمة</b>","","استخدم الأسهم لتحريك الصفوف. إذا كان الصف يحوي زرين يمكن تبديلهما يمين/يسار.",""]
    rows=[]
    for i,row in enumerate(layout):
        labels=" | ".join(button_label(rt,k) for k in row); lines.append(f"{i+1}. {html.escape(labels)}")
        controls=[]
        if i>0: controls.append(InlineKeyboardButton(text=f"⬆️ {i+1}",callback_data=f"admin:ui:layout_up:{i}"))
        if i+1<len(layout): controls.append(InlineKeyboardButton(text=f"⬇️ {i+1}",callback_data=f"admin:ui:layout_down:{i}"))
        if len(row)==2: controls.append(InlineKeyboardButton(text=f"↔️ {i+1}",callback_data=f"admin:ui:layout_swap:{i}"))
        if controls: rows.append(controls)
    rows += [[InlineKeyboardButton(text="↩️ استعادة الترتيب الافتراضي",callback_data="admin:ui:layout_reset")],[InlineKeyboardButton(text="⬅️ إدارة النصوص والأزرار",callback_data="admin:ui_content")]]
    return "\n".join(lines),InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin:ui:layout")
async def ui_layout(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    text,kb=_layout_text(runtime_settings); await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:ui:layout_(up|down|swap):\d+$"))
async def ui_layout_move(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    parts=str(callback.data).split(":"); action=parts[2].removeprefix("layout_"); idx=int(parts[3]); layout=main_menu_layout(runtime_settings)
    if 0<=idx<len(layout):
        if action=="up" and idx>0: layout[idx-1],layout[idx]=layout[idx],layout[idx-1]
        elif action=="down" and idx+1<len(layout): layout[idx],layout[idx+1]=layout[idx+1],layout[idx]
        elif action=="swap" and len(layout[idx])==2: layout[idx]=list(reversed(layout[idx]))
        await set_main_menu_layout(runtime_settings,layout,callback.from_user.id)
    text,kb=_layout_text(runtime_settings); await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data == "admin:ui:layout_reset")
async def ui_layout_reset(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    from app.core.ui_customization import DEFAULT_MAIN_MENU_LAYOUT
    await set_main_menu_layout(runtime_settings,[list(x) for x in DEFAULT_MAIN_MENU_LAYOUT],callback.from_user.id)
    text,kb=_layout_text(runtime_settings); await safe_edit(callback,text,reply_markup=kb)


async def _show_messages(callback: CallbackQuery, rt: RuntimeSettingsService, page: int) -> None:
    items=list(MESSAGES.items()); chunk,page,pages=_paged(items,page); rows=[]
    for key,spec in chunk: rows.append([InlineKeyboardButton(text=f"📝 {spec.title[:40]}",callback_data=f"admin:ui:message:{key}:{page}")])
    nav=[]
    if page>0: nav.append(InlineKeyboardButton(text="⬅️ السابق",callback_data=f"admin:ui:messages:{page-1}"))
    if page+1<pages: nav.append(InlineKeyboardButton(text="التالي ➡️",callback_data=f"admin:ui:messages:{page+1}"))
    if nav: rows.append(nav)
    rows.append([InlineKeyboardButton(text="⬅️ إدارة النصوص والأزرار",callback_data="admin:ui_content")])
    await safe_edit(callback,f"📝 <b>نصوص الرسائل</b>\n\nالصفحة {page+1}/{pages}\nاختر الرسالة:",reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:ui:messages:\d+$"))
async def ui_messages(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    await _show_messages(callback,runtime_settings,int(str(callback.data).rsplit(":",1)[-1]))


async def _show_message(callback: CallbackQuery, rt: RuntimeSettingsService, key: str, page: int) -> None:
    spec=MESSAGES.get(key)
    if not spec: return
    fields="، ".join(f"<code>{{{html.escape(x)}}}</code>" for x in sorted(spec.fields)) or "لا توجد متغيرات"
    tpl=get_message_template(rt,key)
    await safe_edit(callback,f"📝 <b>{html.escape(spec.title)}</b>\nالقسم: <b>{html.escape(spec.group)}</b>\n\n🔒 المتغيرات المحمية: {fields}\n\n<b>القالب الحالي:</b>\n<pre>{html.escape(tpl)}</pre>",reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👁 معاينة",callback_data=f"admin:ui:message_preview:{key}:{page}"),InlineKeyboardButton(text="✏️ تعديل",callback_data=f"admin:ui:message_edit:{key}:{page}")],
        [InlineKeyboardButton(text="↩️ استعادة الافتراضي",callback_data=f"admin:ui:message_reset:{key}:{page}")],
        [InlineKeyboardButton(text="⬅️ رجوع",callback_data=f"admin:ui:messages:{page}")],
    ]))


@router.callback_query(F.data.regexp(r"^admin:ui:message:[a-z0-9_]+:\d+$"))
async def ui_message_detail(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    await state.clear(); _,_,_,key,page=str(callback.data).split(":"); await _show_message(callback,runtime_settings,key,int(page))


@router.callback_query(F.data.regexp(r"^admin:ui:message_preview:[a-z0-9_]+:\d+$"))
async def ui_message_preview(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    _,_,_,key,page=str(callback.data).split(":")
    try: preview=message_preview(runtime_settings,key)
    except Exception as exc: await callback.answer(str(exc)[:150],show_alert=True); return
    await safe_edit(callback,"👁 <b>معاينة الرسالة</b>\n\n"+preview,reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ رجوع",callback_data=f"admin:ui:message:{key}:{page}")]]))


@router.callback_query(F.data.regexp(r"^admin:ui:message_edit:[a-z0-9_]+:\d+$"))
async def ui_message_edit_start(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    _,_,_,key,page=str(callback.data).split(":"); spec=MESSAGES.get(key)
    if not spec: return
    await state.set_state(UiAdminState.message_text); await state.update_data(key=key,page=int(page))
    fields="، ".join("{"+x+"}" for x in sorted(spec.fields)) or "لا توجد"
    await safe_edit(callback,f"✏️ أرسل النص الجديد كما تريد أن يظهر.\n\n🔒 المتغيرات المحمية: <code>{html.escape(fields)}</code>\nيجب إبقاء كل متغير مرة واحدة بالضبط. يمكنك استخدام تنسيق Telegram وCustom Emoji.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء",callback_data=f"admin:ui:message:{key}:{page}")]]))


@router.message(UiAdminState.message_text)
async def ui_message_edit_save(message: Message, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings): return
    data=await state.get_data(); key=str(data.get("key") or ""); page=int(data.get("page") or 0)
    # Aiogram exposes preformatted HTML while preserving Telegram entities including custom emoji.
    try: formatted=message.html_text
    except Exception: formatted=html.escape(message.text or "")
    formatted=str(formatted or "").strip(); ok,err=validate_message_template(key,formatted)
    if not ok: await message.answer(f"❌ {html.escape(err)}\nأرسل النص من جديد."); return
    try: preview=message_preview(runtime_settings,key,formatted)
    except Exception as exc: await message.answer(f"❌ تعذر تجهيز المعاينة: {html.escape(str(exc))}"); return
    await set_message_template(runtime_settings,key,formatted,message.from_user.id); await state.clear()
    await message.answer("✅ تم حفظ النص.\n\n👁 <b>معاينة:</b>\n\n"+preview,reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ العودة للرسالة",callback_data=f"admin:ui:message:{key}:{page}")]]))


@router.callback_query(F.data.regexp(r"^admin:ui:message_reset:[a-z0-9_]+:\d+$"))
async def ui_message_reset_cb(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    _,_,_,key,page=str(callback.data).split(":"); await reset_message(runtime_settings,key,callback.from_user.id); await _show_message(callback,runtime_settings,key,int(page))


@router.callback_query(F.data == "admin:ui:search")
async def ui_search_start(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings): return
    await state.set_state(UiAdminState.message_search)
    await safe_edit(
        callback,
        "🔎 <b>بحث عن رسالة</b>\n\n"
        "انسخ الرسالة التي تريد تعديلها كما ظهرت من البوت وأرسلها هنا كاملة.\n"
        "يمكن أن تحتوي مبالغ أو أسماء أو أرقام عمليات حقيقية؛ النظام يتعرف على القالب ويحمي هذه القيم تلقائياً.\n\n"
        "يمكنك أيضاً إرسال جزء من النص أو اسم الرسالة للبحث التقليدي.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء",callback_data="admin:ui_content")]]),
    )


@router.message(UiAdminState.message_search)
async def ui_search_result(message: Message, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings):
        return
    copied=(message.text or "").strip()
    keys=find_message_templates_by_rendered_text(runtime_settings,copied)
    if not keys:
        keys=find_messages(runtime_settings,copied)
    if not keys:
        await message.answer("❌ لم أجد رسالة مطابقة. انسخ الرسالة كاملة كما ظهرت من البوت أو جرّب جزءاً أوضح من النص.",reply_markup=_home_kb())
        return
    await state.clear()
    if len(keys)==1:
        await _show_message_parts_message(message,runtime_settings,keys[0],state)
        return
    rows=[[InlineKeyboardButton(text=f"📝 {MESSAGES[k].title[:40]}",callback_data=f"admin:ui:message_parts:{k}")] for k in keys[:12]]
    rows.append([InlineKeyboardButton(text="⬅️ إدارة النصوص والأزرار",callback_data="admin:ui_content")])
    await message.answer(f"🔎 تم العثور على <b>{len(keys)}</b> نتيجة. اختر الرسالة المقصودة:",reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


async def _parts_markup(rt: RuntimeSettingsService, key: str) -> InlineKeyboardMarkup:
    parts=message_editable_parts(get_message_template(rt,key))
    rows=[]
    for idx,part in enumerate(parts):
        label=" ".join(str(part.get("display") or "").split())
        if len(label)>46: label=label[:45]+"…"
        rows.append([InlineKeyboardButton(text=f"✏️ {idx+1}. {label}",callback_data=f"admin:ui:message_part:{key}:{idx}")])
    rows += [
        [InlineKeyboardButton(text="👁 معاينة كاملة",callback_data=f"admin:ui:message_preview:{key}:0"),InlineKeyboardButton(text="↩️ استعادة الأصل",callback_data=f"admin:ui:message_reset:{key}:0")],
        [InlineKeyboardButton(text="🔎 بحث جديد",callback_data="admin:ui:search")],
        [InlineKeyboardButton(text="⬅️ النصوص",callback_data="admin:ui:messages:0")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _show_message_parts_message(message: Message, rt: RuntimeSettingsService, key: str, state: FSMContext) -> None:
    spec=MESSAGES.get(key)
    if not spec:
        await message.answer("❌ لم تعد الرسالة متاحة للتعديل.")
        return
    parts=message_editable_parts(get_message_template(rt,key))
    if not parts:
        await message.answer("❌ تم التعرف على الرسالة لكن لا يوجد فيها نص ثابت قابل للتعديل.",reply_markup=_home_kb())
        return
    await state.update_data(message_key=key)
    await message.answer(
        "✅ <b>تم العثور على الرسالة</b>\n\n"
        f"القسم: <b>{html.escape(spec.group)}</b>\n"
        f"الرسالة: <b>{html.escape(spec.title)}</b>\n\n"
        "اختر فقط الجزء الذي تريد تغييره.\n🔒 المتغيرات والقيم الديناميكية لا تظهر كأجزاء قابلة للتعديل.",
        reply_markup=await _parts_markup(rt,key),
    )


@router.callback_query(F.data.regexp(r"^admin:ui:message_parts:[a-z0-9_]+$"))
async def ui_message_parts_cb(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    key=str(callback.data).rsplit(":",1)[-1]
    spec=MESSAGES.get(key)
    if not spec:
        return
    await state.clear(); await state.update_data(message_key=key)
    parts=message_editable_parts(get_message_template(runtime_settings,key))
    rows=[]
    for idx,part in enumerate(parts):
        label=" ".join(str(part.get("display") or "").split())
        if len(label)>46: label=label[:45]+"…"
        rows.append([InlineKeyboardButton(text=f"✏️ {idx+1}. {label}",callback_data=f"admin:ui:message_part:{key}:{idx}")])
    rows += [[InlineKeyboardButton(text="🔎 بحث جديد",callback_data="admin:ui:search")],[InlineKeyboardButton(text="⬅️ النصوص",callback_data="admin:ui:messages:0")]]
    await safe_edit(callback,"✅ <b>اختر الجزء النصي المطلوب</b>\n\n🔒 المتغيرات محمية وغير قابلة للاختيار.",reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:ui:message_part:[a-z0-9_]+:\d+$"))
async def ui_message_part_start(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    parts=str(callback.data).split(":"); key=parts[-2]; idx=int(parts[-1])
    current_parts=message_editable_parts(get_message_template(runtime_settings,key))
    if idx<0 or idx>=len(current_parts):
        await callback.answer("الجزء لم يعد موجوداً. أعد البحث.",show_alert=True); return
    await state.set_state(UiAdminState.message_part_text); await state.update_data(message_key=key,part_index=idx)
    visible=str(current_parts[idx].get("display") or "")
    await safe_edit(
        callback,
        "✏️ <b>تعديل هذا الجزء فقط</b>\n\n"
        f"النص الحالي:\n<blockquote>{html.escape(visible)}</blockquote>\n\n"
        "أرسل النص البديل فقط. يمكنك استخدام تنسيق Telegram وCustom Emoji.\n"
        "🔒 المبلغ/الرصيد/رقم العملية وأي متغير ديناميكي سيبقى في مكانه ولن يتغير.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء",callback_data=f"admin:ui:message_parts:{key}")]]),
    )


@router.message(UiAdminState.message_part_text)
async def ui_message_part_text(message: Message, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings):
        return
    data=await state.get_data(); key=str(data.get("message_key") or ""); idx=int(data.get("part_index",-1))
    try: formatted=str(message.html_text or "").strip()
    except Exception: formatted=html.escape(message.text or "").strip()
    if not formatted:
        await message.answer("❌ النص البديل لا يمكن أن يكون فارغاً."); return
    if len(formatted)>1600:
        await message.answer("❌ هذا الجزء طويل جداً."); return
    try:
        candidate=replace_message_editable_part(get_message_template(runtime_settings,key),idx,formatted)
    except Exception as exc:
        await message.answer(f"❌ {html.escape(str(exc))}"); return
    ok,err=validate_message_template(key,candidate)
    if not ok:
        await message.answer(f"❌ تعذر تجهيز التعديل بأمان: {html.escape(err)}"); return
    try: preview=message_preview(runtime_settings,key,candidate)
    except Exception as exc:
        await message.answer(f"❌ تعذر إنشاء المعاينة: {html.escape(str(exc))}"); return
    await state.set_state(UiAdminState.message_part_confirm); await state.update_data(candidate=candidate)
    await message.answer(
        "👁 <b>معاينة الرسالة بعد تعديل الجزء</b>\n\n"+preview+"\n\nهل تريد حفظ التعديل؟",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ حفظ",callback_data="admin:ui:message_part_save")],
            [InlineKeyboardButton(text="✏️ تعديل مرة أخرى",callback_data="admin:ui:message_part_retry")],
            [InlineKeyboardButton(text="❌ إلغاء",callback_data=f"admin:ui:message_parts:{key}")],
        ]),
    )


@router.callback_query(UiAdminState.message_part_confirm, F.data == "admin:ui:message_part_save")
async def ui_message_part_save(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    data=await state.get_data(); key=str(data.get("message_key") or ""); candidate=str(data.get("candidate") or "")
    await set_message_template(runtime_settings,key,candidate,callback.from_user.id)
    await state.clear()
    await safe_edit(callback,"✅ تم حفظ الجزء النصي مع إبقاء جميع المتغيرات المحمية كما هي.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📝 الرسالة",callback_data=f"admin:ui:message:{key}:0")],[InlineKeyboardButton(text="🔎 بحث جديد",callback_data="admin:ui:search")]]))


@router.callback_query(UiAdminState.message_part_confirm, F.data == "admin:ui:message_part_retry")
async def ui_message_part_retry(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    data=await state.get_data(); key=str(data.get("message_key") or ""); idx=int(data.get("part_index",-1))
    current_parts=message_editable_parts(get_message_template(runtime_settings,key))
    if idx<0 or idx>=len(current_parts):
        await state.clear(); await callback.answer("الجزء لم يعد موجوداً.",show_alert=True); return
    await state.set_state(UiAdminState.message_part_text)
    await safe_edit(callback,"✏️ أرسل النص البديل لهذا الجزء من جديد.\n\n🔒 المتغيرات محمية ولن تتغير.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء",callback_data=f"admin:ui:message_parts:{key}")]]))
