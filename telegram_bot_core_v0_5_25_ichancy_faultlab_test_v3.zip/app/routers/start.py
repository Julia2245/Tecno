from __future__ import annotations

import html

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.emojis import LOADING
from app.core.user_experience import TERMS_TEXT, terms_accept_keyboard
from app.keyboards.common import main_menu
from app.services.users import UserService
from app.services.deposits import DepositService
from app.services.finance_rules import FinanceRulesService
from app.services.rewards import ReferralService, WheelService
from app.services.runtime_settings import RuntimeSettingsService
from app.services.competitions import CompetitionService
from app.core.ui_customization import render_message

import re
from urllib.parse import urlparse

router = Router(name="start")


def _home_text(display_name: str) -> str:
    name = display_name or "البوت"
    return (
        f"<b>{name}</b>\n\n"
        "أهلاً بك 👋\n"
        "اختر الخدمة التي تريدها من القائمة أدناه."
    )


def _normalize_telegram_url(value: str | None) -> str | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    lowered = raw.lower()
    if lowered.startswith(("t.me/", "www.t.me/", "telegram.me/", "www.telegram.me/")):
        raw = "https://" + raw
    if not raw.startswith(("https://", "http://")):
        username = raw.lstrip("@").strip()
        if re.fullmatch(r"[A-Za-z0-9_]{1,64}", username or ""):
            return f"https://t.me/{username}"
        return None
    parsed = urlparse(raw)
    if (parsed.hostname or "").lower() not in {"t.me", "www.t.me", "telegram.me", "www.telegram.me"}:
        return None
    path = parsed.path.strip("/")
    return f"https://t.me/{path}" if path else None


def _required_channel_info(settings: Settings) -> tuple[str | int | None, str | None]:
    raw = str(settings.required_channel or "").strip()
    join_override = str(settings.required_channel_link or "").strip()
    if not raw:
        return None, None
    if re.fullmatch(r"-?\d+", raw):
        return int(raw), _normalize_telegram_url(join_override)
    candidate = raw
    if candidate.lower().startswith(("t.me/", "www.t.me/", "telegram.me/", "www.telegram.me/")):
        candidate = "https://" + candidate
    if candidate.startswith(("https://", "http://")):
        parsed = urlparse(candidate)
        if (parsed.hostname or "").lower() not in {"t.me", "www.t.me", "telegram.me", "www.telegram.me"}:
            return None, None
        path = parsed.path.strip("/")
        if not path or path.startswith("+") or path.lower().startswith("joinchat/"):
            return None, _normalize_telegram_url(candidate)
        username = path.split("/", 1)[0].lstrip("@").strip()
    else:
        username = candidate.lstrip("@").strip()
    if not re.fullmatch(r"[A-Za-z0-9_]{1,64}", username or ""):
        return None, None
    return f"@{username}", f"https://t.me/{username}"


async def _check_required_channel(bot: Bot, settings: Settings, user_id: int) -> bool:
    if not str(settings.required_channel or "").strip() or user_id in settings.super_admin_ids:
        return True
    chat_ref, _join_url = _required_channel_info(settings)
    if chat_ref is None:
        return False
    try:
        member = await bot.get_chat_member(chat_ref, user_id)
        status = getattr(member.status, "value", member.status)
        return str(status) in {"member", "administrator", "creator", "owner"}
    except Exception:
        return False


def _join_text(settings: Settings) -> str:
    _chat_ref, join_url = _required_channel_info(settings)
    if join_url:
        return "🔒 لازم تشترك بالقناة أولاً لتقدر تستخدم البوت.\n\nاضغط اشتراك ثم تحقق ✅"
    return (
        "⚠️ تعذر فتح قناة الاشتراك حالياً لأن رابط القناة غير مضبوط بشكل صحيح.\n"
        "يرجى المحاولة لاحقاً أو التواصل مع دعم البوت."
    )


def _referral_verify_text(settings: Settings) -> str:
    _chat_ref, join_url = _required_channel_info(settings)
    if join_url:
        return "🤝 لتأكيد تسجيلك عن طريق رابط الإحالة، اشترك بالقناة المطلوبة ثم اضغط تحقق من الاشتراك ✅"
    return "🤝 اضغط تحقق لإكمال تسجيلك وتأكيد الإحالة ✅"


def _join_keyboard(settings: Settings) -> InlineKeyboardMarkup:
    _chat_ref, join_url = _required_channel_info(settings)
    rows: list[list[InlineKeyboardButton]] = []
    if join_url:
        rows.append([InlineKeyboardButton(text="✅ اشترك بالقناة", url=join_url)])
    rows.append([InlineKeyboardButton(text="🔄 تحقق من الاشتراك", callback_data="start:check")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _grant_welcome(
    target: Message, user_id: int, settings: Settings, finance_rules: FinanceRulesService
) -> None:
    if user_id in settings.super_admin_ids:
        return
    try:
        welcome = await finance_rules.grant_welcome_if_eligible(user_id)
    except Exception:
        welcome = {"granted": False}
    if not welcome.get("granted"):
        return
    if welcome.get("mode") == "first_deposit":
        pct = welcome.get("bonus_pct", 0)
        await target.answer(
            "🎁 مبروك\n"
            f"حصلت على بونص بقيمة {pct:g}%، سيتم إضافته تلقائياً على أول عملية شحن ناجحة تقوم بها."
        )
    else:
        await target.answer(
            "🎁 مبروك\n"
            f"تمت إضافة بونص أول دخول إلى رصيدك بقيمة {int(welcome.get('amount') or 0):,} SYP\n"
            f"👛 رصيدك الحالي: {int(welcome.get('balance') or 0):,} SYP"
        )



def _wheel_claim_text(result, runtime_settings: RuntimeSettingsService) -> str:
    if result.ok:
        if result.prize > 0:
            return render_message(runtime_settings, "wheel_win", prize=f"{result.prize:,}", balance=f"{result.balance:,}")
        return render_message(runtime_settings, "wheel_lose")
    return result.message or "❌ تعذر استلام نتيجة عجلة الحظ."


async def _consume_pending_wheel(
    user_id: int, user_service: UserService, wheel_service: WheelService, runtime_settings: RuntimeSettingsService
) -> str | None:
    if await user_service.pending_start_action(user_id) != "claim_wheel":
        return None
    try:
        result = await wheel_service.claim(user_id)
    except Exception:
        # Keep the action so the user can safely retry /start without losing the deep-link intent.
        return "❌ حدث خطأ أثناء استلام جائزة عجلة الحظ. يرجى المحاولة لاحقاً."
    await user_service.clear_pending_start_action(user_id, "claim_wheel")
    return _wheel_claim_text(result, runtime_settings)

async def _consume_pending_competition(user_id: int, user_service: UserService, competition_service: CompetitionService):
    action = await user_service.pending_start_action(user_id)
    if not action or action == "claim_wheel":
        return None
    try:
        kind, raw_id = action.split(":", 1); item_id = int(raw_id)
    except Exception:
        return None
    if kind == "contest":
        row = await competition_service.repository.get_contest(item_id)
        text = f"🏆 <b>المسابقة #{item_id}</b>\n\nاضغط الزر لفتح تفاصيل المسابقة." if row else "❌ المسابقة غير موجودة أو انتهت."
        cb = f"contest:view:{item_id}" if row else "contest:home"
    elif kind == "roulette":
        row = await competition_service.repository.get_roulette(item_id)
        text = f"🎲 <b>الروليت #{item_id}</b>\n\nاضغط الزر لفتح الجولة." if row else "❌ الروليت غير موجودة أو انتهت."
        cb = f"roulette:view:{item_id}" if row else "roulette:home"
    elif kind == "roulette_result":
        row = await competition_service.repository.get_roulette(item_id)
        text = f"🏅 <b>نتيجة الروليت #{item_id}</b>\n\nاضغط الزر لعرض النتيجة." if row else "❌ الروليت غير موجودة."
        cb = f"roulette:result:{item_id}" if row else "roulette:home"
    else:
        return None
    await user_service.clear_pending_start_action(user_id, action)
    return text, InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="فتح", callback_data=cb)]])

def _verification_text() -> str:
    return (
        f"{LOADING} <b>لديك عملية شحن قيد التحقق حالياً</b>\n\n"
        "انتظر نتيجة العملية الحالية. لا يمكن بدء عملية شحن ثانية قبل انتهاء التحقق."
    )


def _start_arg(message: Message) -> str:
    text = (message.text or "").strip()
    parts = text.split(maxsplit=1)
    return parts[1].strip() if len(parts) > 1 else ""


@router.message(CommandStart())
async def start_handler(
    message: Message,
    settings: Settings,
    user_service: UserService,
    deposit_service: DepositService,
    finance_rules: FinanceRulesService,
    wheel_service: WheelService,
    referral_service: ReferralService,
    runtime_settings: RuntimeSettingsService,
    competition_service: CompetitionService,
) -> None:
    if message.from_user is None:
        return

    user_id = int(message.from_user.id)
    arg = _start_arg(message)

    # Permanent first touch: a valid referrer is stored atomically
    # with first-ever user creation as PENDING.  It is never overwritten later.
    referrer_id = int(arg) if arg.isdigit() and int(arg) != user_id else None
    _user, created = await user_service.sync_profile_with_created(message.from_user, referrer_id=referrer_id)
    if arg.startswith("claim_wheel"):
        await user_service.set_pending_start_action(user_id, "claim_wheel")
    else:
        for prefix, kind in (("contest_", "contest"), ("roulette_result_", "roulette_result"), ("roulette_", "roulette")):
            if arg.startswith(prefix) and arg[len(prefix):].isdigit() and int(arg[len(prefix):]) > 0:
                await user_service.set_pending_start_action(user_id, f"{kind}:{int(arg[len(prefix):])}")
                break
    if created:
        pool = referral_service.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await wheel_service.grant_new_user_free_entitlement(conn, user_id)

    referral_pending = await referral_service.is_pending(user_id)
    subscribed = await _check_required_channel(message.bot, settings, user_id)
    if referral_pending or not subscribed:
        await message.answer(
            _referral_verify_text(settings) if referral_pending else _join_text(settings),
            reply_markup=_join_keyboard(settings),
        )
        return

    if user_id not in settings.super_admin_ids and await user_service.needs_terms_cached(user_id):
        resume = "terms:accept:wheel" if await user_service.pending_start_action(user_id) == "claim_wheel" else "terms:accept"
        await message.answer(render_message(runtime_settings, "terms"), reply_markup=terms_accept_keyboard(resume))
        return

    await _grant_welcome(message, user_id, settings, finance_rules)

    # The WebApp only animates/displays the wheel. The server-side pending action
    # survives required-channel and terms gates, so old/deep links are not lost.
    wheel_text = await _consume_pending_wheel(user_id, user_service, wheel_service, runtime_settings)
    if wheel_text is not None:
        await message.answer(
            wheel_text,
            reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids, runtime_settings=runtime_settings),
        )
        return
    pending_comp = await _consume_pending_competition(user_id, user_service, competition_service)
    if pending_comp is not None:
        await message.answer(pending_comp[0], reply_markup=pending_comp[1]); return

    if deposit_service.verification_in_progress(user_id):
        await message.answer(_verification_text())
        return
    await message.answer(
        render_message(runtime_settings, "home", bot_name=html.escape(settings.bot_display_name or "البوت")),
        reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids, runtime_settings=runtime_settings),
    )


@router.callback_query(F.data == "start:check")
async def start_check_callback(
    callback: CallbackQuery, settings: Settings, deposit_service: DepositService,
    finance_rules: FinanceRulesService, referral_service: ReferralService, user_service: UserService,
    wheel_service: WheelService, runtime_settings: RuntimeSettingsService, competition_service: CompetitionService,
) -> None:
    user_id = int(callback.from_user.id)
    await callback.answer()
    if not await _check_required_channel(callback.bot, settings, user_id):
        await safe_edit(callback, _join_text(settings), reply_markup=_join_keyboard(settings))
        return
    try:
        await referral_service.confirm_pending(user_id)
    except Exception:
        if await referral_service.is_pending(user_id):
            await safe_edit(
                callback,
                "⚠️ تعذر إكمال تأكيد الإحالة حالياً. حاول التحقق مرة أخرى بعد قليل.",
                reply_markup=_join_keyboard(settings),
            )
            return
        raise
    if user_id not in settings.super_admin_ids and await user_service.needs_terms_cached(user_id):
        resume = "terms:accept:wheel" if await user_service.pending_start_action(user_id) == "claim_wheel" else "terms:accept"
        await safe_edit(callback, render_message(runtime_settings, "terms"), reply_markup=terms_accept_keyboard(resume))
        return
    if callback.message is not None:
        await _grant_welcome(callback.message, user_id, settings, finance_rules)
    wheel_text = await _consume_pending_wheel(user_id, user_service, wheel_service, runtime_settings)
    if wheel_text is not None:
        await safe_edit(callback, wheel_text, reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids, runtime_settings=runtime_settings))
        return
    pending_comp = await _consume_pending_competition(user_id, user_service, competition_service)
    if pending_comp is not None:
        await safe_edit(callback, pending_comp[0], reply_markup=pending_comp[1]); return
    if deposit_service.verification_in_progress(user_id):
        await safe_edit(callback, _verification_text())
        return
    await safe_edit(
        callback, render_message(runtime_settings, "home", bot_name=html.escape(settings.bot_display_name or "البوت")),
        reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids, runtime_settings=runtime_settings),
    )


@router.message(Command("menu"))
async def menu_handler(
    message: Message, settings: Settings, deposit_service: DepositService, referral_service: ReferralService, runtime_settings: RuntimeSettingsService
) -> None:
    if message.from_user is None:
        return
    user_id = int(message.from_user.id)
    referral_pending = await referral_service.is_pending(user_id)
    subscribed = await _check_required_channel(message.bot, settings, user_id)
    if referral_pending or not subscribed:
        await message.answer(
            _referral_verify_text(settings) if referral_pending else _join_text(settings),
            reply_markup=_join_keyboard(settings),
        )
        return
    if deposit_service.verification_in_progress(user_id):
        await message.answer(_verification_text())
        return
    await message.answer(
        render_message(runtime_settings, "home", bot_name=html.escape(settings.bot_display_name or "البوت")),
        reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids, runtime_settings=runtime_settings),
    )


@router.callback_query(F.data == "core:home")
async def home_callback(
    callback: CallbackQuery, settings: Settings, deposit_service: DepositService, referral_service: ReferralService, runtime_settings: RuntimeSettingsService
) -> None:
    user_id = int(callback.from_user.id)
    referral_pending = await referral_service.is_pending(user_id)
    subscribed = await _check_required_channel(callback.bot, settings, user_id)
    if referral_pending or not subscribed:
        await safe_edit(
            callback, _referral_verify_text(settings) if referral_pending else _join_text(settings),
            reply_markup=_join_keyboard(settings),
        )
        return
    if deposit_service.verification_in_progress(user_id):
        await safe_edit(callback, _verification_text())
        return
    await safe_edit(
        callback,
        render_message(runtime_settings, "home", bot_name=html.escape(settings.bot_display_name or "البوت")),
        reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids, runtime_settings=runtime_settings),
    )
