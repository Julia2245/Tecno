from aiogram import Router

from . import admin, admin_ops, admin_broadcasts, admin_ui, admin_reports, admin_users, admin_wallet, admin_finance, admin_bonus, admin_ichancy, admin_rewards, admin_gifts_loyalty, admin_support, admin_competitions, deposits, errors, ichancy, performance, rewards, start, user_experience, gifts_loyalty, competitions, matches, withdrawals


def build_root_router() -> Router:
    root = Router(name="root")
    root.include_router(start.router)
    root.include_router(performance.router)
    root.include_router(admin.router)
    root.include_router(admin_ops.router)
    root.include_router(admin_broadcasts.router)
    root.include_router(admin_ui.router)
    root.include_router(admin_reports.router)
    root.include_router(admin_users.router)
    root.include_router(admin_wallet.router)
    root.include_router(admin_finance.router)
    root.include_router(admin_bonus.router)
    root.include_router(admin_ichancy.router)
    root.include_router(admin_rewards.router)
    root.include_router(admin_gifts_loyalty.router)
    root.include_router(admin_support.router)
    root.include_router(admin_competitions.router)
    root.include_router(gifts_loyalty.router)
    root.include_router(competitions.router)
    root.include_router(matches.router)
    root.include_router(user_experience.router)
    root.include_router(deposits.router)
    root.include_router(withdrawals.router)
    root.include_router(ichancy.router)
    root.include_router(rewards.router)
    # Register at the parent so failures from every child router are covered.
    root.errors.register(errors.global_error_handler)
    return root
