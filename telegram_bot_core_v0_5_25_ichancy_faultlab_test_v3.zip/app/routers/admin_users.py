from __future__ import annotations

import asyncio
import html
from datetime import datetime

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.wallet import InsufficientFunds, WalletInvariantError
from app.services.ichancy_accounts import IchancyAccountsService
from app.services.users import UserService
from app.services.wallet import WalletService

router = Router(name="admin_users")
PAGE_SIZE = 10


class AdminUserStates(StatesGroup):
    search = State()
    forward_id = State()
    balance_amount = State()
    ichancy_transfer_target = State()


def _is_admin(user_id: int, settings: Settings) -> bool:
    return int(user_id) in settings.super_admin_ids


def _fmt_amount(value: object) -> str:
    try:
        return f"{int(value or 0):,}"
    except Exception:
        return "0"


def _fmt_dt(value: object) -> str:
    if value is None:
        return "-"
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    return html.escape(str(value))


def _users_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🔎 بحث عن لاعب", callback_data="admin:users:search"),
                InlineKeyboardButton(text="🆔 الحصول على معرف لاعب", callback_data="admin:users:forward"),
            ],
            [
                InlineKeyboardButton(text="📈 الأكثر نشاطًا", callback_data="admin:users:rank:activity:0"),
                InlineKeyboardButton(text="💰 الأعلى رصيدًا", callback_data="admin:users:rank:balance:0"),
            ],
            [InlineKeyboardButton(text="🚫 المستخدمون المحظورون", callback_data="admin:users:blocked:0")],
            [InlineKeyboardButton(text="📊 ملخص المستخدمين والعمليات", callback_data="admin:users:overview")],
            [InlineKeyboardButton(text="⬅️ رجوع", callback_data="admin:home")],
        ]
    )


def _card_keyboard(target: int, blocked: bool, has_ichancy: bool) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="➕ إضافة رصيد", callback_data=f"admin:user:balance:add:{target}"),
            InlineKeyboardButton(text="➖ خصم رصيد", callback_data=f"admin:user:balance:sub:{target}"),
        ],
        [
            InlineKeyboardButton(
                text="✅ إلغاء الحظر" if blocked else "🚫 حظر",
                callback_data=f"admin:user:{'unban' if blocked else 'ban'}:prompt:{target}",
            ),
            InlineKeyboardButton(text="🔄 تحديث البطاقة", callback_data=f"admin:user:card:{target}"),
        ],
    ]
    rows.append([InlineKeyboardButton(text="📁 سجلات المستخدم", callback_data=f"admin:user:logs:{target}")])
    if has_ichancy:
        rows.append([
            InlineKeyboardButton(text="🎰 تحديث رصيد iChancy", callback_data=f"admin:user:ichancy_balance:{target}"),
            InlineKeyboardButton(text="⚙️ إدارة حساب iChancy", callback_data=f"admin:user:ichancy_manage:{target}"),
        ])
    rows.append([InlineKeyboardButton(text="⬅️ إدارة المستخدمين", callback_data="admin:users")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _result_keyboard(items: list[dict]) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for item in items:
        target = int(item["telegram_id"])
        uname = str(item.get("username") or "").strip()
        first = str(item.get("first_name") or "").strip()
        label = f"@{uname}" if uname else (first or str(target))
        rows.append([InlineKeyboardButton(text=f"👤 {label} • {_fmt_amount(item.get('balance'))}", callback_data=f"admin:user:card:{target}")])
    rows.append([InlineKeyboardButton(text="⬅️ إدارة المستخدمين", callback_data="admin:users")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _rank_keyboard(kind: str, page: int, items: list[dict], total: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for item in items:
        target = int(item["telegram_id"])
        label = f"@{item['username']}" if item.get("username") else str(item.get("first_name") or target)
        rows.append([InlineKeyboardButton(text=f"👤 {label}", callback_data=f"admin:user:card:{target}")])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ السابق", callback_data=f"admin:users:rank:{kind}:{page-1}"))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(InlineKeyboardButton(text="التالي ➡️", callback_data=f"admin:users:rank:{kind}:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="⬅️ إدارة المستخدمين", callback_data="admin:users")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _blocked_keyboard(page: int, items: list[dict], total: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for item in items:
        target = int(item["telegram_id"])
        label = f"@{item['username']}" if item.get("username") else str(item.get("first_name") or target)
        rows.append([InlineKeyboardButton(text=f"🚫 {label}", callback_data=f"admin:user:card:{target}")])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ السابق", callback_data=f"admin:users:blocked:{page-1}"))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(InlineKeyboardButton(text="التالي ➡️", callback_data=f"admin:users:blocked:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="⬅️ إدارة المستخدمين", callback_data="admin:users")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _render_card(callback: CallbackQuery, users: UserService, target: int) -> None:
    card = await users.admin_card(target)
    if not card:
        await safe_edit(callback, "❌ لم يتم العثور على المستخدم.", reply_markup=_users_menu())
        return
    username = html.escape(str(card.get("username") or ""))
    name = html.escape(" ".join(x for x in [str(card.get("first_name") or "").strip(), str(card.get("last_name") or "").strip()] if x) or "-")
    blocked = bool(card.get("is_blocked"))
    dep_total = int(card.get("deposits_total") or 0)
    wd_total = int(card.get("withdrawals_total") or 0)
    net = dep_total - wd_total
    lines = [
        "👤 <b>بطاقة المستخدم</b>",
        "",
        f"الاسم: {name}",
        f"اسم المستخدم: <code>@{username}</code>" if username else "اسم المستخدم: -",
        f"🆔 Telegram ID: <code>{target}</code>",
        f"💰 الرصيد: <code>{_fmt_amount(card.get('balance'))} SYP</code>",
        f"🔒 المحجوز: <code>{_fmt_amount(card.get('held'))} SYP</code>",
        f"🚫 الحالة: {'محظور ❌' if blocked else 'فعال ✅'}",
        f"📅 الانضمام: <code>{_fmt_dt(card.get('created_at'))}</code>",
        f"⌛ آخر نشاط: <code>{_fmt_dt(card.get('last_active_at'))}</code>",
        "",
        "📊 <b>عمليات محفظة البوت</b>",
        f"▪️ الشحن: <b>{int(card.get('deposits_count') or 0)}</b> | <code>{_fmt_amount(dep_total)} SYP</code>",
        f"▪️ السحب: <b>{int(card.get('withdrawals_count') or 0)}</b> | <code>{_fmt_amount(wd_total)} SYP</code>",
        f"▪️ الصافي: <code>{net:+,} SYP</code>",
        "",
        "🎰 <b>iChancy</b>",
    ]
    if card.get("ichancy_username"):
        lines += [
            f"الحساب: <code>{html.escape(str(card.get('ichancy_username')))}</code>",
            f"Player ID: <code>{html.escape(str(card.get('player_id') or '-'))}</code>",
            f"آخر رصيد مسجل: <code>{_fmt_amount(card.get('ichancy_last_balance'))}</code>",
            f"شحن iChancy: <b>{int(card.get('ichancy_deposits_count') or 0)}</b> | <code>{_fmt_amount(card.get('ichancy_deposits_total'))}</code>",
            f"سحب iChancy: <b>{int(card.get('ichancy_withdrawals_count') or 0)}</b> | <code>{_fmt_amount(card.get('ichancy_withdrawals_total'))}</code>",
        ]
    else:
        lines.append("لا يوجد حساب iChancy فعال.")
    lines += [
        "",
        "🤝 <b>الإحالات</b>",
        f"▪️ الإحالات المؤكدة: <b>{int(card.get('referrals_total') or 0)}</b>",
        f"▪️ دخل الإحالات: <code>{_fmt_amount(card.get('referral_income'))} SYP</code>",
    ]
    if blocked and card.get("blocked_at"):
        lines += [
            "",
            f"🚫 تاريخ الحظر: <code>{_fmt_dt(card.get('blocked_at'))}</code>",
            f"👮 بواسطة: <code>{html.escape(str(card.get('blocked_by') or '-'))}</code>",
        ]
    await safe_edit(
        callback,
        "\n".join(lines),
        reply_markup=_card_keyboard(target, blocked, bool(card.get("ichancy_username"))),
    )


def _history_menu(target: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="💰 شحن البوت", callback_data=f"admin:user:hist:deposits:{target}:0"),
            InlineKeyboardButton(text="💸 سحب البوت", callback_data=f"admin:user:hist:withdrawals:{target}:0"),
        ],
        [
            InlineKeyboardButton(text="🎰 عمليات iChancy", callback_data=f"admin:user:hist:ichancy:{target}:0"),
            InlineKeyboardButton(text="🤝 الإحالات", callback_data=f"admin:user:hist:referrals:{target}:0"),
        ],
        [InlineKeyboardButton(text="🛡 تعديلات الأدمن", callback_data=f"admin:user:hist:admin:{target}:0")],
        [InlineKeyboardButton(text="👤 بطاقة المستخدم", callback_data=f"admin:user:card:{target}")],
    ])


def _history_keyboard(kind: str, target: int, page: int, total: int, page_size: int = 6) -> InlineKeyboardMarkup:
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ السابق", callback_data=f"admin:user:hist:{kind}:{target}:{page-1}"))
    if (page + 1) * page_size < total:
        nav.append(InlineKeyboardButton(text="التالي ➡️", callback_data=f"admin:user:hist:{kind}:{target}:{page+1}"))
    rows: list[list[InlineKeyboardButton]] = []
    if nav:
        rows.append(nav)
    rows += [
        [InlineKeyboardButton(text="⬅️ السجلات", callback_data=f"admin:user:logs:{target}")],
        [InlineKeyboardButton(text="👤 بطاقة المستخدم", callback_data=f"admin:user:card:{target}")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _history_text(kind: str, target: int, items: list[dict], page: int) -> str:
    titles = {
        "deposits": "💰 سجل شحن البوت",
        "withdrawals": "💸 سجل سحب البوت",
        "ichancy": "🎰 سجل iChancy",
        "referrals": "🤝 سجل الإحالات",
        "admin": "🛡 تعديلات الأدمن",
    }
    lines = [f"<b>{titles.get(kind, 'السجل')}</b>", f"🆔 <code>{target}</code>", ""]
    if not items:
        lines.append("لا توجد عمليات في هذه الصفحة.")
        return "\n".join(lines)
    for idx, item in enumerate(items, page * 6 + 1):
        if kind == "deposits":
            lines += [
                f"{idx}. <b>{html.escape(str(item.get('method') or '-'))}</b> • {html.escape(str(item.get('status') or '-'))}",
                f"   المبلغ: <code>{_fmt_amount(item.get('amount'))}</code> + بونص <code>{_fmt_amount(item.get('bonus'))}</code>",
                f"   العملية: <code>{html.escape(str(item.get('provider_tx') or '-'))}</code> • {_fmt_dt(item.get('created_at'))}",
            ]
        elif kind == "withdrawals":
            lines += [
                f"{idx}. <b>{html.escape(str(item.get('method') or '-'))}</b> • {html.escape(str(item.get('status') or '-'))}",
                f"   المبلغ: <code>{_fmt_amount(item.get('amount'))}</code> • العمولة <code>{_fmt_amount(item.get('fee'))}</code>",
                f"   رقم التنفيذ: <code>{html.escape(str(item.get('provider_reference') or '-'))}</code> • {_fmt_dt(item.get('created_at'))}",
            ]
        elif kind == "ichancy":
            op = "شحن" if str(item.get('operation_type')) == "deposit" else "سحب"
            lines += [
                f"{idx}. <b>{op}</b> • {html.escape(str(item.get('status') or '-'))} • <code>{_fmt_amount(item.get('amount'))}</code>",
                f"   رصيد اللاعب: <code>{_fmt_amount(item.get('player_balance_before'))}</code> → <code>{_fmt_amount(item.get('player_balance_after'))}</code>",
                f"   {_fmt_dt(item.get('created_at'))}",
            ]
        elif kind == "referrals":
            uname = f"@{html.escape(str(item.get('username')))}" if item.get('username') else html.escape(str(item.get('first_name') or item.get('telegram_id')))
            lines += [
                f"{idx}. {uname} • <code>{int(item.get('telegram_id') or 0)}</code>",
                f"   الحالة: <b>{html.escape(str(item.get('referral_status') or '-'))}</b> • {_fmt_dt(item.get('referral_confirmed_at') or item.get('referral_first_seen_at'))}",
            ]
        else:
            details = html.escape(str(item.get('details') or '{}'))
            if len(details) > 220:
                details = details[:217] + "..."
            lines += [
                f"{idx}. <b>{html.escape(str(item.get('action') or '-'))}</b> بواسطة <code>{int(item.get('actor_telegram_id') or 0)}</code>",
                f"   <code>{details}</code>",
                f"   {_fmt_dt(item.get('created_at'))}",
            ]
        lines.append("")
    return "\n".join(lines).rstrip()


@router.callback_query(F.data == "admin:users")
async def users_home(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    await state.clear()
    await safe_edit(callback, "👥 <b>إدارة المستخدمين</b>\n\nاختر العملية المطلوبة:", reply_markup=_users_menu())


@router.callback_query(F.data == "admin:users:search")
async def search_start(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    await state.set_state(AdminUserStates.search)
    await safe_edit(
        callback,
        "🔎 <b>بحث عن لاعب</b>\n\nأرسل Telegram ID أو @username أو اسم المستخدم أو اسم حساب iChancy/Player ID.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:users")]]),
    )


@router.message(AdminUserStates.search)
async def search_value(message: Message, state: FSMContext, settings: Settings, user_service: UserService) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings):
        return
    query = str(message.text or "").strip()
    if not query:
        await message.answer("❌ أرسل قيمة بحث صحيحة.")
        return
    items = await user_service.search(query)
    await state.clear()
    if not items:
        await message.answer("❌ لم يتم العثور على مستخدم مطابق.", reply_markup=_users_menu())
        return
    if len(items) == 1:
        target = int(items[0]["telegram_id"])
        # Message flows cannot edit the previous admin card reliably, so render a new card.
        card = await user_service.admin_card(target)
        if not card:
            await message.answer("❌ لم يتم العثور على المستخدم.", reply_markup=_users_menu())
            return
        username = html.escape(str(card.get("username") or ""))
        name = html.escape(" ".join(x for x in [str(card.get("first_name") or "").strip(), str(card.get("last_name") or "").strip()] if x) or "-")
        await message.answer(
            "👤 <b>نتيجة البحث</b>\n\n"
            f"الاسم: {name}\n"
            + (f"اسم المستخدم: <code>@{username}</code>\n" if username else "")
            + f"🆔 <code>{target}</code>\n💰 <code>{_fmt_amount(card.get('balance'))} SYP</code>",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="👤 فتح البطاقة الكاملة", callback_data=f"admin:user:card:{target}")],
                [InlineKeyboardButton(text="⬅️ إدارة المستخدمين", callback_data="admin:users")],
            ]),
        )
        return
    await message.answer(f"🔎 تم العثور على <b>{len(items)}</b> نتيجة:", reply_markup=_result_keyboard(items))


@router.callback_query(F.data == "admin:users:forward")
async def forward_start(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    await state.set_state(AdminUserStates.forward_id)
    await safe_edit(
        callback,
        "🆔 <b>الحصول على معرف لاعب</b>\n\nحوّل الآن رسالة أصلية من المستخدم إلى البوت.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:users")]]),
    )


@router.message(AdminUserStates.forward_id)
async def forward_value(message: Message, state: FSMContext, settings: Settings, user_service: UserService) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings):
        return
    await state.clear()
    origin = getattr(message, "forward_origin", None)
    sender = getattr(origin, "sender_user", None) if origin is not None else None
    if sender is None:
        sender = getattr(message, "forward_from", None)
    if sender is None:
        await message.answer(
            "⚠️ تعذر استخراج Telegram ID. غالبًا المستخدم أخفى هوية المرسل في إعدادات الخصوصية.",
            reply_markup=_users_menu(),
        )
        return
    target = int(sender.id)
    existing = await user_service.admin_card(target)
    rows = []
    if existing:
        rows.append([InlineKeyboardButton(text="👤 فتح بطاقة المستخدم", callback_data=f"admin:user:card:{target}")])
    rows.append([InlineKeyboardButton(text="⬅️ إدارة المستخدمين", callback_data="admin:users")])
    username = getattr(sender, "username", None)
    text = f"✅ <b>تم العثور على المعرف</b>\n\n🆔 Telegram ID: <code>{target}</code>"
    if username:
        text += f"\n🔗 Username: <code>@{html.escape(str(username))}</code>"
    if not existing:
        text += "\n\nℹ️ هذا الحساب غير مسجل في قاعدة مستخدمي البوت حتى الآن."
    await message.answer(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("admin:user:card:"))
async def user_card(callback: CallbackQuery, settings: Settings, user_service: UserService) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        target = int(str(callback.data).rsplit(":", 1)[-1])
    except Exception:
        return
    await _render_card(callback, user_service, target)


@router.callback_query(F.data.startswith("admin:users:rank:"))
async def users_rank(callback: CallbackQuery, settings: Settings, user_service: UserService) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        _, _, _, kind, page_raw = str(callback.data).split(":", 4)
        if kind not in {"activity", "balance"}:
            return
        page = max(0, int(page_raw))
    except Exception:
        return
    items, total = await user_service.ranked(kind, limit=PAGE_SIZE, offset=page * PAGE_SIZE)
    title = "📈 الأكثر نشاطًا خلال آخر 24 ساعة" if kind == "activity" else "💰 أعلى المستخدمين رصيدًا"
    lines = [f"<b>{title}</b>", ""]
    if not items:
        lines.append("لا توجد بيانات.")
    else:
        for index, item in enumerate(items, page * PAGE_SIZE + 1):
            uname = f"@{html.escape(str(item['username']))}" if item.get("username") else html.escape(str(item.get("first_name") or item["telegram_id"]))
            metric = f"{int(item.get('activity_count') or 0):,} عملية" if kind == "activity" else f"{_fmt_amount(item.get('balance'))} SYP"
            lines.append(f"{index}. {uname} — <b>{metric}</b>")
    await safe_edit(callback, "\n".join(lines), reply_markup=_rank_keyboard(kind, page, items, total))


@router.callback_query(F.data.startswith("admin:users:blocked:"))
async def blocked_users(callback: CallbackQuery, settings: Settings, user_service: UserService) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        page = max(0, int(str(callback.data).rsplit(":", 1)[-1]))
    except Exception:
        page = 0
    items, total = await user_service.blocked_users(limit=PAGE_SIZE, offset=page * PAGE_SIZE)
    lines = ["🚫 <b>المستخدمون المحظورون</b>", ""]
    if not items:
        lines.append("لا يوجد مستخدمون محظورون.")
    else:
        for index, item in enumerate(items, page * PAGE_SIZE + 1):
            uname = f"@{html.escape(str(item['username']))}" if item.get("username") else html.escape(str(item.get("first_name") or item["telegram_id"]))
            lines.append(f"{index}. {uname} • <code>{int(item['telegram_id'])}</code>")
    await safe_edit(callback, "\n".join(lines), reply_markup=_blocked_keyboard(page, items, total))


@router.callback_query(F.data.regexp(r"^admin:user:(ban|unban):prompt:\d+$"))
async def block_prompt(callback: CallbackQuery, settings: Settings) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    parts = str(callback.data).split(":")
    action, target = parts[2], int(parts[-1])
    if target in settings.super_admin_ids:
        await callback.answer("❌ لا يمكن حظر الأدمن الرئيسي.", show_alert=True)
        return
    verb = "حظر" if action == "ban" else "إلغاء حظر"
    await safe_edit(
        callback,
        f"⚠️ هل تريد تأكيد {verb} المستخدم <code>{target}</code>؟",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ تأكيد", callback_data=f"admin:user:{action}:do:{target}")],
            [InlineKeyboardButton(text="⬅️ بطاقة المستخدم", callback_data=f"admin:user:card:{target}")],
        ]),
    )


@router.callback_query(F.data.regexp(r"^admin:user:(ban|unban):do:\d+$"))
async def block_do(callback: CallbackQuery, settings: Settings, user_service: UserService, bot: Bot) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    parts = str(callback.data).split(":")
    action, target = parts[2], int(parts[-1])
    if target in settings.super_admin_ids:
        await callback.answer("❌ لا يمكن حظر الأدمن الرئيسي.", show_alert=True)
        return
    blocked = action == "ban"
    try:
        await user_service.set_blocked(target, blocked, actor_id=int(callback.from_user.id))
    except ValueError:
        await callback.answer("❌ المستخدم غير موجود.", show_alert=True)
        return
    try:
        await bot.send_message(
            target,
            "🚫 تم حظر حسابك من استخدام البوت.\n\nللاستفسار يرجى التواصل مع الدعم."
            if blocked
            else "✅ تم رفع الحظر عن حسابك.\n\nيمكنك الآن استخدام البوت بشكل طبيعي.",
        )
    except Exception:
        pass
    await _render_card(callback, user_service, target)


@router.callback_query(F.data.regexp(r"^admin:user:balance:(add|sub):\d+$"))
async def balance_start(callback: CallbackQuery, state: FSMContext, settings: Settings, user_service: UserService) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    parts = str(callback.data).split(":")
    action, target = parts[3], int(parts[-1])
    if await user_service.admin_card(target) is None:
        await callback.answer("❌ المستخدم غير موجود.", show_alert=True)
        return
    await state.set_state(AdminUserStates.balance_amount)
    await state.update_data(balance_action=action, balance_target=target)
    title = "➕ إضافة رصيد" if action == "add" else "➖ خصم رصيد"
    await safe_edit(
        callback,
        f"{title}\n\n🆔 <code>{target}</code>\nأرسل المبلغ بالليرة السورية كرقم صحيح:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data=f"admin:user:card:{target}")]]),
    )


@router.message(AdminUserStates.balance_amount)
async def balance_value(
    message: Message,
    state: FSMContext,
    settings: Settings,
    wallet_service: WalletService,
    user_service: UserService,
    bot: Bot,
) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings):
        return
    raw = str(message.text or "").replace(",", "").strip()
    if not raw.isdigit() or int(raw) <= 0:
        await message.answer("❌ أدخل مبلغًا صحيحًا أكبر من صفر.")
        return
    amount = int(raw)
    if amount > 9_000_000_000_000_000_000:
        await message.answer("❌ المبلغ أكبر من الحد المسموح.")
        return
    data = await state.get_data()
    action = str(data.get("balance_action") or "")
    target = int(data.get("balance_target") or 0)
    if action not in {"add", "sub"} or target <= 0:
        await state.clear()
        await message.answer("❌ انتهت جلسة التعديل. افتح بطاقة المستخدم وحاول من جديد.", reply_markup=_users_menu())
        return
    key = f"admin-user-{action}:{message.from_user.id}:{target}:{message.chat.id}:{message.message_id}"
    try:
        if action == "add":
            mutation = await wallet_service.credit(
                target,
                amount,
                idempotency_key=key,
                reason="admin user balance credit",
                actor_telegram_id=int(message.from_user.id),
                metadata={"source": "admin_user_card"},
            )
            audit_action = "balance_credit"
        else:
            mutation = await wallet_service.debit(
                target,
                amount,
                idempotency_key=key,
                reason="admin user balance debit",
                actor_telegram_id=int(message.from_user.id),
                metadata={"source": "admin_user_card"},
            )
            audit_action = "balance_debit"
    except InsufficientFunds:
        await message.answer("❌ رصيد المستخدم المتاح لا يكفي لإتمام الخصم.")
        return
    except WalletInvariantError:
        await message.answer("❌ العملية ستتجاوز الحد الآمن للرصيد، لذلك تم رفضها دون أي تعديل مالي.")
        return
    # The ledger mutation is the financial source of truth. Clear the FSM first
    # so an optional audit/Telegram failure can never invite a second debit/credit.
    await state.clear()
    try:
        await user_service.log_admin_action(
            int(message.from_user.id), target, audit_action,
            {"amount": amount, "wallet_operation_id": str(mutation.operation_id), "duplicate": bool(mutation.duplicate)},
        )
    except Exception:
        # Supplementary admin audit failed; immutable wallet ledger still contains
        # actor, reason, amount and operation id. Never roll back or repeat money.
        pass
    balance = mutation.balance_after.available
    verb = "إضافة" if action == "add" else "خصم"
    await message.answer(
        f"✅ تم {verb} <code>{amount:,} SYP</code> بنجاح.\n"
        f"👛 الرصيد الحالي: <code>{balance:,} SYP</code>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="👤 بطاقة المستخدم", callback_data=f"admin:user:card:{target}")],
            [InlineKeyboardButton(text="⬅️ إدارة المستخدمين", callback_data="admin:users")],
        ]),
    )
    try:
        await bot.send_message(
            target,
            (f"➕ تمت إضافة <code>{amount:,} SYP</code> إلى رصيدك." if action == "add" else f"➖ تم خصم <code>{amount:,} SYP</code> من رصيدك.")
            + f"\n👛 رصيدك الحالي: <code>{balance:,} SYP</code>",
        )
    except Exception:
        pass


@router.callback_query(F.data == "admin:users:overview")
async def users_overview(callback: CallbackQuery, settings: Settings, user_service: UserService) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    data = await user_service.overview()
    net = int(data.get("deposits_24h_total") or 0) - int(data.get("withdrawals_24h_total") or 0)
    text = (
        "📊 <b>ملخص المستخدمين والعمليات — آخر 24 ساعة</b>\n\n"
        f"👥 إجمالي المستخدمين: <b>{int(data.get('total_users') or 0):,}</b>\n"
        f"🟢 نشطون خلال 24 ساعة: <b>{int(data.get('active_24h') or 0):,}</b>\n"
        f"🚫 محظورون: <b>{int(data.get('blocked_users') or 0):,}</b>\n\n"
        f"👛 أرصدة المستخدمين المتاحة: <code>{_fmt_amount(data.get('wallet_available'))} SYP</code>\n"
        f"🔒 أرصدة محجوزة: <code>{_fmt_amount(data.get('wallet_held'))} SYP</code>\n\n"
        f"💰 شحن ناجح: <b>{int(data.get('deposits_24h_count') or 0):,}</b> | <code>{_fmt_amount(data.get('deposits_24h_total'))}</code>\n"
        f"💸 سحب ناجح: <b>{int(data.get('withdrawals_24h_count') or 0):,}</b> | <code>{_fmt_amount(data.get('withdrawals_24h_total'))}</code>\n"
        f"📈 صافي محفظة البوت: <code>{net:+,} SYP</code>\n\n"
        f"🎰 شحن iChancy: <code>{_fmt_amount(data.get('ichancy_deposit_24h'))}</code>\n"
        f"🎰 سحب iChancy: <code>{_fmt_amount(data.get('ichancy_withdraw_24h'))}</code>\n\n"
        f"⏳ شحن معلق/تحقق: <b>{int(data.get('deposits_pending') or 0)}</b>\n"
        f"⏳ سحب غير محسوم: <b>{int(data.get('withdrawals_pending') or 0)}</b>\n"
        f"⏳ عمليات iChancy غير محسومة: <b>{int(data.get('ichancy_pending') or 0)}</b>"
    )
    await safe_edit(callback, text, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 تحديث", callback_data="admin:users:overview")],
        [InlineKeyboardButton(text="⬅️ إدارة المستخدمين", callback_data="admin:users")],
    ]))


@router.callback_query(F.data.startswith("admin:user:logs:"))
async def user_logs(callback: CallbackQuery, settings: Settings) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        target = int(str(callback.data).rsplit(":", 1)[-1])
    except Exception:
        return
    await safe_edit(callback, f"📁 <b>سجلات المستخدم</b>\n\n🆔 <code>{target}</code>\nاختر السجل المطلوب:", reply_markup=_history_menu(target))


@router.callback_query(F.data.regexp(r"^admin:user:hist:(deposits|withdrawals|ichancy|referrals|admin):\d+:\d+$"))
async def user_history(callback: CallbackQuery, settings: Settings, user_service: UserService) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        parts = str(callback.data).split(":")
        kind = parts[3]
        target = int(parts[4])
        page = max(0, int(parts[5]))
    except Exception:
        return
    items, total = await user_service.history(target, kind, limit=6, offset=page * 6)
    await safe_edit(callback, _history_text(kind, target, items, page), reply_markup=_history_keyboard(kind, target, page, total))


@router.callback_query(F.data.startswith("admin:user:ichancy_manage:"))
async def ichancy_manage(
    callback: CallbackQuery, settings: Settings, ichancy_accounts: IchancyAccountsService, state: FSMContext
) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    await state.clear()
    try:
        target = int(str(callback.data).rsplit(":", 1)[-1])
    except Exception:
        return
    account = await ichancy_accounts.active_account(target)
    if account is None:
        await safe_edit(
            callback, "❌ لا يوجد حساب iChancy فعال لهذا المستخدم.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="👤 بطاقة المستخدم", callback_data=f"admin:user:card:{target}")]]),
        )
        return
    await safe_edit(
        callback,
        "⚙️ <b>إدارة حساب iChancy</b>\n\n"
        f"🆔 المستخدم: <code>{target}</code>\n"
        f"👤 الحساب: <code>{html.escape(account.username)}</code>\n"
        f"🎮 Player ID: <code>{html.escape(account.player_id)}</code>\n\n"
        "الحذف هنا يفك الربط من البوت فقط ولا يحذف الحساب من موقع iChancy.\n"
        "النقل يغير Telegram ID المرتبط بالحساب بعد فحوصات الأمان.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="🗑 حذف الربط", callback_data=f"admin:user:ichancy_unlink_prompt:{target}"),
                InlineKeyboardButton(text="🔁 نقل الحساب", callback_data=f"admin:user:ichancy_transfer:{target}"),
            ],
            [InlineKeyboardButton(text="👤 بطاقة المستخدم", callback_data=f"admin:user:card:{target}")],
        ]),
    )


@router.callback_query(F.data.startswith("admin:user:ichancy_unlink_prompt:"))
async def ichancy_unlink_prompt(callback: CallbackQuery, settings: Settings, ichancy_accounts: IchancyAccountsService) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        target = int(str(callback.data).rsplit(":", 1)[-1])
    except Exception:
        return
    account = await ichancy_accounts.active_account(target)
    if account is None:
        await safe_edit(callback, "❌ لا يوجد حساب iChancy فعال.")
        return
    await safe_edit(
        callback,
        "⚠️ <b>تأكيد حذف ربط حساب iChancy</b>\n\n"
        f"المستخدم: <code>{target}</code>\n"
        f"الحساب: <code>{html.escape(account.username)}</code>\n"
        f"Player ID: <code>{html.escape(account.player_id)}</code>\n\n"
        "لن يتم حذف الحساب الخارجي. سيتم فقط فك ربطه من هذا Telegram ID مع الاحتفاظ بكل السجلات المالية القديمة.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ تأكيد فك الربط", callback_data=f"admin:user:ichancy_unlink_confirm:{target}")],
            [InlineKeyboardButton(text="❌ إلغاء", callback_data=f"admin:user:ichancy_manage:{target}")],
        ]),
    )


@router.callback_query(F.data.startswith("admin:user:ichancy_unlink_confirm:"))
async def ichancy_unlink_confirm(
    callback: CallbackQuery, settings: Settings, ichancy_accounts: IchancyAccountsService
) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        target = int(str(callback.data).rsplit(":", 1)[-1])
    except Exception:
        return
    try:
        account = await ichancy_accounts.unlink_account(target, admin_id=callback.from_user.id, reason="admin support unlink")
    except Exception as exc:
        await safe_edit(
            callback, f"❌ تعذر فك الربط:\n<code>{html.escape(str(exc)[:700])}</code>",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ رجوع", callback_data=f"admin:user:ichancy_manage:{target}")]]),
        )
        return
    try:
        await callback.bot.send_message(
            target,
            "✅ تم حذف ربط حساب iChancy الخاص بك من البوت بواسطة الدعم.\n\n"
            "يمكنك إنشاء حساب جديد على هذا Telegram ID. الحساب الخارجي نفسه لم يتم حذفه من موقع iChancy.",
        )
    except Exception:
        pass
    await safe_edit(
        callback,
        f"✅ تم فك ربط حساب iChancy بنجاح.\n\nالحساب المحفوظ بالسجل: <code>{html.escape(account.username)}</code>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="👤 بطاقة المستخدم", callback_data=f"admin:user:card:{target}")]]),
    )


@router.callback_query(F.data.startswith("admin:user:ichancy_transfer:"))
async def ichancy_transfer_start(
    callback: CallbackQuery, settings: Settings, ichancy_accounts: IchancyAccountsService, state: FSMContext
) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        source = int(str(callback.data).rsplit(":", 1)[-1])
    except Exception:
        return
    account = await ichancy_accounts.active_account(source)
    if account is None:
        await safe_edit(callback, "❌ لا يوجد حساب iChancy فعال للمستخدم المصدر.")
        return
    await state.set_state(AdminUserStates.ichancy_transfer_target)
    await state.update_data(ichancy_transfer_source=source)
    await safe_edit(
        callback,
        "🔁 <b>نقل حساب iChancy</b>\n\n"
        f"من Telegram ID: <code>{source}</code>\n"
        f"الحساب: <code>{html.escape(account.username)}</code>\n\n"
        "أرسل Telegram ID الجديد. يجب أن يكون المستخدم مسجلاً في البوت ولا يملك حساب iChancy فعالاً.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data=f"admin:user:ichancy_manage:{source}")]]),
    )


@router.message(AdminUserStates.ichancy_transfer_target, F.text)
async def ichancy_transfer_target(
    message: Message, state: FSMContext, settings: Settings, user_service: UserService
) -> None:
    if message.from_user is None or not _is_admin(message.from_user.id, settings):
        return
    data = await state.get_data()
    source = int(data.get("ichancy_transfer_source") or 0)
    raw = str(message.text or "").strip()
    if not raw.isdigit() or int(raw) <= 0:
        await message.answer("❌ أرسل Telegram ID رقمي صحيح.")
        return
    target = int(raw)
    if target == source:
        await message.answer("❌ لا يمكن نقل الحساب إلى نفس Telegram ID.")
        return
    target_card = await user_service.admin_card(target)
    if target_card is None:
        await message.answer("❌ Telegram ID الجديد غير مسجل في البوت. يجب أن يدخل المستخدم إلى البوت أولاً.")
        return
    if target_card.get("ichancy_username"):
        await message.answer("❌ المستخدم الهدف لديه حساب iChancy فعال بالفعل.")
        return
    await state.clear()
    await message.answer(
        "⚠️ <b>تأكيد نقل حساب iChancy</b>\n\n"
        f"من: <code>{source}</code>\n"
        f"إلى: <code>{target}</code>\n\n"
        "سيتم إجراء فحص نهائي ذري عند التأكيد. إذا وُجدت عملية معلقة أو نشاط ضمن دورة مالية مفتوحة سيتم رفض النقل تلقائيًا.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ تأكيد النقل", callback_data=f"admin:user:ichancy_move_confirm:{source}:{target}")],
            [InlineKeyboardButton(text="❌ إلغاء", callback_data=f"admin:user:ichancy_manage:{source}")],
        ]),
    )


@router.callback_query(F.data.regexp(r"^admin:user:ichancy_move_confirm:\d+:\d+$"))
async def ichancy_transfer_confirm(
    callback: CallbackQuery, settings: Settings, ichancy_accounts: IchancyAccountsService
) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        parts = str(callback.data).split(":")
        source = int(parts[-2]); target = int(parts[-1])
    except Exception:
        return
    try:
        account = await ichancy_accounts.transfer_account(source, target, admin_id=callback.from_user.id)
    except Exception as exc:
        await safe_edit(
            callback, f"❌ تعذر نقل الحساب:\n<code>{html.escape(str(exc)[:700])}</code>",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ رجوع", callback_data=f"admin:user:ichancy_manage:{source}")]]),
        )
        return
    for chat_id, text in (
        (source, f"✅ تم نقل حساب iChancy الخاص بك إلى Telegram ID جديد: {target}. يمكنك إنشاء حساب جديد على هذا الآيدي عند الحاجة."),
        (target, f"✅ تم ربط حساب iChancy <code>{html.escape(account.username)}</code> بحساب Telegram الخاص بك بواسطة الدعم."),
    ):
        try:
            await callback.bot.send_message(chat_id, text)
        except Exception:
            pass
    await safe_edit(
        callback,
        "✅ <b>تم نقل حساب iChancy بنجاح</b>\n\n"
        f"الحساب: <code>{html.escape(account.username)}</code>\n"
        f"من: <code>{source}</code> → إلى: <code>{target}</code>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="👤 فتح المستخدم الجديد", callback_data=f"admin:user:card:{target}")]]),
    )


@router.callback_query(F.data.startswith("admin:user:ichancy_balance:"))
async def live_ichancy_balance(
    callback: CallbackQuery,
    settings: Settings,
    ichancy_accounts: IchancyAccountsService,
) -> None:
    if not _is_admin(callback.from_user.id, settings):
        return
    try:
        target = int(str(callback.data).rsplit(":", 1)[-1])
    except Exception:
        return
    try:
        async with asyncio.timeout(8):
            value = await ichancy_accounts.player_balance(target)
    except Exception:
        await callback.answer("⚠️ تعذر جلب رصيد iChancy الآن.", show_alert=True)
        return
    if value is None:
        await callback.answer("ℹ️ لا يوجد حساب iChancy فعال أو تعذر تحديد الرصيد.", show_alert=True)
    else:
        await callback.answer(f"🎰 رصيد iChancy الحالي: {int(value):,}", show_alert=True)
