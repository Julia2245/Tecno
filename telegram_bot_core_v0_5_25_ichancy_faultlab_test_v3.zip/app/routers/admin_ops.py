from __future__ import annotations

import asyncio
import html
import math
import os
import re
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.repositories.admin_ops import AdminOpsRepository
from app.services.admin_access import AdminAccessService
from app.services.backups import BackupArtifact, BackupService
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin_ops")
DAMASCUS = ZoneInfo("Asia/Damascus")
PAGE = 10
RESERVED_SCOPES = {
    "syriatel": "📲 سيرياتيل",
    "shamcash": "💳 شام كاش",
    "binance_usdt": "₮ Binance USDT",
    "whish_proof": "💵 Whish Money",
}


class AdminOpsState(StatesGroup):
    assistant_add = State()
    backup_channel = State()
    restore_file = State()
    reserved_add = State()
    reserved_search = State()


def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data=data)


def _admin(uid: int, settings: Settings) -> bool:
    return int(uid) in settings.super_admin_ids


def _owner(uid: int, settings: Settings) -> bool:
    return int(uid) in settings.owner_admin_ids


def _fmt_dt(value) -> str:
    if not isinstance(value, datetime):
        return "—"
    try:
        return value.astimezone(DAMASCUS).strftime("%d/%m/%Y - %I:%M %p")
    except Exception:
        return str(value)


def _actor_label(row: dict, prefix: str) -> str:
    uid = row.get(f"{prefix}_telegram_id")
    username = str(row.get(f"{prefix}_username") or "").strip().lstrip("@")
    first = str(row.get(f"{prefix}_first_name") or "").strip()
    label = f"@{username}" if username else first or "غير معروف"
    return f"{html.escape(label)} — <code>{int(uid)}</code>" if uid else html.escape(label)


def _ops_menu(settings: Settings, uid: int) -> InlineKeyboardMarkup:
    rows = [
        [_btn("🔒 أرقام العمليات المحجوزة", "admin:ops:reserved")],
    ]
    if _owner(uid, settings):
        rows += [
            [_btn("👮 إدارة الأدمن المساعدين", "admin:ops:assistants")],
            [_btn("🧰 النسخ الاحتياطي والاستعادة", "admin:ops:backup")],
            [_btn("📜 تدقيق العمليات المالية", "admin:ops:audit:wallet:0")],
            [_btn("🛡 سجل الحماية والإدارة", "admin:ops:audit:security:0")],
        ]
    rows.append([_btn("⬅️ لوحة الإدارة", "admin:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin:ops")
async def ops_home(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await state.clear()
    role = "سوبر أدمن" if _owner(callback.from_user.id, settings) else "أدمن مساعد"
    await safe_edit(
        callback,
        "🛡 <b>الإدارة والحماية</b>\n\n"
        f"صلاحيتك الحالية: <b>{role}</b>\n\n"
        "• أرقام العمليات المحجوزة مرتبطة مباشرة بحماية الشحن الحالية.\n"
        "• النسخ والاستعادة وإدارة المساعدين والتدقيق الحساس للسوبر أدمن فقط.\n"
        "• جميع تغييرات هذا القسم تسجّل في سجل حماية غير قابل للتعديل.",
        reply_markup=_ops_menu(settings, callback.from_user.id),
    )


# -------------------- assistant admins --------------------

def _assistants_kb(rows: list[dict]) -> InlineKeyboardMarkup:
    buttons = [[_btn("➕ إضافة مساعد", "admin:ops:assistant:add")]]
    for row in rows[:20]:
        uid = int(row["telegram_id"])
        username = str(row.get("username") or "").strip()
        label = f"@{username}" if username else str(row.get("first_name") or uid)
        buttons.append([_btn(f"➖ {label}"[:60], f"admin:ops:assistant:remove_confirm:{uid}")])
    buttons.append([_btn("⬅️ الإدارة والحماية", "admin:ops")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


@router.callback_query(F.data == "admin:ops:assistants")
async def assistants_home(callback: CallbackQuery, settings: Settings, admin_access: AdminAccessService, state: FSMContext) -> None:
    if not _owner(callback.from_user.id, settings):
        await callback.answer("هذه الصلاحية للسوبر أدمن فقط", show_alert=True)
        return
    await state.clear()
    rows = await admin_access.list_assistants()
    lines = ["👮 <b>إدارة الأدمن المساعدين</b>", "", "السوبر أدمن الحقيقي يبقى من إعدادات السيرفر ولا يمكن تغييره من هنا.", ""]
    if rows:
        lines.append("<b>المساعدون الحاليون:</b>")
        for i, row in enumerate(rows, 1):
            username = str(row.get("username") or "").strip().lstrip("@")
            first = str(row.get("first_name") or "").strip()
            label = f"@{username}" if username else first or "بدون اسم"
            lines.append(f"{i}. {html.escape(label)} — <code>{int(row['telegram_id'])}</code>\n   📅 {_fmt_dt(row.get('added_at'))}")
    else:
        lines.append("لا يوجد أدمن مساعدين حاليًا.")
    await safe_edit(callback, "\n".join(lines), reply_markup=_assistants_kb(rows))


@router.callback_query(F.data == "admin:ops:assistant:add")
async def assistant_add_start(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _owner(callback.from_user.id, settings):
        return
    await state.set_state(AdminOpsState.assistant_add)
    await safe_edit(callback, "➕ <b>إضافة أدمن مساعد</b>\n\nأرسل Telegram ID لمستخدم موجود مسبقًا في البوت.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:ops:assistants")]]))


@router.message(AdminOpsState.assistant_add)
async def assistant_add_message(message: Message, settings: Settings, admin_access: AdminAccessService, state: FSMContext) -> None:
    if message.from_user is None or not _owner(message.from_user.id, settings):
        return
    raw = str(message.text or "").strip()
    if not raw.isdigit() or int(raw) <= 0:
        await message.answer("❌ أرسل Telegram ID رقمي صحيح.")
        return
    target = int(raw)
    ok, reason = await admin_access.add(target, actor=message.from_user.id)
    if not ok:
        text = {
            "user_not_found": "❌ المستخدم غير موجود في قاعدة مستخدمي البوت. اطلب منه تشغيل /start أولًا.",
            "already_exists": "ℹ️ المستخدم أدمن مساعد أصلًا.",
            "is_owner": "❌ هذا المستخدم سوبر أدمن من إعدادات السيرفر.",
            "not_owner": "❌ غير مصرح.",
        }.get(reason, "❌ تعذر إضافة المساعد.")
        await message.answer(text)
        return
    await state.clear()
    try:
        await message.bot.send_message(target, "✅ تم منحك صلاحية الأدمن المساعد في البوت.")
    except Exception:
        pass
    rows = await admin_access.list_assistants()
    await message.answer(f"✅ تم إضافة <code>{target}</code> كأدمن مساعد.\nالصلاحية أصبحت فعالة فورًا دون Restart.", reply_markup=_assistants_kb(rows))


@router.callback_query(F.data.regexp(r"^admin:ops:assistant:remove_confirm:\d+$"))
async def assistant_remove_confirm(callback: CallbackQuery, settings: Settings) -> None:
    if not _owner(callback.from_user.id, settings):
        return
    target = int(str(callback.data).rsplit(":", 1)[-1])
    await safe_edit(callback, f"⚠️ هل تريد إزالة صلاحيات المساعد <code>{target}</code>؟\n\nستُسحب صلاحياته فورًا حتى من الأزرار القديمة.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ نعم، إزالة", f"admin:ops:assistant:remove:{target}")], [_btn("❌ إلغاء", "admin:ops:assistants")]]))


@router.callback_query(F.data.regexp(r"^admin:ops:assistant:remove:\d+$"))
async def assistant_remove(callback: CallbackQuery, settings: Settings, admin_access: AdminAccessService) -> None:
    if not _owner(callback.from_user.id, settings):
        return
    target = int(str(callback.data).rsplit(":", 1)[-1])
    ok = await admin_access.remove(target, actor=callback.from_user.id)
    if not ok:
        await callback.answer("تعذر إزالة المساعد", show_alert=True)
        return
    try:
        await callback.bot.send_message(target, "⚠️ تم سحب صلاحية الأدمن المساعد من حسابك.")
    except Exception:
        pass
    rows = await admin_access.list_assistants()
    await safe_edit(callback, f"✅ تم إزالة <code>{target}</code> من المساعدين.", reply_markup=_assistants_kb(rows))


# -------------------- backups / restore --------------------

def _backup_kb(runtime: RuntimeSettingsService) -> InlineKeyboardMarkup:
    enabled = runtime.get_bool("backup.auto_enabled", True)
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn("🧰 إنشاء نسخة الآن", "admin:ops:backup:now")],
        [_btn("📡 قناة النسخ الاحتياطي", "admin:notify_channels")],
        [_btn("⛔ إيقاف النسخ اليومي" if enabled else "✅ تشغيل النسخ اليومي", "admin:ops:backup:toggle")],
        [_btn("♻️ استعادة نسخة", "admin:ops:restore:start")],
        [_btn("⬅️ الإدارة والحماية", "admin:ops")],
    ])


def _backup_text(runtime: RuntimeSettingsService, history: list[dict]) -> str:
    channel = str(runtime.get("backup.channel", "") or "غير مضبوط")
    enabled = runtime.get_bool("backup.auto_enabled", True)
    last_ok = str(runtime.get("backup.last_ok_at", "") or "غير متوفر")
    last_err = str(runtime.get("backup.last_error", "") or "")
    lines = [
        "🧰 <b>النسخ الاحتياطي والاستعادة</b>", "",
        f"📡 القناة: <code>{html.escape(channel)}</code>",
        f"🔁 النسخ اليومي قرابة 03:00 دمشق: <b>{'مفعل' if enabled else 'متوقف'}</b>",
        f"✅ آخر نسخة ناجحة: <code>{html.escape(last_ok)}</code>",
    ]
    if last_err:
        lines.append(f"❌ آخر خطأ: <code>{html.escape(last_err[:700])}</code>")
    lines += ["", "🔐 النسخة بصيغة PostgreSQL custom dump لمخطط bot_core فقط.", "⚠️ الاستعادة لا تنفذ أثناء عمل الـworkers؛ تُجدول وتطبق عند Restart قبل فتح قاعدة البيانات."]
    if history:
        lines += ["", "<b>آخر العمليات:</b>"]
        for row in history[:4]:
            mark = "✅" if row.get("status") == "success" else "⏳" if row.get("status") == "scheduled" else "❌"
            lines.append(f"{mark} {html.escape(str(row.get('kind')))} — {_fmt_dt(row.get('created_at'))}")
    return "\n".join(lines)


@router.callback_query(F.data == "admin:ops:backup")
async def backup_home(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, admin_ops_repository: AdminOpsRepository, state: FSMContext) -> None:
    if not _owner(callback.from_user.id, settings):
        await callback.answer("هذه الصلاحية للسوبر أدمن فقط", show_alert=True)
        return
    await state.clear()
    hist = await admin_ops_repository.backup_history(limit=4)
    await safe_edit(callback, _backup_text(runtime_settings, hist), reply_markup=_backup_kb(runtime_settings))


@router.callback_query(F.data == "admin:ops:backup:toggle")
async def backup_toggle(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, admin_ops_repository: AdminOpsRepository) -> None:
    if not _owner(callback.from_user.id, settings):
        return
    value = not runtime_settings.get_bool("backup.auto_enabled", True)
    await runtime_settings.set("backup.auto_enabled", value, updated_by=callback.from_user.id)
    await admin_ops_repository.log_security_event(actor=callback.from_user.id, action="backup_auto_toggle", details={"enabled": value})
    hist = await admin_ops_repository.backup_history(limit=4)
    await safe_edit(callback, _backup_text(runtime_settings, hist), reply_markup=_backup_kb(runtime_settings))


@router.callback_query(F.data == "admin:ops:backup:channel")
async def backup_channel_start(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _owner(callback.from_user.id, settings):
        return
    await state.set_state(AdminOpsState.backup_channel)
    await safe_edit(callback, "📡 أرسل معرف القناة بصيغة <code>-100...</code> أو <code>@channel</code>.\nأرسل <code>-</code> لتعطيل القناة.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:ops:backup")]]))


@router.message(AdminOpsState.backup_channel)
async def backup_channel_message(message: Message, settings: Settings, runtime_settings: RuntimeSettingsService, admin_ops_repository: AdminOpsRepository, state: FSMContext) -> None:
    if message.from_user is None or not _owner(message.from_user.id, settings):
        return
    raw = str(message.text or "").strip()
    value = "" if raw == "-" else raw
    if value and not (value.startswith("@") or re.fullmatch(r"-?\d+", value)):
        await message.answer("❌ أرسل -100... أو @channel أو - للتعطيل.")
        return
    await runtime_settings.set("backup.channel", value, updated_by=message.from_user.id)
    await admin_ops_repository.log_security_event(actor=message.from_user.id, action="backup_channel_set", details={"channel": value})
    await state.clear()
    await message.answer("✅ تم حفظ قناة النسخ الاحتياطي.", reply_markup=_backup_kb(runtime_settings))


@router.callback_query(F.data == "admin:ops:backup:now")
async def backup_now(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, backup_service: BackupService) -> None:
    if not _owner(callback.from_user.id, settings):
        return
    await safe_edit(callback, "⏳ جاري إنشاء نسخة PostgreSQL آمنة...")
    try:
        artifact = await backup_service.create_backup(actor=callback.from_user.id, kind="manual")
        target = BackupService._backup_target(runtime_settings.get("backup.channel", "")) or callback.message.chat.id
        await backup_service.send_backup(artifact, target)
        suffix = " وإرسالها لقناة النسخ." if target != callback.message.chat.id else " وإرسالها لك هنا."
        await callback.message.answer(f"✅ تم إنشاء النسخة{suffix}\n🔐 <code>{artifact.sha256}</code>", reply_markup=_backup_kb(runtime_settings))
    except Exception as exc:
        await callback.message.answer(f"❌ فشل النسخ الاحتياطي:\n<code>{html.escape(str(exc)[:3000])}</code>", reply_markup=_backup_kb(runtime_settings))


@router.callback_query(F.data == "admin:ops:restore:start")
async def restore_start(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _owner(callback.from_user.id, settings):
        return
    await state.set_state(AdminOpsState.restore_file)
    await safe_edit(callback, "♻️ <b>استعادة قاعدة البيانات</b>\n\nأرسل ملف <code>.dump</code> أنشأه قسم النسخ الاحتياطي في البوت.\n\nبعد التحقق من الملف سيظهر تأكيد منفصل. لا يتم تنفيذ أي استعادة بمجرد رفع الملف.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:ops:backup")]]))


@router.message(AdminOpsState.restore_file, F.document)
async def restore_file_message(message: Message, settings: Settings, backup_service: BackupService, state: FSMContext) -> None:
    if message.from_user is None or not _owner(message.from_user.id, settings) or message.document is None:
        return
    try:
        artifact = await backup_service.save_restore_upload(message.document)
    except Exception as exc:
        await message.answer(f"❌ الملف غير صالح:\n<code>{html.escape(str(exc)[:2500])}</code>")
        return
    await state.update_data(restore_path=str(artifact.path), restore_sha=artifact.sha256, restore_size=artifact.size_bytes)
    mb = artifact.size_bytes / (1024 * 1024)
    await message.answer(
        "⚠️ <b>تأكيد استعادة خطير</b>\n\n"
        f"📦 الحجم: <b>{mb:.2f} MB</b>\n🔐 SHA-256: <code>{artifact.sha256}</code>\n\n"
        "عند التأكيد سيقوم البوت بـ:\n"
        "1) تفعيل الصيانة.\n2) رفض الاستعادة إذا توجد عملية مالية غير محسومة.\n"
        "3) إنشاء نسخة احترازية جديدة للحالة الحالية.\n4) جدولة الاستعادة ثم إعادة تشغيل الخدمة.\n"
        "5) تطبيق الاستعادة قبل بدء أي worker، ثم يبقى وضع الصيانة مفعلاً للمراجعة.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ أؤكد الاستعادة", "admin:ops:restore:confirm")], [_btn("❌ إلغاء", "admin:ops:restore:cancel")]]),
    )


@router.callback_query(F.data == "admin:ops:restore:cancel")
async def restore_cancel(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _owner(callback.from_user.id, settings):
        return
    data = await state.get_data()
    path = Path(str(data.get("restore_path") or ""))
    try:
        if path.is_file():
            path.unlink()
    except Exception:
        pass
    await state.clear()
    await safe_edit(callback, "✅ تم إلغاء الاستعادة.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ النسخ الاحتياطي", "admin:ops:backup")]]))


@router.callback_query(F.data == "admin:ops:restore:confirm")
async def restore_confirm(callback: CallbackQuery, settings: Settings, backup_service: BackupService, state: FSMContext) -> None:
    if not _owner(callback.from_user.id, settings):
        return
    data = await state.get_data()
    path = Path(str(data.get("restore_path") or ""))
    sha = str(data.get("restore_sha") or "")
    size = int(data.get("restore_size") or 0)
    if not path.is_file() or len(sha) != 64:
        await callback.answer("انتهت جلسة الاستعادة أو الملف غير موجود", show_alert=True)
        return
    artifact = BackupArtifact(path=path, sha256=sha, size_bytes=size)
    await safe_edit(callback, "⏳ جاري تنفيذ فحوص الأمان وإنشاء نسخة احترازية قبل الاستعادة...")
    try:
        safety = await backup_service.schedule_restore(artifact, actor=callback.from_user.id)
    except Exception as exc:
        await state.clear()
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass
        await callback.message.answer(
            f"❌ لم تتم جدولة الاستعادة:\n<code>{html.escape(str(exc)[:3000])}</code>\n\n"
            "وضع الصيانة يبقى مفعلاً إذا وصلنا لمرحلة فحص الاستعادة؛ راجعه من لوحة الأدمن.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ النسخ الاحتياطي", "admin:ops:backup")]]),
        )
        return
    await state.clear()
    await callback.message.answer(
        "✅ <b>تمت جدولة الاستعادة بأمان</b>\n\n"
        f"🛡 النسخة الاحترازية الحالية: <code>{html.escape(safety.path.name)}</code>\n"
        f"🔐 <code>{safety.sha256}</code>\n\n"
        "سيعاد تشغيل خدمة البوت الآن، وستطبق الاستعادة قبل تشغيل أي عملية مالية.\n"
        "بعد العودة سيبقى وضع الصيانة مفعلاً حتى تقوم أنت بإيقافه بعد المراجعة."
    )
    # systemd service uses Restart=always. Exit only after the confirmation was
    # sent and all restore prerequisites were persisted to disk/database.
    asyncio.get_running_loop().call_later(1.0, os._exit, 75)


# -------------------- reserved provider transaction ids --------------------

def _reserved_home_kb(settings: Settings, uid: int) -> InlineKeyboardMarkup:
    rows = [
        [_btn("➕ إضافة أرقام", "admin:ops:reserved:add")],
        [_btn("📋 عرض المحجوزة", "admin:ops:reserved:list:0"), _btn("🔍 بحث", "admin:ops:reserved:search")],
    ]
    if _owner(uid, settings):
        rows.append([_btn("🧹 حذف الكل", "admin:ops:reserved:clear_confirm")])
    rows.append([_btn("⬅️ الإدارة والحماية", "admin:ops")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _scope_kb(prefix: str) -> InlineKeyboardMarkup:
    rows = [[_btn(label, f"{prefix}:{scope}")] for scope, label in RESERVED_SCOPES.items()]
    rows.append([_btn("❌ إلغاء", "admin:ops:reserved")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin:ops:reserved")
async def reserved_home(callback: CallbackQuery, settings: Settings, admin_ops_repository: AdminOpsRepository, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await state.clear()
    total = await admin_ops_repository.reserved_count()
    await safe_edit(callback, "🔒 <b>أرقام العمليات المحجوزة</b>\n\nهذه الواجهة تستخدم نفس جدول الحماية الذي يفحصه الشحن قبل قبول رقم العملية.\nأي رقم محجوز يُرفض ماليًا قبل إنشاء claim.\n\n" f"📊 العدد الحالي: <b>{total:,}</b>", reply_markup=_reserved_home_kb(settings, callback.from_user.id))


@router.callback_query(F.data == "admin:ops:reserved:add")
async def reserved_add_choose(callback: CallbackQuery, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await safe_edit(callback, "➕ اختر نطاق رقم العملية الذي تريد حجزه:", reply_markup=_scope_kb("admin:ops:reserved:add_scope"))


@router.callback_query(F.data.regexp(r"^admin:ops:reserved:add_scope:[a-z0-9_]+$"))
async def reserved_add_scope(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    scope = str(callback.data).rsplit(":", 1)[-1]
    if scope not in RESERVED_SCOPES:
        return
    await state.set_state(AdminOpsState.reserved_add)
    await state.update_data(reserved_scope=scope)
    await safe_edit(callback, f"➕ <b>{RESERVED_SCOPES[scope]}</b>\n\nأرسل رقمًا واحدًا أو عدة أرقام، كل رقم في سطر مستقل أو مفصول بمسافة.\nلن يتم حذف أو تعديل أي claim مالي موجود.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:ops:reserved")]]))


@router.message(AdminOpsState.reserved_add)
async def reserved_add_message(message: Message, settings: Settings, admin_ops_repository: AdminOpsRepository, state: FSMContext) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings):
        return
    data = await state.get_data()
    scope = str(data.get("reserved_scope") or "")
    if scope not in RESERVED_SCOPES:
        await state.clear(); return
    values = [x.strip() for x in re.split(r"[\s,;]+", str(message.text or "")) if x.strip()]
    values = [x for x in values if 1 <= len(x) <= 160]
    if not values:
        await message.answer("❌ لم أجد أرقام عمليات صالحة.")
        return
    if len(values) > 200:
        await message.answer("❌ الحد الأقصى 200 رقم في الدفعة الواحدة.")
        return
    inserted, duplicates = await admin_ops_repository.reserved_add_many(scope, values, created_by=message.from_user.id)
    await state.clear()
    await message.answer(f"✅ تمت الإضافة.\n\n➕ جديد: <b>{inserted}</b>\n♻️ موجود مسبقًا: <b>{duplicates}</b>", reply_markup=_reserved_home_kb(settings, message.from_user.id))


@router.callback_query(F.data.regexp(r"^admin:ops:reserved:list:\d+$"))
async def reserved_list(callback: CallbackQuery, settings: Settings, admin_ops_repository: AdminOpsRepository) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    page = max(0, int(str(callback.data).rsplit(":", 1)[-1]))
    total = await admin_ops_repository.reserved_count()
    rows = await admin_ops_repository.reserved_list(limit=PAGE, offset=page * PAGE)
    pages = max(1, math.ceil(total / PAGE))
    if page >= pages and total:
        page = pages - 1
        rows = await admin_ops_repository.reserved_list(limit=PAGE, offset=page * PAGE)
    lines = [f"📋 <b>الأرقام المحجوزة</b> — صفحة {page+1}/{pages}", ""]
    if not rows:
        lines.append("لا توجد أرقام محجوزة.")
    for i, row in enumerate(rows, page * PAGE + 1):
        lines.append(f"{i}. <code>{html.escape(str(row['provider_tx']))}</code>\n   {html.escape(RESERVED_SCOPES.get(str(row['provider_scope']), str(row['provider_scope'])))} — {_fmt_dt(row.get('created_at'))}")
    nav = []
    if page > 0: nav.append(_btn("⬅️ السابق", f"admin:ops:reserved:list:{page-1}"))
    if (page + 1) * PAGE < total: nav.append(_btn("التالي ➡️", f"admin:ops:reserved:list:{page+1}"))
    kb = [nav] if nav else []
    kb += [[_btn("🔍 بحث/حذف رقم", "admin:ops:reserved:search")], [_btn("⬅️ رجوع", "admin:ops:reserved")]]
    await safe_edit(callback, "\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data == "admin:ops:reserved:search")
async def reserved_search_start(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.set_state(AdminOpsState.reserved_search)
    await safe_edit(callback, "🔍 أرسل رقم العملية المطلوب البحث عنه.\nسيتم البحث عنه في جميع النطاقات.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:ops:reserved")]]))


@router.message(AdminOpsState.reserved_search)
async def reserved_search_message(message: Message, settings: Settings, admin_ops_repository: AdminOpsRepository, state: FSMContext) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    tx = str(message.text or "").strip()
    if not tx or len(tx) > 160:
        await message.answer("❌ رقم العملية غير صالح."); return
    rows = await admin_ops_repository.reserved_find_tx(tx)
    if not rows:
        await message.answer(f"❌ الرقم <code>{html.escape(tx)}</code> غير محجوز.", reply_markup=_reserved_home_kb(settings, message.from_user.id)); await state.clear(); return
    # Deletion uses session state instead of embedding a possibly long tx id in callback_data.
    row = rows[0]
    await state.update_data(reserved_found_scope=str(row["provider_scope"]), reserved_found_tx=tx)
    lines = [f"🔒 الرقم <code>{html.escape(tx)}</code> محجوز في:"]
    for r in rows:
        lines.append(f"• {html.escape(RESERVED_SCOPES.get(str(r['provider_scope']), str(r['provider_scope'])))} — {_fmt_dt(r.get('created_at'))}")
    kb = [[_btn("🗑 حذف الحجز الأول المعروض", "admin:ops:reserved:delete_confirm")], [_btn("🔍 بحث آخر", "admin:ops:reserved:search")], [_btn("⬅️ رجوع", "admin:ops:reserved")]]
    await message.answer("\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data == "admin:ops:reserved:delete_confirm")
async def reserved_delete_confirm(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings): return
    data = await state.get_data(); tx = str(data.get("reserved_found_tx") or ""); scope = str(data.get("reserved_found_scope") or "")
    if not tx or scope not in RESERVED_SCOPES:
        await callback.answer("انتهت جلسة البحث", show_alert=True); return
    await safe_edit(callback, f"⚠️ حذف حجز <code>{html.escape(tx)}</code> من {html.escape(RESERVED_SCOPES[scope])}؟\n\nهذا لا يحذف أي عملية مالية أو claim سابق؛ فقط يسمح باستخدام الرقم مستقبلًا إذا لم يكن مستخدمًا أصلًا.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ حذف الحجز", "admin:ops:reserved:delete_do")], [_btn("❌ إلغاء", "admin:ops:reserved")]]))


@router.callback_query(F.data == "admin:ops:reserved:delete_do")
async def reserved_delete_do(callback: CallbackQuery, settings: Settings, admin_ops_repository: AdminOpsRepository, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings): return
    data = await state.get_data(); tx = str(data.get("reserved_found_tx") or ""); scope = str(data.get("reserved_found_scope") or "")
    ok = bool(tx and scope in RESERVED_SCOPES and await admin_ops_repository.reserved_delete(scope, tx, actor=callback.from_user.id))
    await state.clear()
    await safe_edit(callback, "✅ تم حذف الحجز." if ok else "ℹ️ الحجز غير موجود أصلًا.", reply_markup=_reserved_home_kb(settings, callback.from_user.id))


@router.callback_query(F.data == "admin:ops:reserved:clear_confirm")
async def reserved_clear_confirm(callback: CallbackQuery, settings: Settings) -> None:
    if not _owner(callback.from_user.id, settings):
        await callback.answer("هذه الصلاحية للسوبر أدمن فقط", show_alert=True); return
    await safe_edit(callback, "⚠️ <b>حذف كل الأرقام المحجوزة؟</b>\n\nهذا لا يمس claims أو عمليات الشحن السابقة، لكنه يزيل حاجز الحجز المستقبلي عن جميع الأرقام.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ نعم، حذف الكل", "admin:ops:reserved:clear_do")], [_btn("❌ إلغاء", "admin:ops:reserved")]]))


@router.callback_query(F.data == "admin:ops:reserved:clear_do")
async def reserved_clear_do(callback: CallbackQuery, settings: Settings, admin_ops_repository: AdminOpsRepository) -> None:
    if not _owner(callback.from_user.id, settings): return
    count = await admin_ops_repository.reserved_clear(actor=callback.from_user.id)
    await safe_edit(callback, f"✅ تم حذف <b>{count}</b> حجز رقم عملية.\nلم يتم حذف أي claim أو سجل مالي.", reply_markup=_reserved_home_kb(settings, callback.from_user.id))


# -------------------- immutable read-only audit --------------------

@router.callback_query(F.data.regexp(r"^admin:ops:audit:(wallet|security):\d+$"))
async def audit_page(callback: CallbackQuery, settings: Settings, admin_ops_repository: AdminOpsRepository) -> None:
    if not _owner(callback.from_user.id, settings):
        await callback.answer("هذه الصلاحية للسوبر أدمن فقط", show_alert=True); return
    _, _, _, kind, page_raw = str(callback.data).split(":")
    page = max(0, int(page_raw))
    if kind == "wallet":
        rows, total = await admin_ops_repository.wallet_admin_audit(limit=PAGE, offset=page * PAGE)
        title = "📜 <b>تدقيق تعديلات الرصيد اليدوية</b>"
        lines = [title, "", "المصدر: Wallet Ledger غير القابل للتعديل.", ""]
        for row in rows:
            delta = int(row.get("available_delta") or 0)
            sign = "+" if delta > 0 else ""
            lines += [
                f"• {_fmt_dt(row.get('created_at'))}",
                f"  👮 {_actor_label(row, 'actor')}",
                f"  👤 {_actor_label(row, 'target')}",
                f"  💰 <code>{sign}{delta:,}</code> SYP | <code>{int(row.get('available_before') or 0):,}</code> → <code>{int(row.get('available_after') or 0):,}</code>",
                "",
            ]
    else:
        rows, total = await admin_ops_repository.security_audit(limit=PAGE, offset=page * PAGE)
        title = "🛡 <b>سجل الحماية والإدارة</b>"
        lines = [title, "", "السجل immutable ولا يستخدم لتغيير أي حالة مالية.", ""]
        for row in rows:
            target = f" → {_actor_label(row, 'target')}" if row.get("target_telegram_id") else ""
            lines += [f"• {_fmt_dt(row.get('created_at'))} — <code>{html.escape(str(row.get('action')))}</code>", f"  👮 {_actor_label(row, 'actor')}{target}", ""]
    pages = max(1, math.ceil(total / PAGE))
    if page >= pages and total:
        page = pages - 1
    nav = []
    if page > 0: nav.append(_btn("⬅️ السابق", f"admin:ops:audit:{kind}:{page-1}"))
    if (page + 1) * PAGE < total: nav.append(_btn("التالي ➡️", f"admin:ops:audit:{kind}:{page+1}"))
    kb = [nav] if nav else []
    other = "security" if kind == "wallet" else "wallet"
    kb += [[_btn("🛡 سجل الإدارة" if other == "security" else "📜 التدقيق المالي", f"admin:ops:audit:{other}:0")], [_btn("⬅️ الإدارة والحماية", "admin:ops")]]
    if not rows:
        lines.append("لا توجد سجلات بعد.")
    await safe_edit(callback, "\n".join(lines)[:3900], reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))
