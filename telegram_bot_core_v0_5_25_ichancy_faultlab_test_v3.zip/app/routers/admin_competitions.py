from __future__ import annotations

import html
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.services.competitions import CompetitionError, CompetitionService

router=Router(name='admin_competitions')

class AdminCompetitionStates(StatesGroup):
    input=State()

def _admin(uid:int,settings:Settings)->bool: return int(uid) in settings.super_admin_ids

def _btn(t,d): return InlineKeyboardButton(text=t,callback_data=d)

def _cancel(data='admin:competitions'): return InlineKeyboardMarkup(inline_keyboard=[[_btn('❌ إلغاء',data)]])

def _home_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn('➕ مسابقة جديدة','admin:contest:new'),_btn('📋 المسابقات','admin:contest:list')],
        [_btn('🎲 روليت جديدة','admin:roulette:new'),_btn('📋 جولات الروليت','admin:roulette:list')],
        [_btn('⬅️ لوحة الإدارة','admin:home')],
    ])

@router.callback_query(F.data=='admin:competitions')
async def home(callback:CallbackQuery,state:FSMContext,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.clear(); cs=await competition_service.repository.active_contests(100); rs=await competition_service.repository.active_roulettes(100)
    await safe_edit(callback,f"🏆 <b>المسابقات والروليت</b>\n\n🏆 مسابقات مفتوحة/معلقة: <code>{len(cs)}</code>\n🎲 روليت مفتوحة/جاهزة: <code>{len(rs)}</code>\n\nجوائز الرصيد هنا ترويجية لمدة 24 ساعة وتُستخدم فقط عند شحن iChancy، وليست كاشًا قابلًا للسحب مباشرة.",reply_markup=_home_kb())

@router.callback_query(F.data=='admin:contest:new')
async def contest_new(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.clear(); await safe_edit(callback,'➕ <b>مسابقة جديدة</b>\n\nاختر النوع:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [_btn('⚽ توقع مباراة','admin:contest:type:match_prediction')],
        [_btn('💸 الحظ النقدي','admin:contest:type:cash_luck')],
        [_btn('🏆 أعلى الشاحنين','admin:contest:type:top_depositors')],
        [_btn('🎟 سحب الشاحنين','admin:contest:type:deposit_raffle')],
        [_btn('⬅️ رجوع','admin:competitions')],
    ]))

@router.callback_query(F.data.startswith('admin:contest:type:'))
async def contest_type(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    typ=callback.data.split(':',3)[3]
    if typ not in {'match_prediction','cash_luck','top_depositors','deposit_raffle'}: return
    data={'flow':'contest','template_type':typ,'step':''}
    await state.set_state(AdminCompetitionStates.input)
    if typ=='match_prediction':
        await state.set_data({**data,'step':'prediction_type'})
        await safe_edit(callback,'🎯 اختر نوع التوقع:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('⚽ النتيجة','admin:contest:pred:score'),_btn('🚩 الركنيات','admin:contest:pred:corners')],[_btn('🟨 البطاقات','admin:contest:pred:cards')],[_btn('❌ إلغاء','admin:competitions')]])); return
    if typ=='cash_luck':
        await state.set_data({**data,'step':'suffixes'}); await safe_edit(callback,'🔢 أرسل نهايات أرقام العمليات الفائزة مفصولة بفاصلة. مثال:\n<code>77,88,123</code>',reply_markup=_cancel()); return
    if typ=='deposit_raffle':
        await state.set_data({**data,'step':'raffle_mode'}); await safe_edit(callback,'🎟 اختر طريقة الدخول:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('👤 مرة لكل مستخدم','admin:contest:raffle:user_once')],[_btn('💳 فرصة لكل عملية شحن','admin:contest:raffle:per_deposit')],[_btn('❌ إلغاء','admin:competitions')]])); return
    await state.set_data({**data,'step':'prize_type'}); await _ask_prize_type(callback)

@router.callback_query(F.data.startswith('admin:contest:pred:'))
async def contest_pred_type(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    p=callback.data.rsplit(':',1)[-1]
    if p not in {'score','corners','cards'}: return
    await state.update_data(prediction_type=p,step='teams'); await safe_edit(callback,'⚽ أرسل اسمي الفريقين بهذا الشكل:\n<code>الفريق الأول | الفريق الثاني</code>',reply_markup=_cancel())

@router.callback_query(F.data.startswith('admin:contest:raffle:'))
async def contest_raffle_mode(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    mode=callback.data.rsplit(':',1)[-1]
    if mode not in {'user_once','per_deposit'}: return
    await state.update_data(raffle_entry_mode=mode,step='prize_type'); await _ask_prize_type(callback)

async def _ask_prize_type(target):
    await safe_edit(target,'🎁 اختر نوع الجائزة لكل فائز:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('💰 رصيد ترويجي iChancy','admin:contest:prize:balance')],[_btn('📈 بونص أول شحن %','admin:contest:prize:deposit_bonus')],[_btn('❌ إلغاء','admin:competitions')]]))

@router.callback_query(F.data.startswith('admin:contest:prize:'))
async def contest_prize_type(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    p=callback.data.rsplit(':',1)[-1]
    if p not in {'balance','deposit_bonus'}: return
    await state.update_data(prize_type=p,step='prize_value')
    await safe_edit(callback,'💰 أرسل قيمة الرصيد SYP:' if p=='balance' else '📈 أرسل نسبة البونص (مثال 5):',reply_markup=_cancel())

async def _contest_publish_question(target,state:FSMContext):
    await state.update_data(step='publish')
    if isinstance(target, CallbackQuery):
        await safe_edit(target,'📢 هل تريد نشر رابط المسابقة في القناة المطلوبة؟',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('✅ نعم','admin:contest:publish:yes'),_btn('❌ لا','admin:contest:publish:no')]]))
    else:
        await target.answer('📢 هل تريد نشر رابط المسابقة في القناة المطلوبة؟',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('✅ نعم','admin:contest:publish:yes'),_btn('❌ لا','admin:contest:publish:no')]]))

@router.callback_query(F.data=='admin:contest:media_skip')
async def contest_media_skip(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.update_data(media_type=None,media_file_id=None); await _contest_publish_question(callback,state)

@router.callback_query(F.data.startswith('admin:contest:publish:'))
async def contest_publish(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    yes=callback.data.endswith(':yes'); await state.update_data(publish_to_channel=yes,step='confirm'); await _contest_preview(callback,state)

async def _contest_preview(callback:CallbackQuery,state:FSMContext)->None:
    d=await state.get_data(); lines=['✅ <b>معاينة المسابقة</b>','',f"النوع: <code>{d.get('template_type')}</code>",f"الفائزون: <code>{d.get('winners_count')}</code>",f"الجائزة: <code>{d.get('prize_type')} {d.get('prize_value')}</code>",f"المدة: <code>{d.get('hours')} ساعة</code>",f"النشر بالقناة: <code>{'نعم' if d.get('publish_to_channel') else 'لا'}</code>"]
    await safe_edit(callback,'\n'.join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('✅ إنشاء','admin:contest:create_confirm'),_btn('❌ إلغاء','admin:competitions')]]))

@router.callback_query(F.data=='admin:contest:create_confirm')
async def contest_create_confirm(callback:CallbackQuery,state:FSMContext,settings:Settings,competition_service:CompetitionService,bot:Bot)->None:
    if not _admin(callback.from_user.id,settings): return
    d=await state.get_data(); now=datetime.now(timezone.utc)
    try:
        row=await competition_service.create_contest(
            template_type=d['template_type'],prediction_type=d.get('prediction_type'),team1_name=d.get('team1_name'),team2_name=d.get('team2_name'),suffixes=d.get('suffixes',[]),raffle_entry_mode=d.get('raffle_entry_mode','user_once'),prize_type=d['prize_type'],prize_value=Decimal(str(d['prize_value'])),winners_count=int(d['winners_count']),media_type=d.get('media_type'),media_file_id=d.get('media_file_id'),publish_to_channel=bool(d.get('publish_to_channel')),start_at=now,end_at=now+timedelta(hours=int(d['hours'])),created_by=callback.from_user.id)
    except Exception as exc:
        await state.clear(); await safe_edit(callback,f"❌ {html.escape(str(exc))}",reply_markup=_home_kb()); return
    publish_note=""
    if bool(d.get('publish_to_channel')):
        try:
            ok=await competition_service.publish_contest(bot,int(row['id']),settings.required_channel)
            publish_note="\n📢 تم النشر في القناة المطلوبة." if ok else "\n⚠️ تم الإنشاء لكن قناة النشر غير مضبوطة/غير صالحة."
        except Exception:
            publish_note="\n⚠️ تم الإنشاء لكن تعذر النشر في القناة؛ يمكن متابعة المسابقة من البوت."
    await state.clear(); await safe_edit(callback,f"✅ تم إنشاء المسابقة رقم <code>{int(row['id'])}</code>.{publish_note}",reply_markup=_home_kb())

@router.message(AdminCompetitionStates.input, F.photo | F.video | F.animation)
async def admin_media(message:Message,state:FSMContext,settings:Settings)->None:
    if not _admin(message.from_user.id,settings): return
    d=await state.get_data()
    if d.get('step')!='media': return
    if message.photo: media_type='photo'; file_id=message.photo[-1].file_id
    elif message.animation: media_type='animation'; file_id=message.animation.file_id
    elif message.video: media_type='video'; file_id=message.video.file_id
    else: return
    await state.update_data(media_type=media_type,media_file_id=file_id)
    if d.get('flow')=='contest': await _contest_publish_question(message,state)
    elif d.get('flow')=='roulette': await _roulette_preview(message,state)

@router.message(AdminCompetitionStates.input)
async def admin_input(message:Message,state:FSMContext,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(message.from_user.id,settings): return
    d=await state.get_data(); flow=d.get('flow'); step=d.get('step'); raw=(message.text or '').strip()
    if flow=='contest':
        if step=='teams':
            parts=[x.strip() for x in raw.split('|',1)]
            if len(parts)!=2 or not all(parts): await message.answer('❌ استخدم: الفريق الأول | الفريق الثاني'); return
            await state.update_data(team1_name=parts[0][:80],team2_name=parts[1][:80],step='prize_type'); await message.answer('✅ تم. اختر نوع الجائزة من الزر:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('💰 رصيد ترويجي','admin:contest:prize:balance')],[_btn('📈 بونص شحن %','admin:contest:prize:deposit_bonus')]])); return
        if step=='suffixes':
            vals=[]
            for x in raw.replace(' ','').split(','):
                if not x.isdigit() or len(x)>12: await message.answer('❌ النهايات يجب أن تكون أرقامًا مفصولة بفاصلة.'); return
                if x not in vals: vals.append(x)
            if not vals or len(vals)>100: await message.answer('❌ أدخل من 1 إلى 100 نهاية.'); return
            await state.update_data(suffixes=vals,step='prize_type'); await message.answer('✅ اختر نوع الجائزة:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('💰 رصيد ترويجي','admin:contest:prize:balance')],[_btn('📈 بونص شحن %','admin:contest:prize:deposit_bonus')]])); return
        if step=='prize_value':
            try: value=Decimal(raw.replace(',',''))
            except InvalidOperation: await message.answer('❌ أرسل قيمة رقمية.'); return
            ptype=d.get('prize_type')
            if value<=0 or (ptype=='deposit_bonus' and value>100): await message.answer('❌ القيمة غير صالحة.'); return
            await state.update_data(prize_value=str(value),step='winners'); await message.answer('👥 أرسل عدد الفائزين (1-100):'); return
        if step=='winners':
            if not raw.isdigit() or not (1<=int(raw)<=100): await message.answer('❌ أرسل عددًا من 1 إلى 100.'); return
            await state.update_data(winners_count=int(raw),step='hours'); await message.answer('⏳ أرسل مدة المسابقة بالساعات (1-720):'); return
        if step=='hours':
            if not raw.isdigit() or not (1<=int(raw)<=720): await message.answer('❌ المدة من 1 إلى 720 ساعة.'); return
            await state.update_data(hours=int(raw),step='media')
            await message.answer('🖼 أرسل صورة/GIF/فيديو للمسابقة أو اضغط تخطي:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('⏭ تخطي','admin:contest:media_skip')],[_btn('❌ إلغاء','admin:competitions')]])); return
        return
    if flow=='manual_contest':
        if not raw.isdigit(): await message.answer('❌ أرسل Telegram ID رقميًا.'); return
        try: award=await competition_service.manual_contest_winner(int(d['contest_id']),int(raw),message.from_user.id)
        except Exception as exc: await message.answer(f"❌ {html.escape(str(exc))}"); return
        await state.clear(); await message.answer(f"✅ تم اعتماد <code>{int(award['telegram_id'])}</code> كفائز بالمركز #{int(award['position'])}.",reply_markup=_cancel('admin:contest:list')); return
    if flow=='manual_roulette':
        if not raw.isdigit(): await message.answer('❌ أرسل Telegram ID رقميًا.'); return
        try: award=await competition_service.manual_roulette_winner(int(d['roulette_id']),int(raw),message.from_user.id)
        except Exception as exc: await message.answer(f"❌ {html.escape(str(exc))}"); return
        await state.clear(); await message.answer(f"✅ تم اعتماد <code>{int(award['telegram_id'])}</code> كفائز بالمركز #{int(award['position'])}.",reply_markup=_cancel('admin:roulette:list')); return
    if flow=='result':
        parts=raw.replace(':','-').split('-',1)
        if len(parts)!=2 or not all(x.strip().isdigit() for x in parts): await message.answer('❌ أرسل النتيجة مثل 2-1'); return
        await state.update_data(v1=int(parts[0]),v2=int(parts[1]),step='result_confirm')
        await message.answer(f"تأكيد النتيجة <b>{int(parts[0])} - {int(parts[1])}</b>؟",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('✅ تأكيد','admin:contest:result_confirm'),_btn('❌ إلغاء','admin:contest:list')]])); return
    if flow=='roulette':
        await _roulette_text_input(message,state,d,step,raw)

@router.callback_query(F.data=='admin:contest:list')
async def contest_list(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    kb=InlineKeyboardMarkup(inline_keyboard=[
        [_btn('🟢 النشطة','admin:contest:list:active:0'),_btn('⏳ بانتظار إجراء','admin:contest:list:waiting:0')],
        [_btn('✅ المنتهية/الملغاة','admin:contest:list:ended:0')],
        [_btn('⬅️ رجوع','admin:competitions')],
    ])
    await safe_edit(callback,'📋 <b>قائمة المسابقات</b>\n\nاختر القسم:',reply_markup=kb)

@router.callback_query(F.data.startswith('admin:contest:list:'))
async def contest_group_list(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    parts=callback.data.split(':'); group=parts[-2]; page=max(0,int(parts[-1])); offset=page*10
    where={
        'active':"status='active'",
        'waiting':"status IN ('waiting_result','ready_for_draw')",
        'ended':"status IN ('completed','cancelled')",
    }.get(group)
    if where is None: return
    pool=competition_service.db.require_pool()
    async with pool.acquire() as conn:
        rows=await conn.fetch(f"SELECT * FROM bot_core.contests WHERE {where} ORDER BY id DESC LIMIT 10 OFFSET $1",offset)
    title={'active':'🟢 المسابقات النشطة','waiting':'⏳ بانتظار إجراء','ended':'✅ المسابقات المنتهية/الملغاة'}[group]
    kb=[]
    for c in rows: kb.append([_btn(f"#{int(c['id'])} • {str(c['template_type'])[:32]} • {c['status']}",f"admin:contest:view:{int(c['id'])}")])
    nav=[]
    if page>0: nav.append(_btn('⬅️ السابق',f'admin:contest:list:{group}:{page-1}'))
    if len(rows)==10: nav.append(_btn('التالي ➡️',f'admin:contest:list:{group}:{page+1}'))
    if nav: kb.append(nav)
    kb.append([_btn('⬅️ الأقسام','admin:contest:list')])
    await safe_edit(callback,f'<b>{title}</b>' if rows else f'<b>{title}</b>\n\nلا توجد عناصر في هذا القسم.',reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith('admin:contest:view:'))
async def contest_view(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(callback.data.rsplit(':',1)[-1]); c=await competition_service.repository.get_contest(cid)
    if not c: return
    count=int(await competition_service.db.require_pool().fetchval('SELECT 0') or 0) if False else 0
    pool=competition_service.db.require_pool()
    async with pool.acquire() as conn: count=int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.contest_entries WHERE contest_id=$1',cid) or 0)
    kb=[]
    if c['publish_to_channel'] and not c['channel_message_id'] and c['status']!='cancelled': kb.append([_btn('📢 نشر في القناة',f'admin:contest:publish:{cid}')])
    if c['template_type']=='match_prediction' and c['status']=='waiting_result': kb.append([_btn('🎯 إدخال النتيجة',f'admin:contest:result:{cid}')])
    if c['status']=='ready_for_draw': kb.append([_btn('🎲 إجراء السحب',f'admin:contest:draw:{cid}'),_btn('👤 فائز يدوي',f'admin:contest:manual:{cid}')])
    kb.append([_btn('🏆 الفائزون',f'contest:winners:{cid}'),_btn('👁 عرض كمستخدم',f'contest:view:{cid}')])
    kb.append([_btn('🗑 إلغاء وحذف نهائي',f'admin:contest:cancel:{cid}')])
    kb.append([_btn('⬅️ القائمة','admin:contest:list')])
    await safe_edit(callback,f"🏆 <b>مسابقة #{cid}</b>\n\nالنوع: <code>{c['template_type']}</code>\nالحالة: <b>{c['status']}</b>\nالمشاركات: <code>{count}</code>\nالنهاية: <code>{c['end_at']}</code>",reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith('admin:contest:publish:'))
async def contest_publish_retry(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService,bot:Bot)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(callback.data.rsplit(':',1)[-1])
    try:
        ok=await competition_service.publish_contest(bot,cid,settings.required_channel)
        await callback.answer('✅ تم النشر في القناة.' if ok else '❌ قناة النشر غير مضبوطة أو غير صالحة.',show_alert=True)
    except Exception as exc:
        await callback.answer(f'❌ {str(exc)[:150]}',show_alert=True)
    await contest_view(callback,settings,competition_service)

@router.callback_query(F.data.startswith('admin:contest:result:'))
async def contest_result_start(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(callback.data.rsplit(':',1)[-1]); await state.set_state(AdminCompetitionStates.input); await state.set_data({'flow':'result','step':'result','contest_id':cid}); await safe_edit(callback,'🎯 أرسل النتيجة بصيغة <code>2-1</code>:',reply_markup=_cancel('admin:contest:list'))

@router.callback_query(F.data=='admin:contest:result_confirm')
async def contest_result_confirm(callback:CallbackQuery,state:FSMContext,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    d=await state.get_data()
    try: awards=await competition_service.set_match_result_and_draw(int(d['contest_id']),int(d['v1']),int(d['v2']),callback.from_user.id)
    except Exception as exc: await state.clear(); await safe_edit(callback,f"❌ {html.escape(str(exc))}",reply_markup=_home_kb()); return
    await state.clear(); await safe_edit(callback,f"✅ تم اعتماد النتيجة والسحب. الفائزون: <code>{len(awards)}</code>",reply_markup=_home_kb())

@router.callback_query(F.data.startswith('admin:contest:manual:'))
async def contest_manual_start(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(callback.data.rsplit(':',1)[-1]); await state.set_state(AdminCompetitionStates.input); await state.set_data({'flow':'manual_contest','contest_id':cid}); await safe_edit(callback,'👤 أرسل Telegram ID لمشارك صالح لإضافته كفائز يدوي:',reply_markup=_cancel(f'admin:contest:view:{cid}'))

@router.callback_query(F.data.startswith('admin:contest:draw:'))
async def contest_draw(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(callback.data.rsplit(':',1)[-1])
    try: rows=await competition_service.draw_contest(cid,callback.from_user.id); await callback.answer(f'✅ تم السحب: {len(rows)} فائز',show_alert=True)
    except Exception as exc: await callback.answer(str(exc),show_alert=True)
    await contest_view(callback,settings,competition_service)

@router.callback_query(F.data.startswith('admin:contest:cancel:'))
async def contest_cancel(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(callback.data.rsplit(':',1)[-1]); c=await competition_service.repository.get_contest(cid)
    if not c: await callback.answer('المسابقة غير موجودة.',show_alert=True); return
    await safe_edit(callback,f"⚠️ <b>تأكيد الإلغاء والحذف النهائي</b>\n\nالمسابقة: <code>#{cid}</code>\nالحالة: <b>{c['status']}</b>\n\nسيتم حذف المسابقة ومشاركاتها نهائيًا. إذا تم اعتماد أي جائزة سيمنع النظام الحذف تلقائيًا.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('🗑 نعم، حذف نهائي',f'admin:contest:cancel_confirm:{cid}')],[_btn('⬅️ لا، رجوع',f'admin:contest:view:{cid}')]]))

@router.callback_query(F.data.startswith('admin:contest:cancel_confirm:'))
async def contest_cancel_confirm(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService,bot:Bot)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(callback.data.rsplit(':',1)[-1])
    try:
        result=await competition_service.delete_contest_permanently(cid,callback.from_user.id)
    except Exception as exc:
        await callback.answer(str(exc)[:180],show_alert=True); return
    if result.get('channel_chat_ref') and result.get('channel_message_id'):
        try: await bot.delete_message(result['channel_chat_ref'],int(result['channel_message_id']))
        except Exception: pass
    await safe_edit(callback,f"✅ تم إلغاء وحذف المسابقة <b>#{cid}</b> نهائيًا.\n\nحُذفت المشاركات المرتبطة: <code>{int(result['entry_count'])}</code>.\nلم يتم تعديل أي محفظة أو عملية مالية.",reply_markup=_home_kb())

# ---------------- advanced roulette ----------------

@router.callback_query(F.data=='admin:roulette:new')
async def roulette_new(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.clear(); await safe_edit(callback,'🎲 اختر طريقة المشاركة:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('🎟 مجانية','admin:roulette:mode:free')],[_btn('💳 حسب الشحن','admin:roulette:mode:deposit')],[_btn('❌ إلغاء','admin:competitions')]]))

@router.callback_query(F.data.startswith('admin:roulette:mode:'))
async def roulette_mode(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    mode=callback.data.rsplit(':',1)[-1]; await state.set_state(AdminCompetitionStates.input)
    if mode=='free': await state.set_data({'flow':'roulette','step':'winners','participation_mode':'free','min_deposit_syp':0,'max_chances_per_user':1}); await safe_edit(callback,'🏆 أرسل عدد الفائزين (1-100):',reply_markup=_cancel())
    elif mode=='deposit': await state.set_data({'flow':'roulette','step':'min_deposit','participation_mode':'deposit'}); await safe_edit(callback,'💳 أرسل الحد الأدنى للشحن لكل فرصة SYP:',reply_markup=_cancel())

async def _roulette_text_input(message:Message,state:FSMContext,d:dict,step:str,raw:str)->None:
    if step=='min_deposit':
        clean=raw.replace(',','')
        if not clean.isdigit() or int(clean)<=0: await message.answer('❌ أرسل مبلغًا صحيحًا.'); return
        await state.update_data(min_deposit_syp=int(clean),step='max_chances'); await message.answer('🎫 أرسل الحد الأقصى للفرص لكل مستخدم (0 = غير محدود):'); return
    if step=='max_chances':
        if not raw.isdigit() or int(raw)>10000: await message.answer('❌ أرسل رقمًا من 0 إلى 10000.'); return
        await state.update_data(max_chances_per_user=int(raw),step='winners'); await message.answer('🏆 أرسل عدد الفائزين (1-100):'); return
    if step=='winners':
        if not raw.isdigit() or not 1<=int(raw)<=100: await message.answer('❌ من 1 إلى 100.'); return
        await state.update_data(winners_count=int(raw),step='prizes'); await message.answer('🎁 أرسل الجوائز سطرًا لكل مركز، وعدد الأسطر يجب أن يساوي عدد الفائزين.\n\nالصيغ:\n<code>balance:50000</code>\n<code>deposit_bonus:5</code>\n<code>custom:هاتف</code>'); return
    if step=='prizes':
        prizes=[]
        for line in [x.strip() for x in raw.splitlines() if x.strip()]:
            if ':' not in line: await message.answer('❌ صيغة الجائزة غير صحيحة.'); return
            typ,val=line.split(':',1); typ=typ.strip(); val=val.strip()
            if typ in {'balance','deposit_bonus'}:
                try: num=Decimal(val.replace(',',''))
                except InvalidOperation: await message.answer('❌ قيمة جائزة غير صحيحة.'); return
                if num<=0 or (typ=='deposit_bonus' and num>100): await message.answer('❌ قيمة الجائزة غير صالحة.'); return
                prizes.append({'prize_type':typ,'prize_value':str(num)})
            elif typ=='custom' and val: prizes.append({'prize_type':'custom','prize_value':'0','custom_text':val[:300]})
            else: await message.answer('❌ نوع الجائزة غير معروف.'); return
        if len(prizes)!=int(d['winners_count']): await message.answer(f"❌ المطلوب {int(d['winners_count'])} أسطر جوائز."); return
        await state.update_data(prizes=prizes,step='max_participants'); await message.answer('👥 أرسل الحد الأقصى للمشاركين (0 = غير محدود):'); return
    if step=='max_participants':
        if not raw.isdigit(): await message.answer('❌ أرسل رقمًا صحيحًا.'); return
        n=int(raw)
        if n and n<int(d['winners_count']): await message.answer('❌ الحد الأقصى لا يمكن أن يكون أقل من عدد الفائزين.'); return
        await state.update_data(max_participants=n,step='hours'); await message.answer('⏳ أرسل مدة الروليت بالساعات (1-720):'); return
    if step=='hours':
        if not raw.isdigit() or not 1<=int(raw)<=720: await message.answer('❌ من 1 إلى 720 ساعة.'); return
        await state.update_data(hours=int(raw),step='auto'); await message.answer('🎲 طريقة السحب:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('⚡ تلقائي عند الانتهاء','admin:roulette:auto:yes')],[_btn('👆 يدوي من الأدمن','admin:roulette:auto:no')]])); return

@router.callback_query(F.data.startswith('admin:roulette:auto:'))
async def roulette_auto(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.update_data(auto_draw=callback.data.endswith(':yes'),step='media')
    await safe_edit(callback,'🖼 أرسل صورة/GIF/فيديو خاص بهذه الروليت أو اضغط تخطي:',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('⏭ تخطي','admin:roulette:media_skip')],[_btn('❌ إلغاء','admin:competitions')]]))

async def _roulette_preview(target,state:FSMContext):
    d=await state.get_data(); await state.update_data(step='confirm')
    text=f"✅ <b>معاينة الروليت</b>\n\nالمشاركة: <code>{d['participation_mode']}</code>\nالفائزون: <code>{d['winners_count']}</code>\nالمدة: <code>{d['hours']} ساعة</code>\nالسحب التلقائي: <code>{'نعم' if d.get('auto_draw') else 'لا'}</code>\nالوسائط: <code>{d.get('media_type') or 'بدون'}</code>"
    kb=InlineKeyboardMarkup(inline_keyboard=[[_btn('✅ إنشاء','admin:roulette:create_confirm'),_btn('❌ إلغاء','admin:competitions')]])
    if isinstance(target,CallbackQuery): await safe_edit(target,text,reply_markup=kb)
    else: await target.answer(text,reply_markup=kb)

@router.callback_query(F.data=='admin:roulette:media_skip')
async def roulette_media_skip(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.update_data(media_type=None,media_file_id=None); await _roulette_preview(callback,state)

@router.callback_query(F.data=='admin:roulette:create_confirm')
async def roulette_create_confirm(callback:CallbackQuery,state:FSMContext,settings:Settings,competition_service:CompetitionService,bot:Bot)->None:
    if not _admin(callback.from_user.id,settings): return
    d=await state.get_data(); now=datetime.now(timezone.utc)
    try:
        row=await competition_service.create_roulette(bot_name_snapshot=settings.bot_display_name or 'البوت',participation_mode=d['participation_mode'],min_deposit_syp=int(d.get('min_deposit_syp',0)),max_chances_per_user=int(d.get('max_chances_per_user',0)),winners_count=int(d['winners_count']),max_participants=int(d.get('max_participants',0)),auto_draw=bool(d.get('auto_draw')),media_type=d.get('media_type'),media_file_id=d.get('media_file_id'),start_at=now,end_at=now+timedelta(hours=int(d['hours'])),created_by=callback.from_user.id,prizes=d['prizes'])
    except Exception as exc: await state.clear(); await safe_edit(callback,f"❌ {html.escape(str(exc))}",reply_markup=_home_kb()); return
    publish_note=""
    if str(settings.required_channel or '').strip():
        try:
            ok=await competition_service.publish_roulette(bot,int(row['id']),settings.required_channel)
            publish_note="\n📢 تم نشر الروليت في القناة المطلوبة." if ok else "\n⚠️ تم الإنشاء لكن تعذر تحديد قناة النشر."
        except Exception:
            publish_note="\n⚠️ تم الإنشاء لكن تعذر نشر الروليت في القناة."
    await state.clear(); await safe_edit(callback,f"✅ تم إنشاء الروليت رقم <code>{int(row['id'])}</code>.{publish_note}",reply_markup=_home_kb())

@router.callback_query(F.data=='admin:roulette:list')
async def roulette_list(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    kb=InlineKeyboardMarkup(inline_keyboard=[
        [_btn('🟢 النشطة','admin:roulette:list:active:0'),_btn('⏳ جاهزة للسحب','admin:roulette:list:waiting:0')],
        [_btn('✅ المنتهية/الملغاة','admin:roulette:list:ended:0')],
        [_btn('⬅️ رجوع','admin:competitions')],
    ])
    await safe_edit(callback,'📋 <b>جولات الروليت</b>\n\nاختر القسم:',reply_markup=kb)

@router.callback_query(F.data.startswith('admin:roulette:list:'))
async def roulette_group_list(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    parts=callback.data.split(':'); group=parts[-2]; page=max(0,int(parts[-1])); offset=page*10
    where={'active':"status='active'",'waiting':"status='ready_for_draw'",'ended':"status IN ('completed','cancelled')"}.get(group)
    if where is None: return
    pool=competition_service.db.require_pool()
    async with pool.acquire() as conn:
        rows=await conn.fetch(f"SELECT * FROM bot_core.roulettes WHERE {where} ORDER BY id DESC LIMIT 10 OFFSET $1",offset)
    title={'active':'🟢 الروليت النشطة','waiting':'⏳ الروليت الجاهزة للسحب','ended':'✅ الروليت المنتهية/الملغاة'}[group]
    kb=[]
    for r in rows: kb.append([_btn(f"🎲 #{int(r['id'])} • {r['status']}",f"admin:roulette:view:{int(r['id'])}")])
    nav=[]
    if page>0: nav.append(_btn('⬅️ السابق',f'admin:roulette:list:{group}:{page-1}'))
    if len(rows)==10: nav.append(_btn('التالي ➡️',f'admin:roulette:list:{group}:{page+1}'))
    if nav: kb.append(nav)
    kb.append([_btn('⬅️ الأقسام','admin:roulette:list')])
    await safe_edit(callback,f'<b>{title}</b>' if rows else f'<b>{title}</b>\n\nلا توجد عناصر في هذا القسم.',reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith('admin:roulette:view:'))
async def roulette_admin_view(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService,roulette_id:int|None=None)->None:
    if not _admin(callback.from_user.id,settings): return
    rid=int(roulette_id) if roulette_id is not None else int(callback.data.rsplit(':',1)[-1]); r=await competition_service.repository.get_roulette(rid)
    if not r:return
    pool=competition_service.db.require_pool()
    async with pool.acquire() as conn:
        chances=int(await conn.fetchval('SELECT COUNT(*) FROM bot_core.roulette_entries WHERE roulette_id=$1',rid) or 0); users=int(await conn.fetchval('SELECT COUNT(DISTINCT telegram_id) FROM bot_core.roulette_entries WHERE roulette_id=$1',rid) or 0)
        pending=await conn.fetch('SELECT id,position,telegram_id,custom_text FROM bot_core.roulette_awards WHERE roulette_id=$1 AND prize_type=\'custom\' AND fulfillment_status=\'pending\' ORDER BY position',rid)
    kb=[]
    if not r['channel_message_id'] and r['status']!='cancelled': kb.append([_btn('📢 نشر في القناة',f'admin:roulette:publish:{rid}')])
    if r['status']=='active': kb.append([_btn('🔒 إغلاق المشاركة الآن',f'admin:roulette:close:{rid}')])
    if r['status']=='ready_for_draw': kb.append([_btn('🎲 إجراء السحب',f'admin:roulette:draw:{rid}'),_btn('👤 فائز يدوي',f'admin:roulette:manual:{rid}')])
    if r['status'] in {'active','ready_for_draw'}: kb.append([_btn('⛔ إلغاء',f'admin:roulette:cancel:{rid}')])
    if r['status']=='completed': kb.append([_btn('🏆 عرض الفائزين',f'admin:roulette:winners:{rid}')])
    for a in pending[:10]: kb.append([_btn(f"✅ تسليم جائزة #{int(a['position'])}",f"admin:roulette:fulfill:{int(a['id'])}")])
    kb.append([_btn('⬅️ القائمة','admin:roulette:list')])
    await safe_edit(callback,f"🎲 <b>روليت #{rid}</b>\n\nالحالة: <b>{r['status']}</b>\nالمستخدمون: <code>{users}</code>\nإجمالي الفرص: <code>{chances}</code>\nالفائزون: <code>{int(r['winners_count'])}</code>\nالنهاية: <code>{r['end_at']}</code>",reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith('admin:roulette:publish:'))
async def roulette_publish_retry(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService,bot:Bot)->None:
    if not _admin(callback.from_user.id,settings): return
    rid=int(callback.data.rsplit(':',1)[-1])
    try:
        ok=await competition_service.publish_roulette(bot,rid,settings.required_channel)
        await callback.answer('✅ تم النشر في القناة.' if ok else '❌ قناة النشر غير مضبوطة أو غير صالحة.',show_alert=True)
    except Exception as exc:
        await callback.answer(f'❌ {str(exc)[:150]}',show_alert=True)
    await roulette_admin_view(callback,settings,competition_service,rid)

@router.callback_query(F.data.startswith('admin:roulette:close:'))
async def roulette_close_now(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    rid=int(callback.data.rsplit(':',1)[-1])
    try:
        r=await competition_service.force_roulette_ready(rid,callback.from_user.id)
        if bool(r['auto_draw']):
            awards=await competition_service.draw_roulette(rid,callback.from_user.id)
            await callback.answer(f'✅ تم الإغلاق والسحب: {len(awards)} فائز',show_alert=True)
        else:
            await callback.answer('✅ تم إغلاق المشاركة. الروليت جاهزة للسحب.',show_alert=True)
    except Exception as exc:
        await callback.answer(str(exc)[:180],show_alert=True)
    await roulette_admin_view(callback,settings,competition_service,rid)

@router.callback_query(F.data.startswith('admin:roulette:manual:'))
async def roulette_manual_start(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    rid=int(callback.data.rsplit(':',1)[-1]); await state.set_state(AdminCompetitionStates.input); await state.set_data({'flow':'manual_roulette','roulette_id':rid}); await safe_edit(callback,'👤 أرسل Telegram ID لمشارك صالح لإضافته كفائز يدوي:',reply_markup=_cancel(f'admin:roulette:view:{rid}'))

@router.callback_query(F.data.startswith('admin:roulette:draw:'))
async def roulette_draw(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    rid=int(callback.data.rsplit(':',1)[-1])
    try: awards=await competition_service.draw_roulette(rid,callback.from_user.id); await callback.answer(f'✅ تم السحب: {len(awards)} فائز',show_alert=True)
    except Exception as exc: await callback.answer(str(exc),show_alert=True)
    await roulette_admin_view(callback,settings,competition_service)

@router.callback_query(F.data.startswith('admin:roulette:winners:'))
async def roulette_admin_winners(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    rid=int(callback.data.rsplit(':',1)[-1]); pool=competition_service.db.require_pool()
    async with pool.acquire() as conn:
        rows=await conn.fetch("""SELECT a.*,u.first_name,u.username FROM bot_core.roulette_awards a LEFT JOIN bot_core.users u ON u.telegram_id=a.telegram_id WHERE a.roulette_id=$1 ORDER BY a.position""",rid)
    lines=[f'🏆 <b>فائزون روليت #{rid}</b>','']
    for a in rows:
        name=str(a['first_name'] or (f"@{a['username']}" if a['username'] else f"ID {int(a['telegram_id'])}"))
        prize=str(a['custom_text'] if a['prize_type']=='custom' else a['prize_value'])
        state=(' • ⏳ بانتظار التسليم' if a['prize_type']=='custom' and a['fulfillment_status']=='pending' else '')
        lines.append(f"#{int(a['position'])} — <b>{html.escape(name)}</b> — {html.escape(prize)}{state}")
    if not rows: lines.append('لا يوجد فائزون بعد.')
    await safe_edit(callback,'\n'.join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('⬅️ التفاصيل',f'admin:roulette:view:{rid}')]]))

@router.callback_query(F.data.startswith('admin:roulette:fulfill:'))
async def roulette_fulfill(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    aid=int(callback.data.rsplit(':',1)[-1])
    rid=None
    try:
        pool=competition_service.db.require_pool()
        async with pool.acquire() as conn:
            rid=await conn.fetchval('SELECT roulette_id FROM bot_core.roulette_awards WHERE id=$1',aid)
        await competition_service.fulfill_custom_roulette_prize(aid,callback.from_user.id)
        await callback.answer('✅ تم تسجيل تسليم الجائزة.',show_alert=True)
    except Exception as exc:
        await callback.answer(str(exc),show_alert=True)
    if rid is not None:
        await roulette_admin_view(callback,settings,competition_service,int(rid))

@router.callback_query(F.data.startswith('admin:roulette:cancel:'))
async def roulette_cancel(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    rid=int(callback.data.rsplit(':',1)[-1]); r=await competition_service.repository.get_roulette(rid)
    if not r: await callback.answer('الروليت غير موجودة.',show_alert=True); return
    await safe_edit(callback,f"⚠️ هل تريد إلغاء روليت <b>#{rid}</b>؟\nلن يتم صرف أي جوائز جديدة.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn('✅ نعم، إلغاء',f'admin:roulette:cancel_confirm:{rid}')],[_btn('⬅️ رجوع',f'admin:roulette:view:{rid}')]]))

@router.callback_query(F.data.startswith('admin:roulette:cancel_confirm:'))
async def roulette_cancel_confirm(callback:CallbackQuery,settings:Settings,competition_service:CompetitionService)->None:
    if not _admin(callback.from_user.id,settings): return
    rid=int(callback.data.rsplit(':',1)[-1]); pool=competition_service.db.require_pool()
    async with pool.acquire() as conn:
        async with conn.transaction():
            r=await conn.fetchrow('SELECT * FROM bot_core.roulettes WHERE id=$1 FOR UPDATE',rid)
            if not r:return
            if await conn.fetchval('SELECT 1 FROM bot_core.roulette_awards WHERE roulette_id=$1 LIMIT 1',rid): await callback.answer('لا يمكن الإلغاء بعد بدء توزيع الجوائز.',show_alert=True); return
            await conn.execute("UPDATE bot_core.roulettes SET status='cancelled',cancelled_at=NOW(),cancelled_by=$2,updated_at=NOW() WHERE id=$1 AND status NOT IN ('completed','cancelled')",rid,callback.from_user.id)
    await callback.answer('✅ تم إلغاء الروليت.',show_alert=True); await roulette_list(callback,settings,competition_service)
