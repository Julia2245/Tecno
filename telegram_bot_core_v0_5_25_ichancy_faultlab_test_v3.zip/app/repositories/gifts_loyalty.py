from __future__ import annotations

from typing import Any
import json
from uuid import UUID

import asyncpg

from app.core.db import Database


class GiftsLoyaltyRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def user_exists(self, conn: asyncpg.Connection, telegram_id: int, *, for_update: bool = False) -> dict[str, Any] | None:
        suffix = " FOR UPDATE" if for_update else ""
        row = await conn.fetchrow(
            "SELECT telegram_id,username,first_name,is_blocked,is_bot FROM bot_core.users WHERE telegram_id=$1" + suffix,
            int(telegram_id),
        )
        return dict(row) if row else None

    async def protected_available(self, conn: asyncpg.Connection, telegram_id: int) -> int:
        """Replay immutable wallet history to find the unspent non-transferable amount.

        New protected credits are marked in ledger metadata. Ordinary spending consumes
        protected value first, matching the reference behaviour. Gift transfers are the
        only debits that preserve it. Hold releases restore exactly the protected portion
        allocated when that hold was created.
        """
        rows = await conn.fetch(
            """
            SELECT l.id,l.operation_id,l.entry_type,l.available_delta,l.held_delta,l.metadata,
                   hc.id AS created_hold_id, hx.id AS closed_hold_id
            FROM bot_core.wallet_accounts a
            JOIN bot_core.wallet_ledger l ON l.account_id=a.id
            LEFT JOIN bot_core.wallet_holds hc ON hc.created_by_operation_id=l.operation_id
            LEFT JOIN bot_core.wallet_holds hx ON hx.closed_by_operation_id=l.operation_id
            WHERE a.telegram_id=$1 AND a.asset_code='SYP' AND a.bucket='cash'
            ORDER BY l.id ASC
            """,
            int(telegram_id),
        )
        protected = 0
        hold_parts: dict[UUID, int] = {}
        for r in rows:
            raw_meta = r["metadata"] or {}
            if isinstance(raw_meta, str):
                try:
                    raw_meta = json.loads(raw_meta)
                except Exception:
                    raw_meta = {}
            meta = dict(raw_meta or {})
            entry = str(r["entry_type"])
            available_delta = int(r["available_delta"] or 0)
            if entry == "credit":
                # Whole-credit promo markers are used by gift codes, loyalty,
                # wheel/referral rewards and instant welcome bonus. Deposit credits
                # can carry only a protected *portion* (e.g. first-deposit welcome
                # bonus) so the real deposit principal remains giftable.
                partial = meta.get("non_transferable_amount")
                if partial is not None:
                    try:
                        protected += max(0, min(max(0, available_delta), int(partial)))
                    except (TypeError, ValueError):
                        pass
                elif bool(meta.get("non_transferable_credit")):
                    protected += max(0, available_delta)
            elif entry == "debit":
                if not bool(meta.get("gift_transfer")):
                    protected = max(0, protected - abs(available_delta))
            elif entry == "hold":
                used = min(protected, abs(available_delta))
                protected -= used
                if r["created_hold_id"] is not None:
                    hold_parts[UUID(str(r["created_hold_id"]))] = used
            elif entry == "release":
                if r["closed_hold_id"] is not None:
                    protected += hold_parts.get(UUID(str(r["closed_hold_id"])), 0)
            # capture permanently spends a previously allocated hold; no restore.
        available = await conn.fetchval(
            "SELECT COALESCE(available,0) FROM bot_core.wallet_accounts WHERE telegram_id=$1 AND asset_code='SYP' AND bucket='cash'",
            int(telegram_id),
        )
        return max(0, min(int(available or 0), int(protected)))

    async def gift_by_token(self, conn: asyncpg.Connection, token: UUID) -> dict[str, Any] | None:
        row = await conn.fetchrow("SELECT * FROM bot_core.gift_transfers WHERE request_token=$1", token)
        return dict(row) if row else None

    async def insert_gift(
        self, conn: asyncpg.Connection, *, gift_id: UUID, token: UUID, sender: int, recipient: int,
        amount: int, sender_op: UUID, recipient_op: UUID, sender_balance: int, recipient_balance: int,
    ) -> dict[str, Any]:
        row = await conn.fetchrow(
            """
            INSERT INTO bot_core.gift_transfers(
              id,request_token,from_telegram_id,to_telegram_id,amount_syp,
              sender_wallet_operation_id,recipient_wallet_operation_id,sender_balance_after,recipient_balance_after
            ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)
            ON CONFLICT(request_token) DO UPDATE SET request_token=EXCLUDED.request_token
            RETURNING *
            """,
            gift_id, token, sender, recipient, amount, sender_op, recipient_op, sender_balance, recipient_balance,
        )
        return dict(row)

    async def gift_history(self, telegram_id: int, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.gift_transfers WHERE from_telegram_id=$1 OR to_telegram_id=$1", int(telegram_id)
            )
            rows = await conn.fetch(
                """
                SELECT g.*,uf.first_name AS from_name,uf.username AS from_username,
                       ut.first_name AS to_name,ut.username AS to_username
                FROM bot_core.gift_transfers g
                JOIN bot_core.users uf ON uf.telegram_id=g.from_telegram_id
                JOIN bot_core.users ut ON ut.telegram_id=g.to_telegram_id
                WHERE g.from_telegram_id=$1 OR g.to_telegram_id=$1
                ORDER BY g.created_at DESC LIMIT $2 OFFSET $3
                """,
                int(telegram_id), max(1,min(int(limit),50)), max(0,int(offset)),
            )
        return [dict(r) for r in rows], int(total or 0)

    async def create_code(self, *, code: str, amount: int, max_uses: int, target: int | None, actor: int, is_fake: bool = False) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                "INSERT INTO bot_core.gift_codes(code,amount_syp,is_fake,max_uses,target_telegram_id,created_by) VALUES($1,$2,$3,$4,$5,$6)",
                code, amount, bool(is_fake), max_uses, target, actor,
            )

    async def code_detail(self, code: str) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT g.*,(SELECT COUNT(*) FROM bot_core.gift_code_redemptions r WHERE r.code=g.code) AS actual_uses
                   FROM bot_core.gift_codes g WHERE code=$1""", code,
            )
        return dict(row) if row else None

    async def disable_code(self, code: str, actor: int) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """UPDATE bot_core.gift_codes SET disabled_at=COALESCE(disabled_at,NOW()),disabled_by=COALESCE(disabled_by,$2)
                   WHERE code=$1 RETURNING code""", code, actor,
            )
        return row is not None

    async def list_codes(self, *, active: bool = True, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        where = "disabled_at IS NULL AND NOT is_fake AND uses_count < max_uses" if active else "is_fake OR disabled_at IS NOT NULL OR uses_count >= max_uses"
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = await conn.fetchval(f"SELECT COUNT(*) FROM bot_core.gift_codes WHERE {where}")
            rows = await conn.fetch(
                f"SELECT * FROM bot_core.gift_codes WHERE {where} ORDER BY created_at DESC LIMIT $1 OFFSET $2",
                max(1,min(int(limit),50)), max(0,int(offset)),
            )
        return [dict(r) for r in rows], int(total or 0)

    async def code_redemptions_admin(self, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = await conn.fetchval("SELECT COUNT(*) FROM bot_core.gift_code_redemptions")
            rows = await conn.fetch(
                """SELECT r.code,r.telegram_id,r.amount_syp,r.balance_before,r.balance_after,r.used_at,
                          u.first_name,u.username
                   FROM bot_core.gift_code_redemptions r
                   LEFT JOIN bot_core.users u ON u.telegram_id=r.telegram_id
                   ORDER BY r.used_at DESC LIMIT $1 OFFSET $2""",
                max(1,min(int(limit),50)), max(0,int(offset)),
            )
        return [dict(r) for r in rows], int(total or 0)

    async def code_history(self, telegram_id: int, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = await conn.fetchval("SELECT COUNT(*) FROM bot_core.gift_code_redemptions WHERE telegram_id=$1", int(telegram_id))
            rows = await conn.fetch(
                "SELECT code,amount_syp,balance_before,balance_after,used_at FROM bot_core.gift_code_redemptions WHERE telegram_id=$1 ORDER BY used_at DESC LIMIT $2 OFFSET $3",
                int(telegram_id), max(1,min(int(limit),50)), max(0,int(offset)),
            )
        return [dict(r) for r in rows], int(total or 0)

    async def loyalty_summary(self, telegram_id: int) -> dict[str, Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM bot_core.loyalty_accounts WHERE telegram_id=$1", int(telegram_id))
        return dict(row) if row else {"telegram_id": int(telegram_id), "points":0, "total_earned":0, "total_redeemed":0}

    async def loyalty_history(self, telegram_id: int, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = await conn.fetchval("SELECT COUNT(*) FROM bot_core.loyalty_events WHERE telegram_id=$1", int(telegram_id))
            rows = await conn.fetch(
                "SELECT * FROM bot_core.loyalty_events WHERE telegram_id=$1 ORDER BY id DESC LIMIT $2 OFFSET $3",
                int(telegram_id), max(1,min(int(limit),50)), max(0,int(offset)),
            )
        return [dict(r) for r in rows], int(total or 0)

    async def rewards(self, *, include_disabled: bool = False, limit: int = 20, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        where = "" if include_disabled else "WHERE r.enabled"
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = await conn.fetchval(f"SELECT COUNT(*) FROM bot_core.loyalty_rewards r {where}")
            rows = await conn.fetch(
                f"""SELECT r.*,
                    (SELECT COUNT(*) FROM bot_core.loyalty_reward_claims c WHERE c.reward_id=r.id AND c.status IN ('pending','completed','delivered')) AS claims_count
                    FROM bot_core.loyalty_rewards r {where}
                    ORDER BY r.id ASC LIMIT $1 OFFSET $2""",
                max(1,min(int(limit),100)), max(0,int(offset)),
            )
        out=[]
        for r in rows:
            d=dict(r)
            d["remaining_stock"] = None if int(d["stock_total"] or 0)==0 else max(0,int(d["stock_total"])-int(d["claims_count"] or 0))
            d["available"] = bool(d["enabled"]) and (d["remaining_stock"] is None or d["remaining_stock"]>0)
            out.append(d)
        return out,int(total or 0)

    async def reward(self, reward_id: int, *, conn: asyncpg.Connection | None = None, for_update: bool = False) -> dict[str, Any] | None:
        async def _fetch(c: asyncpg.Connection):
            suffix=" FOR UPDATE" if for_update else ""
            row=await c.fetchrow("SELECT * FROM bot_core.loyalty_rewards WHERE id=$1"+suffix,int(reward_id))
            if not row: return None
            d=dict(row)
            claims=await c.fetchval("SELECT COUNT(*) FROM bot_core.loyalty_reward_claims WHERE reward_id=$1 AND status IN ('pending','completed','delivered')",int(reward_id))
            d["claims_count"]=int(claims or 0)
            d["remaining_stock"]=None if int(d["stock_total"] or 0)==0 else max(0,int(d["stock_total"])-int(claims or 0))
            d["available"]=bool(d["enabled"]) and (d["remaining_stock"] is None or d["remaining_stock"]>0)
            return d
        if conn is not None: return await _fetch(conn)
        pool=self.db.require_pool()
        async with pool.acquire() as c: return await _fetch(c)

    async def loyalty_user(self, telegram_id: int) -> dict[str, Any] | None:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            row=await conn.fetchrow(
                """SELECT u.telegram_id,u.first_name,u.username,u.is_blocked,
                          COALESCE(a.points,0) AS points,COALESCE(a.total_earned,0) AS total_earned,
                          COALESCE(a.total_redeemed,0) AS total_redeemed,a.updated_at
                   FROM bot_core.users u LEFT JOIN bot_core.loyalty_accounts a ON a.telegram_id=u.telegram_id
                   WHERE u.telegram_id=$1""", int(telegram_id),
            )
        return dict(row) if row else None

    async def loyalty_user_search(self, query: str) -> dict[str, Any] | None:
        raw=str(query or '').strip(); pool=self.db.require_pool()
        async with pool.acquire() as conn:
            if raw.lstrip('-').isdigit():
                row=await conn.fetchrow(
                    """SELECT u.telegram_id,u.first_name,u.username,u.is_blocked,COALESCE(a.points,0) AS points,
                              COALESCE(a.total_earned,0) AS total_earned,COALESCE(a.total_redeemed,0) AS total_redeemed,a.updated_at
                       FROM bot_core.users u LEFT JOIN bot_core.loyalty_accounts a ON a.telegram_id=u.telegram_id WHERE u.telegram_id=$1""", int(raw),
                )
            else:
                username=raw.lstrip('@')
                row=await conn.fetchrow(
                    """SELECT u.telegram_id,u.first_name,u.username,u.is_blocked,COALESCE(a.points,0) AS points,
                              COALESCE(a.total_earned,0) AS total_earned,COALESCE(a.total_redeemed,0) AS total_redeemed,a.updated_at
                       FROM bot_core.users u LEFT JOIN bot_core.loyalty_accounts a ON a.telegram_id=u.telegram_id
                       WHERE LOWER(COALESCE(u.username,''))=LOWER($1) ORDER BY u.telegram_id LIMIT 1""", username,
                )
        return dict(row) if row else None

    async def loyalty_holders(self, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int, int]:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            total=await conn.fetchval("SELECT COUNT(*) FROM bot_core.loyalty_accounts WHERE points>0")
            total_points=await conn.fetchval("SELECT COALESCE(SUM(points),0) FROM bot_core.loyalty_accounts WHERE points>0")
            rows=await conn.fetch(
                """SELECT a.telegram_id,a.points,a.total_earned,a.total_redeemed,u.first_name,u.username
                   FROM bot_core.loyalty_accounts a LEFT JOIN bot_core.users u ON u.telegram_id=a.telegram_id
                   WHERE a.points>0 ORDER BY a.points DESC,a.telegram_id LIMIT $1 OFFSET $2""",
                max(1,min(int(limit),50)),max(0,int(offset)),
            )
        return [dict(r) for r in rows],int(total or 0),int(total_points or 0)

    async def pending_claims(self, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            total=await conn.fetchval("SELECT COUNT(*) FROM bot_core.loyalty_reward_claims WHERE status='pending'")
            rows=await conn.fetch(
                """SELECT c.*,u.first_name,u.username FROM bot_core.loyalty_reward_claims c
                   LEFT JOIN bot_core.users u ON u.telegram_id=c.telegram_id
                   WHERE c.status='pending' ORDER BY c.created_at,c.id LIMIT $1 OFFSET $2""",
                max(1,min(int(limit),50)),max(0,int(offset)),
            )
        return [dict(r) for r in rows],int(total or 0)
