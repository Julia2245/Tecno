from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from app.core.db import Database


class BroadcastRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def create_draft(
        self,
        *,
        created_by: int,
        source_chat_id: int,
        source_message_id: int,
        content_type: str,
        preview_text: str,
        per_minute: int,
        concurrency: int,
    ) -> UUID:
        campaign_id = uuid4()
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO bot_core.broadcast_campaigns(
                    id,created_by,source_chat_id,source_message_id,content_type,preview_text,
                    per_minute,concurrency,status
                ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,'draft')
                """,
                campaign_id, int(created_by), int(source_chat_id), int(source_message_id),
                str(content_type or "message")[:64], str(preview_text or "")[:500],
                int(per_minute), int(concurrency),
            )
        return campaign_id

    async def cancel_draft(self, campaign_id: UUID, *, actor_id: int) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE bot_core.broadcast_campaigns
                SET status='cancelled',updated_at=NOW()
                WHERE id=$1 AND created_by=$2 AND status='draft'
                """,
                campaign_id, int(actor_id),
            )
        return result.endswith(" 1")

    async def eligible_count(self) -> int:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            value = await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.users WHERE NOT is_blocked AND NOT is_bot"
            )
        return int(value or 0)

    async def confirm_campaign(
        self,
        campaign_id: UUID,
        *,
        actor_id: int,
        admin_chat_id: int,
        admin_status_message_id: int,
    ) -> dict[str, Any] | None:
        """Atomically snapshot eligible recipients and queue a draft exactly once."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                campaign = await conn.fetchrow(
                    "SELECT * FROM bot_core.broadcast_campaigns WHERE id=$1 FOR UPDATE",
                    campaign_id,
                )
                if campaign is None or int(campaign["created_by"]) != int(actor_id):
                    return None
                if str(campaign["status"]) != "draft":
                    return dict(campaign)
                await conn.execute(
                    """
                    INSERT INTO bot_core.broadcast_recipients(campaign_id,telegram_id)
                    SELECT $1,u.telegram_id
                    FROM bot_core.users u
                    WHERE NOT u.is_blocked AND NOT u.is_bot
                    ON CONFLICT DO NOTHING
                    """,
                    campaign_id,
                )
                total = int(await conn.fetchval(
                    "SELECT COUNT(*) FROM bot_core.broadcast_recipients WHERE campaign_id=$1",
                    campaign_id,
                ) or 0)
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.broadcast_campaigns
                    SET status=CASE WHEN $2::int>0 THEN 'queued' ELSE 'completed' END,
                        total_recipients=$2,admin_chat_id=$3,admin_status_message_id=$4,
                        queued_at=CASE WHEN $2::int>0 THEN NOW() ELSE NULL END,
                        finished_at=CASE WHEN $2::int=0 THEN NOW() ELSE NULL END,
                        updated_at=NOW()
                    WHERE id=$1
                    RETURNING *
                    """,
                    campaign_id, total, int(admin_chat_id), int(admin_status_message_id),
                )
        return dict(row) if row else None

    async def get_campaign(self, campaign_id: UUID) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM bot_core.broadcast_campaigns WHERE id=$1", campaign_id
            )
        return dict(row) if row else None

    async def list_campaigns(self, *, limit: int = 8, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = int(await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.broadcast_campaigns WHERE status<>'draft'"
            ) or 0)
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.broadcast_campaigns
                WHERE status<>'draft'
                ORDER BY created_at DESC
                LIMIT $1 OFFSET $2
                """,
                int(limit), int(offset),
            )
        return [dict(r) for r in rows], total

    async def request_stop(self, campaign_id: UUID) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                UPDATE bot_core.broadcast_campaigns
                SET stop_requested=TRUE,
                    status=CASE WHEN status='queued' THEN 'stopped' WHEN status='running' THEN 'stopping' ELSE status END,
                    finished_at=CASE WHEN status='queued' THEN NOW() ELSE finished_at END,
                    updated_at=NOW()
                WHERE id=$1 AND status IN ('queued','running','stopping')
                RETURNING id
                """,
                campaign_id,
            )
        return row is not None

    async def request_delete(self, campaign_id: UUID) -> dict[str, Any] | None:
        """Queue deletion for all successfully recorded deliveries; failed deletes may be retried."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                campaign = await conn.fetchrow(
                    "SELECT * FROM bot_core.broadcast_campaigns WHERE id=$1 FOR UPDATE",
                    campaign_id,
                )
                if campaign is None or str(campaign["status"]) not in {"completed", "stopped", "failed"}:
                    return None
                await conn.execute(
                    """
                    UPDATE bot_core.broadcast_recipients
                    SET delete_status='pending',delete_error=NULL,updated_at=NOW()
                    WHERE campaign_id=$1 AND send_status='sent' AND message_id IS NOT NULL
                      AND delete_status IN ('none','failed')
                    """,
                    campaign_id,
                )
                total = int(await conn.fetchval(
                    """SELECT COUNT(*) FROM bot_core.broadcast_recipients
                       WHERE campaign_id=$1 AND send_status='sent' AND message_id IS NOT NULL""",
                    campaign_id,
                ) or 0)
                await self._refresh_delete_counts_conn(conn, campaign_id)
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.broadcast_campaigns
                    SET delete_status=CASE WHEN $2::int>0 THEN 'queued' ELSE 'completed' END,
                        delete_total=$2,
                        delete_started_at=NULL,
                        delete_finished_at=CASE WHEN $2::int=0 THEN NOW() ELSE NULL END,
                        updated_at=NOW()
                    WHERE id=$1
                    RETURNING *
                    """,
                    campaign_id, total,
                )
        return dict(row) if row else None

    async def recover_interrupted(self) -> dict[str, int]:
        """Fail closed after restart: ambiguous sends are never blindly repeated."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                unknown_rows = await conn.fetch(
                    """
                    UPDATE bot_core.broadcast_recipients
                    SET send_status='unknown',send_error='interrupted_after_dispatch',updated_at=NOW()
                    WHERE send_status='sending'
                    RETURNING campaign_id
                    """
                )
                # Deleting a message is idempotent in effect. Resume interrupted deletes.
                await conn.execute(
                    """
                    UPDATE bot_core.broadcast_recipients
                    SET delete_status='pending',delete_error='resumed_after_restart',updated_at=NOW()
                    WHERE delete_status='deleting'
                    """
                )
                await conn.execute(
                    """
                    UPDATE bot_core.broadcast_campaigns
                    SET status=CASE WHEN stop_requested THEN 'stopped' ELSE 'queued' END,
                        finished_at=CASE WHEN stop_requested THEN COALESCE(finished_at,NOW()) ELSE finished_at END,
                        updated_at=NOW()
                    WHERE status IN ('running','stopping')
                    """
                )
                await conn.execute(
                    """
                    UPDATE bot_core.broadcast_campaigns
                    SET delete_status='queued',updated_at=NOW()
                    WHERE delete_status='deleting'
                    """
                )
                campaign_ids = {r["campaign_id"] for r in unknown_rows}
                for cid in campaign_ids:
                    await self._refresh_counts_conn(conn, cid)
        return {"unknown_sends": len(unknown_rows), "campaigns": len(campaign_ids)}

    async def claim_send_campaign(self) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    SELECT * FROM bot_core.broadcast_campaigns
                    WHERE status='queued' AND NOT stop_requested
                    ORDER BY queued_at NULLS LAST,created_at
                    FOR UPDATE SKIP LOCKED LIMIT 1
                    """
                )
                if row is None:
                    return None
                claimed = await conn.fetchrow(
                    """
                    UPDATE bot_core.broadcast_campaigns
                    SET status='running',started_at=COALESCE(started_at,NOW()),updated_at=NOW()
                    WHERE id=$1 RETURNING *
                    """,
                    row["id"],
                )
        return dict(claimed) if claimed else None

    async def claim_delete_campaign(self) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    SELECT * FROM bot_core.broadcast_campaigns
                    WHERE delete_status='queued'
                    ORDER BY updated_at,created_at
                    FOR UPDATE SKIP LOCKED LIMIT 1
                    """
                )
                if row is None:
                    return None
                claimed = await conn.fetchrow(
                    """
                    UPDATE bot_core.broadcast_campaigns
                    SET delete_status='deleting',delete_started_at=COALESCE(delete_started_at,NOW()),updated_at=NOW()
                    WHERE id=$1 RETURNING *
                    """,
                    row["id"],
                )
        return dict(claimed) if claimed else None

    async def claim_send_batch(self, campaign_id: UUID, *, limit: int) -> list[int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                stop = bool(await conn.fetchval(
                    "SELECT stop_requested FROM bot_core.broadcast_campaigns WHERE id=$1 FOR UPDATE",
                    campaign_id,
                ))
                if stop:
                    return []
                newly_blocked = await conn.fetch(
                    """
                    UPDATE bot_core.broadcast_recipients r
                    SET send_status='blocked',send_error='blocked_before_dispatch',updated_at=NOW()
                    FROM bot_core.users u
                    WHERE r.campaign_id=$1 AND r.send_status='pending'
                      AND u.telegram_id=r.telegram_id AND (u.is_blocked OR u.is_bot)
                    RETURNING r.telegram_id
                    """,
                    campaign_id,
                )
                if newly_blocked:
                    await conn.execute(
                        """UPDATE bot_core.broadcast_campaigns
                           SET blocked_count=blocked_count+$2,updated_at=NOW() WHERE id=$1""",
                        campaign_id, len(newly_blocked),
                    )
                rows = await conn.fetch(
                    """
                    SELECT telegram_id FROM bot_core.broadcast_recipients
                    WHERE campaign_id=$1 AND send_status='pending'
                    ORDER BY telegram_id
                    FOR UPDATE SKIP LOCKED LIMIT $2
                    """,
                    campaign_id, int(limit),
                )
                ids = [int(r["telegram_id"]) for r in rows]
                if ids:
                    await conn.execute(
                        """
                        UPDATE bot_core.broadcast_recipients
                        SET send_status='sending',send_attempts=send_attempts+1,send_started_at=NOW(),updated_at=NOW()
                        WHERE campaign_id=$1 AND telegram_id=ANY($2::bigint[])
                        """,
                        campaign_id, ids,
                    )
        return ids

    async def mark_send_result(
        self,
        campaign_id: UUID,
        telegram_id: int,
        *,
        status: str,
        message_id: int | None = None,
        error: str | None = None,
    ) -> None:
        if status not in {"sent", "blocked", "failed", "unknown"}:
            raise ValueError("invalid broadcast recipient result")
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                changed = await conn.fetchrow(
                    """
                    UPDATE bot_core.broadcast_recipients
                    SET send_status=$3,message_id=$4,send_error=$5,
                        sent_at=CASE WHEN $3='sent' THEN NOW() ELSE sent_at END,updated_at=NOW()
                    WHERE campaign_id=$1 AND telegram_id=$2 AND send_status='sending'
                    RETURNING send_status
                    """,
                    campaign_id, int(telegram_id), status, message_id, (error or None),
                )
                if changed is not None:
                    await conn.execute(
                        """
                        UPDATE bot_core.broadcast_campaigns
                        SET sent_count=sent_count+CASE WHEN $2='sent' THEN 1 ELSE 0 END,
                            blocked_count=blocked_count+CASE WHEN $2='blocked' THEN 1 ELSE 0 END,
                            failed_count=failed_count+CASE WHEN $2='failed' THEN 1 ELSE 0 END,
                            unknown_count=unknown_count+CASE WHEN $2='unknown' THEN 1 ELSE 0 END,
                            updated_at=NOW()
                        WHERE id=$1
                        """,
                        campaign_id, status,
                    )

    async def pending_send_count(self, campaign_id: UUID) -> int:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            value = await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.broadcast_recipients WHERE campaign_id=$1 AND send_status='pending'",
                campaign_id,
            )
        return int(value or 0)

    async def finish_send_campaign(self, campaign_id: UUID, *, error: str | None = None) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._refresh_counts_conn(conn, campaign_id)
                row = await conn.fetchrow(
                    "SELECT stop_requested FROM bot_core.broadcast_campaigns WHERE id=$1 FOR UPDATE",
                    campaign_id,
                )
                if row is None:
                    return None
                final_status = "failed" if error else ("stopped" if bool(row["stop_requested"]) else "completed")
                result = await conn.fetchrow(
                    """
                    UPDATE bot_core.broadcast_campaigns
                    SET status=$2,last_error=$3,finished_at=NOW(),updated_at=NOW()
                    WHERE id=$1 RETURNING *
                    """,
                    campaign_id, final_status, error,
                )
        return dict(result) if result else None

    async def claim_delete_batch(self, campaign_id: UUID, *, limit: int) -> list[tuple[int, int]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                rows = await conn.fetch(
                    """
                    SELECT telegram_id,message_id FROM bot_core.broadcast_recipients
                    WHERE campaign_id=$1 AND delete_status='pending' AND message_id IS NOT NULL
                    ORDER BY telegram_id
                    FOR UPDATE SKIP LOCKED LIMIT $2
                    """,
                    campaign_id, int(limit),
                )
                pairs = [(int(r["telegram_id"]), int(r["message_id"])) for r in rows]
                if pairs:
                    ids = [p[0] for p in pairs]
                    await conn.execute(
                        """
                        UPDATE bot_core.broadcast_recipients
                        SET delete_status='deleting',delete_attempts=delete_attempts+1,updated_at=NOW()
                        WHERE campaign_id=$1 AND telegram_id=ANY($2::bigint[])
                        """,
                        campaign_id, ids,
                    )
        return pairs

    async def mark_delete_result(
        self,
        campaign_id: UUID,
        telegram_id: int,
        *,
        deleted: bool,
        error: str | None = None,
    ) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                changed = await conn.fetchrow(
                    """
                    UPDATE bot_core.broadcast_recipients
                    SET delete_status=CASE WHEN $3 THEN 'deleted' ELSE 'failed' END,
                        delete_error=$4,
                        deleted_at=CASE WHEN $3 THEN NOW() ELSE deleted_at END,
                        updated_at=NOW()
                    WHERE campaign_id=$1 AND telegram_id=$2 AND delete_status='deleting'
                    RETURNING delete_status
                    """,
                    campaign_id, int(telegram_id), bool(deleted), error,
                )
                if changed is not None:
                    await conn.execute(
                        """
                        UPDATE bot_core.broadcast_campaigns
                        SET deleted_count=deleted_count+CASE WHEN $2::boolean THEN 1 ELSE 0 END,
                            delete_failed_count=delete_failed_count+CASE WHEN $2::boolean THEN 0 ELSE 1 END,
                            updated_at=NOW()
                        WHERE id=$1
                        """,
                        campaign_id, bool(deleted),
                    )

    async def pending_delete_count(self, campaign_id: UUID) -> int:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            value = await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.broadcast_recipients WHERE campaign_id=$1 AND delete_status='pending'",
                campaign_id,
            )
        return int(value or 0)

    async def finish_delete_campaign(self, campaign_id: UUID, *, error: str | None = None) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._refresh_delete_counts_conn(conn, campaign_id)
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.broadcast_campaigns
                    SET delete_status=CASE WHEN $2::text IS NULL THEN 'completed' ELSE 'failed' END,
                        last_error=COALESCE($2,last_error),delete_finished_at=NOW(),updated_at=NOW()
                    WHERE id=$1 RETURNING *
                    """,
                    campaign_id, error,
                )
        return dict(row) if row else None

    async def _refresh_counts_conn(self, conn: Any, campaign_id: UUID) -> None:
        await conn.execute(
            """
            UPDATE bot_core.broadcast_campaigns c
            SET sent_count=s.sent,
                blocked_count=s.blocked,
                failed_count=s.failed,
                unknown_count=s.unknown,
                updated_at=NOW()
            FROM (
                SELECT
                    COUNT(*) FILTER (WHERE send_status='sent')::int AS sent,
                    COUNT(*) FILTER (WHERE send_status='blocked')::int AS blocked,
                    COUNT(*) FILTER (WHERE send_status='failed')::int AS failed,
                    COUNT(*) FILTER (WHERE send_status='unknown')::int AS unknown
                FROM bot_core.broadcast_recipients WHERE campaign_id=$1
            ) s
            WHERE c.id=$1
            """,
            campaign_id,
        )

    async def _refresh_delete_counts_conn(self, conn: Any, campaign_id: UUID) -> None:
        await conn.execute(
            """
            UPDATE bot_core.broadcast_campaigns c
            SET deleted_count=s.deleted,delete_failed_count=s.failed,updated_at=NOW()
            FROM (
                SELECT
                    COUNT(*) FILTER (WHERE delete_status='deleted')::int AS deleted,
                    COUNT(*) FILTER (WHERE delete_status='failed')::int AS failed
                FROM bot_core.broadcast_recipients WHERE campaign_id=$1
            ) s
            WHERE c.id=$1
            """,
            campaign_id,
        )
