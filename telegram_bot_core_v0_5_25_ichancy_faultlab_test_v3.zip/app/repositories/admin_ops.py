from __future__ import annotations

import json
from typing import Any

from app.core.db import Database


class AdminOpsRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def list_assistants(self) -> list[dict[str, Any]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT a.telegram_id,a.added_by,a.permissions,a.added_at,
                       u.username,u.first_name
                FROM bot_core.admin_assistants a
                JOIN bot_core.users u ON u.telegram_id=a.telegram_id
                ORDER BY a.added_at DESC,a.telegram_id DESC
                """
            )
        return [dict(r) for r in rows]

    async def assistant_ids(self) -> set[int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT telegram_id FROM bot_core.admin_assistants")
        return {int(r["telegram_id"]) for r in rows}

    async def add_assistant(self, telegram_id: int, *, added_by: int) -> tuple[bool, str]:
        target = int(telegram_id)
        actor = int(added_by)
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                exists = await conn.fetchval(
                    "SELECT EXISTS(SELECT 1 FROM bot_core.users WHERE telegram_id=$1)", target
                )
                if not exists:
                    return False, "user_not_found"
                row = await conn.fetchrow(
                    """
                    INSERT INTO bot_core.admin_assistants(telegram_id,added_by,permissions)
                    VALUES($1,$2,'basic')
                    ON CONFLICT(telegram_id) DO NOTHING
                    RETURNING telegram_id
                    """,
                    target, actor,
                )
                if row is None:
                    return False, "already_exists"
                await self._security_event_conn(
                    conn, actor=actor, action="assistant_add", target=target,
                    details={"permissions": "basic"},
                )
        return True, "ok"

    async def remove_assistant(self, telegram_id: int, *, removed_by: int) -> bool:
        target = int(telegram_id)
        actor = int(removed_by)
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "DELETE FROM bot_core.admin_assistants WHERE telegram_id=$1 RETURNING telegram_id",
                    target,
                )
                if row is None:
                    return False
                await self._security_event_conn(
                    conn, actor=actor, action="assistant_remove", target=target, details={}
                )
        return True

    async def log_security_event(
        self, *, actor: int, action: str, target: int | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await self._security_event_conn(
                conn, actor=int(actor), action=str(action), target=target, details=details or {}
            )

    @staticmethod
    async def _security_event_conn(conn, *, actor: int, action: str, target: int | None, details: dict[str, Any]) -> None:
        await conn.execute(
            """
            INSERT INTO bot_core.admin_security_events(actor_telegram_id,action,target_telegram_id,details)
            VALUES($1,$2,$3,$4::jsonb)
            """,
            int(actor), str(action), int(target) if target is not None else None,
            json.dumps(details, ensure_ascii=False, separators=(",", ":"), default=str),
        )

    async def security_audit(self, *, limit: int = 12, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        limit = max(1, min(50, int(limit)))
        offset = max(0, int(offset))
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = int(await conn.fetchval("SELECT COUNT(*) FROM bot_core.admin_security_events") or 0)
            rows = await conn.fetch(
                """
                SELECT e.id,e.actor_telegram_id,e.action,e.target_telegram_id,e.details,e.created_at,
                       au.username AS actor_username,au.first_name AS actor_first_name,
                       tu.username AS target_username,tu.first_name AS target_first_name
                FROM bot_core.admin_security_events e
                LEFT JOIN bot_core.users au ON au.telegram_id=e.actor_telegram_id
                LEFT JOIN bot_core.users tu ON tu.telegram_id=e.target_telegram_id
                ORDER BY e.created_at DESC,e.id DESC
                LIMIT $1 OFFSET $2
                """,
                limit, offset,
            )
        return [dict(r) for r in rows], total

    async def wallet_admin_audit(self, *, limit: int = 12, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        """Read-only audit for admin-initiated wallet mutations.

        The immutable wallet ledger remains canonical; this query does not use
        the supplementary admin_user_actions table as a source of truth.
        """
        limit = max(1, min(50, int(limit)))
        offset = max(0, int(offset))
        pool = self.db.require_pool()
        where = "o.actor_telegram_id IS NOT NULL AND l.reason IN ('admin user balance credit','admin user balance debit')"
        async with pool.acquire() as conn:
            total = int(await conn.fetchval(
                f"SELECT COUNT(*) FROM bot_core.wallet_ledger l JOIN bot_core.wallet_operations o ON o.id=l.operation_id WHERE {where}"
            ) or 0)
            rows = await conn.fetch(
                f"""
                SELECT l.id,l.entry_type,l.available_delta,l.available_before,l.available_after,l.reason,l.created_at,
                       o.actor_telegram_id,a.telegram_id AS target_telegram_id,
                       au.username AS actor_username,au.first_name AS actor_first_name,
                       tu.username AS target_username,tu.first_name AS target_first_name
                FROM bot_core.wallet_ledger l
                JOIN bot_core.wallet_operations o ON o.id=l.operation_id
                JOIN bot_core.wallet_accounts a ON a.id=l.account_id
                LEFT JOIN bot_core.users au ON au.telegram_id=o.actor_telegram_id
                LEFT JOIN bot_core.users tu ON tu.telegram_id=a.telegram_id
                WHERE {where}
                ORDER BY l.created_at DESC,l.id DESC
                LIMIT $1 OFFSET $2
                """,
                limit, offset,
            )
        return [dict(r) for r in rows], total

    async def reserved_count(self) -> int:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return int(await conn.fetchval("SELECT COUNT(*) FROM bot_core.reserved_transaction_numbers") or 0)

    async def reserved_list(self, *, limit: int = 12, offset: int = 0) -> list[dict[str, Any]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT provider_scope,provider_tx,note,created_by,created_at
                FROM bot_core.reserved_transaction_numbers
                ORDER BY created_at DESC,provider_scope,provider_tx
                LIMIT $1 OFFSET $2
                """,
                max(1, min(50, int(limit))), max(0, int(offset)),
            )
        return [dict(r) for r in rows]

    async def reserved_get(self, scope: str, tx: str) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT provider_scope,provider_tx,note,created_by,created_at FROM bot_core.reserved_transaction_numbers WHERE provider_scope=$1 AND provider_tx=$2",
                str(scope), str(tx),
            )
        return dict(row) if row else None


    async def reserved_find_tx(self, tx: str) -> list[dict[str, Any]]:
        wanted = str(tx).strip()
        if not wanted:
            return []
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT provider_scope,provider_tx,note,created_by,created_at
                FROM bot_core.reserved_transaction_numbers
                WHERE provider_tx=$1
                ORDER BY provider_scope
                """,
                wanted,
            )
        return [dict(r) for r in rows]

    async def reserved_add_many(
        self, scope: str, tx_values: list[str], *, created_by: int, note: str | None = None
    ) -> tuple[int, int]:
        scope = str(scope).strip().lower()
        unique = []
        seen: set[str] = set()
        for raw in tx_values:
            tx = str(raw).strip()
            if not tx or tx in seen:
                continue
            seen.add(tx)
            unique.append(tx)
        if not unique:
            return 0, 0
        pool = self.db.require_pool()
        inserted = 0
        async with pool.acquire() as conn:
            async with conn.transaction():
                for tx in unique:
                    row = await conn.fetchrow(
                        """
                        INSERT INTO bot_core.reserved_transaction_numbers(provider_scope,provider_tx,note,created_by)
                        SELECT $1,$2,$3,$4
                        WHERE NOT EXISTS (
                            SELECT 1 FROM bot_core.deposit_tx_claims
                            WHERE provider_scope=$1 AND provider_tx=$2
                        )
                        ON CONFLICT(provider_scope,provider_tx) DO NOTHING
                        RETURNING provider_tx
                        """,
                        scope, tx, note, int(created_by),
                    )
                    inserted += 1 if row is not None else 0
                await self._security_event_conn(
                    conn, actor=int(created_by), action="reserved_tx_add", target=None,
                    details={"scope": scope, "requested": len(unique), "inserted": inserted},
                )
        return inserted, len(unique) - inserted

    async def reserved_delete(self, scope: str, tx: str, *, actor: int) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "DELETE FROM bot_core.reserved_transaction_numbers WHERE provider_scope=$1 AND provider_tx=$2 RETURNING provider_tx",
                    str(scope), str(tx),
                )
                if row is None:
                    return False
                await self._security_event_conn(
                    conn, actor=int(actor), action="reserved_tx_delete", target=None,
                    details={"scope": str(scope), "tx": str(tx)},
                )
        return True

    async def reserved_clear(self, *, actor: int) -> int:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                count = int(await conn.fetchval("SELECT COUNT(*) FROM bot_core.reserved_transaction_numbers") or 0)
                await conn.execute("DELETE FROM bot_core.reserved_transaction_numbers")
                await self._security_event_conn(
                    conn, actor=int(actor), action="reserved_tx_clear", target=None,
                    details={"count": count},
                )
        return count

    async def record_backup(
        self, *, actor: int | None, kind: str, status: str, file_name: str | None = None,
        file_sha256: str | None = None, size_bytes: int | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO bot_core.backup_history(actor_telegram_id,kind,status,file_name,file_sha256,size_bytes,details)
                VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)
                """,
                int(actor) if actor is not None else None, str(kind), str(status), file_name,
                file_sha256, int(size_bytes) if size_bytes is not None else None,
                json.dumps(details or {}, ensure_ascii=False, separators=(",", ":"), default=str),
            )

    async def backup_history(self, *, limit: int = 8) -> list[dict[str, Any]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM bot_core.backup_history ORDER BY created_at DESC,id DESC LIMIT $1",
                max(1, min(50, int(limit))),
            )
        return [dict(r) for r in rows]

    async def unresolved_financial_count(self) -> int:
        """Conservative guard used before scheduling a destructive restore."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            values = await conn.fetchrow(
                """
                SELECT
                  (SELECT COUNT(*) FROM bot_core.deposit_requests WHERE status IN ('verifying','manual_pending')) AS deposits,
                  (SELECT COUNT(*) FROM bot_core.withdraw_requests WHERE status IN ('pending','processing','provider_success','needs_review')) AS withdraws,
                  (SELECT COUNT(*) FROM bot_core.ichancy_jobs WHERE status IN ('queued','executing','remote_success','reconciling')) AS ichancy,
                  (SELECT COUNT(*) FROM bot_core.admin_manual_transfer_intents WHERE status IN ('processing','needs_review')) AS manual_transfers,
                  (SELECT COUNT(*) FROM bot_core.ichancy_cashier_replacements WHERE status IN ('preparing','checking','settling','ready','blocked')) AS cashier_replacements
                """
            )
        return sum(int(values[k] or 0) for k in values.keys())
