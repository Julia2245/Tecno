from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any
from uuid import UUID

import asyncpg

from app.core.db import Database


class CompetitionRepository:
    """Persistence helpers for contests, advanced roulette and promotional rewards.

    Monetary balance writes intentionally do not live here. Contest balance prizes are
    isolated promo rewards and deposit-bonus prizes are consumed by FinanceRulesService.
    """

    def __init__(self, db: Database) -> None:
        self.db = db

    async def active_contests(self, limit: int = 20):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(
                """SELECT * FROM bot_core.contests
                   WHERE status IN ('active','waiting_result','ready_for_draw')
                   ORDER BY end_at,id LIMIT $1""", max(1, min(100, int(limit))))

    async def get_contest(self, contest_id: int):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetchrow("SELECT * FROM bot_core.contests WHERE id=$1", int(contest_id))

    async def active_roulettes(self, limit: int = 20):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(
                """SELECT * FROM bot_core.roulettes
                   WHERE status IN ('active','ready_for_draw')
                   ORDER BY end_at,id LIMIT $1""", max(1, min(100, int(limit))))

    async def get_roulette(self, roulette_id: int):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetchrow("SELECT * FROM bot_core.roulettes WHERE id=$1", int(roulette_id))

    async def create_contest(self, *, template_type: str, prediction_type: str | None,
                             team1_name: str | None, team2_name: str | None,
                             suffixes: list[str], raffle_entry_mode: str,
                             prize_type: str, prize_value: Decimal, winners_count: int,
                             media_type: str | None, media_file_id: str | None,
                             publish_to_channel: bool, start_at: datetime, end_at: datetime,
                             created_by: int):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetchrow(
                """INSERT INTO bot_core.contests(
                       template_type,prediction_type,team1_name,team2_name,suffixes,raffle_entry_mode,
                       prize_type,prize_value,winners_count,media_type,media_file_id,publish_to_channel,
                       start_at,end_at,created_by)
                   VALUES($1,$2,$3,$4,$5::jsonb,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
                   RETURNING *""",
                template_type, prediction_type, team1_name, team2_name,
                __import__('json').dumps(suffixes), raffle_entry_mode, prize_type, prize_value,
                winners_count, media_type, media_file_id, bool(publish_to_channel), start_at, end_at, created_by)

    async def create_roulette(self, *, bot_name_snapshot: str, participation_mode: str,
                              min_deposit_syp: int, max_chances_per_user: int, winners_count: int,
                              max_participants: int, auto_draw: bool, media_type: str | None,
                              media_file_id: str | None, start_at: datetime, end_at: datetime,
                              created_by: int, prizes: list[dict[str, Any]]):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """INSERT INTO bot_core.roulettes(
                           bot_name_snapshot,participation_mode,min_deposit_syp,max_chances_per_user,
                           winners_count,max_participants,auto_draw,media_type,media_file_id,start_at,end_at,created_by)
                       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *""",
                    bot_name_snapshot, participation_mode, int(min_deposit_syp), int(max_chances_per_user),
                    int(winners_count), int(max_participants), bool(auto_draw), media_type, media_file_id,
                    start_at, end_at, int(created_by))
                for pos, prize in enumerate(prizes, start=1):
                    await conn.execute(
                        """INSERT INTO bot_core.roulette_prizes(roulette_id,position,prize_type,prize_value,custom_text)
                           VALUES($1,$2,$3,$4,$5)""",
                        int(row['id']), pos, str(prize['prize_type']), Decimal(str(prize.get('prize_value') or 0)),
                        str(prize.get('custom_text') or '').strip() or None)
                return row

    async def roulette_prizes(self, roulette_id: int):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(
                "SELECT * FROM bot_core.roulette_prizes WHERE roulette_id=$1 ORDER BY position", int(roulette_id))

    async def contest_awards(self, contest_id: int):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(
                "SELECT * FROM bot_core.contest_awards WHERE contest_id=$1 ORDER BY position", int(contest_id))

    async def roulette_awards(self, roulette_id: int):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(
                "SELECT * FROM bot_core.roulette_awards WHERE roulette_id=$1 ORDER BY position", int(roulette_id))

    async def user_contest_entry(self, contest_id: int, telegram_id: int):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetchrow(
                "SELECT * FROM bot_core.contest_entries WHERE contest_id=$1 AND telegram_id=$2 ORDER BY id LIMIT 1",
                int(contest_id), int(telegram_id))

    async def user_roulette_chances(self, roulette_id: int, telegram_id: int) -> int:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return int(await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.roulette_entries WHERE roulette_id=$1 AND telegram_id=$2",
                int(roulette_id), int(telegram_id)) or 0)
