from __future__ import annotations

from dataclasses import dataclass
import json
from datetime import datetime
from typing import Any

from aiogram.types import User as TelegramUser

from app.core.db import Database


@dataclass(slots=True, frozen=True)
class UserRecord:
    telegram_id: int
    username: str | None
    first_name: str
    last_name: str | None
    language_code: str | None
    is_blocked: bool
    created_at: datetime
    updated_at: datetime


class UserRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def upsert_from_telegram(self, user: TelegramUser) -> UserRecord:
        record, _created = await self.upsert_from_telegram_with_created(user)
        return record

    async def upsert_from_telegram_with_created(
        self, user: TelegramUser, referrer_id: int | None = None
    ) -> tuple[UserRecord, bool]:
        """Upsert profile and atomically persist valid first-touch referral attribution."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    WITH candidate AS (
                        SELECT telegram_id
                        FROM bot_core.users
                        WHERE telegram_id=$7::BIGINT AND $7::BIGINT IS NOT NULL AND $7::BIGINT<>$1
                          AND NOT is_blocked AND NOT is_bot
                    ), ins AS (
                        INSERT INTO bot_core.users (
                            telegram_id, username, first_name, last_name, language_code, is_bot,
                            referrer_telegram_id, referral_status, referral_first_seen_at, last_active_at,
                            terms_required, terms_accepted_at
                        )
                        SELECT $1,$2,$3,$4,$5,$6,
                               candidate.telegram_id,
                               CASE WHEN candidate.telegram_id IS NULL THEN 'none' ELSE 'pending' END,
                               CASE WHEN candidate.telegram_id IS NULL THEN NULL ELSE NOW() END,
                               NOW(), TRUE, NULL
                        FROM (SELECT 1) AS seed
                        LEFT JOIN candidate ON TRUE
                        ON CONFLICT (telegram_id) DO NOTHING
                        RETURNING telegram_id,username,first_name,last_name,language_code,is_blocked,created_at,updated_at,TRUE AS created
                    ), upd AS (
                        UPDATE bot_core.users SET
                            username=$2, first_name=$3, last_name=$4, language_code=$5, is_bot=$6,
                            updated_at=NOW(), last_active_at=NOW()
                        WHERE telegram_id=$1 AND NOT EXISTS (SELECT 1 FROM ins)
                        RETURNING telegram_id,username,first_name,last_name,language_code,is_blocked,created_at,updated_at,FALSE AS created
                    )
                    SELECT * FROM ins UNION ALL SELECT * FROM upd LIMIT 1
                    """,
                    user.id, user.username, user.first_name or "", user.last_name, user.language_code, user.is_bot, referrer_id,
                )
        data = dict(row)
        created = bool(data.pop("created"))
        return UserRecord(**data), created

    async def get(self, telegram_id: int) -> UserRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT telegram_id, username, first_name, last_name, language_code,
                       is_blocked, created_at, updated_at
                FROM bot_core.users
                WHERE telegram_id = $1
                """,
                telegram_id,
            )
        return UserRecord(**dict(row)) if row else None

    async def needs_terms(self, telegram_id: int) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT terms_required,terms_accepted_at FROM bot_core.users WHERE telegram_id=$1",
                int(telegram_id),
            )
        return bool(row and row["terms_required"] and row["terms_accepted_at"] is None)

    async def accept_terms(self, telegram_id: int) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                UPDATE bot_core.users
                SET terms_required=TRUE,terms_accepted_at=COALESCE(terms_accepted_at,NOW()),updated_at=NOW()
                WHERE telegram_id=$1
                RETURNING telegram_id
                """,
                int(telegram_id),
            )
        return row is not None

    async def set_pending_start_action(self, telegram_id: int, action: str | None) -> None:
        normalized = str(action or "").strip() or None
        if normalized not in {None, "claim_wheel"}:
            import re
            if normalized is None or re.fullmatch(r"(?:contest|roulette|roulette_result):[1-9][0-9]{0,18}", normalized) is None:
                raise ValueError("INVALID_PENDING_START_ACTION")
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                "UPDATE bot_core.users SET pending_start_action=$2,updated_at=NOW() WHERE telegram_id=$1",
                int(telegram_id), normalized,
            )

    async def pending_start_action(self, telegram_id: int) -> str | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            value = await conn.fetchval(
                "SELECT pending_start_action FROM bot_core.users WHERE telegram_id=$1",
                int(telegram_id),
            )
        return str(value) if value else None

    async def clear_pending_start_action(self, telegram_id: int, expected: str) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """UPDATE bot_core.users SET pending_start_action=NULL,updated_at=NOW()
                   WHERE telegram_id=$1 AND pending_start_action=$2""",
                int(telegram_id), str(expected),
            )
        return result.endswith(" 1")

    async def is_blocked(self, telegram_id: int) -> bool | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            value = await conn.fetchval(
                "SELECT is_blocked FROM bot_core.users WHERE telegram_id=$1",
                int(telegram_id),
            )
        return None if value is None else bool(value)

    async def touch_existing_from_telegram(self, user: TelegramUser) -> bool:
        """Refresh an existing profile/activity row without creating a new user."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE bot_core.users
                SET username=$2, first_name=$3, last_name=$4, language_code=$5,
                    is_bot=$6, last_active_at=NOW(), updated_at=NOW()
                WHERE telegram_id=$1
                """,
                int(user.id), user.username, user.first_name or "", user.last_name,
                user.language_code, bool(user.is_bot),
            )
        return result.endswith(" 1")

    async def set_blocked(self, target_id: int, blocked: bool, *, actor_id: int) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.users
                    SET is_blocked=$2,
                        blocked_at=CASE WHEN $2 THEN NOW() ELSE NULL END,
                        blocked_by=$3,
                        updated_at=NOW()
                    WHERE telegram_id=$1
                    RETURNING telegram_id
                    """,
                    int(target_id), bool(blocked), int(actor_id),
                )
                if row is None:
                    raise ValueError("user not found")
                await conn.execute(
                    """
                    INSERT INTO bot_core.admin_user_actions(actor_telegram_id,target_telegram_id,action,details)
                    VALUES($1,$2,$3,jsonb_build_object('blocked',$4::boolean))
                    """,
                    int(actor_id), int(target_id), "user_blocked" if blocked else "user_unblocked", bool(blocked),
                )

    async def log_admin_action(
        self, actor_id: int, target_id: int, action: str, details: dict[str, Any] | None = None
    ) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO bot_core.admin_user_actions(actor_telegram_id,target_telegram_id,action,details)
                VALUES($1,$2,$3,$4::jsonb)
                """,
                int(actor_id), int(target_id), str(action), json.dumps(details or {}, ensure_ascii=False, separators=(",", ":"), default=str),
            )

    async def search_admin_users(self, query: str, *, limit: int = 12) -> list[dict[str, Any]]:
        clean = str(query or "").strip()
        if not clean:
            return []
        numeric_id = None
        if clean.isdigit():
            parsed = int(clean)
            if 0 < parsed <= 9_223_372_036_854_775_807:
                numeric_id = parsed
        text = clean.lstrip("@").strip().lower()
        if numeric_id is None and not text:
            return []
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT u.telegram_id,u.username,u.first_name,u.last_name,u.is_blocked,
                       COALESCE(w.available,0) AS balance,
                       ia.username AS ichancy_username, ia.player_id
                FROM bot_core.users u
                LEFT JOIN bot_core.wallet_accounts w
                  ON w.telegram_id=u.telegram_id AND w.asset_code='SYP' AND w.bucket='cash'
                LEFT JOIN bot_core.ichancy_accounts ia
                  ON ia.telegram_id=u.telegram_id AND ia.status='active'
                WHERE NOT u.is_bot AND (
                    ($1::BIGINT IS NOT NULL AND u.telegram_id=$1)
                    OR LOWER(COALESCE(u.username,'')) = $2
                    OR LOWER(COALESCE(u.username,'')) LIKE '%' || $2 || '%'
                    OR LOWER(COALESCE(u.first_name,'') || ' ' || COALESCE(u.last_name,'')) LIKE '%' || $2 || '%'
                    OR LOWER(COALESCE(ia.username,'')) = $2
                    OR LOWER(COALESCE(ia.player_id,'')) = $2
                )
                ORDER BY CASE WHEN $1::BIGINT IS NOT NULL AND u.telegram_id=$1 THEN 0 ELSE 1 END,
                         u.updated_at DESC
                LIMIT $3
                """,
                numeric_id, text, max(1, min(int(limit), 25)),
            )
        return [dict(row) for row in rows]

    async def admin_user_card(self, telegram_id: int) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT
                    u.telegram_id,u.username,u.first_name,u.last_name,u.is_blocked,
                    u.created_at,u.last_active_at,u.blocked_at,u.blocked_by,
                    COALESCE(w.available,0) AS balance,COALESCE(w.held,0) AS held,
                    ia.username AS ichancy_username,ia.player_id,
                    (SELECT j.player_balance_after FROM bot_core.ichancy_jobs j
                     WHERE j.telegram_id=u.telegram_id AND j.player_balance_after IS NOT NULL
                     ORDER BY COALESCE(j.finished_at,j.updated_at,j.created_at) DESC LIMIT 1) AS ichancy_last_balance,
                    COALESCE((SELECT COUNT(*) FROM bot_core.deposit_requests d
                              WHERE d.telegram_id=u.telegram_id AND d.status='success'),0) AS deposits_count,
                    COALESCE((SELECT SUM(d.base_credit_syp) FROM bot_core.deposit_requests d
                              WHERE d.telegram_id=u.telegram_id AND d.status='success'),0) AS deposits_total,
                    COALESCE((SELECT COUNT(*) FROM bot_core.withdraw_requests x
                              WHERE x.telegram_id=u.telegram_id AND x.status='success'),0) AS withdrawals_count,
                    COALESCE((SELECT SUM(x.amount_wallet) FROM bot_core.withdraw_requests x
                              WHERE x.telegram_id=u.telegram_id AND x.status='success'),0) AS withdrawals_total,
                    COALESCE((SELECT COUNT(*) FROM bot_core.ichancy_jobs j
                              WHERE j.telegram_id=u.telegram_id AND j.operation_type='deposit' AND j.status='success'),0) AS ichancy_deposits_count,
                    COALESCE((SELECT SUM(j.amount) FROM bot_core.ichancy_jobs j
                              WHERE j.telegram_id=u.telegram_id AND j.operation_type='deposit' AND j.status='success'),0) AS ichancy_deposits_total,
                    COALESCE((SELECT COUNT(*) FROM bot_core.ichancy_jobs j
                              WHERE j.telegram_id=u.telegram_id AND j.operation_type IN ('withdraw','retirement_withdraw') AND j.status='success'),0) AS ichancy_withdrawals_count,
                    COALESCE((SELECT SUM(j.amount) FROM bot_core.ichancy_jobs j
                              WHERE j.telegram_id=u.telegram_id AND j.operation_type IN ('withdraw','retirement_withdraw') AND j.status='success'),0) AS ichancy_withdrawals_total,
                    COALESCE((SELECT COUNT(*) FROM bot_core.users r
                              WHERE r.referrer_telegram_id=u.telegram_id AND r.referral_status='confirmed'),0) AS referrals_total,
                    COALESCE((SELECT SUM(fr.amount_syp) FROM bot_core.referral_fixed_rewards fr
                              WHERE fr.referrer_telegram_id=u.telegram_id),0)
                    + COALESCE((SELECT SUM(p.amount_syp) FROM bot_core.referral_cycle_payouts p
                                WHERE p.referrer_telegram_id=u.telegram_id AND p.status='paid'),0) AS referral_income
                FROM bot_core.users u
                LEFT JOIN bot_core.wallet_accounts w
                  ON w.telegram_id=u.telegram_id AND w.asset_code='SYP' AND w.bucket='cash'
                LEFT JOIN bot_core.ichancy_accounts ia
                  ON ia.telegram_id=u.telegram_id AND ia.status='active'
                WHERE u.telegram_id=$1
                LIMIT 1
                """,
                int(telegram_id),
            )
        return dict(row) if row else None

    async def ranked_users(self, kind: str, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        limit = max(1, min(int(limit), 25))
        offset = max(0, int(offset))
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            if kind == "activity":
                total = await conn.fetchval(
                    """
                    SELECT COUNT(*) FROM bot_core.users u
                    WHERE NOT u.is_bot AND (
                      EXISTS(SELECT 1 FROM bot_core.deposit_requests d WHERE d.telegram_id=u.telegram_id AND d.created_at>=NOW()-INTERVAL '24 hours')
                      OR EXISTS(SELECT 1 FROM bot_core.withdraw_requests w WHERE w.telegram_id=u.telegram_id AND w.created_at>=NOW()-INTERVAL '24 hours')
                      OR EXISTS(SELECT 1 FROM bot_core.ichancy_jobs j WHERE j.telegram_id=u.telegram_id AND j.created_at>=NOW()-INTERVAL '24 hours')
                    )
                    """
                )
                rows = await conn.fetch(
                    """
                    SELECT u.telegram_id,u.username,u.first_name,
                      (SELECT COUNT(*) FROM bot_core.deposit_requests d WHERE d.telegram_id=u.telegram_id AND d.created_at>=NOW()-INTERVAL '24 hours')
                      +(SELECT COUNT(*) FROM bot_core.withdraw_requests w WHERE w.telegram_id=u.telegram_id AND w.created_at>=NOW()-INTERVAL '24 hours')
                      +(SELECT COUNT(*) FROM bot_core.ichancy_jobs j WHERE j.telegram_id=u.telegram_id AND j.created_at>=NOW()-INTERVAL '24 hours') AS activity_count
                    FROM bot_core.users u
                    WHERE NOT u.is_bot AND (
                      EXISTS(SELECT 1 FROM bot_core.deposit_requests d WHERE d.telegram_id=u.telegram_id AND d.created_at>=NOW()-INTERVAL '24 hours')
                      OR EXISTS(SELECT 1 FROM bot_core.withdraw_requests w WHERE w.telegram_id=u.telegram_id AND w.created_at>=NOW()-INTERVAL '24 hours')
                      OR EXISTS(SELECT 1 FROM bot_core.ichancy_jobs j WHERE j.telegram_id=u.telegram_id AND j.created_at>=NOW()-INTERVAL '24 hours')
                    )
                    ORDER BY activity_count DESC,u.last_active_at DESC NULLS LAST
                    LIMIT $1 OFFSET $2
                    """,
                    limit, offset,
                )
            else:
                total = await conn.fetchval("SELECT COUNT(*) FROM bot_core.users WHERE NOT is_bot")
                rows = await conn.fetch(
                    """
                    SELECT u.telegram_id,u.username,u.first_name,COALESCE(w.available,0) AS balance
                    FROM bot_core.users u
                    LEFT JOIN bot_core.wallet_accounts w
                      ON w.telegram_id=u.telegram_id AND w.asset_code='SYP' AND w.bucket='cash'
                    WHERE NOT u.is_bot
                    ORDER BY COALESCE(w.available,0) DESC,u.telegram_id
                    LIMIT $1 OFFSET $2
                    """,
                    limit, offset,
                )
        return [dict(row) for row in rows], int(total or 0)

    async def list_blocked(self, *, limit: int = 10, offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        limit = max(1, min(int(limit), 25))
        offset = max(0, int(offset))
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = await conn.fetchval("SELECT COUNT(*) FROM bot_core.users WHERE is_blocked")
            rows = await conn.fetch(
                """
                SELECT u.telegram_id,u.username,u.first_name,u.blocked_at,u.blocked_by,
                       COALESCE(w.available,0) AS balance
                FROM bot_core.users u
                LEFT JOIN bot_core.wallet_accounts w
                  ON w.telegram_id=u.telegram_id AND w.asset_code='SYP' AND w.bucket='cash'
                WHERE u.is_blocked
                ORDER BY u.blocked_at DESC NULLS LAST,u.telegram_id DESC
                LIMIT $1 OFFSET $2
                """,
                limit, offset,
            )
        return [dict(row) for row in rows], int(total or 0)
    async def admin_overview(self) -> dict[str, Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT
                  (SELECT COUNT(*) FROM bot_core.users WHERE NOT is_bot) AS total_users,
                  (SELECT COUNT(*) FROM bot_core.users WHERE NOT is_bot AND last_active_at>=NOW()-INTERVAL '24 hours') AS active_24h,
                  (SELECT COUNT(*) FROM bot_core.users WHERE is_blocked) AS blocked_users,
                  (SELECT COALESCE(SUM(available),0) FROM bot_core.wallet_accounts WHERE asset_code='SYP' AND bucket='cash') AS wallet_available,
                  (SELECT COALESCE(SUM(held),0) FROM bot_core.wallet_accounts WHERE asset_code='SYP' AND bucket='cash') AS wallet_held,
                  (SELECT COUNT(*) FROM bot_core.deposit_requests WHERE status='success' AND settled_at>=NOW()-INTERVAL '24 hours') AS deposits_24h_count,
                  (SELECT COALESCE(SUM(base_credit_syp),0) FROM bot_core.deposit_requests WHERE status='success' AND settled_at>=NOW()-INTERVAL '24 hours') AS deposits_24h_total,
                  (SELECT COUNT(*) FROM bot_core.withdraw_requests WHERE status='success' AND finished_at>=NOW()-INTERVAL '24 hours') AS withdrawals_24h_count,
                  (SELECT COALESCE(SUM(amount_wallet),0) FROM bot_core.withdraw_requests WHERE status='success' AND finished_at>=NOW()-INTERVAL '24 hours') AS withdrawals_24h_total,
                  (SELECT COUNT(*) FROM bot_core.deposit_requests WHERE status IN ('verifying','manual_pending')) AS deposits_pending,
                  (SELECT COUNT(*) FROM bot_core.withdraw_requests WHERE status IN ('pending','processing','provider_success','needs_review')) AS withdrawals_pending,
                  (SELECT COUNT(*) FROM bot_core.ichancy_jobs WHERE status IN ('queued','executing','remote_success','reconciling')) AS ichancy_pending,
                  (SELECT COALESCE(SUM(amount),0) FROM bot_core.ichancy_jobs WHERE operation_type='deposit' AND status='success' AND finished_at>=NOW()-INTERVAL '24 hours') AS ichancy_deposit_24h,
                  (SELECT COALESCE(SUM(amount),0) FROM bot_core.ichancy_jobs WHERE operation_type IN ('withdraw','retirement_withdraw') AND status='success' AND finished_at>=NOW()-INTERVAL '24 hours') AS ichancy_withdraw_24h
                """
            )
        return dict(row) if row else {}

    async def public_history(
        self, telegram_id: int, kind: str, *, limit: int = 15, offset: int = 0
    ) -> tuple[list[dict[str, Any]], int]:
        target = int(telegram_id)
        limit = max(1, min(int(limit), 25))
        offset = max(0, int(offset))
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            if kind == "deposits":
                total = await conn.fetchval(
                    "SELECT COUNT(*) FROM bot_core.deposit_requests WHERE telegram_id=$1 AND status='success'", target
                )
                rows = await conn.fetch(
                    """SELECT id,method,base_credit_syp AS amount,bonus_credit_syp AS bonus,provider_tx,created_at,settled_at
                       FROM bot_core.deposit_requests WHERE telegram_id=$1 AND status='success'
                       ORDER BY COALESCE(settled_at,created_at) DESC LIMIT $2 OFFSET $3""",
                    target, limit, offset,
                )
            elif kind == "withdrawals":
                total = await conn.fetchval(
                    "SELECT COUNT(*) FROM bot_core.withdraw_requests WHERE telegram_id=$1 AND status='success'", target
                )
                rows = await conn.fetch(
                    """SELECT id,method,amount_wallet AS amount,fee_wallet AS fee,net_wallet AS net_amount,
                              provider_reference,receiver,created_at,finished_at
                       FROM bot_core.withdraw_requests WHERE telegram_id=$1 AND status='success'
                       ORDER BY COALESCE(finished_at,created_at) DESC LIMIT $2 OFFSET $3""",
                    target, limit, offset,
                )
            elif kind == "ichancy":
                total = await conn.fetchval(
                    "SELECT COUNT(*) FROM bot_core.ichancy_jobs WHERE telegram_id=$1 AND status='success'", target
                )
                rows = await conn.fetch(
                    """SELECT id,operation_type,amount,source,provider_reference,created_at,finished_at
                       FROM bot_core.ichancy_jobs WHERE telegram_id=$1 AND status='success'
                       ORDER BY COALESCE(finished_at,created_at) DESC LIMIT $2 OFFSET $3""",
                    target, limit, offset,
                )
            else:
                return [], 0
        return [dict(row) for row in rows], int(total or 0)

    async def user_history(
        self, telegram_id: int, kind: str, *, limit: int = 8, offset: int = 0
    ) -> tuple[list[dict[str, Any]], int]:
        target = int(telegram_id)
        limit = max(1, min(int(limit), 25))
        offset = max(0, int(offset))
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            if kind == "deposits":
                total = await conn.fetchval("SELECT COUNT(*) FROM bot_core.deposit_requests WHERE telegram_id=$1", target)
                rows = await conn.fetch(
                    """SELECT id,method,status,base_credit_syp AS amount,bonus_credit_syp AS bonus,provider_tx,created_at,settled_at
                       FROM bot_core.deposit_requests WHERE telegram_id=$1
                       ORDER BY created_at DESC LIMIT $2 OFFSET $3""", target, limit, offset)
            elif kind == "withdrawals":
                total = await conn.fetchval("SELECT COUNT(*) FROM bot_core.withdraw_requests WHERE telegram_id=$1", target)
                rows = await conn.fetch(
                    """SELECT id,method,status,amount_wallet AS amount,fee_wallet AS fee,provider_reference,created_at,finished_at
                       FROM bot_core.withdraw_requests WHERE telegram_id=$1
                       ORDER BY created_at DESC LIMIT $2 OFFSET $3""", target, limit, offset)
            elif kind == "ichancy":
                total = await conn.fetchval("SELECT COUNT(*) FROM bot_core.ichancy_jobs WHERE telegram_id=$1", target)
                rows = await conn.fetch(
                    """SELECT id,operation_type,status,amount,source,player_balance_before,player_balance_after,created_at,finished_at
                       FROM bot_core.ichancy_jobs WHERE telegram_id=$1
                       ORDER BY created_at DESC LIMIT $2 OFFSET $3""", target, limit, offset)
            elif kind == "referrals":
                total = await conn.fetchval(
                    "SELECT COUNT(*) FROM bot_core.users WHERE referrer_telegram_id=$1", target)
                rows = await conn.fetch(
                    """SELECT telegram_id,username,first_name,referral_status,referral_first_seen_at,referral_confirmed_at
                       FROM bot_core.users WHERE referrer_telegram_id=$1
                       ORDER BY COALESCE(referral_confirmed_at,referral_first_seen_at,created_at) DESC
                       LIMIT $2 OFFSET $3""", target, limit, offset)
            elif kind == "admin":
                total = await conn.fetchval("SELECT COUNT(*) FROM bot_core.admin_user_actions WHERE target_telegram_id=$1", target)
                rows = await conn.fetch(
                    """SELECT id,actor_telegram_id,action,details,created_at
                       FROM bot_core.admin_user_actions WHERE target_telegram_id=$1
                       ORDER BY created_at DESC LIMIT $2 OFFSET $3""", target, limit, offset)
            else:
                return [], 0
        return [dict(row) for row in rows], int(total or 0)

