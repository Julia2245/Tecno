from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Update


@dataclass(slots=True)
class _LockEntry:
    lock: asyncio.Lock
    users: int = 0


def update_user_id(event: TelegramObject) -> int | None:
    """Return the human Telegram user behind an update, if there is one."""
    if not isinstance(event, Update):
        user = getattr(event, "from_user", None)
        return int(user.id) if user is not None else None
    inner = event.event
    user = getattr(inner, "from_user", None)
    if user is None:
        message = getattr(inner, "message", None)
        user = getattr(message, "from_user", None) if message is not None else None
    return int(user.id) if user is not None else None


class PerUserSerializationMiddleware(BaseMiddleware):
    """Serialize one user's updates while preserving cross-user concurrency.

    The registry is reference-counted.  An entry is removed as soon as its last
    running/waiting update leaves, so a large user base does not turn this into
    an ever-growing lock cache.
    """

    def __init__(self) -> None:
        self._entries: dict[int, _LockEntry] = {}
        self._registry_lock = asyncio.Lock()

    async def _checkout(self, user_id: int) -> _LockEntry:
        async with self._registry_lock:
            entry = self._entries.get(user_id)
            if entry is None:
                entry = _LockEntry(lock=asyncio.Lock())
                self._entries[user_id] = entry
            entry.users += 1
            return entry

    async def _checkin(self, user_id: int, entry: _LockEntry) -> None:
        async with self._registry_lock:
            entry.users -= 1
            if entry.users <= 0 and not entry.lock.locked() and self._entries.get(user_id) is entry:
                self._entries.pop(user_id, None)

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user_id = update_user_id(event)
        if user_id is None:
            return await handler(event, data)

        entry = await self._checkout(user_id)
        acquired = False
        try:
            await entry.lock.acquire()
            acquired = True
            data["serialized_user_id"] = user_id
            return await handler(event, data)
        finally:
            if acquired:
                entry.lock.release()
            await self._checkin(user_id, entry)
