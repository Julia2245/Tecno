from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError
from aiogram.types import CallbackQuery, Message, TelegramObject, Update

from app.services.runtime_settings import RuntimeSettingsService

logger = logging.getLogger(__name__)

DEFAULT_MAINTENANCE_TEXT = (
    "🛠 البوت في وضع الصيانة حاليًا\n\n"
    "نعمل على بعض التحسينات. يرجى المحاولة مرة أخرى بعد انتهاء الصيانة."
)


def _source(event: TelegramObject) -> tuple[object | None, CallbackQuery | None, Message | None]:
    inner = event.event if isinstance(event, Update) else event
    callback = inner if isinstance(inner, CallbackQuery) else None
    message = inner if isinstance(inner, Message) else None
    user = getattr(inner, "from_user", None)
    if callback is not None and message is None:
        message = callback.message if isinstance(callback.message, Message) else None
    return user, callback, message


class MaintenanceModeMiddleware(BaseMiddleware):
    """Globally block non-admin interactions while maintenance mode is enabled.

    This is intentionally an *update outer middleware*: stale inline keyboards,
    commands, text messages and new menus are rejected before any business router
    or FSM handler can run.  Background financial workers are not stopped here;
    already-started provider operations must still reconcile safely.
    """

    def __init__(
        self, runtime_settings: RuntimeSettingsService, admin_ids_source
    ) -> None:
        self.runtime_settings = runtime_settings
        self.admin_ids_source = admin_ids_source

    def _admin_ids(self) -> set[int]:
        source = self.admin_ids_source
        values = getattr(source, "super_admin_ids", source)
        return {int(x) for x in values}

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        runtime = self.runtime_settings
        user, callback, message = _source(event)
        if user is None:
            return await handler(event, data)

        user_id = int(user.id)

        # A confirmed database restore has a stricter gate than normal maintenance:
        # no new update (including admin updates) may race the final quiescence
        # check / restart window. The update that set this flag is already inside
        # its handler and is therefore not interrupted.
        if runtime.get_bool("system.restore_lock", False):
            try:
                if callback is not None:
                    await callback.answer("♻️ الاستعادة قيد التجهيز. لا يمكن تنفيذ أي إجراء جديد الآن.", show_alert=True)
                elif message is not None:
                    await message.answer("♻️ تجري الآن عملية استعادة محمية. سيتم فتح لوحة الإدارة بعد إعادة تشغيل البوت.", parse_mode=None)
            except (TelegramBadRequest, TelegramNetworkError):
                logger.debug("Could not notify user %s about restore lock", user_id, exc_info=True)
            return None

        if user_id in self._admin_ids():
            return await handler(event, data)

        if not runtime.get_bool("maintenance.enabled", False):
            return await handler(event, data)

        text = str(runtime.get("maintenance.message", DEFAULT_MAINTENANCE_TEXT) or DEFAULT_MAINTENANCE_TEXT)
        alert_text = "🛠 البوت في وضع الصيانة حاليًا. يرجى المحاولة لاحقًا."
        try:
            if callback is not None:
                # Always answer stale callback queries here because the normal
                # callback middleware/router chain is intentionally bypassed.
                await callback.answer(alert_text, show_alert=True)
            elif message is not None:
                await message.answer(text, parse_mode=None)
        except (TelegramBadRequest, TelegramNetworkError):
            logger.debug("Could not notify user %s about maintenance mode", user_id, exc_info=True)
        return None
