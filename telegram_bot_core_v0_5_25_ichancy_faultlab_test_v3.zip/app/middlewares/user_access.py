from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError
from aiogram.types import CallbackQuery, Message, TelegramObject, Update

from app.services.users import UserService
from app.services.runtime_settings import RuntimeSettingsService
from app.core.user_experience import support_keyboard, terms_accept_keyboard
from app.core.ui_customization import render_message

logger = logging.getLogger(__name__)


def _source(event: TelegramObject) -> tuple[object | None, CallbackQuery | None, Message | None]:
    inner = event.event if isinstance(event, Update) else event
    callback = inner if isinstance(inner, CallbackQuery) else None
    message = inner if isinstance(inner, Message) else None
    user = getattr(inner, "from_user", None)
    if callback is not None and message is None:
        message = callback.message if isinstance(callback.message, Message) else None
    return user, callback, message


class UserAccessMiddleware(BaseMiddleware):
    """Fail closed for locally blocked users and cheaply refresh activity/profile.

    It never creates an unknown user.  That is important for /start referral
    attribution: the start handler remains the first writer for a brand-new user.
    """

    def __init__(
        self, users: UserService, admin_ids_source,
        runtime_settings: RuntimeSettingsService | None = None,
    ) -> None:
        self.users = users
        self.runtime_settings = runtime_settings
        self.admin_ids_source = admin_ids_source

    def _admin_ids(self) -> set[int]:
        source = self.admin_ids_source
        values = getattr(source, "super_admin_ids", source)
        return {int(x) for x in values}

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user, callback, message = _source(event)
        if user is None:
            return await handler(event, data)
        user_id = int(user.id)
        if user_id in self._admin_ids():
            await self.users.touch_existing(user)
            return await handler(event, data)

        blocked = await self.users.is_blocked_cached(user_id)
        if blocked:
            text = "🚫 حسابك محظور من استخدام البوت.\n\nللاستفسار يرجى التواصل مع الدعم."
            try:
                if callback is not None:
                    await callback.answer("🚫 حسابك محظور من استخدام البوت.", show_alert=True)
                elif message is not None:
                    markup = support_keyboard(self.runtime_settings, include_back=False) if self.runtime_settings is not None else None
                    await message.answer(text, reply_markup=markup)
            except (TelegramBadRequest, TelegramNetworkError):
                logger.debug("Could not notify blocked user %s", user_id, exc_info=True)
            return None

        await self.users.touch_existing(user)

        # Terms are a central access gate for newly registered users. Unknown users
        # are intentionally not created here so /start remains the first-touch writer.
        if await self.users.needs_terms_cached(user_id):
            callback_data = str(callback.data or "") if callback is not None else ""
            message_text = str(message.text or "").strip() if message is not None else ""
            allowed = (
                message_text.startswith("/start")
                or callback_data == "start:check"
                or callback_data.startswith("terms:accept")
                or callback_data in {"terms:reject", "menu:terms"}
            )
            if not allowed:
                try:
                    if callback is not None:
                        await callback.answer("📜 يجب الموافقة على الشروط أولاً", show_alert=True)
                        if message is not None:
                            await message.edit_text(render_message(self.runtime_settings, "terms"), reply_markup=terms_accept_keyboard())
                    elif message is not None:
                        await message.answer(render_message(self.runtime_settings, "terms"), reply_markup=terms_accept_keyboard())
                except (TelegramBadRequest, TelegramNetworkError):
                    logger.debug("Could not show terms gate to user %s", user_id, exc_info=True)
                return None
        return await handler(event, data)
