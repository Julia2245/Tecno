-- Batch 5: gift codes, user-to-user gifting, loyalty points and reward claims.

CREATE TABLE IF NOT EXISTS bot_core.gift_transfers (
    id UUID PRIMARY KEY,
    request_token UUID NOT NULL UNIQUE,
    from_telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    to_telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    amount_syp BIGINT NOT NULL CHECK (amount_syp > 0),
    sender_wallet_operation_id UUID NOT NULL REFERENCES bot_core.wallet_operations(id) ON DELETE RESTRICT,
    recipient_wallet_operation_id UUID NOT NULL REFERENCES bot_core.wallet_operations(id) ON DELETE RESTRICT,
    sender_balance_after BIGINT NOT NULL CHECK (sender_balance_after >= 0),
    recipient_balance_after BIGINT NOT NULL CHECK (recipient_balance_after >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT gift_transfer_not_self CHECK (from_telegram_id <> to_telegram_id)
);
CREATE INDEX IF NOT EXISTS idx_gift_transfers_from_created ON bot_core.gift_transfers(from_telegram_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_gift_transfers_to_created ON bot_core.gift_transfers(to_telegram_id,created_at DESC);

CREATE TABLE IF NOT EXISTS bot_core.gift_codes (
    code TEXT PRIMARY KEY,
    amount_syp BIGINT NOT NULL CHECK (amount_syp >= 0),
    is_fake BOOLEAN NOT NULL DEFAULT FALSE,
    max_uses INTEGER NOT NULL DEFAULT 1 CHECK (max_uses BETWEEN 1 AND 100000),
    uses_count INTEGER NOT NULL DEFAULT 0 CHECK (uses_count >= 0 AND uses_count <= max_uses),
    target_telegram_id BIGINT REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    created_by BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    disabled_at TIMESTAMPTZ,
    disabled_by BIGINT,
    CONSTRAINT gift_codes_code_format CHECK (code ~ '^[A-Z0-9-]{4,40}$'),
    CONSTRAINT gift_codes_private_single CHECK (target_telegram_id IS NULL OR max_uses=1),
    CONSTRAINT gift_codes_fake_value CHECK ((is_fake AND amount_syp=0 AND max_uses=1 AND target_telegram_id IS NULL) OR (NOT is_fake AND amount_syp>0))
);
CREATE INDEX IF NOT EXISTS idx_gift_codes_active ON bot_core.gift_codes(created_at DESC) WHERE disabled_at IS NULL AND NOT is_fake AND uses_count < max_uses;

CREATE TABLE IF NOT EXISTS bot_core.gift_code_redemptions (
    code TEXT NOT NULL REFERENCES bot_core.gift_codes(code) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    amount_syp BIGINT NOT NULL CHECK (amount_syp > 0),
    wallet_operation_id UUID NOT NULL UNIQUE REFERENCES bot_core.wallet_operations(id) ON DELETE RESTRICT,
    balance_before BIGINT NOT NULL CHECK (balance_before >= 0),
    balance_after BIGINT NOT NULL CHECK (balance_after >= 0),
    used_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY(code,telegram_id)
);
CREATE INDEX IF NOT EXISTS idx_gift_code_redemptions_user ON bot_core.gift_code_redemptions(telegram_id,used_at DESC);

CREATE TABLE IF NOT EXISTS bot_core.loyalty_accounts (
    telegram_id BIGINT PRIMARY KEY REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    points BIGINT NOT NULL DEFAULT 0 CHECK (points >= 0),
    total_earned BIGINT NOT NULL DEFAULT 0 CHECK (total_earned >= 0),
    total_redeemed BIGINT NOT NULL DEFAULT 0 CHECK (total_redeemed >= 0),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bot_core.loyalty_deposit_awards (
    deposit_id UUID PRIMARY KEY REFERENCES bot_core.deposit_requests(id) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    base_amount_syp BIGINT NOT NULL CHECK (base_amount_syp >= 0),
    enabled_snapshot BOOLEAN NOT NULL,
    earn_syp_per_point BIGINT NOT NULL CHECK (earn_syp_per_point > 0),
    min_deposit_syp BIGINT NOT NULL CHECK (min_deposit_syp >= 0),
    points_awarded BIGINT NOT NULL DEFAULT 0 CHECK (points_awarded >= 0),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','awarded','skipped_disabled','skipped_below_minimum','skipped_zero_points','failed')),
    attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    settled_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_loyalty_awards_pending ON bot_core.loyalty_deposit_awards(updated_at,deposit_id) WHERE status IN ('pending','failed');

CREATE TABLE IF NOT EXISTS bot_core.loyalty_events (
    id BIGSERIAL PRIMARY KEY,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    event_type TEXT NOT NULL CHECK (event_type ~ '^[a-z][a-z0-9_]{1,39}$'),
    points_delta BIGINT NOT NULL,
    amount_syp BIGINT NOT NULL DEFAULT 0 CHECK (amount_syp >= 0),
    deposit_id UUID REFERENCES bot_core.deposit_requests(id) ON DELETE RESTRICT,
    reward_claim_id UUID,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_loyalty_events_user ON bot_core.loyalty_events(telegram_id,id DESC);

CREATE TABLE IF NOT EXISTS bot_core.loyalty_rewards (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL CHECK (char_length(name) BETWEEN 1 AND 120),
    reward_type TEXT NOT NULL CHECK (reward_type IN ('balance','manual')),
    points_cost BIGINT NOT NULL CHECK (points_cost > 0),
    balance_amount_syp BIGINT NOT NULL DEFAULT 0 CHECK (balance_amount_syp >= 0),
    stock_total INTEGER NOT NULL DEFAULT 0 CHECK (stock_total >= 0),
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT loyalty_reward_balance_value CHECK (
       (reward_type='balance' AND balance_amount_syp>0) OR reward_type='manual'
    )
);

CREATE TABLE IF NOT EXISTS bot_core.loyalty_reward_claims (
    id UUID PRIMARY KEY,
    reward_id BIGINT NOT NULL REFERENCES bot_core.loyalty_rewards(id) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    reward_name TEXT NOT NULL,
    reward_type TEXT NOT NULL CHECK (reward_type IN ('balance','manual')),
    points_spent BIGINT NOT NULL CHECK (points_spent > 0),
    balance_amount_syp BIGINT NOT NULL DEFAULT 0 CHECK (balance_amount_syp >= 0),
    status TEXT NOT NULL CHECK (status IN ('pending','completed','delivered','rejected')),
    wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    decided_at TIMESTAMPTZ,
    decided_by BIGINT
);
CREATE INDEX IF NOT EXISTS idx_loyalty_claims_user ON bot_core.loyalty_reward_claims(telegram_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_loyalty_claims_pending ON bot_core.loyalty_reward_claims(created_at,id) WHERE status='pending';

-- Immutable history rows. State/config tables remain mutable by design.
CREATE OR REPLACE FUNCTION bot_core.reject_batch5_history_change() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'immutable batch5 history row cannot be changed'; END; $$;
DROP TRIGGER IF EXISTS gift_transfers_immutable ON bot_core.gift_transfers;
CREATE TRIGGER gift_transfers_immutable BEFORE UPDATE OR DELETE ON bot_core.gift_transfers FOR EACH ROW EXECUTE FUNCTION bot_core.reject_batch5_history_change();
DROP TRIGGER IF EXISTS gift_code_redemptions_immutable ON bot_core.gift_code_redemptions;
CREATE TRIGGER gift_code_redemptions_immutable BEFORE UPDATE OR DELETE ON bot_core.gift_code_redemptions FOR EACH ROW EXECUTE FUNCTION bot_core.reject_batch5_history_change();
DROP TRIGGER IF EXISTS loyalty_events_immutable ON bot_core.loyalty_events;
CREATE TRIGGER loyalty_events_immutable BEFORE UPDATE OR DELETE ON bot_core.loyalty_events FOR EACH ROW EXECUTE FUNCTION bot_core.reject_batch5_history_change();
