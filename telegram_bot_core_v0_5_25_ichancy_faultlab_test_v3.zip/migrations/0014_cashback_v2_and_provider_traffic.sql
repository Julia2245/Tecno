-- Cashback cycle accounting V2 + safe legacy-cycle recalculation metadata.
-- Existing prepared/distributed financial rows are preserved. Existing cycles remain
-- calc_version=1 until they are safely recalculated or newly prepared with V2.

ALTER TABLE bot_core.cashback_cycles
    ADD COLUMN IF NOT EXISTS calc_version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE bot_core.cashback_cycles
    ADD COLUMN IF NOT EXISTS last_error TEXT;
ALTER TABLE bot_core.cashback_cycles
    ADD COLUMN IF NOT EXISTS v2_recalc_token UUID;
ALTER TABLE bot_core.cashback_cycles
    ADD COLUMN IF NOT EXISTS v2_recalc_started_at TIMESTAMPTZ;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname='cashback_cycles_calc_version_positive'
          AND conrelid='bot_core.cashback_cycles'::regclass
    ) THEN
        ALTER TABLE bot_core.cashback_cycles
            ADD CONSTRAINT cashback_cycles_calc_version_positive
            CHECK (calc_version >= 1);
    END IF;
END
$$;

CREATE INDEX IF NOT EXISTS idx_cashback_cycles_v2_repair
    ON bot_core.cashback_cycles(calc_version,status,cycle_end)
    WHERE calc_version < 2;

-- Helps cycle-freeze checks and exact provider-success window accounting.
CREATE INDEX IF NOT EXISTS idx_ichancy_jobs_cycle_financial_window
    ON bot_core.ichancy_jobs(financial_post_started_at,remote_success_at,finished_at,status)
    WHERE operation_type IN ('deposit','withdraw','retirement_withdraw');
