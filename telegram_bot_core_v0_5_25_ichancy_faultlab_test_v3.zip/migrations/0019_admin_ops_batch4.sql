-- Batch 4: assistant-admin access, immutable admin security audit, and backup metadata.
-- Financial tables are not altered; reserved transaction numbers reuse the table
-- created by the deposit core migration.

CREATE TABLE IF NOT EXISTS bot_core.admin_assistants (
    telegram_id BIGINT PRIMARY KEY REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    added_by BIGINT NOT NULL,
    permissions TEXT NOT NULL DEFAULT 'basic',
    added_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT admin_assistants_id_positive CHECK (telegram_id > 0 AND added_by > 0),
    CONSTRAINT admin_assistants_permissions CHECK (permissions IN ('basic'))
);
CREATE INDEX IF NOT EXISTS idx_admin_assistants_added_at
    ON bot_core.admin_assistants(added_at DESC);

CREATE TABLE IF NOT EXISTS bot_core.admin_security_events (
    id BIGSERIAL PRIMARY KEY,
    actor_telegram_id BIGINT NOT NULL,
    action TEXT NOT NULL,
    target_telegram_id BIGINT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT admin_security_actor_positive CHECK (actor_telegram_id > 0),
    CONSTRAINT admin_security_target_positive CHECK (target_telegram_id IS NULL OR target_telegram_id > 0),
    CONSTRAINT admin_security_action_format CHECK (action ~ '^[a-z][a-z0-9_]{2,63}$')
);
CREATE INDEX IF NOT EXISTS idx_admin_security_events_created
    ON bot_core.admin_security_events(created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_admin_security_events_actor
    ON bot_core.admin_security_events(actor_telegram_id, created_at DESC);

CREATE OR REPLACE FUNCTION bot_core.reject_admin_security_event_change()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'admin security audit rows are immutable';
END;
$$;
DROP TRIGGER IF EXISTS admin_security_events_immutable ON bot_core.admin_security_events;
CREATE TRIGGER admin_security_events_immutable
BEFORE UPDATE OR DELETE ON bot_core.admin_security_events
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_admin_security_event_change();

CREATE TABLE IF NOT EXISTS bot_core.backup_history (
    id BIGSERIAL PRIMARY KEY,
    actor_telegram_id BIGINT,
    kind TEXT NOT NULL,
    status TEXT NOT NULL,
    file_name TEXT,
    file_sha256 CHAR(64),
    size_bytes BIGINT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT backup_actor_positive CHECK (actor_telegram_id IS NULL OR actor_telegram_id > 0),
    CONSTRAINT backup_kind_allowed CHECK (kind IN ('manual','automatic','pre_restore','restore')),
    CONSTRAINT backup_status_allowed CHECK (status IN ('success','failed','scheduled')),
    CONSTRAINT backup_size_nonnegative CHECK (size_bytes IS NULL OR size_bytes >= 0),
    CONSTRAINT backup_sha_format CHECK (file_sha256 IS NULL OR file_sha256 ~ '^[0-9a-f]{64}$')
);
CREATE INDEX IF NOT EXISTS idx_backup_history_created
    ON bot_core.backup_history(created_at DESC, id DESC);

CREATE OR REPLACE FUNCTION bot_core.reject_backup_history_change()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'backup history rows are immutable';
END;
$$;
DROP TRIGGER IF EXISTS backup_history_immutable ON bot_core.backup_history;
CREATE TRIGGER backup_history_immutable
BEFORE UPDATE OR DELETE ON bot_core.backup_history
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_backup_history_change();

-- Reserved transaction numbers are intentionally mutable administrative state,
-- but add indexes needed by the management UI. Deposit anti-reuse checks keep
-- using the exact same table and primary key.
CREATE INDEX IF NOT EXISTS idx_reserved_transaction_numbers_created
    ON bot_core.reserved_transaction_numbers(created_at DESC);
