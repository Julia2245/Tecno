-- Reference-parity hardening for referral confirmation and cashback settlement.
-- Additive/constraint-only migration; existing financial rows are preserved.

ALTER TABLE bot_core.users DROP CONSTRAINT IF EXISTS users_referral_status_allowed;
ALTER TABLE bot_core.users
    ADD CONSTRAINT users_referral_status_allowed
    CHECK (referral_status IN ('none','pending','confirmed','cancelled','invalid'));

ALTER TABLE bot_core.referral_fixed_entitlements
    ADD COLUMN IF NOT EXISTS attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE bot_core.referral_fixed_entitlements
    ADD COLUMN IF NOT EXISTS last_error TEXT;

ALTER TABLE bot_core.cashback_cycle_users
    ADD COLUMN IF NOT EXISTS error_code TEXT;
ALTER TABLE bot_core.cashback_cycle_users
    DROP CONSTRAINT IF EXISTS cashback_cycle_users_status_check;

-- v0.5.14 used `ready` for per-user cashback eligibility. Convert only those
-- per-user rows while the old check is absent; cycle-level `ready` is a different table.
UPDATE bot_core.cashback_cycle_users
SET status='eligible'
WHERE status='ready';

ALTER TABLE bot_core.cashback_cycle_users
    ADD CONSTRAINT cashback_cycle_users_status_check
    CHECK (status IN ('pending','eligible','not_eligible','failed','banned','paid','skipped'));

ALTER TABLE bot_core.referral_cycles
    ADD COLUMN IF NOT EXISTS failed_count INTEGER NOT NULL DEFAULT 0;

ALTER TABLE bot_core.referral_loss_snapshots
    ADD COLUMN IF NOT EXISTS attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE bot_core.referral_loss_snapshots
    ADD COLUMN IF NOT EXISTS error_code TEXT;
ALTER TABLE bot_core.referral_loss_snapshots
    ADD COLUMN IF NOT EXISTS error_message TEXT;
ALTER TABLE bot_core.referral_loss_snapshots
    DROP CONSTRAINT IF EXISTS referral_loss_snapshots_status_check;
ALTER TABLE bot_core.referral_loss_snapshots
    ADD CONSTRAINT referral_loss_snapshots_status_check
    CHECK (status IN ('ready','not_eligible','failed'));
