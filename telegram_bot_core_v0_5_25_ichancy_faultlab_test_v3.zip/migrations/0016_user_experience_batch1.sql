-- User-experience batch 1: terms acceptance and safe iChancy account unlink metadata.
-- Existing users are not retroactively forced through the terms gate; new users are.

ALTER TABLE bot_core.users
    ADD COLUMN IF NOT EXISTS terms_required BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE bot_core.users
    ADD COLUMN IF NOT EXISTS terms_accepted_at TIMESTAMPTZ;
ALTER TABLE bot_core.users
    ADD COLUMN IF NOT EXISTS pending_start_action TEXT;

ALTER TABLE bot_core.users
    DROP CONSTRAINT IF EXISTS users_pending_start_action_check;
ALTER TABLE bot_core.users
    ADD CONSTRAINT users_pending_start_action_check
    CHECK (pending_start_action IS NULL OR pending_start_action IN ('claim_wheel'));

ALTER TABLE bot_core.ichancy_accounts
    ADD COLUMN IF NOT EXISTS unlinked_at TIMESTAMPTZ;
ALTER TABLE bot_core.ichancy_accounts
    ADD COLUMN IF NOT EXISTS unlinked_by BIGINT;
ALTER TABLE bot_core.ichancy_accounts
    ADD COLUMN IF NOT EXISTS unlink_reason TEXT;

ALTER TABLE bot_core.ichancy_accounts
    DROP CONSTRAINT IF EXISTS ichancy_account_status;
ALTER TABLE bot_core.ichancy_accounts
    ADD CONSTRAINT ichancy_account_status
    CHECK (status IN ('active','retiring','retired','unlinked'));

CREATE INDEX IF NOT EXISTS idx_ichancy_accounts_unlinked
    ON bot_core.ichancy_accounts(unlinked_at DESC NULLS LAST)
    WHERE status='unlinked';
