-- v0.5.25: presentation-only public withdrawal numbers.
-- UUID request ids remain the immutable financial/idempotency identity.
CREATE SEQUENCE IF NOT EXISTS bot_core.withdraw_display_seq START WITH 1 INCREMENT BY 1 NO CYCLE;

-- Adding the volatile nextval() default fills existing rows during ALTER TABLE
-- without changing any financial identity field through application code.
ALTER TABLE bot_core.withdraw_requests
    ADD COLUMN IF NOT EXISTS display_no BIGINT DEFAULT nextval('bot_core.withdraw_display_seq');

ALTER TABLE bot_core.withdraw_requests
    ALTER COLUMN display_no SET DEFAULT nextval('bot_core.withdraw_display_seq');

-- Recovery only for a partially-applied migration. The normal first application
-- never enters this block. Migrations execute before polling/workers start.
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM bot_core.withdraw_requests WHERE display_no IS NULL) THEN
        ALTER TABLE bot_core.withdraw_requests DISABLE TRIGGER withdraw_identity_guard;
        UPDATE bot_core.withdraw_requests
        SET display_no = nextval('bot_core.withdraw_display_seq')
        WHERE display_no IS NULL;
        ALTER TABLE bot_core.withdraw_requests ENABLE TRIGGER withdraw_identity_guard;
    END IF;
END $$;

DO $$
DECLARE
    max_no BIGINT;
BEGIN
    SELECT MAX(display_no) INTO max_no FROM bot_core.withdraw_requests;
    IF max_no IS NULL THEN
        PERFORM setval('bot_core.withdraw_display_seq', 1, false);
    ELSE
        PERFORM setval('bot_core.withdraw_display_seq', max_no, true);
    END IF;
END $$;

ALTER TABLE bot_core.withdraw_requests
    ALTER COLUMN display_no SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ux_withdraw_display_no
    ON bot_core.withdraw_requests(display_no);

-- Public number is identity metadata too: it may never be rewritten after creation.
CREATE OR REPLACE FUNCTION bot_core.guard_withdraw_identity_update()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.id<>OLD.id OR NEW.display_no<>OLD.display_no OR NEW.telegram_id<>OLD.telegram_id OR NEW.method<>OLD.method
       OR NEW.amount_wallet<>OLD.amount_wallet OR NEW.fee_pct<>OLD.fee_pct OR NEW.fee_wallet<>OLD.fee_wallet
       OR NEW.net_wallet<>OLD.net_wallet OR NEW.payout_amount<>OLD.payout_amount
       OR NEW.payout_currency<>OLD.payout_currency OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate
       OR NEW.receiver<>OLD.receiver OR NEW.receiver_name IS DISTINCT FROM OLD.receiver_name
       OR NEW.network IS DISTINCT FROM OLD.network OR NEW.wallet_hold_id<>OLD.wallet_hold_id
       OR NEW.created_at<>OLD.created_at THEN
        RAISE EXCEPTION 'withdraw financial identity is immutable';
    END IF;
    IF OLD.status IN ('success','rejected','cancelled') THEN
        RAISE EXCEPTION 'terminal withdrawal cannot be changed';
    END IF;
    RETURN NEW;
END;
$$;

-- This release intentionally re-enables Matches Today once on upgrade.  Later
-- admin UI changes still win normally because this migration is applied once.
INSERT INTO bot_core.runtime_settings(key,value,updated_by)
VALUES('ui.button_visible.home_matches','true'::jsonb,NULL)
ON CONFLICT(key) DO UPDATE
SET value='true'::jsonb, updated_by=NULL, updated_at=NOW();
