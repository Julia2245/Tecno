-- Admin user-management metadata.  Financial balance changes continue to flow
-- exclusively through the immutable wallet ledger; this migration creates no
-- alternate balance column or financial write path.

ALTER TABLE bot_core.users
    ADD COLUMN IF NOT EXISTS last_active_at TIMESTAMPTZ;
ALTER TABLE bot_core.users
    ADD COLUMN IF NOT EXISTS blocked_at TIMESTAMPTZ;
ALTER TABLE bot_core.users
    ADD COLUMN IF NOT EXISTS blocked_by BIGINT;

UPDATE bot_core.users
SET last_active_at = COALESCE(last_active_at, updated_at, created_at)
WHERE last_active_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_users_last_active_at
    ON bot_core.users(last_active_at DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_users_blocked
    ON bot_core.users(blocked_at DESC NULLS LAST)
    WHERE is_blocked;

CREATE TABLE IF NOT EXISTS bot_core.admin_user_actions (
    id BIGSERIAL PRIMARY KEY,
    actor_telegram_id BIGINT NOT NULL,
    target_telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    action TEXT NOT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT admin_user_actions_actor_positive CHECK (actor_telegram_id > 0),
    CONSTRAINT admin_user_actions_target_positive CHECK (target_telegram_id > 0),
    CONSTRAINT admin_user_actions_action_format CHECK (action ~ '^[a-z][a-z0-9_]{2,47}$')
);
CREATE INDEX IF NOT EXISTS idx_admin_user_actions_target
    ON bot_core.admin_user_actions(target_telegram_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_user_actions_actor
    ON bot_core.admin_user_actions(actor_telegram_id, created_at DESC);

CREATE OR REPLACE FUNCTION bot_core.reject_admin_user_action_change()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'admin user action audit rows are immutable';
END;
$$;
DROP TRIGGER IF EXISTS admin_user_actions_immutable ON bot_core.admin_user_actions;
CREATE TRIGGER admin_user_actions_immutable
BEFORE UPDATE OR DELETE ON bot_core.admin_user_actions
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_admin_user_action_change();
