-- Batch 2: reporting indexes only. Runtime UI customization uses the existing
-- bot_core.runtime_settings table so no user-facing financial rows are rewritten.

CREATE INDEX IF NOT EXISTS idx_deposit_success_settled_report
    ON bot_core.deposit_requests(settled_at, method)
    WHERE status='success';

CREATE INDEX IF NOT EXISTS idx_withdraw_success_finished_report
    ON bot_core.withdraw_requests(finished_at, method)
    WHERE status='success';

CREATE INDEX IF NOT EXISTS idx_ichancy_success_finished_report
    ON bot_core.ichancy_jobs(finished_at, operation_type)
    WHERE status='success';

CREATE INDEX IF NOT EXISTS idx_users_last_active_report
    ON bot_core.users(last_active_at DESC)
    WHERE NOT is_bot;

CREATE INDEX IF NOT EXISTS idx_referral_cycle_paid_report
    ON bot_core.referral_cycle_payouts(paid_at)
    WHERE status='paid';

CREATE INDEX IF NOT EXISTS idx_cashback_paid_report
    ON bot_core.cashback_cycle_users(paid_at)
    WHERE status='paid';
