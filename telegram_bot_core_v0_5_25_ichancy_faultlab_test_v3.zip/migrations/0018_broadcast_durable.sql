-- Durable admin broadcast campaigns.  Financial tables are intentionally not touched.

CREATE TABLE IF NOT EXISTS bot_core.broadcast_campaigns (
    id UUID PRIMARY KEY,
    created_by BIGINT NOT NULL,
    source_chat_id BIGINT NOT NULL,
    source_message_id BIGINT NOT NULL,
    content_type TEXT NOT NULL DEFAULT 'message',
    preview_text TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft',
    total_recipients INTEGER NOT NULL DEFAULT 0,
    sent_count INTEGER NOT NULL DEFAULT 0,
    failed_count INTEGER NOT NULL DEFAULT 0,
    blocked_count INTEGER NOT NULL DEFAULT 0,
    unknown_count INTEGER NOT NULL DEFAULT 0,
    stop_requested BOOLEAN NOT NULL DEFAULT FALSE,
    per_minute INTEGER NOT NULL DEFAULT 700,
    concurrency INTEGER NOT NULL DEFAULT 8,
    admin_chat_id BIGINT,
    admin_status_message_id BIGINT,
    last_error TEXT,
    delete_status TEXT NOT NULL DEFAULT 'none',
    delete_total INTEGER NOT NULL DEFAULT 0,
    deleted_count INTEGER NOT NULL DEFAULT 0,
    delete_failed_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    queued_at TIMESTAMPTZ,
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    delete_started_at TIMESTAMPTZ,
    delete_finished_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT broadcast_campaign_status CHECK (
        status IN ('draft','queued','running','stopping','stopped','completed','failed','cancelled')
    ),
    CONSTRAINT broadcast_delete_status CHECK (
        delete_status IN ('none','queued','deleting','completed','failed')
    ),
    CONSTRAINT broadcast_rate_bounds CHECK (per_minute BETWEEN 5 AND 5000),
    CONSTRAINT broadcast_concurrency_bounds CHECK (concurrency BETWEEN 1 AND 32),
    CONSTRAINT broadcast_counts_nonnegative CHECK (
        total_recipients >= 0 AND sent_count >= 0 AND failed_count >= 0
        AND blocked_count >= 0 AND unknown_count >= 0 AND delete_total >= 0
        AND deleted_count >= 0 AND delete_failed_count >= 0
    )
);

CREATE INDEX IF NOT EXISTS idx_broadcast_campaigns_created
    ON bot_core.broadcast_campaigns(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_broadcast_campaigns_send_queue
    ON bot_core.broadcast_campaigns(status, queued_at, created_at)
    WHERE status IN ('queued','running','stopping');
CREATE INDEX IF NOT EXISTS idx_broadcast_campaigns_delete_queue
    ON bot_core.broadcast_campaigns(delete_status, updated_at)
    WHERE delete_status IN ('queued','deleting');

CREATE TABLE IF NOT EXISTS bot_core.broadcast_recipients (
    campaign_id UUID NOT NULL REFERENCES bot_core.broadcast_campaigns(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    send_status TEXT NOT NULL DEFAULT 'pending',
    message_id BIGINT,
    send_attempts SMALLINT NOT NULL DEFAULT 0,
    send_error TEXT,
    send_started_at TIMESTAMPTZ,
    sent_at TIMESTAMPTZ,
    delete_status TEXT NOT NULL DEFAULT 'none',
    delete_attempts SMALLINT NOT NULL DEFAULT 0,
    delete_error TEXT,
    deleted_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY(campaign_id, telegram_id),
    CONSTRAINT broadcast_recipient_send_status CHECK (
        send_status IN ('pending','sending','sent','blocked','failed','unknown')
    ),
    CONSTRAINT broadcast_recipient_delete_status CHECK (
        delete_status IN ('none','pending','deleting','deleted','failed')
    ),
    CONSTRAINT broadcast_recipient_attempts_nonnegative CHECK (
        send_attempts >= 0 AND delete_attempts >= 0
    )
);

CREATE INDEX IF NOT EXISTS idx_broadcast_recipients_send
    ON bot_core.broadcast_recipients(campaign_id, send_status, telegram_id);
CREATE INDEX IF NOT EXISTS idx_broadcast_recipients_delete
    ON bot_core.broadcast_recipients(campaign_id, delete_status, telegram_id);
