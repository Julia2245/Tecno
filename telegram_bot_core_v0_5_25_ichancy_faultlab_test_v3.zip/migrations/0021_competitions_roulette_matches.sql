BEGIN;

-- Batch 6: contests, match predictions, daily football cache and roulette.
-- Financial writes remain routed through WalletService / FinanceRules / iChancy jobs.

CREATE TABLE IF NOT EXISTS bot_core.promo_rewards (
    id BIGSERIAL PRIMARY KEY,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    source_type TEXT NOT NULL CHECK (source_type IN ('contest','roulette')),
    source_ref TEXT NOT NULL,
    amount_syp BIGINT NOT NULL CHECK (amount_syp > 0),
    remaining_syp BIGINT NOT NULL CHECK (remaining_syp >= 0 AND remaining_syp <= amount_syp),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','used','expired')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    used_at TIMESTAMPTZ,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    UNIQUE(telegram_id,source_type,source_ref)
);
CREATE INDEX IF NOT EXISTS idx_promo_rewards_user_active
    ON bot_core.promo_rewards(telegram_id,status,expires_at,id)
    WHERE remaining_syp > 0;

CREATE TABLE IF NOT EXISTS bot_core.promo_reward_spends (
    id BIGSERIAL PRIMARY KEY,
    reward_id BIGINT NOT NULL REFERENCES bot_core.promo_rewards(id) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    amount_syp BIGINT NOT NULL CHECK (amount_syp > 0),
    ichancy_job_id UUID NOT NULL REFERENCES bot_core.ichancy_jobs(id) ON DELETE RESTRICT,
    status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','consumed','released')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at TIMESTAMPTZ,
    UNIQUE(ichancy_job_id)
);
CREATE INDEX IF NOT EXISTS idx_promo_spends_reward ON bot_core.promo_reward_spends(reward_id,created_at);

ALTER TABLE bot_core.ichancy_jobs ADD COLUMN IF NOT EXISTS wallet_amount_syp BIGINT;
ALTER TABLE bot_core.ichancy_jobs ADD COLUMN IF NOT EXISTS promo_reward_id BIGINT REFERENCES bot_core.promo_rewards(id) ON DELETE RESTRICT;
ALTER TABLE bot_core.ichancy_jobs ADD COLUMN IF NOT EXISTS promo_amount_syp BIGINT NOT NULL DEFAULT 0;
UPDATE bot_core.ichancy_jobs SET wallet_amount_syp=amount WHERE wallet_amount_syp IS NULL;
ALTER TABLE bot_core.ichancy_jobs ALTER COLUMN wallet_amount_syp SET NOT NULL;
ALTER TABLE bot_core.ichancy_jobs DROP CONSTRAINT IF EXISTS ichancy_job_deposit_hold;
ALTER TABLE bot_core.ichancy_jobs DROP CONSTRAINT IF EXISTS ichancy_job_wallet_promo_sum;
ALTER TABLE bot_core.ichancy_jobs ADD CONSTRAINT ichancy_job_wallet_promo_sum CHECK (
    operation_type <> 'deposit'
    OR (
        wallet_amount_syp >= 0 AND promo_amount_syp >= 0
        AND wallet_amount_syp + promo_amount_syp = amount
        AND (wallet_amount_syp = 0 OR wallet_hold_id IS NOT NULL)
        AND (promo_amount_syp = 0 OR promo_reward_id IS NOT NULL)
    )
);

CREATE TABLE IF NOT EXISTS bot_core.contests (
    id BIGSERIAL PRIMARY KEY,
    template_type TEXT NOT NULL CHECK (template_type IN ('match_prediction','cash_luck','top_depositors','deposit_raffle')),
    prediction_type TEXT CHECK (prediction_type IS NULL OR prediction_type IN ('score','corners','cards')),
    team1_name TEXT,
    team2_name TEXT,
    suffixes JSONB NOT NULL DEFAULT '[]'::jsonb,
    raffle_entry_mode TEXT NOT NULL DEFAULT 'user_once' CHECK (raffle_entry_mode IN ('user_once','per_deposit')),
    prize_type TEXT NOT NULL CHECK (prize_type IN ('balance','deposit_bonus')),
    prize_value NUMERIC(18,4) NOT NULL CHECK (prize_value > 0),
    winners_count INTEGER NOT NULL DEFAULT 1 CHECK (winners_count BETWEEN 1 AND 100),
    media_type TEXT CHECK (media_type IS NULL OR media_type IN ('photo','animation','video')),
    media_file_id TEXT,
    publish_to_channel BOOLEAN NOT NULL DEFAULT FALSE,
    start_at TIMESTAMPTZ NOT NULL,
    end_at TIMESTAMPTZ NOT NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','waiting_result','ready_for_draw','completed','cancelled')),
    result_value1 INTEGER,
    result_value2 INTEGER,
    result_set_by BIGINT,
    result_set_at TIMESTAMPTZ,
    snapshot_at TIMESTAMPTZ,
    draw_at TIMESTAMPTZ,
    draw_by BIGINT,
    completed_at TIMESTAMPTZ,
    cancelled_at TIMESTAMPTZ,
    cancelled_by BIGINT,
    created_by BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    channel_chat_ref TEXT,
    channel_message_id BIGINT,
    channel_media_type TEXT,
    result_message_id BIGINT,
    last_channel_sync_at TIMESTAMPTZ,
    admin_notified_at TIMESTAMPTZ,
    CHECK (end_at > start_at)
);
CREATE INDEX IF NOT EXISTS idx_contests_status_end ON bot_core.contests(status,end_at,id);

CREATE TABLE IF NOT EXISTS bot_core.competition_deposit_effects (
    deposit_id UUID PRIMARY KEY REFERENCES bot_core.deposit_requests(id) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    provider_tx TEXT,
    base_amount_syp BIGINT NOT NULL CHECK (base_amount_syp >= 0),
    settled_at TIMESTAMPTZ NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','settled','failed')),
    attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    last_error TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_competition_effects_retry
    ON bot_core.competition_deposit_effects(status,updated_at,deposit_id)
    WHERE status IN ('pending','failed');

CREATE TABLE IF NOT EXISTS bot_core.contest_entries (
    id BIGSERIAL PRIMARY KEY,
    contest_id BIGINT NOT NULL REFERENCES bot_core.contests(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    entry_kind TEXT NOT NULL CHECK (entry_kind IN ('prediction','cash_luck','top_deposit','deposit_raffle')),
    value1 INTEGER,
    value2 INTEGER,
    provider_tx TEXT,
    deposit_id UUID REFERENCES bot_core.deposit_requests(id) ON DELETE RESTRICT,
    dedupe_key TEXT NOT NULL,
    base_amount_syp BIGINT NOT NULL DEFAULT 0 CHECK (base_amount_syp >= 0),
    eligible BOOLEAN NOT NULL DEFAULT TRUE,
    weight INTEGER NOT NULL DEFAULT 1 CHECK (weight >= 1),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    confirmed_at TIMESTAMPTZ,
    UNIQUE(contest_id,dedupe_key)
);
CREATE INDEX IF NOT EXISTS idx_contest_entries_user ON bot_core.contest_entries(contest_id,telegram_id,id);
CREATE INDEX IF NOT EXISTS idx_contest_entries_rank ON bot_core.contest_entries(contest_id,entry_kind,eligible,base_amount_syp DESC);

CREATE TABLE IF NOT EXISTS bot_core.contest_awards (
    id BIGSERIAL PRIMARY KEY,
    contest_id BIGINT NOT NULL REFERENCES bot_core.contests(id) ON DELETE RESTRICT,
    entry_id BIGINT NOT NULL REFERENCES bot_core.contest_entries(id) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    position INTEGER NOT NULL CHECK (position >= 1),
    prize_type TEXT NOT NULL CHECK (prize_type IN ('balance','deposit_bonus')),
    prize_value NUMERIC(18,4) NOT NULL CHECK (prize_value > 0),
    promo_reward_id BIGINT REFERENCES bot_core.promo_rewards(id) ON DELETE RESTRICT,
    bonus_reward_id BIGINT,
    selected_mode TEXT NOT NULL DEFAULT 'auto' CHECK (selected_mode IN ('auto','manual')),
    selected_by BIGINT,
    awarded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    notified_at TIMESTAMPTZ,
    UNIQUE(contest_id,position),
    UNIQUE(contest_id,entry_id)
);

CREATE TABLE IF NOT EXISTS bot_core.contest_bonus_rewards (
    id BIGSERIAL PRIMARY KEY,
    contest_id BIGINT NOT NULL REFERENCES bot_core.contests(id) ON DELETE RESTRICT,
    award_id BIGINT NOT NULL UNIQUE REFERENCES bot_core.contest_awards(id) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    pct NUMERIC(9,4) NOT NULL CHECK (pct > 0 AND pct <= 100),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','consumed','expired')),
    awarded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    consumed_at TIMESTAMPTZ,
    deposit_id UUID REFERENCES bot_core.deposit_requests(id) ON DELETE RESTRICT,
    base_amount_syp BIGINT NOT NULL DEFAULT 0,
    bonus_syp BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_contest_bonus_active ON bot_core.contest_bonus_rewards(telegram_id,status,expires_at,id);

CREATE TABLE IF NOT EXISTS bot_core.roulettes (
    id BIGSERIAL PRIMARY KEY,
    bot_name_snapshot TEXT NOT NULL DEFAULT '',
    participation_mode TEXT NOT NULL CHECK (participation_mode IN ('free','deposit')),
    min_deposit_syp BIGINT NOT NULL DEFAULT 0 CHECK (min_deposit_syp >= 0),
    max_chances_per_user INTEGER NOT NULL DEFAULT 0 CHECK (max_chances_per_user >= 0),
    winners_count INTEGER NOT NULL CHECK (winners_count BETWEEN 1 AND 100),
    max_participants INTEGER NOT NULL DEFAULT 0 CHECK (max_participants >= 0),
    auto_draw BOOLEAN NOT NULL DEFAULT FALSE,
    media_type TEXT CHECK (media_type IS NULL OR media_type IN ('photo','animation','video')),
    media_file_id TEXT,
    start_at TIMESTAMPTZ NOT NULL,
    end_at TIMESTAMPTZ NOT NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','ready_for_draw','completed','cancelled')),
    snapshot_at TIMESTAMPTZ,
    draw_at TIMESTAMPTZ,
    draw_by BIGINT,
    completed_at TIMESTAMPTZ,
    cancelled_at TIMESTAMPTZ,
    cancelled_by BIGINT,
    created_by BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    channel_chat_ref TEXT,
    channel_message_id BIGINT,
    channel_media_type TEXT,
    result_message_id BIGINT,
    last_channel_sync_at TIMESTAMPTZ,
    admin_notified_at TIMESTAMPTZ,
    CHECK (end_at > start_at),
    CHECK (max_participants = 0 OR max_participants >= winners_count)
);
CREATE INDEX IF NOT EXISTS idx_roulettes_status_end ON bot_core.roulettes(status,end_at,id);

CREATE TABLE IF NOT EXISTS bot_core.roulette_prizes (
    id BIGSERIAL PRIMARY KEY,
    roulette_id BIGINT NOT NULL REFERENCES bot_core.roulettes(id) ON DELETE CASCADE,
    position INTEGER NOT NULL CHECK (position >= 1),
    prize_type TEXT NOT NULL CHECK (prize_type IN ('balance','deposit_bonus','custom')),
    prize_value NUMERIC(18,4) NOT NULL DEFAULT 0,
    custom_text TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(roulette_id,position),
    CHECK ((prize_type='custom' AND COALESCE(length(custom_text),0)>0) OR (prize_type<>'custom' AND prize_value>0))
);

CREATE TABLE IF NOT EXISTS bot_core.roulette_entries (
    id BIGSERIAL PRIMARY KEY,
    roulette_id BIGINT NOT NULL REFERENCES bot_core.roulettes(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    entry_kind TEXT NOT NULL CHECK (entry_kind IN ('free','deposit')),
    deposit_id UUID REFERENCES bot_core.deposit_requests(id) ON DELETE RESTRICT,
    dedupe_key TEXT NOT NULL,
    base_amount_syp BIGINT NOT NULL DEFAULT 0 CHECK (base_amount_syp >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(roulette_id,dedupe_key)
);
CREATE INDEX IF NOT EXISTS idx_roulette_entries_user ON bot_core.roulette_entries(roulette_id,telegram_id,id);

CREATE TABLE IF NOT EXISTS bot_core.roulette_awards (
    id BIGSERIAL PRIMARY KEY,
    roulette_id BIGINT NOT NULL REFERENCES bot_core.roulettes(id) ON DELETE RESTRICT,
    position INTEGER NOT NULL CHECK (position >= 1),
    entry_id BIGINT REFERENCES bot_core.roulette_entries(id) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    prize_type TEXT NOT NULL CHECK (prize_type IN ('balance','deposit_bonus','custom')),
    prize_value NUMERIC(18,4) NOT NULL DEFAULT 0,
    custom_text TEXT,
    promo_reward_id BIGINT REFERENCES bot_core.promo_rewards(id) ON DELETE RESTRICT,
    bonus_reward_id BIGINT,
    fulfillment_status TEXT NOT NULL DEFAULT 'completed' CHECK (fulfillment_status IN ('completed','pending')),
    selected_mode TEXT NOT NULL DEFAULT 'auto' CHECK (selected_mode IN ('auto','manual')),
    awarded_by BIGINT,
    awarded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    notified_at TIMESTAMPTZ,
    UNIQUE(roulette_id,position),
    UNIQUE(roulette_id,telegram_id)
);

CREATE TABLE IF NOT EXISTS bot_core.roulette_bonus_rewards (
    id BIGSERIAL PRIMARY KEY,
    roulette_id BIGINT NOT NULL REFERENCES bot_core.roulettes(id) ON DELETE RESTRICT,
    award_id BIGINT NOT NULL UNIQUE REFERENCES bot_core.roulette_awards(id) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    pct NUMERIC(9,4) NOT NULL CHECK (pct > 0 AND pct <= 100),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','consumed','expired')),
    awarded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    consumed_at TIMESTAMPTZ,
    deposit_id UUID REFERENCES bot_core.deposit_requests(id) ON DELETE RESTRICT,
    base_amount_syp BIGINT NOT NULL DEFAULT 0,
    bonus_syp BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_roulette_bonus_active ON bot_core.roulette_bonus_rewards(telegram_id,status,expires_at,id);

-- Deep-link intent must survive required-channel and terms gates.
ALTER TABLE bot_core.users DROP CONSTRAINT IF EXISTS users_pending_start_action_check;
ALTER TABLE bot_core.users ADD CONSTRAINT users_pending_start_action_check CHECK (
    pending_start_action IS NULL
    OR pending_start_action='claim_wheel'
    OR pending_start_action ~ '^(contest|roulette|roulette_result):[1-9][0-9]{0,18}$'
);

-- Selection evidence cannot be deleted; operational notification/fulfillment fields remain updateable.
CREATE OR REPLACE FUNCTION bot_core.block_batch6_history_mutation() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'batch6 history is append-only';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS contest_awards_immutable ON bot_core.contest_awards;
CREATE TRIGGER contest_awards_immutable BEFORE DELETE ON bot_core.contest_awards
FOR EACH ROW EXECUTE FUNCTION bot_core.block_batch6_history_mutation();
DROP TRIGGER IF EXISTS roulette_awards_immutable ON bot_core.roulette_awards;
CREATE TRIGGER roulette_awards_immutable BEFORE DELETE ON bot_core.roulette_awards
FOR EACH ROW EXECUTE FUNCTION bot_core.block_batch6_history_mutation();
DROP TRIGGER IF EXISTS promo_reward_spends_immutable_delete ON bot_core.promo_reward_spends;
CREATE OR REPLACE FUNCTION bot_core.block_promo_spend_delete() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'promo reward spend history cannot be deleted';
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER promo_reward_spends_immutable_delete BEFORE DELETE ON bot_core.promo_reward_spends
FOR EACH ROW EXECUTE FUNCTION bot_core.block_promo_spend_delete();

COMMIT;
