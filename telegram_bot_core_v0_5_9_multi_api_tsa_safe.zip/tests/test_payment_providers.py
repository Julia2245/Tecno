from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest

from app.providers.payment import PaymentProviderManager
from app.providers.tsa import TsaApiClient

ROOT = Path(__file__).resolve().parents[1]


class FakeRuntime:
    def __init__(self, values=None):
        self.values = dict(values or {})

    def get(self, key, default=None):
        return self.values.get(key, default)

    async def set(self, key, value, *, updated_by):
        self.values[key] = value


class FakeProvider:
    def __init__(self, provider_id, label, configured=True):
        self.provider_id = provider_id
        self.provider_label = label
        self.configured = configured

    async def healthcheck(self):
        return {"success": True}


@pytest.mark.asyncio
async def test_provider_manager_uses_one_persisted_active_provider():
    runtime = FakeRuntime()
    syria = FakeProvider("api_syria", "API SYRIA")
    tsa = FakeProvider("tsa", "TSA API")
    manager = PaymentProviderManager(runtime, providers=[syria, tsa])
    assert manager.active() is syria
    await manager.set_active("tsa", updated_by=1)
    assert manager.active() is tsa
    assert runtime.values["payments.api_provider"] == "tsa"


@pytest.mark.asyncio
async def test_provider_manager_refuses_unconfigured_provider():
    runtime = FakeRuntime()
    syria = FakeProvider("api_syria", "API SYRIA")
    tsa = FakeProvider("tsa", "TSA API", configured=False)
    manager = PaymentProviderManager(runtime, providers=[syria, tsa])
    with pytest.raises(ValueError):
        await manager.set_active("tsa", updated_by=1)
    assert manager.active() is syria


@pytest.mark.asyncio
async def test_tsa_syriatel_find_accepts_only_successful_incoming(monkeypatch):
    client = object.__new__(TsaApiClient)

    async def fake_gsm(value):
        return "09330000001"

    async def incoming(**kwargs):
        return {"transaction": {"amount": "5000", "status": "1", "history_type": "incoming", "date": "2026-10-10 01:02:03"}}

    monkeypatch.setattr(client, "_syriatel_gsm", fake_gsm)
    monkeypatch.setattr(client, "_find", incoming)
    tx = await client.find_syriatel("600100002", "07184562")
    assert tx is not None
    assert tx.amount == Decimal("5000")
    assert tx.destination == "09330000001"

    async def outgoing(**kwargs):
        return {"transaction": {"amount": "5000", "status": "1", "history_type": "outgoing", "date": "2026-10-10 01:02:03"}}

    monkeypatch.setattr(client, "_find", outgoing)
    assert await client.find_syriatel("600100002", "07184562") is None

    async def failed(**kwargs):
        return {"transaction": {"amount": "5000", "status": "0", "history_type": "incoming", "date": "2026-10-10 01:02:03"}}

    monkeypatch.setattr(client, "_find", failed)
    assert await client.find_syriatel("600100002", "07184562") is None


def test_finance_ui_contains_provider_switch_and_independent_usd_rates():
    source = open("app/routers/admin_finance.py", encoding="utf-8").read()
    for token in (
        "admin:finance:api_provider",
        "admin:api_provider:set:",
        "api_syria|tsa",
        "deposit.sham_usd.rate",
        "deposit.whish_money.rate",
        "deposit.binance_trc20.rate",
        "deposit.binance_bep20.rate",
    ):
        assert token in source


def test_start_is_guarded_while_deposit_verification_is_in_progress():
    source = open("app/routers/start.py", encoding="utf-8").read()
    assert source.count("verification_in_progress") >= 3
    assert "لديك عملية شحن قيد التحقق حالياً" in source


def test_no_financial_provider_fallback_is_implemented():
    manager = open("app/providers/payment.py", encoding="utf-8").read()
    withdrawals = open("app/services/withdrawals.py", encoding="utf-8").read()
    assert "fallback" not in manager.lower()
    assert "provider = self.active_provider()" in withdrawals
    assert "provider.transfer_syriatel" in withdrawals
    assert "provider.transfer_shamcash" in withdrawals


def test_provider_identity_is_persisted_before_financial_posts() -> None:
    withdraw_repo = (ROOT / "app/repositories/withdrawals.py").read_text()
    manual_repo = (ROOT / "app/repositories/manual_transfers.py").read_text()
    withdrawals = (ROOT / "app/services/withdrawals.py").read_text()
    manual = (ROOT / "app/services/manual_transfers.py").read_text()

    assert "jsonb_build_object('_api_provider',$3::text)" in withdraw_repo
    assert "provider_id=provider_id" in withdrawals
    assert "set_processing_source" in withdraw_repo
    assert "set_processing_source" in withdrawals
    assert '"_api_provider": str(provider_id or "").strip()' in manual_repo
    assert "provider_id=provider_id" in manual


def test_tsa_financial_post_has_no_retry_loop() -> None:
    tsa = (ROOT / "app/providers/tsa.py").read_text()
    start = tsa.index("async def _financial_post_tsa")
    body = tsa[start:]
    assert "Exactly one financial POST" in body
    assert "for attempt" not in body
    assert "while True" not in body
