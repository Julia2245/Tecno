from __future__ import annotations

from functools import lru_cache
from decimal import Decimal
from typing import FrozenSet

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.core.syriatel import parse_syriatel_cash_codes


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    bot_token: str = Field(alias="BOT_TOKEN")
    bot_display_name: str = Field(default="", alias="BOT_DISPLAY_NAME")
    super_admins: str = Field(default="", alias="SUPER_ADMINS")
    drop_pending_updates: bool = Field(default=False, alias="DROP_PENDING_UPDATES")

    database_url: str = Field(alias="DATABASE_URL")
    pg_pool_min: int = Field(default=2, ge=1, le=100, alias="PG_POOL_MIN")
    pg_pool_max: int = Field(default=20, ge=1, le=200, alias="PG_POOL_MAX")
    pg_command_timeout: float = Field(default=15.0, gt=0, le=120, alias="PG_COMMAND_TIMEOUT")
    telegram_connection_limit: int = Field(default=100, ge=8, le=500, alias="TELEGRAM_CONNECTION_LIMIT")
    max_concurrent_updates: int = Field(default=64, ge=1, le=1000, alias="MAX_CONCURRENT_UPDATES")

    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    slow_update_warning_ms: float = Field(default=250.0, ge=1, alias="SLOW_UPDATE_WARNING_MS")

    # Bot-wallet deposit providers. These are per-deployment values; no bot brand
    # or merchant secret is hardcoded in the reusable project.
    api_syria_base_url: str = Field(default="https://apisyria.com/api/v1", alias="API_SYRIA_BASE_URL")
    api_syria_key: str = Field(default="", alias="API_SYRIA_KEY")
    tsa_api_base_url: str = Field(default="https://tsa-api.com/api/v1", alias="TSA_API_BASE_URL")
    tsa_api_key: str = Field(default="", alias="TSA_API_KEY")
    payment_api_provider: str = Field(default="api_syria", alias="PAYMENT_API_PROVIDER")

    syriatel_charge_mode: str = Field(default="off", alias="SYRIATEL_CHARGE_MODE")
    syriatel_cash_codes: str = Field(default="", alias="SYRIATEL_CASH_CODES")
    syriatel_cash_pin_code: str = Field(default="", alias="SYRIATEL_CASH_PIN_CODE")
    min_deposit_syp: Decimal = Field(default=Decimal("1000"), gt=0, alias="MIN_DEPOSIT_SYP")
    rate_syriatel_syp_to_wallet: Decimal = Field(default=Decimal("100"), gt=0, alias="RATE_SYRIATEL_SYP_TO_WALLET")
    bonus_syriatel_pct: Decimal = Field(default=Decimal("0"), ge=0, le=100, alias="BONUS_SYRIATEL_PCT")

    sham_charge_mode: str = Field(default="off", alias="SHAM_CHARGE_MODE")
    shamcash_address_syp: str = Field(default="", alias="SHAMCASH_ADDRESS_SYP")
    shamcash_address_usd: str = Field(default="", alias="SHAMCASH_ADDRESS_USD")
    rate_sham_syp_to_wallet: Decimal = Field(default=Decimal("100"), gt=0, alias="RATE_SHAM_SYP_TO_WALLET")
    rate_sham_usd_to_wallet: Decimal = Field(default=Decimal("11500"), gt=0, alias="RATE_SHAM_USD_TO_WALLET")
    min_sham_usd_deposit: Decimal = Field(default=Decimal("1"), gt=0, alias="MIN_SHAM_USD_DEPOSIT")
    bonus_sham_syp_pct: Decimal = Field(default=Decimal("0"), ge=0, le=100, alias="BONUS_SHAM_SYP_PCT")
    bonus_sham_usd_pct: Decimal = Field(default=Decimal("0"), ge=0, le=100, alias="BONUS_SHAM_USD_PCT")

    whish_money_enabled: bool = Field(default=False, alias="WHISH_MONEY_ENABLED")
    whish_money_number: str = Field(default="", alias="WHISH_MONEY_NUMBER")
    rate_whish_usd_to_wallet: Decimal = Field(default=Decimal("11500"), gt=0, alias="RATE_WHISH_USD_TO_WALLET")
    min_whish_usd_deposit: Decimal = Field(default=Decimal("1"), gt=0, alias="MIN_WHISH_USD_DEPOSIT")
    bonus_whish_money_pct: Decimal = Field(default=Decimal("0"), ge=0, le=100, alias="BONUS_WHISH_MONEY_PCT")

    binance_deposit_enabled: bool = Field(default=False, alias="BINANCE_DEPOSIT_ENABLED")
    binance_api_key: str = Field(default="", alias="BINANCE_API_KEY")
    binance_api_secret: str = Field(default="", alias="BINANCE_API_SECRET")
    binance_base_url: str = Field(default="https://api.binance.com", alias="BINANCE_BASE_URL")
    binance_trc20_address: str = Field(default="", alias="BINANCE_TRC20_ADDRESS")
    binance_bep20_address: str = Field(default="", alias="BINANCE_BEP20_ADDRESS")
    binance_trc20_network: str = Field(default="TRX", alias="BINANCE_TRC20_NETWORK")
    binance_bep20_network: str = Field(default="BSC", alias="BINANCE_BEP20_NETWORK")
    rate_binance_usdt_to_wallet: Decimal = Field(default=Decimal("11500"), gt=0, alias="RATE_BINANCE_USDT_TO_WALLET")
    min_binance_usdt_deposit: Decimal = Field(default=Decimal("1"), gt=0, alias="MIN_BINANCE_USDT_DEPOSIT")
    bonus_binance_usdt_pct: Decimal = Field(default=Decimal("0"), ge=0, le=100, alias="BONUS_BINANCE_USDT_PCT")

    deposit_notify_chat_id: int | None = Field(default=None, alias="DEPOSIT_NOTIFY_CHAT_ID")
    deposit_manual_review_chat_id: int | None = Field(default=None, alias="DEPOSIT_MANUAL_REVIEW_CHAT_ID")
    auto_deposit_max_age_hours: int = Field(default=168, ge=1, le=720, alias="AUTO_DEPOSIT_MAX_AGE_HOURS")

    # iChancy configuration. The active cashier can later be replaced from the
    # admin panel; these values are only the bootstrap cashier for a fresh install.
    ichancy_base_url: str = Field(default="https://agents.ichancy.com", alias="ICHANCY_BASE_URL")
    ichancy_api_username: str = Field(default="", alias="ICHANCY_API_USERNAME")
    ichancy_api_password: str = Field(default="", alias="ICHANCY_API_PASSWORD")
    ichancy_parent_id: str = Field(default="", alias="ICHANCY_PARENT_ID")
    ichancy_currency: str = Field(default="SYP", alias="ICHANCY_CURRENCY")
    ichancy_username_prefix: str = Field(default="bot", alias="ICHANCY_USERNAME_PREFIX")
    ichancy_gateway_url: str = Field(default="", alias="ICHANCY_GATEWAY_URL")
    ichancy_gateway_secret: str = Field(default="", alias="ICHANCY_GATEWAY_SECRET")
    ichancy_credentials_key: str = Field(default="", alias="ICHANCY_CREDENTIALS_KEY")
    ichancy_website_url: str = Field(default="https://www.ichancy300.com/ar", alias="ICHANCY_WEBSITE_URL")
    ichancy_ws_url: str = Field(default="wss://eu-swarm-springre.betcoswarm.com/", alias="ICHANCY_WS_URL")
    ichancy_ws_origin: str = Field(default="https://www.ichancy.com", alias="ICHANCY_WS_ORIGIN")
    ichancy_ws_site_id: int = Field(default=18755655, ge=1, alias="ICHANCY_WS_SITE_ID")
    ichancy_ws_source: int = Field(default=42, ge=1, alias="ICHANCY_WS_SOURCE")
    ichancy_worker_poll_seconds: float = Field(default=2.0, ge=0.2, le=60, alias="ICHANCY_WORKER_POLL_SECONDS")
    ichancy_reconcile_delay_seconds: float = Field(default=8.0, ge=1, le=300, alias="ICHANCY_RECONCILE_DELAY_SECONDS")

    @field_validator("bot_token", "database_url")
    @classmethod
    def required_non_empty(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("value must not be empty")
        return value

    @field_validator("database_url")
    @classmethod
    def postgres_only(cls, value: str) -> str:
        lowered = value.lower()
        if not (lowered.startswith("postgresql://") or lowered.startswith("postgres://")):
            raise ValueError("DATABASE_URL must be a PostgreSQL URL")
        return value

    @field_validator("pg_pool_max")
    @classmethod
    def pool_bounds(cls, value: int, info):
        minimum = info.data.get("pg_pool_min")
        if minimum is not None and value < minimum:
            raise ValueError("PG_POOL_MAX must be >= PG_POOL_MIN")
        return value

    @field_validator("syriatel_charge_mode", "sham_charge_mode")
    @classmethod
    def deposit_mode(cls, value: str) -> str:
        mode = value.strip().lower()
        if mode not in {"auto", "manual", "off"}:
            raise ValueError("deposit charge mode must be auto, manual, or off")
        return mode

    @field_validator("api_syria_base_url", "tsa_api_base_url", "binance_base_url", "ichancy_base_url", "ichancy_gateway_url")
    @classmethod
    def normalize_base_url(cls, value: str) -> str:
        return value.strip().rstrip("/")


    @field_validator("payment_api_provider")
    @classmethod
    def payment_provider(cls, value: str) -> str:
        provider = value.strip().lower()
        if provider not in {"api_syria", "tsa"}:
            raise ValueError("PAYMENT_API_PROVIDER must be api_syria or tsa")
        return provider

    @property
    def syriatel_codes(self) -> tuple[str, ...]:
        return parse_syriatel_cash_codes(self.syriatel_cash_codes)

    @property
    def super_admin_ids(self) -> FrozenSet[int]:
        values: set[int] = set()
        raw = self.super_admins.replace(";", ",")
        for item in raw.split(","):
            item = item.strip()
            if not item:
                continue
            try:
                user_id = int(item)
            except ValueError as exc:
                raise ValueError(f"Invalid SUPER_ADMINS value: {item!r}") from exc
            if user_id <= 0:
                raise ValueError("SUPER_ADMINS values must be positive Telegram IDs")
            values.add(user_id)
        return frozenset(values)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
