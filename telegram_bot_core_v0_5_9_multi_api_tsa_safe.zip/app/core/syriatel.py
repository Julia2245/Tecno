from __future__ import annotations

_NUMERIC_TRANSLATION = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_QUOTE_CHARS = '"\'“”‘’«»‹›`'


def normalize_syriatel_cash_code(raw: object) -> str:
    """Return a canonical numeric Syriatel Cash code.

    Admins often paste values copied from .env snippets or messages where the
    number is wrapped in ASCII/typographic quotes.  Those quote characters must
    never reach مزود الـ API as the `gsm` parameter.
    """
    value = str(raw or "").translate(_NUMERIC_TRANSLATION).strip()
    # Repeatedly remove wrapping quotes (e.g. '"45191900"').
    previous = None
    while value and value != previous:
        previous = value
        value = value.strip().strip(_QUOTE_CHARS).strip()
    # Spaces inside a copied numeric code are harmless and can be normalized.
    value = "".join(value.split())
    return value


def parse_syriatel_cash_codes(raw: object) -> tuple[str, ...]:
    text = str(raw or "").replace("\n", ",").replace(";", ",")
    items: list[str] = []
    seen: set[str] = set()
    for part in text.split(","):
        code = normalize_syriatel_cash_code(part)
        if not code or code in seen:
            continue
        items.append(code)
        seen.add(code)
    return tuple(items)
