from __future__ import annotations

import html
from decimal import Decimal

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def fmt_decimal(value: Decimal) -> str:
    return str(int(value)) if value == value.to_integral_value() else format(value.normalize(), "f")


def fmt_dt(value) -> str:
    if value is None:
        return "—"
    try:
        return value.isoformat(sep=" ", timespec="seconds")
    except Exception:
        return str(value)


def method_label(method: str, network: str | None = None) -> str:
    labels = {
        "syriatel": "سيرياتيل كاش",
        "shamcash": "شام كاش",
        "hawala": "حوالة",
        "usdt": f"USDT {network or ''}".strip(),
    }
    return labels.get(str(method or ""), str(method or "-") or "-")


def deposit_method_label(method: str) -> str:
    return {
        "syriatel": "سيرياتيل كاش",
        "sham_syp": "شام كاش – ليرة",
        "sham_usd": "شام كاش – دولار",
        "whish_money": "Whish Money",
        "binance_trc20": "Binance USDT TRC20",
        "binance_bep20": "Binance USDT BEP20",
    }.get(str(method or ""), str(method or "-") or "-")


def status_label(status: str) -> str:
    return {
        "pending": "بانتظار التنفيذ",
        "processing": "جاري التنفيذ",
        "provider_success": "نجح لدى المزود — بانتظار التثبيت المحلي",
        "needs_review": "يحتاج مراجعة",
        "success": "تم التقبيض",
        "rejected": "مرفوض",
        "cancelled": "ملغي",
    }.get(str(status or ""), str(status or "-"))


def withdraw_card(rec, last_deposits=()) -> str:
    success = str(rec.status) == "success"
    rejected = str(rec.status) == "rejected"
    if success:
        title = "✅ <b>تم تنفيذ طلب السحب</b>"
    elif rejected:
        title = "❌ <b>تم رفض طلب السحب</b>"
    elif str(rec.status) == "needs_review":
        title = "⚠️ <b>طلب سحب يحتاج مراجعة</b>"
    else:
        title = "💸 <b>طلب سحب جديد</b>"
    lines = [
        title,
        "",
        f"🧾 رقم الطلب: <code>{rec.id}</code>",
        f"👤 المستخدم: <code>{rec.telegram_id}</code>",
        f"💳 الطريقة: <b>{html.escape(method_label(rec.method, rec.network))}</b>",
        f"💰 المبلغ المحجوز: <code>{rec.amount_wallet:,}</code>",
        f"💸 العمولة: <code>{rec.fee_wallet:,}</code> ({rec.fee_pct:g}%)",
        f"💵 الصافي: <code>{rec.net_wallet:,}</code>",
        f"📤 المبلغ المرسل: <code>{fmt_decimal(rec.payout_amount)} {html.escape(rec.payout_currency)}</code>",
    ]
    if rec.method == "shamcash" and rec.receiver_name:
        lines.append(f"👤 اسم حساب شام كاش: <b>{html.escape(rec.receiver_name)}</b>")
    receiver_label = "عنوان المحفظة" if rec.method in {"shamcash", "usdt"} else "المستلم"
    lines.extend([
        f"📍 {receiver_label}: <code>{html.escape(rec.receiver)}</code>",
        f"📌 الحالة: <b>{html.escape(status_label(rec.status))}</b>",
        f"🕐 وقت الطلب: <code>{html.escape(fmt_dt(rec.created_at))}</code>",
    ])
    if rec.finished_at:
        lines.append(f"✅ وقت التنفيذ: <code>{html.escape(fmt_dt(rec.finished_at))}</code>")
    if rec.provider_reference:
        provider = "رقم عملية شام كاش" if rec.method == "shamcash" else "رقم عملية المزود"
        lines.append(f"🔢 {provider}: <code>{html.escape(rec.provider_reference)}</code>")
    if rec.source_ref and rec.status in {"processing", "provider_success", "needs_review", "success"}:
        lines.append(f"🏦 حساب المصدر: <code>{html.escape(rec.source_ref)}</code>")
    if rec.last_error and rec.status in {"needs_review", "pending"}:
        lines.append(f"⚠️ ملاحظة إدارية: {html.escape(rec.last_error)}")

    items = list(last_deposits or ())[:3]
    lines.extend(["", "🟢 <b>آخر 3 عمليات شحن ناجحة</b>"])
    if not items:
        lines.append("لا توجد عمليات شحن ناجحة سابقة")
    else:
        for index, dep in enumerate(items, 1):
            bonus = int(dep.bonus_credit_syp or 0)
            lines.append(
                f"{index}) 💰 <b>{dep.total_credit_syp:,} SYP</b> • {deposit_method_label(dep.method)}"
                f" | 🎁 البونص: <b>{bonus:,} SYP</b>"
            )
    return "\n".join(lines)


def withdraw_actions(rec, *, include_back: bool = True) -> InlineKeyboardMarkup | None:
    rows: list[list[InlineKeyboardButton]] = []
    if rec.status == "pending":
        rows.append([
            InlineKeyboardButton(text="❌ رفض", callback_data=f"admin:withdraw:reject:{rec.id}"),
            InlineKeyboardButton(text="🛠 تنفيذ يدوي", callback_data=f"admin:withdraw:paid:{rec.id}"),
        ])
        if rec.method in {"syriatel", "shamcash"}:
            rows.append([InlineKeyboardButton(text="⚡ تنفيذ آلي", callback_data=f"admin:withdraw:auto:{rec.id}")])
    elif rec.status == "provider_success":
        rows.append([InlineKeyboardButton(text="✅ تثبيت العملية محلياً", callback_data=f"admin:withdraw:paid:{rec.id}")])
    elif rec.status == "processing":
        rows.append([InlineKeyboardButton(text="⏳ جاري التنفيذ", callback_data=f"admin:withdraw:view:{rec.id}")])
    elif rec.status == "needs_review":
        rows.append([InlineKeyboardButton(text="🔎 يحتاج تدخل الأدمن", callback_data=f"admin:withdraw:view:{rec.id}")])
        rows.append([
            InlineKeyboardButton(text="✅ تأكيد أنها تمت", callback_data=f"admin:withdraw:paid:{rec.id}"),
            InlineKeyboardButton(text="↩️ تأكيد أنها لم تتم", callback_data=f"admin:withdraw:notpaid:{rec.id}"),
        ])
    if include_back:
        rows.append([InlineKeyboardButton(text="⬅️ طلبات السحب", callback_data="admin:withdraws:pending")])
    return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None
