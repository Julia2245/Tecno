from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from uuid import UUID

from app.core.money import parse_decimal
from app.core.shamcash import normalize_shamcash_address
from app.providers.api_syria import ApiSyriaClient
from app.providers.payment import (
    PaymentProviderManager,
    ProviderFinancialDefiniteError,
    ProviderFinancialUncertain,
)
from app.repositories.manual_transfers import ManualTransferRepository
from app.services.runtime_settings import RuntimeSettingsService
from app.services.withdrawals import WithdrawService


class ManualTransferError(RuntimeError):
    pass


class ManualTransferOutcomeUncertain(ManualTransferError):
    pass


@dataclass(frozen=True, slots=True)
class ManualTransferSource:
    method: str
    source: str
    currency: str
    label: str


class ManualTransferService:
    """Admin direct transfers with durable one-POST safety."""

    def __init__(
        self,
        repository: ManualTransferRepository,
        runtime: RuntimeSettingsService,
        api_syria: ApiSyriaClient,
        withdraw_service: WithdrawService,
        payment_providers: PaymentProviderManager | None = None,
    ) -> None:
        self.repository = repository
        self.runtime = runtime
        self.api_syria = api_syria
        self.withdraw_service = withdraw_service
        self.payment_providers = payment_providers

    def active_provider(self):
        return self.payment_providers.active() if self.payment_providers is not None else self.api_syria

    def source_options(self, method: str) -> list[ManualTransferSource]:
        method = str(method or "")
        out: list[ManualTransferSource] = []
        if method == "syriatel":
            for code in self.withdraw_service.syriatel_sources():
                out.append(ManualTransferSource("syriatel", str(code), "SYP", f"سيرياتيل {code}"))
        elif method == "shamcash":
            for currency, key, label in (
                ("SYP", "deposit.sham.address_syp", "محفظة شام كاش SYP"),
                ("USD", "deposit.sham.address_usd", "محفظة شام كاش USD"),
            ):
                source = normalize_shamcash_address(self.runtime.get(key, ""))
                if source:
                    out.append(ManualTransferSource("shamcash", source, currency, label))
        return out

    def source_still_valid(self, method: str, source: str, currency: str) -> bool:
        return any(
            opt.source == str(source) and opt.currency.upper() == str(currency).upper()
            for opt in self.source_options(method)
        )

    async def source_balance(self, method: str, source: str, currency: str, provider=None) -> Decimal:
        provider = provider or self.active_provider()
        if not provider.configured:
            raise ManualTransferError(f"{getattr(provider, 'provider_label', 'API')} غير مضبوط")
        if method == "syriatel":
            _, balance = await provider.syriatel_balance(source)
            return balance
        if method == "shamcash":
            return await provider.shamcash_balance(source, currency)
        raise ManualTransferError("طريقة غير معروفة")

    async def execute(
        self,
        *,
        intent_id: UUID,
        admin_id: int,
        method: str,
        receiver: str,
        amount: Decimal,
        currency: str,
        source: str,
        source_label: str,
    ) -> dict:
        method = str(method or "")
        source = str(source or "").strip()
        receiver = str(receiver or "").strip()
        currency = str(currency or "SYP").upper()
        amount = parse_decimal(amount)
        if method not in {"shamcash", "syriatel"} or amount <= 0 or not receiver or not source:
            raise ManualTransferError("بيانات الحوالة ناقصة أو غير صالحة")
        if method == "syriatel":
            currency = "SYP"
        if not self.source_still_valid(method, source, currency):
            raise ManualTransferError("حساب الإرسال المختار لم يعد صالحاً أو تم تغييره في الإعدادات.")

        provider = self.active_provider()
        if not provider.configured:
            raise ManualTransferError(f"{getattr(provider, 'provider_label', 'API')} غير مضبوط")
        provider_id = str(getattr(provider, "provider_id", "api_syria"))
        provider_label = str(getattr(provider, "provider_label", "API SYRIA"))

        claim = await self.repository.claim_intent(
            intent_id=intent_id, admin_id=admin_id, method=method, source=source,
            receiver=receiver, amount=amount, currency=currency, provider_id=provider_id,
        )
        if claim == "success":
            existing = await self.repository.get_by_intent(intent_id)
            if existing:
                return existing
            raise ManualTransferError("الحوالة منفذة بالفعل")
        if claim == "needs_review":
            raise ManualTransferOutcomeUncertain("نتيجة هذه الحوالة غير محسومة. افحص العملية قبل أي محاولة جديدة.")
        if claim == "failed":
            raise ManualTransferError("المحاولة السابقة فشلت بشكل مؤكد. ابدأ حوالة جديدة لإعادة المحاولة.")
        if claim != "processing_new":
            raise ManualTransferOutcomeUncertain("الحوالة قيد التنفيذ بالفعل. لا تضغط تنفيذ مرة ثانية.")

        balance_before: Decimal | None = None
        try:
            balance_before = await self.source_balance(method, source, currency, provider)
        except Exception:
            pass

        linked = await provider.source_is_linked(method, source)
        if linked is False:
            err = f"حساب {'شام كاش' if method == 'shamcash' else 'سيرياتيل'} المصدر غير ظاهر ضمن الحسابات الفعالة في {provider_label}: {source}"
            await self.repository.mark_failed(intent_id, err)
            raise ManualTransferError(err)

        before_ids: set[str] = set()
        snapshot_ok = False
        if method == "shamcash":
            before_ids, snapshot_ok = await provider.shamcash_outgoing_snapshot(source)
        else:
            before_ids, snapshot_ok = await provider.syriatel_outgoing_snapshot(source)

        try:
            if method == "syriatel":
                try:
                    pin = self.withdraw_service.syriatel_pin()
                except Exception as exc:
                    raise ProviderFinancialDefiniteError(str(exc)) from exc
                if not pin:
                    raise ProviderFinancialDefiniteError("لم يتم ضبط PIN سحب سيرياتيل كاش.")
                payload = await provider.transfer_syriatel(
                    source=source, receiver=receiver, amount=amount, pin_code=pin,
                )
            else:
                # Manual Sham Cash transfer intentionally omits the optional note field.
                try:
                    sham_pin = self.withdraw_service.shamcash_pin()
                except Exception as exc:
                    raise ProviderFinancialDefiniteError(str(exc)) from exc
                payload = await provider.transfer_shamcash(
                    source=source, receiver=receiver, amount=amount, currency=currency, note=None,
                    pin=sham_pin or None,
                )
        except ProviderFinancialDefiniteError as exc:
            await self.repository.mark_failed(intent_id, str(exc))
            raise ManualTransferError(str(exc)) from exc
        except ProviderFinancialUncertain as exc:
            await self.repository.mark_uncertain(intent_id, str(exc))
            raise ManualTransferOutcomeUncertain(
                "نتيجة الحوالة غير مؤكدة. لا تعِد الإرسال؛ استخدم فحص العملية وسجل المزود أولاً."
            ) from exc
        except Exception as exc:
            await self.repository.mark_uncertain(intent_id, f"{type(exc).__name__}: {exc}")
            raise ManualTransferOutcomeUncertain(
                "تعذر حسم نتيجة الحوالة. لا تعِد الإرسال قبل التحقق من المزود."
            ) from exc

        tx_no = provider.provider_reference(payload)
        recipient_name = provider.shamcash_recipient_name(payload) if method == "shamcash" else ""
        if method == "shamcash" and snapshot_ok:
            resolved_tx, resolved_name = await provider.resolve_shamcash_outgoing_transfer(
                source=source, receiver=receiver, amount=amount, currency=currency,
                note="", api_data=payload, exclude_tx_ids=before_ids,
            )
            tx_no = resolved_tx or tx_no
            recipient_name = resolved_name or recipient_name
        elif method == "syriatel" and not tx_no and snapshot_ok:
            tx_no = await provider.resolve_syriatel_outgoing_transfer(
                source=source, receiver=receiver, amount=amount, exclude_tx_ids=before_ids,
            )

        balance_after: Decimal | None = None
        try:
            balance_after = await self.source_balance(method, source, currency, provider)
        except Exception:
            pass

        provider_payload = dict(payload or {})
        provider_payload["_api_provider"] = provider_id
        return await self.repository.finalize_success(
            intent_id=intent_id,
            admin_id=admin_id,
            method=method,
            method_label="شام كاش" if method == "shamcash" else "سيرياتيل كاش",
            source=source,
            source_label=source_label,
            receiver=receiver,
            recipient_name=recipient_name or None,
            amount=amount,
            currency=currency,
            balance_before=balance_before,
            balance_after=balance_after,
            provider_reference=tx_no or None,
            provider_payload=provider_payload,
        )
