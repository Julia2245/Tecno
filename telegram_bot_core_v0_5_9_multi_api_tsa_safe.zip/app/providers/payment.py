from __future__ import annotations

from typing import Any, Protocol, TYPE_CHECKING

if TYPE_CHECKING:
    from app.services.runtime_settings import RuntimeSettingsService


class ProviderFinancialError(RuntimeError):
    """Base class for payment-provider transfer failures."""


class ProviderFinancialDefiniteError(ProviderFinancialError):
    """The provider definitely rejected the transfer; a new POST is safe later."""


class ProviderFinancialUncertain(ProviderFinancialError):
    """The provider may have executed the transfer; never repeat the POST blindly."""


class PaymentProvider(Protocol):
    provider_id: str
    provider_label: str

    @property
    def configured(self) -> bool: ...

    async def healthcheck(self) -> dict[str, Any]: ...


class PaymentProviderManager:
    """Runtime-selectable provider registry.

    Only one provider is active at a time. Callers intentionally resolve the
    active provider once at the start of an operation and keep that object for
    the whole operation, so an admin switch cannot change provider mid-transfer.
    """

    SETTING_KEY = "payments.api_provider"

    def __init__(
        self,
        runtime: "RuntimeSettingsService",
        *,
        providers: list[PaymentProvider],
        default_provider: str = "api_syria",
    ) -> None:
        self.runtime = runtime
        self._providers = {p.provider_id: p for p in providers}
        self.default_provider = (
            default_provider if default_provider in self._providers else next(iter(self._providers), "")
        )

    def ids(self) -> tuple[str, ...]:
        return tuple(self._providers)

    def get(self, provider_id: str) -> PaymentProvider | None:
        return self._providers.get(str(provider_id or "").strip().lower())

    def active_id(self) -> str:
        value = str(self.runtime.get(self.SETTING_KEY, self.default_provider) or self.default_provider).strip().lower()
        return value if value in self._providers else self.default_provider

    def active(self) -> PaymentProvider:
        provider = self.get(self.active_id())
        if provider is None:
            raise RuntimeError("No payment API provider is registered")
        return provider

    def active_label(self) -> str:
        return self.active().provider_label

    def statuses(self) -> list[tuple[str, str, bool, bool]]:
        active = self.active_id()
        return [
            (provider_id, provider.provider_label, bool(provider.configured), provider_id == active)
            for provider_id, provider in self._providers.items()
        ]

    async def set_active(self, provider_id: str, *, updated_by: int) -> PaymentProvider:
        provider = self.get(provider_id)
        if provider is None:
            raise ValueError("مزود API غير معروف")
        if not provider.configured:
            raise ValueError(f"{provider.provider_label} غير مضبوط. أضف مفتاح API أولاً.")
        await self.runtime.set(self.SETTING_KEY, provider.provider_id, updated_by=updated_by)
        return provider

    async def healthcheck(self, provider_id: str | None = None) -> dict[str, Any]:
        provider = self.get(provider_id or self.active_id())
        if provider is None:
            raise ValueError("مزود API غير معروف")
        if not provider.configured:
            raise ValueError(f"{provider.provider_label} غير مضبوط")
        data = await provider.healthcheck()
        return {
            "provider_id": provider.provider_id,
            "provider_label": provider.provider_label,
            "data": data,
        }
