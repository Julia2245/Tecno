from __future__ import annotations

import asyncio
from decimal import Decimal

import aiohttp

from app.core.deposits import DepositProviderUnavailable, DepositVerificationFailed, ProviderTransaction
from app.core.money import parse_decimal
from app.providers.api_syria import ApiSyriaClient
from app.providers.payment import ProviderFinancialDefiniteError, ProviderFinancialUncertain


class TsaApiClient(ApiSyriaClient):
    """TSA API adapter exposing the same safe provider surface used by finance services."""

    provider_id = "tsa"
    provider_label = "TSA API"

    def __init__(self, session: aiohttp.ClientSession, *, base_url: str, api_key: str) -> None:
        super().__init__(session, base_url=base_url, api_key=api_key)
        # Deposit verification should fail fast rather than leaving a user waiting.
        self._verify_timeout = aiohttp.ClientTimeout(total=9)
        self._read_spacing_seconds = 0.25
        self._accounts_cache: tuple[float, dict] | None = None
        self._accounts_lock = asyncio.Lock()

    async def healthcheck(self) -> dict:
        return await self._generic_get({"resource": "status"})

    async def _syriatel_gsm(self, source: str) -> str:
        """TSA requires GSM, while the bot historically accepted cash_code too."""
        wanted = str(source or "").strip()
        if not wanted:
            raise DepositProviderUnavailable("tsa_missing_syriatel_source")
        # A normal Syrian GSM can be used directly. Still accept +963/963 forms
        # because linked accounts may expose them that way.
        digits = wanted.replace("+", "")
        if wanted.startswith("09") and wanted.isdigit() and len(wanted) >= 9:
            return wanted
        if digits.startswith("9639") and digits.isdigit():
            return wanted

        data = await self._accounts_cached()
        accounts = (data.get("data") or {}).get("syriatel") or []
        for item in accounts if isinstance(accounts, list) else []:
            if not isinstance(item, dict):
                continue
            gsm = str(item.get("gsm") or "").strip()
            cash_code = str(item.get("cash_code") or "").strip()
            if wanted in {gsm, cash_code} and gsm:
                return gsm
        raise DepositProviderUnavailable("tsa_syriatel_source_not_linked")

    async def _accounts_cached(self) -> dict:
        loop = asyncio.get_running_loop()
        now = loop.time()
        if self._accounts_cache and now - self._accounts_cache[0] < 30:
            return self._accounts_cache[1]
        async with self._accounts_lock:
            now = loop.time()
            if self._accounts_cache and now - self._accounts_cache[0] < 30:
                return self._accounts_cache[1]
            data = await self.list_accounts()
            self._accounts_cache = (loop.time(), data)
            return data

    async def find_syriatel(self, tx: str, gsm: str) -> ProviderTransaction | None:
        actual_gsm = await self._syriatel_gsm(gsm)
        payload = await self._find(resource="syriatel", tx=tx, gsm=actual_gsm)
        if payload is None:
            return None
        obj = payload.get("transaction") or {}
        # TSA find_tx searches incoming and outgoing. A deposit is valid only if
        # the provider confirms a successful incoming transaction.
        if str(obj.get("status") or "").strip() != "1":
            return None
        if str(obj.get("history_type") or "").strip().lower() != "incoming":
            return None
        amount = self._amount(obj)
        return ProviderTransaction(
            provider="syriatel",
            tx_key=tx,
            amount=amount,
            currency="SYP",
            destination=actual_gsm,
            occurred_at=self._parse_datetime(obj.get("date")),
            raw=dict(obj),
        )

    async def syriatel_balance(self, gsm: str) -> tuple[str, Decimal]:
        actual_gsm = await self._syriatel_gsm(gsm)
        data = await self._generic_get({"resource": "syriatel", "action": "balance", "gsm": actual_gsm})
        info = data.get("data") or {}
        try:
            balance = parse_decimal(info.get("balance") or 0)
        except ValueError as exc:
            raise DepositProviderUnavailable("tsa_invalid_balance") from exc
        return actual_gsm, balance

    async def source_is_linked(self, kind: str, source: str) -> bool | None:
        try:
            data = await self._accounts_cached()
        except Exception:
            return None
        payload = data.get("data") or {}
        wanted = str(source or "").strip()
        if not wanted:
            return False
        if kind == "syriatel":
            for item in payload.get("syriatel") or []:
                if not isinstance(item, dict):
                    continue
                if wanted in {
                    str(item.get("gsm") or "").strip(),
                    str(item.get("cash_code") or "").strip(),
                }:
                    return True
            return False
        if kind == "shamcash":
            return any(
                isinstance(item, dict) and wanted == str(item.get("account_address") or "").strip()
                for item in payload.get("shamcash") or []
            )
        return None

    async def syriatel_outgoing_snapshot(self, source: str) -> tuple[set[str], bool]:
        try:
            gsm = await self._syriatel_gsm(source)
        except Exception:
            return set(), False
        try:
            data = await self._generic_get({
                "resource": "syriatel", "action": "outgoing_history", "gsm": gsm, "period": "7",
            })
            items = ((data.get("data") or {}).get("items") or [])
            found = {self.provider_reference(item) for item in items if isinstance(item, dict)}
            return {x for x in found if x}, True
        except Exception:
            return set(), False

    async def resolve_syriatel_outgoing_transfer(
        self, *, source: str, receiver: str, amount: Decimal, exclude_tx_ids: set[str] | None = None,
    ) -> str:
        try:
            gsm = await self._syriatel_gsm(source)
        except Exception:
            return ""
        return await super().resolve_syriatel_outgoing_transfer(
            source=gsm, receiver=receiver, amount=amount, exclude_tx_ids=exclude_tx_ids,
        )

    async def resolve_shamcash_recipient_name(self, *, source: str, receiver: str) -> str:
        source = str(source or "").strip()
        receiver = str(receiver or "").strip()
        if not source or not receiver:
            return ""
        data = await self._generic_get({
            "resource": "shamcash",
            "action": "resolve",
            "account_address": source,
            "to_address": receiver,
        })
        info = data.get("data") or {}
        return str(info.get("name") or "").strip()

    async def transfer_syriatel(
        self, *, source: str, receiver: str, amount: Decimal, pin_code: str,
    ) -> dict:
        gsm = await self._syriatel_gsm(source)
        return await self._financial_post_tsa(
            {"resource": "syriatel", "action": "transfer_cash"},
            {
                "gsm": gsm,
                "to_gsm": receiver,
                "amount": self._decimal_text(amount),
                "pin_code": pin_code,
            },
        )

    async def transfer_shamcash(
        self,
        *,
        source: str,
        receiver: str,
        amount: Decimal,
        currency: str = "SYP",
        note: str | None = "مبروك",
        pin: str | None = None,
    ) -> dict:
        params = {
            "resource": "shamcash",
            "action": "transfer",
            "account_address": str(source or "").strip(),
        }
        form = {
            "to_address": str(receiver or "").strip(),
            "amount": self._decimal_text(amount),
            "currency": str(currency or "SYP").upper(),
        }
        if note is not None:
            form["note"] = str(note)
        if pin:
            form["pin"] = str(pin)
        return await self._financial_post_tsa(params, form)

    async def _financial_post_tsa(self, params: dict[str, str], form: dict[str, str]) -> dict:
        if not self.configured:
            raise ProviderFinancialDefiniteError("TSA API غير مضبوط")
        headers = {
            "X-Api-Key": self.api_key,
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        try:
            # Exactly one financial POST. No retry for timeout, 5xx, or network errors.
            async with self.session.post(
                self.base_url,
                params=dict(params),
                data=form,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=35),
            ) as response:
                text = await response.text()
                try:
                    data = await response.json(content_type=None)
                except Exception as exc:
                    if response.status >= 500 or response.status == 200:
                        raise ProviderFinancialUncertain(
                            f"TSA non-json HTTP {response.status}: {text[:300]}"
                        ) from exc
                    raise ProviderFinancialDefiniteError(
                        f"TSA HTTP {response.status}: {text[:300]}"
                    ) from exc
                if response.status == 429:
                    raise ProviderFinancialDefiniteError("TSA API rate limit")
                if response.status >= 500:
                    raise ProviderFinancialUncertain(f"TSA HTTP {response.status}: {text[:300]}")
                if response.status >= 400:
                    raise ProviderFinancialDefiniteError(
                        str(data.get("error") or data.get("message") or f"TSA HTTP {response.status}")
                    )
                if not isinstance(data, dict):
                    raise ProviderFinancialUncertain("TSA unexpected financial response")
                if data.get("success") is False:
                    raise ProviderFinancialDefiniteError(
                        str(data.get("error") or data.get("message") or "TSA rejected transfer")
                    )
                return data
        except (ProviderFinancialDefiniteError, ProviderFinancialUncertain):
            raise
        except (aiohttp.ClientError, asyncio.TimeoutError, TimeoutError) as exc:
            raise ProviderFinancialUncertain(f"TSA financial network outcome uncertain: {exc}") from exc
