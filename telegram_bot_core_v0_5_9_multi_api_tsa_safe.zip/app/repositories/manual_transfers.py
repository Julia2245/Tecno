from __future__ import annotations

import json
from decimal import Decimal
from typing import Any, Mapping
from uuid import UUID

from app.core.db import Database


class ManualTransferRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def claim_intent(
        self, *, intent_id: UUID, admin_id: int, method: str, source: str,
        receiver: str, amount: Decimal, currency: str, provider_id: str | None = None,
    ) -> str:
        """Return newly-created/known status. Same intent can never POST twice."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    INSERT INTO bot_core.admin_manual_transfer_intents(
                        id,admin_telegram_id,method,source,receiver,amount,currency,status,provider_payload
                    ) VALUES($1,$2,$3,$4,$5,$6,$7,'processing',$8::jsonb)
                    ON CONFLICT(id) DO NOTHING
                    RETURNING status
                    """,
                    intent_id, int(admin_id), method, source, receiver, amount, currency,
                    json.dumps(
                        {"_api_provider": str(provider_id or "").strip()} if provider_id else {},
                        ensure_ascii=False, separators=(",", ":"),
                    ),
                )
                if row is not None:
                    return "processing_new"
                current = await conn.fetchrow(
                    "SELECT * FROM bot_core.admin_manual_transfer_intents WHERE id=$1 FOR UPDATE", intent_id
                )
                if current is None:
                    raise RuntimeError("manual transfer intent disappeared")
                identity = (
                    int(current["admin_telegram_id"]) == int(admin_id)
                    and str(current["method"]) == method
                    and str(current["source"]) == source
                    and str(current["receiver"]) == receiver
                    and Decimal(current["amount"]) == amount
                    and str(current["currency"]) == currency
                )
                if not identity:
                    raise RuntimeError("manual transfer intent identity mismatch")
                return str(current["status"])

    async def mark_failed(self, intent_id: UUID, error: str) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.admin_manual_transfer_intents
                SET status='failed',last_error=$2,updated_at=NOW()
                WHERE id=$1 AND status='processing'
                """,
                intent_id, str(error)[:1200],
            )

    async def mark_uncertain(self, intent_id: UUID, error: str) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.admin_manual_transfer_intents
                SET status='needs_review',last_error=$2,updated_at=NOW()
                WHERE id=$1 AND status='processing'
                """,
                intent_id, str(error)[:1200],
            )

    async def finalize_success(
        self, *, intent_id: UUID, admin_id: int, method: str, method_label: str,
        source: str, source_label: str, receiver: str, recipient_name: str | None,
        amount: Decimal, currency: str, balance_before: Decimal | None,
        balance_after: Decimal | None, provider_reference: str | None,
        provider_payload: Mapping[str, Any] | None,
    ) -> dict[str, Any]:
        pool = self.db.require_pool()
        payload = json.dumps(dict(provider_payload or {}), ensure_ascii=False, separators=(",", ":"), default=str)
        async with pool.acquire() as conn:
            async with conn.transaction():
                intent = await conn.fetchrow(
                    "SELECT * FROM bot_core.admin_manual_transfer_intents WHERE id=$1 FOR UPDATE", intent_id
                )
                if intent is None:
                    raise RuntimeError("manual transfer intent not found")
                if str(intent["status"]) == "success":
                    existing = await conn.fetchrow(
                        "SELECT * FROM bot_core.admin_manual_transfers WHERE intent_key=$1", intent_id
                    )
                    return dict(existing) if existing else {}
                if str(intent["status"]) != "processing":
                    raise RuntimeError(f"manual transfer intent is {intent['status']}")
                await conn.execute(
                    """
                    UPDATE bot_core.admin_manual_transfer_intents
                    SET status='success',provider_reference=$2,provider_payload=$3::jsonb,last_error=NULL,updated_at=NOW()
                    WHERE id=$1
                    """,
                    intent_id, provider_reference, payload,
                )
                row = await conn.fetchrow(
                    """
                    INSERT INTO bot_core.admin_manual_transfers(
                        intent_key,admin_telegram_id,method,method_label,source,source_label,
                        receiver,recipient_name,amount,currency,source_balance_before,
                        source_balance_after,provider_reference,provider_payload,status
                    ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14::jsonb,'success')
                    ON CONFLICT(intent_key) DO NOTHING
                    RETURNING *
                    """,
                    intent_id, int(admin_id), method, method_label, source, source_label,
                    receiver, recipient_name, amount, currency, balance_before, balance_after,
                    provider_reference, payload,
                )
                if row is None:
                    row = await conn.fetchrow(
                        "SELECT * FROM bot_core.admin_manual_transfers WHERE intent_key=$1", intent_id
                    )
                    if row is None:
                        raise RuntimeError("manual transfer audit row was not created")
        return dict(row)

    async def recover_stale_processing(self, *, minutes: int = 3) -> int:
        """Move interrupted one-POST attempts to review; never make them executable again."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE bot_core.admin_manual_transfer_intents
                SET status='needs_review',
                    last_error=COALESCE(last_error,'execution interrupted; provider outcome requires review'),
                    updated_at=NOW()
                WHERE status='processing'
                  AND updated_at < NOW() - ($1::int * INTERVAL '1 minute')
                """,
                max(1, int(minutes)),
            )
        try:
            return int(str(result).rsplit(" ", 1)[-1])
        except Exception:
            return 0

    async def get_by_intent(self, intent_id: UUID) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM bot_core.admin_manual_transfers WHERE intent_key=$1", intent_id
            )
        return dict(row) if row else None

    async def list_success(self, *, limit: int = 8, offset: int = 0) -> tuple[int, list[dict[str, Any]]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = int(await conn.fetchval("SELECT COUNT(*) FROM bot_core.admin_manual_transfers WHERE status='success'") or 0)
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.admin_manual_transfers
                WHERE status='success' ORDER BY id DESC LIMIT $1 OFFSET $2
                """,
                max(1, min(50, int(limit))), max(0, int(offset)),
            )
        return total, [dict(r) for r in rows]

    async def get(self, log_id: int) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM bot_core.admin_manual_transfers WHERE id=$1 AND status='success'", int(log_id)
            )
        return dict(row) if row else None
