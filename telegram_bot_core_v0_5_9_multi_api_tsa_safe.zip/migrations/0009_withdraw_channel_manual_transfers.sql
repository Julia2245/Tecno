-- Phase 5.8: live withdrawal-channel message identity + admin manual-transfer audit.

ALTER TABLE bot_core.withdraw_requests
    ADD COLUMN IF NOT EXISTS channel_chat_id BIGINT,
    ADD COLUMN IF NOT EXISTS channel_message_id BIGINT;

CREATE INDEX IF NOT EXISTS idx_withdraw_channel_message
    ON bot_core.withdraw_requests(channel_chat_id, channel_message_id)
    WHERE channel_chat_id IS NOT NULL AND channel_message_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS bot_core.admin_manual_transfer_intents (
    id UUID PRIMARY KEY,
    admin_telegram_id BIGINT NOT NULL,
    method TEXT NOT NULL,
    source TEXT NOT NULL,
    receiver TEXT NOT NULL,
    amount NUMERIC(28,8) NOT NULL,
    currency TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'processing',
    provider_reference TEXT,
    provider_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT admin_manual_intent_method CHECK (method IN ('shamcash','syriatel')),
    CONSTRAINT admin_manual_intent_status CHECK (status IN ('processing','success','needs_review','failed')),
    CONSTRAINT admin_manual_intent_amount_positive CHECK (amount > 0),
    CONSTRAINT admin_manual_intent_currency CHECK (currency IN ('SYP','USD')),
    CONSTRAINT admin_manual_intent_admin_positive CHECK (admin_telegram_id > 0)
);
CREATE INDEX IF NOT EXISTS idx_admin_manual_transfer_intents_status
    ON bot_core.admin_manual_transfer_intents(status,created_at DESC);

CREATE TABLE IF NOT EXISTS bot_core.admin_manual_transfers (
    id BIGSERIAL PRIMARY KEY,
    intent_key UUID NOT NULL UNIQUE REFERENCES bot_core.admin_manual_transfer_intents(id) ON DELETE RESTRICT,
    admin_telegram_id BIGINT NOT NULL,
    method TEXT NOT NULL,
    method_label TEXT NOT NULL,
    source TEXT NOT NULL,
    source_label TEXT NOT NULL,
    receiver TEXT NOT NULL,
    recipient_name TEXT,
    amount NUMERIC(28,8) NOT NULL,
    currency TEXT NOT NULL,
    source_balance_before NUMERIC(28,8),
    source_balance_after NUMERIC(28,8),
    provider_reference TEXT,
    provider_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    status TEXT NOT NULL DEFAULT 'success',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT admin_manual_transfer_method CHECK (method IN ('shamcash','syriatel')),
    CONSTRAINT admin_manual_transfer_status CHECK (status IN ('success')),
    CONSTRAINT admin_manual_transfer_amount_positive CHECK (amount > 0),
    CONSTRAINT admin_manual_transfer_currency CHECK (currency IN ('SYP','USD')),
    CONSTRAINT admin_manual_transfer_admin_positive CHECK (admin_telegram_id > 0)
);
CREATE INDEX IF NOT EXISTS idx_admin_manual_transfers_created
    ON bot_core.admin_manual_transfers(created_at DESC,id DESC);
CREATE INDEX IF NOT EXISTS idx_admin_manual_transfers_method
    ON bot_core.admin_manual_transfers(method,created_at DESC,id DESC);

CREATE OR REPLACE FUNCTION bot_core.reject_admin_manual_transfer_change()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'admin manual transfer audit rows are immutable';
END;
$$;
DROP TRIGGER IF EXISTS admin_manual_transfers_immutable ON bot_core.admin_manual_transfers;
CREATE TRIGGER admin_manual_transfers_immutable
BEFORE UPDATE OR DELETE ON bot_core.admin_manual_transfers
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_admin_manual_transfer_change();
