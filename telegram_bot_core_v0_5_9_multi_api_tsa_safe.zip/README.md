# Telegram Bot Core — Phase 5

نواة عامة قابلة لإعادة الاستخدام لبوتات Telegram مبنية على **aiogram + PostgreSQL**، بدون ربط الكود بهوية بوت محددة.

> هذه المرحلة تجمع: النواة + Wallet Core + شحن رصيد البوت + iChancy + سحب رصيد البوت + إدارة الشحن والسحب + Durable Notification Outbox.

## الأساس المالي

- PostgreSQL async عبر `asyncpg` وmigrations داخل schema مستقل `bot_core`.
- Wallet Core محمي: ledger append-only، idempotency، row locks، holds، وقيود سلامة على مستوى قاعدة البيانات.
- أي حركة رصيد تمر عبر `WalletRepository`؛ الـrouters لا تكتب على الرصيد مباشرة.
- إنشاء Hold والطلب المالي المرتبط به يتمان في Transaction واحدة.
- التسوية/الإلغاء/الرفض المالي يتم بصورة ذرية قدر الإمكان.
- العمليات الخارجية غير المؤكدة لا يعاد إرسال POST لها بصورة عمياء.

## شحن رصيد البوت

الطرق الحالية:

- Syriatel Cash — Auto / Manual.
- Sham Cash SYP — Auto / Manual.
- Sham Cash USD — Auto / Manual.
- Whish Money — Manual مع صورة إثبات Telegram.
- Binance USDT — TRC20 / BEP20.

الحماية تشمل namespaces مشتركة لمنع إعادة استخدام نفس Tx عبر تحويل العملة/الشبكة، وclaims/idempotency، وربط النجاح بعملية Wallet ثابتة.

- التحقق الآلي يعرض حالة واحدة تتحدث بالنتيجة، مع منع المستخدم من بدء تحقق شحن ثانٍ قبل حسم الأول.
- طلبات التحقق read-only تمر عبر مزود الـAPI النشط (API SYRIA أو TSA) بفاصل قصير وTimeout قصير؛ عند rate-limit/تعذر المزود لا يتم اعتماد العملية ويطلب من المستخدم إعادة المحاولة بنفس رقم العملية.
- أثناء تحقق الشحن يمنع `/start` و`/menu` والرجوع للرئيسية بدء تدفق موازٍ، وتبقى رسالة التحقق نفسها هي التي تتحدث بالنتيجة.
- أكواد استلام Syriatel وعناوين Sham Cash قابلة للتعديل من لوحة الإدارة، وتبقى قيم `.env` قيم bootstrap لقاعدة بيانات جديدة.
- أسعار Sham Cash USD وWhish Money وBinance TRC20/BEP20 مستقلة وقابلة للتعديل فورياً من صفحة كل وسيلة.

### تحويل العملة المحلية

Sham Cash SYP وSyriatel Cash يستخدمان **معامل تحويل واحد مشترك** محفوظ في Runtime Settings:

`money.local_syp_wallet_multiplier`

القيمة الافتراضية الحالية `100`، أي:

`200` من العملة المحلية → `20,000` رصيد محفظة.

يمكن تغييره لاحقاً من لوحة الإدارة إلى `1` لتصبح العلاقة 1:1. كل طلب يحفظ Snapshot للسعر الذي بدأ عليه، لذلك تغيير الإعداد لا يعيد تسعير الطلبات القديمة.

## مزود API لشام كاش وسيرياتيل

البوت يدعم مزودين حالياً عبر طبقة موحدة قابلة للتوسعة:

- `API SYRIA`
- `TSA API`

من **إدارة الشحن والسحب → مزود API** يختار الأدمن مزوداً واحداً فقط كـActive، ويمكن فحص حالته من نفس الصفحة. الاختيار يحفظ في Runtime Settings ولا يحتاج Restart.

مفاتيح المزودين تبقى أسرار Deployment داخل `.env`:

```env
PAYMENT_API_PROVIDER=api_syria
API_SYRIA_BASE_URL=https://apisyria.com/api/v1
API_SYRIA_KEY=
TSA_API_BASE_URL=https://tsa-api.com/api/v1
TSA_API_KEY=
```

قواعد الأمان:

- المزود يُجمّد عند بداية كل عملية مالية؛ تغييره من لوحة الإدارة لا يبدل مزود عملية بدأت بالفعل.
- لا يوجد fallback تلقائي بعد أي POST مالي. Timeout/Network/5xx تعني نتيجة غير مؤكدة ومراجعة، وليس تجربة المزود الآخر.
- معرف المزود يحفظ في `provider_payload` قبل POST للسحب/الحوالة اليدوية، حتى يمكن معرفة المزود الصحيح بعد Restart أو نتيجة غير مؤكدة.
- TSA يستخدم `accounts/list` لتحويل Cash Code القديم إلى GSM عند الحاجة، لأن عمليات Syriatel في TSA تعتمد رقم GSM.
- TSA يتحقق من عملية Syriatel على أنها ناجحة وواردة (`status=1`, `history_type=incoming`) قبل اعتماد الشحن.
- TSA يستخدم `resolve` للتحقق من اسم مستلم Sham Cash قبل السحب، ويستفيد من `tran_id` العائد مباشرة بعد نجاح التحويل.
- PIN شام كاش الاختياري لـTSA يمكن ضبطه مشفراً من صفحة سحب Sham Cash؛ لا يُعرض مرة أخرى في الواجهة.

## iChancy

### إنشاء الحساب

- المستخدم يدخل الاسم فقط.
- الأسماء العربية تنظف وتحوّل تلقائياً إلى صيغة لاتينية صالحة.
- اسم الحساب النهائي يستخدم عداداً ذرياً عاماً في PostgreSQL، مثل:
  - `tecno1_ahmad`
  - `tecno2_samer`
- الـprefix ليس ثابتاً في السورس؛ يحدد عبر `ICHANCY_USERNAME_PREFIX` أو لوحة إدارة iChancy.
- كلمة المرور تولد آلياً بمولد آمن وتخزن مشفرة، ولا تسجل في logs.
- لو كانت نتيجة registerPlayer غير مؤكدة، لا يعاد POST بصورة عمياء؛ تتم مطابقة الـusername الثابت أولاً.

### الدخول الفوري

المسار يطابق تجربة البوت المرجعي:

1. تسجيل الدخول عبر BetConstruct Swarm WebSocket.
2. استخراج `auth_token` مؤقت.
3. إظهار زر WebApp لفتح الموقع مباشرة بالحساب.
4. التوكن لا يخزن في قاعدة البيانات.
5. عند مشكلة فتح الموقع تظهر ملاحظة استخدام VPN على سنغافورة.

### العمليات

- شحن مبلغ إلى iChancy.
- سحب مبلغ من iChancy إلى المحفظة.
- شحن كامل الرصيد المتاح.
- الحد الأدنى للشحن والسحب قابل للتعديل من لوحة الإدارة؛ الافتراضي 20,000.
- العمليات تستخدم queue دائمة وحالات مالية منفصلة عن Telegram handlers.
- يتم حفظ snapshots لرصيد اللاعب والكاشير قبل/بعد عند توفرها.
- النتيجة غير المؤكدة تدخل `reconciling` ولا تعاد العملية المالية تلقائياً.
- توجد لوحة `⚠️ عمليات تحتاج مراجعة` لحسم العملية يدوياً بدون إرسال POST مالي جديد.

## إضافة / استبدال كاشيرة iChancy

عند عدم وجود كاشيرة نشطة، يمكن إدخال بيانات أول كاشيرة من لوحة الإدارة، اختبارها، ثم اعتمادها مباشرة. بعد وجود كاشيرة نشطة يستخدم النظام مسار الاستبدال المحمي أدناه.

الاستبدال Workflow دائم وقابل للاستكمال بعد Restart:

- اختبار الكاشيرة الجديدة قبل بدء الاستبدال.
- منع البدء عند وجود عمليات iChancy أو إنشاءات حساب غير محسومة على الكاشيرة القديمة.
- تحويل الكاشيرة القديمة وحساباتها إلى حالة retiring؛ لا يتم حذف أي حساب قديم.
- فحص أرصدة الحسابات وتصنيفها إلى:
  - صفر.
  - أقل من الحد الأدنى للسحب.
  - مؤهل للسحب.
  - فشل فحص / يحتاج مراجعة.
- الأرصدة المؤهلة تنشأ لها jobs مستقلة لسحب الرصيد وإعادته إلى Wallet المستخدم.
- بعد كل تسوية ناجحة تتم إعادة قراءة رصيد اللاعب:
  - صفر → تمت التصفية.
  - أقل من الحد → يحفظ كرصد متبقٍ في السجل القديم.
  - ما يزال فوق الحد → تنشأ محاولة تسوية جديدة مستقلة.
- الاعتماد النهائي يتطلب عدم وجود jobs نشطة وتطابق إجمالي ما سحب من iChancy مع إجمالي ما أضيف للمحافظ.
- التقدم يعرض في **رسالة إدارة واحدة تتحدث** بدلاً من إرسال رسالة لكل حساب.

### سجلات الكاشيرات القديمة

من إدارة iChancy يمكن البحث بـTelegram ID واستعراض الحسابات المتقاعدة، الرصيد المرصود والمتبقي وحالة التسوية.

الرصيد المتبقي الأقل من الحد يمكن تعويضه يدوياً بعد اكتمال الاستبدال. التعويض مرتبط بالسجل القديم وidempotent، فلا يمكن إضافته مرتين.

## سحب رصيد البوت

الطرق:

- Syriatel Cash.
- Sham Cash مع محاولة جلب اسم الحساب قبل إدخال المبلغ.
- حوالة — هرم / الفؤاد، مع بيانات المستلم.
- USDT — TRC20 / BEP20 مع تحكم مستقل لكل شبكة.

الحماية:

- Hold قبل التنفيذ.
- طلب واحد نشط لكل مستخدم.
- تنفيذ آلي لـSyriatel/Sham فقط؛ الحوالة وUSDT تنفيذ يدوي ثم تأكيد دفع.
- نتيجة مزود مؤكدة النجاح تحفظ أولاً كـ`provider_success`، وبعدها تكتمل التسوية المحلية بدون إعادة POST.
- نتيجة غير مؤكدة → `needs_review`، ولا يجوز رفضها وتحرير الـHold مباشرة.
- الأدمن يقرر صراحة: «تم الدفع» أو «لم يتم الدفع».
- أي `processing` قديم بعد Restart يتحول للمراجعة بدلاً من إعادة التحويل.
- بطاقة طلب السحب للأدمن تعرض آخر 3 عمليات شحن ناجحة للمستخدم مع البونص.
- أثناء التنفيذ الآلي تتحول البطاقة فوراً إلى «جاري التنفيذ» بلا أزرار تنفيذ إضافية، وبعد النجاح تعرض وقت الطلب ووقت التنفيذ ورقم عملية المزود عند إعادته من API.

## التنبيهات والإشعارات

الإشعارات المالية تستخدم **Durable Notification Outbox** داخل PostgreSQL:

- إنشاء حساب iChancy → قناة حسابات iChancy.
- شحن/سحب iChancy → قناة عمليات iChancy.
- شحن رصيد البوت → قناة عمليات الشحن المستقلة.
- سحب رصيد البوت → قناة عمليات السحب المستقلة.
- فشل Telegram أو Restart لا يحذف الحدث؛ العامل يعيد المحاولة.
- `event_key` فريد لمنع إنشاء إشعار منطقي مكرر.

حدود «المبلغ الكبير» قابلة للتعديل من لوحة الإدارة بصورة مستقلة:

- شحن iChancy.
- سحب iChancy.
- شحن رصيد البوت.
- سحب رصيد البوت.

عند تجاوز الحد لا ترسل رسالة ثانية؛ نفس رسالة العملية تحمل شارة `🚨 مبلغ كبير`، ولا يظهر رقم الحد في الإشعار.

## Custom Emoji

القيم مركزية داخل `app/core/emojis.py` وتشمل هوية الأزرار وحالات التنفيذ، ومن ضمنها:

- iChancy: `5994683681220861528`
- Sham Cash: `5996853812231413145`
- Syriatel Cash: `5994366253072916034`
- شحن رصيد البوت: `5377548235709619284`
- سحب رصيد البوت: `5994385322727709668`
- التحقق/التحميل: `5386367538735104399`
- المعالجة/التدقيق: `5884447890960552542`
- النجاح/التأكيد: `5796205953913196373`

## إعداد iChancy المطلوب قبل التشغيل الحقيقي

في `.env`:

```env
ICHANCY_BASE_URL=https://agents.ichancy.com
ICHANCY_API_USERNAME=
ICHANCY_API_PASSWORD=
ICHANCY_PARENT_ID=
ICHANCY_CURRENCY=SYP
ICHANCY_USERNAME_PREFIX=bot
ICHANCY_CREDENTIALS_KEY=
ICHANCY_WEBSITE_URL=https://www.ichancy300.com/ar
ICHANCY_WS_URL=wss://eu-swarm-springre.betcoswarm.com/
ICHANCY_WS_ORIGIN=https://www.ichancy.com
ICHANCY_WS_SITE_ID=18755655
ICHANCY_WS_SOURCE=42
```

لبيئة Tecno التجريبية اضبط:

```env
ICHANCY_USERNAME_PREFIX=tecno
```

قبل إنشاء أول حساب. لا ترفع `.env` إلى GitHub.

إن لم يكن `ICHANCY_CREDENTIALS_KEY` موجوداً، أنشئ مفتاح Fernet مرة واحدة فقط واحفظه في `.env`. تغيير هذا المفتاح بعد تخزين بيانات الحسابات يجعل بياناتها المشفرة غير قابلة للفك.

## الفحوص قبل اعتماد أي إصدار

فحص ثابت لا يحتاج قاعدة بيانات:

```bash
PYTHONPATH=. python -m scripts.preflight
```

ثم داخل بيئة السيرفر التي تحتوي الاعتماديات:

```bash
python -m pytest -q
python -m scripts.wallet_audit
python -m scripts.deposit_audit
python -m scripts.ichancy_audit
python -m scripts.withdraw_audit
python -m scripts.outbox_audit
```

النتائج السليمة يجب أن تحتوي:

```text
PROJECT PREFLIGHT: OK
WALLET AUDIT: OK
DEPOSIT AUDIT: OK
ICHANCY AUDIT: OK
WITHDRAW AUDIT: OK
OUTBOX AUDIT: OK
```

> Audits الجديدة read-only؛ معالجة `processing` المنقطع في السحب تتم عند تشغيل التطبيق، وليس داخل audit.

## قاعدة التطوير

- لا يوجد اسم بوت ثابت داخل منطق التطبيق.
- لا يكتب Router إلى Wallet أو Ledger مباشرة.
- أي API مالي خارجي يجب أن يفرق بين الفشل المؤكد والنتيجة غير المؤكدة.
- لا يعاد POST مالي بسبب Timeout دون reconciliation أو قرار صريح.
- إعدادات المال والحدود تحفظ Snapshot داخل العملية عند الحاجة حتى لا تغير الإعدادات الجديدة التاريخ المالي القديم.
## v0.5.2 callback safety
- Shortened UUID-bearing iChancy admin callback payloads that could exceed Telegram's 64-byte callback_data limit and trigger `BUTTON_DATA_INVALID`. Legacy callback handlers remain accepted where safe for already-open messages.


## v0.5.4 iChancy user-result UX
- Deposit progress is intentionally minimal: `جاري شحن حسابك...`; internal UUID/amount details stay out of the user's progress screen.
- The original progress message is updated to success/failure when the durable job finishes, without blocking callback/menu responsiveness.
- User success/failure outbox messages are delayed fallback notifications only; they are paused after a successful inline edit.
- Pre-transfer temporary provider/read failures are retried briefly, then fail safely so a wallet hold cannot remain queued forever.

## v0.5.5 iChancy safe reconciliation
- Every new iChancy financial job gets a unique provider comment/reference derived from its immutable job UUID (`TEC-D-...` for deposits, `TEC-W-...` for withdrawals).
- The reference is persisted before the financial POST and sent in the documented iChancy `comment` field.
- Explicit provider success settles normally; explicit rejection fails normally.
- Timeout/network/HTTP 429/5xx after a financial POST is never replayed blindly. The job enters read-only reconciliation.
- Reconciliation requires the exact two-sided delta: player balance and cashier balance must both match the transfer amount and direction.
- Reconciliation is throttled and bounded. Unprovable outcomes stop automatic polling and appear in the admin review queue without sending another financial POST.
- The original Telegram progress message is stored with the job and is edited to reconciling/success/failure even after a process restart when possible; delayed outbox messages remain a fallback.
- User progress/result messages contain no amount, UUID, Player ID, cashier balance, or provider reference. Those details remain admin-only.
- Fast callback/navigation files are unchanged from v0.5.4.


## v0.5.6 finance controls + instant capture
- iChancy withdrawal now performs a live player-balance precheck before creating a durable job, then retains the authoritative second balance read immediately before the financial POST.
- iChancy withdrawal progress is user-clean: balance check → withdrawal processing → final/reconciliation result in the same stored progress message, without exposing UUIDs or internal financial metadata.
- Bot-wallet deposit methods have independent runtime minimums and independent admin pages for Syriatel, Sham SYP, Sham USD, Whish, TRC20, and BEP20.
- Bot-wallet withdrawal administration is split into method settings, pending/review/history, commission, and immutable security information. Syriatel and Sham have independent minimums.
- Finance-setting input uses first-message capture: persist immediately, delete the input when possible, clear/cancel FSM safely, and edit the original admin screen with the effective value immediately. Arabic/Persian digits are accepted for numeric settings.
- Bot-wallet operation notifications are split into independent deposit and withdrawal channels. Migration `0007` seeds both from the legacy channel once, while all new events use their dedicated target.
- Approved custom emoji IDs are centralized in `app/core/emojis.py`; UI buttons reference the registry rather than embedding IDs throughout business logic.
- The fast callback ACK/render patch is unchanged byte-for-byte.

### v0.5.7 finance hotfix
- The runtime `notify.bot_deposits` channel is reserved for successful bot-wallet deposit notifications; pending manual-review requests remain on the dedicated review target/admin fallback.
- Sham Cash addresses are canonicalized on input/read; migration `0008` cleans existing runtime values pasted with quotes/whitespace.
- Syriatel withdrawal PIN can be set from the admin withdrawal page. Runtime PIN is encrypted with the deployment credential key and never displayed back in the UI.


### v0.5.8 withdrawal channel + admin transfer parity
- Every new bot-wallet withdrawal is posted as a live actionable card to `notify.bot_withdrawals`; the same channel message is stored and edited through processing, success, rejection, or admin-review states. Automatic execution follows the reference flow: read configured source balances, choose the source, review a confirmation card, then issue exactly one financial POST after the final confirmation.
- Confirmed withdrawal success notifies the user only after final settlement. Explicit admin rejection is the only rejection path that notifies the user. Timeout/network/5xx or any uncertain provider outcome stays admin-only in review and sends no user result.
- Sham Cash withdrawal cards keep the verified recipient account name and resolve the real provider transaction number after a successful POST using read-only outgoing-history reconciliation; the financial POST is never repeated for that lookup.
- The bot-deposit channel remains success-only. Manual pending-deposit review is kept separate from operation notifications.
- Added the admin manual-transfer section with Sham Cash/Syriatel source selection, live source balance, recipient, amount, confirmation, provider transaction reference, before/after balance, and paged immutable success audit. Sham Cash manual transfer intentionally omits the optional note field.
- Added read-only transaction search for Sham Cash, Syriatel Cash, and local bot records; it never credits a wallet or sends a financial transfer.
- Manual-transfer intent claims are durable so a repeated confirmation cannot issue the same financial POST twice; uncertain outcomes require admin review rather than an automatic retry.
- Migration `0009` stores withdrawal-channel message identity and the durable manual-transfer intent/audit tables.
- Callback-ACK, latency, and core UI speed-patch files remain unchanged.

### v0.5.9 multi-provider TSA + finance completion
- Added a runtime-selectable payment-provider layer. API SYRIA remains available and TSA API is added without changing wallet accounting or withdrawal idempotency. Only one provider is active at a time from **إدارة الشحن والسحب → مزود API**.
- Provider selection is frozen per financial operation. There is deliberately no automatic provider fallback after a financial POST, preventing cross-provider double payout after timeout or uncertain outcomes.
- The selected provider id is persisted before withdrawal/manual-transfer execution and retained in audit payloads for restart/reconciliation safety.
- TSA integration includes status/accounts, Sham Cash balance/logs/find/resolve/transfer, Syriatel balance/find/outgoing/transfer, Cash Code→GSM mapping, successful-incoming validation, and direct `tran_id` support.
- Added encrypted optional Sham Cash PIN support for TSA.
- Added independent admin-editable USD/USDT conversion rates for Sham USD, Whish Money, Binance TRC20, and Binance BEP20.
- `/start`, `/menu`, and main-menu navigation now respect the active deposit-verification guard so one user cannot start a second flow while a provider lookup is still in progress.
- Existing v0.5.8 withdrawal-channel processing/success cards, split deposit/withdraw notification channels, manual-transfer one-POST safety, and Julia finance behavior are preserved.

