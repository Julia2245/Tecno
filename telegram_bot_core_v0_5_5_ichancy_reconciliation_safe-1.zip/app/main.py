from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import aiohttp
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode

from app.config import get_settings
from app.core.db import Database
from app.core.logging import configure_logging
from app.middlewares.callback_ack import FastCallbackAckMiddleware
from app.middlewares.latency import UpdateLatencyMiddleware
from app.repositories.users import UserRepository
from app.repositories.deposits import DepositRepository
from app.repositories.wallet import WalletRepository
from app.repositories.runtime_settings import RuntimeSettingsRepository
from app.repositories.outbox import OutboxRepository
from app.repositories.ichancy import IchancyRepository
from app.repositories.ichancy_jobs import IchancyJobRepository
from app.repositories.withdrawals import WithdrawRepository
from app.repositories.ichancy_replacements import CashierReplacementRepository
from app.routers import build_root_router
from app.services.users import UserService
from app.services.deposits import DepositService
from app.providers.api_syria import ApiSyriaClient
from app.providers.binance import BinanceDepositClient
from app.services.wallet import WalletService
from app.services.runtime_settings import RuntimeSettingsService
from app.services.outbox import NotificationOutboxWorker
from app.services.ichancy_accounts import IchancyAccountsService
from app.services.ichancy_jobs import IchancyJobService
from app.services.withdrawals import WithdrawService
from app.services.ichancy_replacements import CashierReplacementService
from app.core.crypto import CredentialCipher

logger = logging.getLogger(__name__)
PROJECT_ROOT = Path(__file__).resolve().parent.parent


async def run() -> None:
    settings = get_settings()
    configure_logging(settings.log_level)

    db = Database(
        settings.database_url,
        min_size=settings.pg_pool_min,
        max_size=settings.pg_pool_max,
        command_timeout=settings.pg_command_timeout,
    )
    await db.connect()
    await db.apply_migrations(PROJECT_ROOT / "migrations")

    session = AiohttpSession(limit=settings.telegram_connection_limit)
    bot = Bot(
        token=settings.bot_token,
        session=session,
        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML,
            link_preview_is_disabled=True,
        ),
    )
    dp = Dispatcher()

    # Fast callback ACK is deliberately isolated from business logic.
    dp.callback_query.middleware(FastCallbackAckMiddleware())
    dp.update.outer_middleware(UpdateLatencyMiddleware(settings.slow_update_warning_ms))
    dp.include_router(build_root_router())

    user_repository = UserRepository(db)
    user_service = UserService(user_repository)
    wallet_repository = WalletRepository(db)
    wallet_service = WalletService(wallet_repository)
    deposit_repository = DepositRepository(db)
    runtime_repository = RuntimeSettingsRepository(db)
    runtime_settings = RuntimeSettingsService(
        runtime_repository,
        default_overrides={
            "ichancy.username_prefix": settings.ichancy_username_prefix,
            # Runtime-editable receiving accounts.  The .env values remain the
            # bootstrap/fallback values for a fresh database only.
            "deposit.syriatel.codes": ",".join(settings.syriatel_codes),
            "deposit.sham.address_syp": settings.shamcash_address_syp.strip(),
            "deposit.sham.address_usd": settings.shamcash_address_usd.strip(),
        },
    )
    await runtime_settings.load()
    outbox_repository = OutboxRepository(db)
    outbox_worker = NotificationOutboxWorker(outbox_repository, runtime_settings, bot)
    ichancy_repository = IchancyRepository(db)
    ichancy_job_repository = IchancyJobRepository(db)
    withdraw_repository = WithdrawRepository(db)
    # A restart while a provider POST was in-flight must never silently re-send it.
    # Any stale `processing` request is moved to manual review; explicit
    # `provider_success` rows remain locally finalizable without another POST.
    recovered_withdraws = await withdraw_repository.recover_stale_processing()
    if recovered_withdraws:
        logger.warning("Recovered %s interrupted withdrawal(s) to needs_review", recovered_withdraws)
    replacement_repository = CashierReplacementRepository(db)

    provider_session = aiohttp.ClientSession(
        connector=aiohttp.TCPConnector(limit=40, ttl_dns_cache=300),
        timeout=aiohttp.ClientTimeout(total=30),
        headers={"Accept": "application/json"},
    )
    api_syria = ApiSyriaClient(
        provider_session,
        base_url=settings.api_syria_base_url,
        api_key=settings.api_syria_key,
    )
    binance_client = BinanceDepositClient(
        provider_session,
        api_key=settings.binance_api_key,
        api_secret=settings.binance_api_secret,
        base_url=settings.binance_base_url,
    )
    deposit_service = DepositService(
        deposit_repository,
        wallet_service,
        settings,
        api_syria,
        binance_client,
        runtime_settings,
        outbox_repository,
        outbox_worker,
    )
    withdraw_service = WithdrawService(
        withdraw_repository,
        wallet_service,
        runtime_settings,
        settings,
        api_syria,
        outbox_worker,
        deposit_repository,
    )

    cipher = None
    if settings.ichancy_credentials_key:
        try:
            cipher = CredentialCipher(settings.ichancy_credentials_key)
        except Exception:
            logger.exception("Invalid ICHANCY_CREDENTIALS_KEY; iChancy credential operations disabled")
    ichancy_accounts = IchancyAccountsService(
        ichancy_repository, runtime_settings, settings, provider_session, cipher
    )
    if settings.ichancy_api_username and settings.ichancy_api_password:
        try:
            await ichancy_accounts.bootstrap_from_env()
        except Exception:
            logger.exception("Could not bootstrap iChancy cashier from environment")

    ichancy_jobs = IchancyJobService(
        ichancy_job_repository, ichancy_repository, ichancy_accounts, wallet_service, runtime_settings, outbox_worker, bot
    )
    replacement_service = CashierReplacementService(
        replacement_repository, ichancy_repository, ichancy_accounts, ichancy_job_repository,
        ichancy_jobs, wallet_service, runtime_settings, outbox_repository, outbox_worker, bot,
    )
    outbox_task = asyncio.create_task(outbox_worker.run(), name="notification-outbox-worker")
    ichancy_task = asyncio.create_task(
        ichancy_jobs.run_worker(settings.ichancy_worker_poll_seconds, settings.ichancy_reconcile_delay_seconds),
        name="ichancy-financial-worker",
    )
    replacement_task = asyncio.create_task(
        replacement_service.run_worker(), name="ichancy-cashier-replacement-worker"
    )

    try:
        me = await bot.get_me()
        if not settings.bot_display_name:
            # Mutable runtime display label only; no project branding is hardcoded.
            settings.bot_display_name = me.first_name or "البوت"
        logger.info("Starting @%s (%s)", me.username or "", me.id)

        # False by default so a restart never silently discards legitimate updates.
        await bot.delete_webhook(drop_pending_updates=settings.drop_pending_updates)
        await dp.start_polling(
            bot,
            settings=settings,
            db=db,
            user_service=user_service,
            wallet_service=wallet_service,
            deposit_service=deposit_service,
            runtime_settings=runtime_settings,
            outbox_worker=outbox_worker,
            ichancy_accounts=ichancy_accounts,
            ichancy_jobs=ichancy_jobs,
            withdraw_service=withdraw_service,
            replacement_repository=replacement_repository,
            replacement_service=replacement_service,
            allowed_updates=dp.resolve_used_update_types(),
            tasks_concurrency_limit=settings.max_concurrent_updates,
            close_bot_session=False,
        )
    finally:
        ichancy_jobs.stop()
        replacement_service.stop()
        outbox_worker.stop()
        for task in (replacement_task, ichancy_task, outbox_task):
            task.cancel()
        await asyncio.gather(replacement_task, ichancy_task, outbox_task, return_exceptions=True)
        await provider_session.close()
        await db.close()
        await bot.session.close()


def main() -> None:
    asyncio.run(run())


if __name__ == "__main__":
    main()
