from __future__ import annotations

import html
import math
from uuid import UUID

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from aiogram import Bot

from app.config import Settings
from app.core.ui import safe_edit
from app.services.gifts_loyalty import GiftService, LoyaltyService
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin_gifts_loyalty")
PAGE=10

class Batch5AdminStates(StatesGroup):
    input=State()


def _admin(uid:int,settings:Settings)->bool: return int(uid) in settings.super_admin_ids

def _btn(text,data): return InlineKeyboardButton(text=text,callback_data=data)

def _digits(raw:str)->str:
    return str(raw or '').translate(str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹","01234567890123456789")).replace(',','').replace('٬','').strip()

async def _home_text(gift:GiftService,loyalty:LoyaltyService)->str:
    stats=await loyalty.stats(); cfg=loyalty.config()
    return (
        "🎁 <b>الهدايا ونقاط الولاء</b>\n\n"
        f"إهداء الرصيد: <b>{'✅ مفعّل' if gift.enabled() else '⛔ متوقف'}</b>\n"
        f"نقاط الولاء: <b>{'✅ مفعلة' if cfg['enabled'] else '⛔ متوقفة'}</b>\n"
        f"⭐ النقاط الحالية: <code>{stats['outstanding']:,}</code>\n"
        f"👥 أصحاب نقاط: <code>{stats['holders']:,}</code>\n"
        f"⏳ مصالحة ولاء معلقة: <code>{stats['pending_reconciliation']:,}</code>\n"
        f"📦 طلبات جوائز عينية: <code>{stats['pending_claims']:,}</code>"
    )

def _home_kb()->InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn("🎁 إدارة الإهداء","admin:gifts"),_btn("🎟 أكواد الهدايا","admin:giftcodes")],
        [_btn("🏆 نقاط الولاء","admin:loyalty")],
        [_btn("⬅️ لوحة الإدارة","admin:home")],
    ])

@router.callback_query(F.data=="admin:benefits")
async def benefits_home(callback:CallbackQuery,state:FSMContext,settings:Settings,gift_service:GiftService,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.clear(); await safe_edit(callback,await _home_text(gift_service,loyalty_service),reply_markup=_home_kb())

# -------- gifting --------

def _gift_kb(enabled:bool)->InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn("⛔ إيقاف الإهداء" if enabled else "✅ تشغيل الإهداء","admin:gifts:toggle")],
        [_btn("📜 سجل الإهداء الأخير","admin:gifts:recent:0")],
        [_btn("⬅️ الهدايا والولاء","admin:benefits")],
    ])

@router.callback_query(F.data=="admin:gifts")
async def gifts_home(callback:CallbackQuery,settings:Settings,gift_service:GiftService)->None:
    if not _admin(callback.from_user.id,settings): return
    await safe_edit(callback,
        "🎁 <b>إدارة إهداء الرصيد</b>\n\n"
        f"الحالة: <b>{'✅ مفعّلة' if gift_service.enabled() else '⛔ متوقفة'}</b>\n\n"
        "الرصيد الناتج من أكواد الهدايا، جوائز الولاء، مكافآت الإحالات وعجلة الحظ يبقى قابلًا للاستخدام والسحب، لكنه غير قابل للإهداء لمستخدم آخر.",
        reply_markup=_gift_kb(gift_service.enabled()))

@router.callback_query(F.data=="admin:gifts:toggle")
async def gifts_toggle(callback:CallbackQuery,settings:Settings,gift_service:GiftService)->None:
    if not _admin(callback.from_user.id,settings): return
    await gift_service.set_enabled(not gift_service.enabled(),callback.from_user.id)
    await gifts_home(callback,settings,gift_service)

@router.callback_query(F.data.startswith("admin:gifts:recent:"))
async def gifts_recent(callback:CallbackQuery,settings:Settings,gift_service:GiftService)->None:
    if not _admin(callback.from_user.id,settings): return
    # Admin audit view directly reads immutable transfer history.
    page=max(0,int(callback.data.rsplit(':',1)[-1])); pool=gift_service.db.require_pool()
    async with pool.acquire() as conn:
        total=int(await conn.fetchval("SELECT COUNT(*) FROM bot_core.gift_transfers") or 0)
        rows=await conn.fetch("SELECT * FROM bot_core.gift_transfers ORDER BY created_at DESC LIMIT $1 OFFSET $2",PAGE,page*PAGE)
    lines=["📜 <b>آخر عمليات الإهداء</b>",""]
    for r in rows: lines.append(f"<code>{int(r['from_telegram_id'])}</code> → <code>{int(r['to_telegram_id'])}</code>\n💰 <code>{int(r['amount_syp']):,}</code> SYP\n🕒 <code>{r['created_at']}</code>")
    if not rows: lines.append("لا توجد عمليات إهداء.")
    pages=max(1,math.ceil(total/PAGE)); nav=[]
    if page>0: nav.append(_btn("⬅️",f"admin:gifts:recent:{page-1}"))
    nav.append(_btn(f"{page+1}/{pages}","noop"))
    if page+1<pages: nav.append(_btn("➡️",f"admin:gifts:recent:{page+1}"))
    await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=[nav,[_btn("⬅️ الإهداء","admin:gifts")]]))

# -------- gift codes --------

def _codes_kb()->InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn("🎟 مفرد عام","admin:giftcodes:new:single"),_btn("👥 متعدد الاستخدام","admin:giftcodes:new:multi")],
        [_btn("🔒 خاص لمستخدم","admin:giftcodes:new:private"),_btn("📚 دفعة أكواد","admin:giftcodes:new:batch")],
        [_btn("🎭 أكواد وهمية","admin:giftcodes:new:fake"),_btn("📋 سجل الاستخدام","admin:giftcodes:uses:0")],
        [_btn("⛔ إنهاء كود","admin:giftcodes:disable"),_btn("📋 الأكواد الفعالة","admin:giftcodes:list:active:0")],
        [_btn("🗃 المنتهية","admin:giftcodes:list:ended:0"),_btn("⚙️ مهلة الاستخدام","admin:giftcodes:cooldown")],
        [_btn("📢 قناة إشعارات المكافآت","admin:giftcodes:channel")],
        [_btn("⬅️ الهدايا والولاء","admin:benefits")],
    ])

@router.callback_query(F.data=="admin:giftcodes")
async def codes_home(callback:CallbackQuery,settings:Settings,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(callback.from_user.id,settings): return
    cooldown=max(0,runtime_settings.get_int("gift.code_cooldown_minutes",0)); ch=str(runtime_settings.get("notify.admin_events") or "-")
    await safe_edit(callback,
        "🎟 <b>إدارة أكواد الهدايا</b>\n\n"
        f"⏱ المهلة بين استخدام كودين لنفس المستخدم: <code>{cooldown}</code> دقيقة\n"
        f"📢 قناة إشعارات الاستخدام/الولاء: <code>{html.escape(ch)}</code>\n\n"
        "الكود الخاص يُستخدم من مستخدم واحد محدد. الكود المتعدد يسمح لعدة مستخدمين مختلفين ضمن الحد، وكل مستخدم مرة واحدة.",reply_markup=_codes_kb())

@router.callback_query(F.data.startswith("admin:giftcodes:new:"))
async def code_new(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    kind=callback.data.rsplit(':',1)[-1]
    if kind not in {'single','multi','private','batch','fake'}: return
    await state.set_state(Batch5AdminStates.input)
    if kind=='fake':
        await state.set_data({"flow":"code_new","kind":kind,"step":"fake_count"})
        await safe_edit(callback,"🎭 أرسل عدد الأكواد الوهمية المراد إنشاؤها (1-200):\n\nهذه الأكواد لا تمنح أي رصيد، وتظهر للمستخدم كأنها مستخدمة مسبقًا.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:giftcodes")]])); return
    await state.set_data({"flow":"code_new","kind":kind,"step":"amount"})
    await safe_edit(callback,"💰 أرسل قيمة كود الهدية بالليرة السورية:",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:giftcodes")]]))

@router.callback_query(F.data=="admin:giftcodes:disable")
async def code_disable_start(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.set_state(Batch5AdminStates.input); await state.set_data({"flow":"code_disable"})
    await safe_edit(callback,"⛔ أرسل الكود الذي تريد إنهاءه فورًا:",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:giftcodes")]]))

@router.callback_query(F.data.in_({"admin:giftcodes:cooldown","admin:giftcodes:channel"}))
async def code_setting_start(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    flow="code_cooldown" if callback.data.endswith('cooldown') else "admin_channel"
    await state.set_state(Batch5AdminStates.input); await state.set_data({"flow":flow})
    prompt="⏱ أرسل عدد الدقائق بين استخدام كودين لنفس المستخدم (0 لإلغاء المهلة):" if flow=='code_cooldown' else "📢 أرسل Chat ID القناة أو @username. أرسل 0 لمسح القناة:"
    await safe_edit(callback,prompt,reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:giftcodes")]]))

@router.callback_query(F.data.startswith("admin:giftcodes:list:"))
async def codes_list(callback:CallbackQuery,settings:Settings,gift_service:GiftService)->None:
    if not _admin(callback.from_user.id,settings): return
    p=callback.data.split(':'); active=p[3]=='active'; page=max(0,int(p[4])); rows,total=await gift_service.repo.list_codes(active=active,limit=PAGE,offset=page*PAGE)
    lines=["🎟 <b>الأكواد الفعالة</b>" if active else "🗃 <b>الأكواد المنتهية</b>",""]
    kb=[]
    for r in rows:
        lines.append(f"<code>{html.escape(str(r['code']))}</code>\n💰 {int(r['amount_syp']):,} SYP • 📊 {int(r['uses_count'])}/{int(r['max_uses'])}"+(f" • 🔒 {int(r['target_telegram_id'])}" if r['target_telegram_id'] is not None else ""))
        if active: kb.append([_btn(f"⛔ {str(r['code'])[:25]}",f"admin:giftcodes:disable_now:{r['code']}")])
    if not rows: lines.append("لا توجد أكواد في هذه القائمة.")
    pages=max(1,math.ceil(total/PAGE)); nav=[]
    if page>0: nav.append(_btn("⬅️",f"admin:giftcodes:list:{'active' if active else 'ended'}:{page-1}"))
    nav.append(_btn(f"{page+1}/{pages}","noop"))
    if page+1<pages: nav.append(_btn("➡️",f"admin:giftcodes:list:{'active' if active else 'ended'}:{page+1}"))
    kb += [nav,[_btn("⬅️ أكواد الهدايا","admin:giftcodes")]]
    await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith("admin:giftcodes:disable_now:"))
async def code_disable_now(callback:CallbackQuery,settings:Settings,gift_service:GiftService)->None:
    if not _admin(callback.from_user.id,settings): return
    code=callback.data.split(':',3)[3].strip().upper(); ok=await gift_service.repo.disable_code(code,callback.from_user.id)
    await callback.answer("✅ تم إنهاء الكود." if ok else "الكود غير موجود.",show_alert=True)
    await codes_home(callback,settings,gift_service.runtime)

@router.callback_query(F.data.startswith("admin:giftcodes:uses:"))
async def code_uses_log(callback:CallbackQuery,settings:Settings,gift_service:GiftService)->None:
    if not _admin(callback.from_user.id,settings): return
    page=max(0,int(callback.data.rsplit(':',1)[-1])); rows,total=await gift_service.repo.code_redemptions_admin(limit=PAGE,offset=page*PAGE)
    lines=["📋 <b>سجل استخدام أكواد الهدايا</b>",""]
    for r in rows:
        user=(f"@{html.escape(str(r['username']))}" if r['username'] else html.escape(str(r['first_name'] or '-')))
        lines.append(f"🎟 <code>{html.escape(str(r['code']))}</code>\n👤 {user} • <code>{int(r['telegram_id'])}</code>\n💰 <code>{int(r['amount_syp']):,}</code> SYP\n🕒 <code>{r['used_at']}</code>")
    if not rows: lines.append("لا توجد استخدامات حتى الآن.")
    pages=max(1,math.ceil(total/PAGE)); nav=[]
    if page>0: nav.append(_btn("⬅️",f"admin:giftcodes:uses:{page-1}"))
    nav.append(_btn(f"{page+1}/{pages}","noop"))
    if page+1<pages: nav.append(_btn("➡️",f"admin:giftcodes:uses:{page+1}"))
    await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=[nav,[_btn("⬅️ أكواد الهدايا","admin:giftcodes")]]))

# -------- loyalty admin --------

def _loyalty_kb(enabled:bool)->InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn("⛔ إيقاف النظام" if enabled else "✅ تشغيل النظام","admin:loyalty:toggle"),_btn("📊 الإحصائيات","admin:loyalty:stats")],
        [_btn("👥 أرصدة المستخدمين","admin:loyalty:holders:0"),_btn("🔎 بحث عن مستخدم","admin:loyalty:search")],
        [_btn("🛠 تعديل نقاط بالمعرف","admin:loyalty:adjust")],
        [_btn("💳 معدل الكسب","admin:loyalty:set:earn"),_btn("📏 حد الشحن","admin:loyalty:set:min")],
        [_btn("🎁 إدارة الجوائز","admin:loyalty:rewards:0"),_btn("📦 طلبات الجوائز","admin:loyalty:claims:0")],
        [_btn("🗑 تصفير كل النقاط","admin:loyalty:reset")],
        [_btn("⬅️ الهدايا والولاء","admin:benefits")],
    ])

@router.callback_query(F.data=="admin:loyalty")
async def loyalty_home(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    cfg=loyalty_service.config(); rewards,total=await loyalty_service.repo.rewards(include_disabled=True,limit=1); _=rewards
    claims,pending=await loyalty_service.repo.pending_claims(limit=1); _=claims
    await safe_edit(callback,
        "🏆 <b>إدارة نقاط الولاء</b>\n\n"
        f"الحالة: <b>{'✅ مفعلة' if cfg['enabled'] else '⛔ متوقفة'}</b>\n"
        f"معدل الكسب: كل <code>{cfg['earn_syp_per_point']:,}</code> SYP من أصل الشحن الحقيقي = نقطة\n"
        f"الحد الأدنى للشحن: <code>{cfg['min_deposit_syp']:,}</code> SYP\n"
        f"الجوائز المسجلة: <code>{total:,}</code>\n📦 طلبات عينية معلقة: <code>{pending:,}</code>\n\n"
        "البونصات والأرصدة المجانية لا تولّد نقاط ولاء.",reply_markup=_loyalty_kb(cfg['enabled']))

@router.callback_query(F.data=="admin:loyalty:toggle")
async def loyalty_toggle(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    await loyalty_service.set_config("loyalty.enabled",not loyalty_service.config()['enabled'],callback.from_user.id)
    await loyalty_home(callback,settings,loyalty_service)

@router.callback_query(F.data=="admin:loyalty:stats")
async def loyalty_stats(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    x=await loyalty_service.stats()
    await safe_edit(callback,
        "📊 <b>إحصائيات نقاط الولاء</b>\n\n"
        f"الحسابات: <code>{x['accounts']:,}</code>\n👥 أصحاب نقاط: <code>{x['holders']:,}</code>\n"
        f"📈 المكتسب تاريخيًا: <code>{x['earned']:,}</code>\n🎁 المستبدل/المحجوز: <code>{x['redeemed']:,}</code>\n"
        f"⭐ النقاط الحالية: <code>{x['outstanding']:,}</code>\n⏳ مصالحة معلقة: <code>{x['pending_reconciliation']:,}</code>\n"
        f"📦 طلبات جوائز عينية: <code>{x['pending_claims']:,}</code>",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ نقاط الولاء","admin:loyalty")]]))

async def _render_loyalty_user(callback:CallbackQuery,tg:int,page:int,loyalty_service:LoyaltyService)->None:
    row=await loyalty_service.repo.loyalty_user(int(tg))
    if not row:
        await callback.answer("المستخدم غير موجود.",show_alert=True); return
    uname=f"@{html.escape(str(row['username']))}" if row['username'] else "بدون يوزر"
    text=(
        "👤 <b>بطاقة نقاط الولاء</b>\n\n"
        f"الاسم: <b>{html.escape(str(row['first_name'] or '-'))}</b>\n"
        f"اليوزر: {uname}\n🆔 <code>{int(row['telegram_id'])}</code>\n"
        f"الحالة: <b>{'⛔ محظور' if row['is_blocked'] else '✅ فعال'}</b>\n\n"
        f"⭐ النقاط الحالية: <b>{int(row['points']):,}</b>\n"
        f"📈 المكتسب تاريخيًا: <code>{int(row['total_earned']):,}</code>\n"
        f"🎁 المستبدل/المحجوز: <code>{int(row['total_redeemed']):,}</code>"
    )
    kb=InlineKeyboardMarkup(inline_keyboard=[
        [_btn("✏️ تعيين",f"a5:pa:set:{int(tg)}:{int(page)}"),_btn("➕ إضافة",f"a5:pa:add:{int(tg)}:{int(page)}"),_btn("➖ خصم",f"a5:pa:sub:{int(tg)}:{int(page)}")],
        [_btn("📜 سجل النقاط",f"a5:lh:{int(tg)}:0:{int(page)}")],
        [_btn("⬅️ القائمة",f"admin:loyalty:holders:{max(0,int(page))}")],
    ])
    await safe_edit(callback,text,reply_markup=kb)

@router.callback_query(F.data.startswith("admin:loyalty:holders:"))
async def loyalty_holders(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    page=max(0,int(callback.data.rsplit(':',1)[-1])); rows,total,total_points=await loyalty_service.repo.loyalty_holders(limit=PAGE,offset=page*PAGE)
    lines=["👥 <b>أرصدة نقاط الولاء</b>","",f"المستخدمون: <code>{total:,}</code> • مجموع النقاط: <code>{total_points:,}</code>",""]
    kb=[]
    for r in rows:
        label=f"⭐ {int(r['points_spent']):,} | "+(f"@{str(r['username'])}" if r['username'] else f"ID {int(r['telegram_id'])}")
        kb.append([_btn(label[:55],f"a5:lu:{int(r['telegram_id'])}:{page}")])
    if not rows: lines.append("لا يوجد مستخدمون لديهم نقاط.")
    pages=max(1,math.ceil(total/PAGE)); nav=[]
    if page>0: nav.append(_btn("⬅️",f"admin:loyalty:holders:{page-1}"))
    nav.append(_btn(f"{page+1}/{pages}","noop"))
    if page+1<pages: nav.append(_btn("➡️",f"admin:loyalty:holders:{page+1}"))
    kb.append(nav); kb.append([_btn("🔎 بحث عن مستخدم","admin:loyalty:search")]); kb.append([_btn("⬅️ نقاط الولاء","admin:loyalty")])
    await safe_edit(callback,"\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith("a5:lu:"))
async def loyalty_user_detail(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    p=callback.data.split(':'); await _render_loyalty_user(callback,int(p[2]),int(p[3]),loyalty_service)

@router.callback_query(F.data=="admin:loyalty:search")
async def loyalty_search_start(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.set_state(Batch5AdminStates.input); await state.set_data({"flow":"loyalty_search"})
    await safe_edit(callback,"🔎 أرسل Telegram ID أو @username للمستخدم:",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:loyalty")]]))

@router.callback_query(F.data.startswith("a5:lh:"))
async def loyalty_user_history_admin(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    p=callback.data.split(':'); tg=int(p[2]); hpage=max(0,int(p[3])); back_page=max(0,int(p[4]))
    rows,total=await loyalty_service.repo.loyalty_history(tg,limit=PAGE,offset=hpage*PAGE)
    names={'earn':'اكتساب من شحن','reward_balance':'جائزة رصيد','reward_request':'طلب جائزة','reward_refund':'إرجاع نقاط','admin_adjust':'تعديل إداري','admin_reset':'تصفير إداري'}
    lines=[f"📜 <b>سجل نقاط المستخدم</b> <code>{tg}</code>",""]
    for r in rows:
        lines.append(f"{names.get(str(r['event_type']),str(r['event_type']))}: <code>{int(r['points_delta']):+,}</code>\n🕒 <code>{r['created_at']}</code>")
    if not rows: lines.append("لا يوجد سجل نقاط لهذا المستخدم.")
    pages=max(1,math.ceil(total/PAGE)); nav=[]
    if hpage>0: nav.append(_btn("⬅️",f"a5:lh:{tg}:{hpage-1}:{back_page}"))
    nav.append(_btn(f"{hpage+1}/{pages}","noop"))
    if hpage+1<pages: nav.append(_btn("➡️",f"a5:lh:{tg}:{hpage+1}:{back_page}"))
    await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=[nav,[_btn("⬅️ المستخدم",f"a5:lu:{tg}:{back_page}")]]))

@router.callback_query(F.data.startswith("a5:pa:"))
async def loyalty_adjust_from_user(callback:CallbackQuery,state:FSMContext,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    p=callback.data.split(':'); mode=p[2]; tg=int(p[3]); page=int(p[4])
    if mode not in {'set','add','sub'}: return
    row=await loyalty_service.repo.loyalty_user(tg)
    if not row: await callback.answer("المستخدم غير موجود.",show_alert=True); return
    await state.set_state(Batch5AdminStates.input); await state.set_data({"flow":"loyalty_adjust_direct_value","mode":mode,"tg":tg,"return_page":page})
    label={'set':'تعيين الرصيد إلى','add':'إضافة نقاط','sub':'خصم نقاط'}[mode]
    await safe_edit(callback,f"🛠 {label} للمستخدم <code>{tg}</code>\n\nالنقاط الحالية: <b>{int(row['points']):,}</b>\nأرسل القيمة الرقمية:",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء",f"a5:lu:{tg}:{page}")]]))

@router.callback_query(F.data.in_({"a5:p:y","a5:p:n"}))
async def loyalty_adjust_confirm(callback:CallbackQuery,state:FSMContext,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    d=await state.get_data()
    if str(d.get('flow'))!='loyalty_adjust_confirm': await callback.answer("انتهت جلسة التعديل.",show_alert=True); return
    tg=int(d['tg']); page=int(d.get('return_page',0))
    if callback.data.endswith(':n'):
        await state.clear(); await _render_loyalty_user(callback,tg,page,loyalty_service); return
    try: r=await loyalty_service.adjust_points(tg,str(d['mode']),int(d['value']),callback.from_user.id,expected_old=int(d['expected_old']))
    except Exception as exc: await callback.answer(str(exc)[:180],show_alert=True); return
    await state.clear(); await callback.answer(f"✅ {r['old_points']:,} → {r['new_points']:,}",show_alert=True); await _render_loyalty_user(callback,tg,page,loyalty_service)

@router.callback_query(F.data.in_({"admin:loyalty:set:earn","admin:loyalty:set:min","admin:loyalty:adjust"}))
async def loyalty_input_start(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    flow="loyalty_earn" if callback.data.endswith('earn') else "loyalty_min" if callback.data.endswith('min') else "loyalty_adjust_user"
    await state.set_state(Batch5AdminStates.input); await state.set_data({"flow":flow})
    prompt={"loyalty_earn":"أرسل عدد SYP المطلوب لكل نقطة واحدة:","loyalty_min":"أرسل الحد الأدنى للشحن المحتسب بالنقاط:","loyalty_adjust_user":"أرسل Telegram ID للمستخدم:"}[flow]
    await safe_edit(callback,prompt,reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:loyalty")]]))

@router.callback_query(F.data=="admin:loyalty:reset")
async def loyalty_reset_prompt(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    x=await loyalty_service.stats()
    await safe_edit(callback,
        "⚠️ <b>تأكيد تصفير جميع النقاط</b>\n\n"
        f"👥 أصحاب نقاط: <code>{x['holders']:,}</code>\n⭐ سيتم تصفير: <code>{x['outstanding']:,}</code> نقطة\n\n"
        "السجل التاريخي والجوائز السابقة لن تُحذف.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ نعم، صفّر الجميع","admin:loyalty:reset_do")],[_btn("❌ إلغاء","admin:loyalty")]]))

@router.callback_query(F.data=="admin:loyalty:reset_do")
async def loyalty_reset_do(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    try: r=await loyalty_service.reset_all(callback.from_user.id)
    except Exception as exc: await callback.answer(str(exc)[:180],show_alert=True); return
    await safe_edit(callback,f"✅ تم التصفير.\n\n👥 المستخدمون: <code>{r['affected_users']}</code>\n⭐ النقاط: <code>{r['total_points_reset']:,}</code>",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ نقاط الولاء","admin:loyalty")]]))

async def _render_loyalty_rewards(callback:CallbackQuery,page:int,loyalty_service:LoyaltyService)->None:
    page=max(0,int(page)); rows,total=await loyalty_service.repo.rewards(include_disabled=True,limit=6,offset=page*6)
    lines=["🎁 <b>إدارة جوائز الولاء</b>",""]
    kb=[[_btn("➕ جائزة رصيد","admin:loyalty:reward_new:balance"),_btn("➕ جائزة عينية","admin:loyalty:reward_new:manual")]]
    for r in rows:
        lines.append(f"#{int(r['id'])} {'✅' if r['enabled'] else '⛔'} {html.escape(str(r['name']))}\n⭐ {int(r['points_cost']):,}"+(f" • 💰 {int(r['balance_amount_syp']):,} SYP" if r['reward_type']=='balance' else (f" • 📦 {int(r['remaining_stock']):,}" if r['remaining_stock'] is not None else " • 📦 غير محدود")))
        kb.append([_btn(f"{'⛔ إيقاف' if r['enabled'] else '✅ تشغيل'} #{r['id']}",f"admin:loyalty:reward_toggle:{r['id']}")])
    if not rows: lines.append("لا توجد جوائز بعد.")
    pages=max(1,math.ceil(total/6)); nav=[]
    if page>0: nav.append(_btn("⬅️",f"admin:loyalty:rewards:{page-1}"))
    if page+1<pages: nav.append(_btn("➡️",f"admin:loyalty:rewards:{page+1}"))
    if nav: kb.append(nav)
    kb.append([_btn("⬅️ نقاط الولاء","admin:loyalty")]); await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith("admin:loyalty:rewards:"))
async def loyalty_rewards(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    page=max(0,int(callback.data.rsplit(':',1)[-1])); await _render_loyalty_rewards(callback,page,loyalty_service)

@router.callback_query(F.data.startswith("admin:loyalty:reward_toggle:"))
async def reward_toggle(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    rid=int(callback.data.rsplit(':',1)[-1]); await loyalty_service.toggle_reward(rid); await callback.answer("✅ تم تحديث حالة الجائزة."); await _render_loyalty_rewards(callback,0,loyalty_service)

@router.callback_query(F.data.startswith("admin:loyalty:reward_new:"))
async def reward_new(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    rtype=callback.data.rsplit(':',1)[-1]
    await state.set_state(Batch5AdminStates.input); await state.set_data({"flow":"reward_new","rtype":rtype,"step":"name"})
    await safe_edit(callback,"🎁 أرسل اسم الجائزة:",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:loyalty:rewards:0")]]))

async def _render_loyalty_claims(callback:CallbackQuery,page:int,loyalty_service:LoyaltyService)->None:
    page=max(0,int(page)); rows,total=await loyalty_service.repo.pending_claims(limit=6,offset=page*6)
    lines=["📦 <b>طلبات الجوائز العينية</b>",""]; kb=[]
    for r in rows:
        lines.append(f"🧾 <code>{r['id']}</code>\n👤 <code>{int(r['telegram_id'])}</code>\n🎁 {html.escape(str(r['reward_name']))}\n⭐ {int(r['points_spent']):,}")
        kb.append([_btn("✅ تم التسليم",f"a5:c:{r['id']}:y"),_btn("❌ رفض وإرجاع النقاط",f"a5:c:{r['id']}:n")])
    if not rows: lines.append("لا توجد طلبات معلقة.")
    pages=max(1,math.ceil(total/6)); nav=[]
    if page>0: nav.append(_btn("⬅️",f"admin:loyalty:claims:{page-1}"))
    if page+1<pages: nav.append(_btn("➡️",f"admin:loyalty:claims:{page+1}"))
    if nav: kb.append(nav)
    kb.append([_btn("⬅️ نقاط الولاء","admin:loyalty")]); await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))

@router.callback_query(F.data.startswith("admin:loyalty:claims:"))
async def loyalty_claims(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService)->None:
    if not _admin(callback.from_user.id,settings): return
    page=max(0,int(callback.data.rsplit(':',1)[-1])); await _render_loyalty_claims(callback,page,loyalty_service)

@router.callback_query(F.data.startswith("a5:c:"))
async def claim_decide(callback:CallbackQuery,settings:Settings,loyalty_service:LoyaltyService,bot:Bot)->None:
    if not _admin(callback.from_user.id,settings): return
    p=callback.data.split(':'); cid=UUID(p[2]); approve=p[3]=='y'
    try: r=await loyalty_service.decide_claim(cid,approve,callback.from_user.id)
    except Exception as exc: await callback.answer(str(exc)[:180],show_alert=True); return
    try:
        text=("✅ تم تأكيد تسليم جائزة الولاء الخاصة بك." if approve else f"↩️ تم رفض طلب جائزة الولاء وأُعيدت <b>{int(r['points']):,}</b> نقطة إلى حسابك.")
        await bot.send_message(int(r['telegram_id']),text)
    except Exception:
        pass
    await callback.answer("✅ تم تأكيد التسليم." if approve else "↩️ تم الرفض وإرجاع النقاط.",show_alert=True)
    await _render_loyalty_claims(callback,0,loyalty_service)

# -------- generic FSM input --------

@router.message(Batch5AdminStates.input)
async def batch5_input(message:Message,state:FSMContext,settings:Settings,gift_service:GiftService,loyalty_service:LoyaltyService,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(message.from_user.id,settings): return
    d=await state.get_data(); flow=str(d.get('flow') or ''); raw=(message.text or '').strip(); digits=_digits(raw)
    if flow=='code_disable':
        ok=await gift_service.repo.disable_code(raw.upper(),message.from_user.id); await state.clear(); await message.answer("✅ تم إنهاء الكود." if ok else "❌ الكود غير موجود.",reply_markup=_codes_kb()); return
    if flow=='code_cooldown':
        if not digits.isdigit(): await message.answer("❌ أرسل رقمًا صحيحًا."); return
        await runtime_settings.set("gift.code_cooldown_minutes",max(0,int(digits)),updated_by=message.from_user.id); await state.clear(); await message.answer("✅ تم تحديث مهلة أكواد الهدايا.",reply_markup=_codes_kb()); return
    if flow=='admin_channel':
        value="" if raw=='0' else raw
        await runtime_settings.set("notify.admin_events",value,updated_by=message.from_user.id); await state.clear(); await message.answer("✅ تم تحديث قناة إشعارات المكافآت.",reply_markup=_codes_kb()); return
    if flow=='loyalty_earn' or flow=='loyalty_min':
        if not digits.isdigit() or (flow=='loyalty_earn' and int(digits)<=0): await message.answer("❌ أرسل رقمًا صحيحًا."); return
        key="loyalty.earn_syp_per_point" if flow=='loyalty_earn' else "loyalty.min_deposit_syp"
        await loyalty_service.set_config(key,int(digits),message.from_user.id); await state.clear(); await message.answer("✅ تم حفظ إعداد نقاط الولاء.",reply_markup=_loyalty_kb(loyalty_service.config()['enabled'])); return
    if flow=='loyalty_search':
        row=await loyalty_service.repo.loyalty_user_search(raw)
        if not row: await message.answer("❌ المستخدم غير موجود. أرسل Telegram ID أو @username صحيحًا."); return
        await state.clear(); tg=int(row['telegram_id'])
        await message.answer(f"✅ تم العثور على المستخدم <code>{tg}</code>.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("👤 فتح بطاقة الولاء",f"a5:lu:{tg}:0")],[_btn("⬅️ نقاط الولاء","admin:loyalty")]])); return
    if flow=='loyalty_adjust_user':
        if not digits.isdigit(): await message.answer("❌ أرسل Telegram ID صحيحًا."); return
        row=await loyalty_service.repo.loyalty_user(int(digits))
        if not row: await message.answer("❌ المستخدم غير موجود."); return
        await state.update_data(flow='loyalty_adjust_value',tg=int(digits),return_page=0);
        await message.answer("أرسل التعديل بالشكل التالي:\n<code>+100</code> للإضافة\n<code>-50</code> للخصم\n<code>=0</code> للتعيين المباشر."); return
    if flow in {'loyalty_adjust_value','loyalty_adjust_direct_value'}:
        tg=int(d['tg']); current=await loyalty_service.repo.loyalty_user(tg)
        if not current: await message.answer("❌ المستخدم غير موجود."); return
        if flow=='loyalty_adjust_direct_value':
            if not digits.isdigit(): await message.answer("❌ أرسل رقمًا صحيحًا."); return
            mode=str(d['mode']); val=int(digits)
            if mode!='set' and val<=0: await message.answer("❌ القيمة يجب أن تكون أكبر من صفر."); return
        else:
            text=raw.replace(',','').strip(); mode=''; val=None
            if text.startswith('+') and text[1:].isdigit(): mode='add'; val=int(text[1:])
            elif text.startswith('-') and text[1:].isdigit(): mode='sub'; val=int(text[1:])
            elif text.startswith('=') and text[1:].isdigit(): mode='set'; val=int(text[1:])
            else: await message.answer("❌ استخدم +رقم أو -رقم أو =رقم."); return
        old=int(current['points']); new=val if mode=='set' else old+val if mode=='add' else old-val
        if new<0: await message.answer("❌ لا يمكن خصم نقاط أكثر من الرصيد الحالي."); return
        await state.update_data(flow='loyalty_adjust_confirm',mode=mode,value=int(val),tg=tg,expected_old=old,return_page=int(d.get('return_page',0)))
        await message.answer(
            "⚠️ <b>تأكيد تعديل نقاط الولاء</b>\n\n"
            f"👤 <code>{tg}</code>\n⭐ قبل: <code>{old:,}</code>\n⭐ بعد: <code>{new:,}</code>\n🔄 الفرق: <code>{new-old:+,}</code>",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ تأكيد","a5:p:y"),_btn("❌ إلغاء","a5:p:n")]])
        ); return
    if flow=='code_new':
        kind=str(d['kind']); step=str(d.get('step') or 'amount')
        if step=='amount':
            if not digits.isdigit() or int(digits)<=0: await message.answer("❌ أرسل قيمة صحيحة."); return
            await state.update_data(amount=int(digits))
            if kind=='single':
                code=await gift_service.create_code(int(digits),message.from_user.id); await state.clear(); await message.answer(f"✅ تم إنشاء الكود:\n<code>{code}</code>\n💰 {int(digits):,} SYP",reply_markup=_codes_kb()); return
            if kind=='multi': await state.update_data(step='uses'); await message.answer("👥 أرسل عدد الاستخدامات المسموح بها:"); return
            if kind=='private': await state.update_data(step='target'); await message.answer("🔒 أرسل Telegram ID للمستخدم المخصص له الكود:"); return
            if kind=='batch': await state.update_data(step='count'); await message.answer("📚 أرسل عدد الأكواد المراد إنشاؤها (1-200):"); return
        if step=='fake_count':
            if not digits.isdigit() or not 1<=int(digits)<=200: await message.answer("❌ العدد يجب أن يكون بين 1 و200."); return
            codes=await gift_service.create_fake_batch(message.from_user.id,int(digits)); await state.clear()
            await message.answer(f"🎭 تم إنشاء <b>{len(codes)}</b> كود وهمي. هذه الأكواد لا تمنح رصيدًا.")
            chunk=[]; size=0
            for c in codes:
                line=f"<code>{c}</code>"
                if chunk and size+len(line)+1>3000:
                    await message.answer("\n".join(chunk)); chunk=[]; size=0
                chunk.append(line); size += len(line)+1
            if chunk: await message.answer("\n".join(chunk))
            await message.answer("🎟 إدارة أكواد الهدايا",reply_markup=_codes_kb()); return
        amount=int(d['amount'])
        if step=='uses':
            if not digits.isdigit() or int(digits)<=0: await message.answer("❌ عدد غير صالح."); return
            code=await gift_service.create_code(amount,message.from_user.id,max_uses=int(digits)); await state.clear(); await message.answer(f"✅ الكود متعدد الاستخدام:\n<code>{code}</code>\n👥 الاستخدامات: {int(digits)}",reply_markup=_codes_kb()); return
        if step=='target':
            if not digits.isdigit(): await message.answer("❌ Telegram ID غير صالح."); return
            try: code=await gift_service.create_code(amount,message.from_user.id,target=int(digits))
            except Exception as exc: await message.answer(f"❌ {html.escape(str(exc))}"); return
            await state.clear(); await message.answer(f"✅ الكود الخاص:\n<code>{code}</code>\n👤 للمستخدم: <code>{int(digits)}</code>",reply_markup=_codes_kb()); return
        if step=='count':
            if not digits.isdigit() or not 1<=int(digits)<=200: await message.answer("❌ العدد يجب أن يكون بين 1 و200."); return
            codes=await gift_service.create_batch(amount,message.from_user.id,int(digits)); await state.clear()
            await message.answer(f"✅ تم إنشاء <b>{len(codes)}</b> كود بقيمة <b>{amount:,}</b> SYP لكل كود.")
            chunk=[]; size=0
            for c in codes:
                line=f"<code>{c}</code>"
                if chunk and size+len(line)+1>3000:
                    await message.answer("\n".join(chunk)); chunk=[]; size=0
                chunk.append(line); size += len(line)+1
            if chunk: await message.answer("\n".join(chunk))
            await message.answer("🎟 إدارة أكواد الهدايا",reply_markup=_codes_kb()); return
    if flow=='reward_new':
        rtype=str(d['rtype']); step=str(d.get('step') or 'name')
        if step=='name':
            if not raw or len(raw)>120: await message.answer("❌ اسم الجائزة غير صالح."); return
            await state.update_data(name=raw,step='cost'); await message.answer("⭐ أرسل تكلفة الجائزة بالنقاط:"); return
        if step=='cost':
            if not digits.isdigit() or int(digits)<=0: await message.answer("❌ تكلفة غير صالحة."); return
            await state.update_data(cost=int(digits),step='amount' if rtype=='balance' else 'stock'); await message.answer("💰 أرسل قيمة رصيد البوت بالـSYP:" if rtype=='balance' else "📦 أرسل المخزون (0 = غير محدود):"); return
        if step=='amount':
            if not digits.isdigit() or int(digits)<=0: await message.answer("❌ قيمة الرصيد غير صالحة."); return
            rid=await loyalty_service.create_reward(d['name'],rtype,int(d['cost']),message.from_user.id,balance_amount=int(digits)); await state.clear(); await message.answer(f"✅ تم إنشاء جائزة الرصيد #{rid}.",reply_markup=_loyalty_kb(loyalty_service.config()['enabled'])); return
        if step=='stock':
            if not digits.isdigit(): await message.answer("❌ المخزون غير صالح."); return
            rid=await loyalty_service.create_reward(d['name'],rtype,int(d['cost']),message.from_user.id,stock_total=int(digits)); await state.clear(); await message.answer(f"✅ تم إنشاء الجائزة العينية #{rid}.",reply_markup=_loyalty_kb(loyalty_service.config()['enabled'])); return
    await state.clear(); await message.answer("❌ انتهت حالة الإدخال. افتح القسم من جديد.")
