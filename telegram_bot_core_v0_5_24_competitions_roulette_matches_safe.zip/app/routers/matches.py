from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from app.core.ui import safe_edit
from app.services.matches import LEAGUES, MatchesService

router=Router(name='matches')

def _kb(active='mixed'):
    rows=[]
    keys=list(LEAGUES)
    for i in range(0,len(keys),2):
        row=[]
        for k in keys[i:i+2]: row.append(InlineKeyboardButton(text=('✅ ' if k==active else '')+LEAGUES[k][0],callback_data=f'matches:{k}'))
        rows.append(row)
    rows.append([InlineKeyboardButton(text='⬅️ الرئيسية',callback_data='core:home')]); return InlineKeyboardMarkup(inline_keyboard=rows)

@router.callback_query(F.data=='menu:matches')
async def matches_home(callback:CallbackQuery,matches_service:MatchesService)->None:
    await _render(callback,matches_service,'mixed')

@router.callback_query(F.data.startswith('matches:'))
async def matches_league(callback:CallbackQuery,matches_service:MatchesService)->None:
    key=callback.data.split(':',1)[1]; await _render(callback,matches_service,key)

async def _render(callback:CallbackQuery,service:MatchesService,key:str)->None:
    rows,note=await service.today(key); lines=[f"⚽ <b>{LEAGUES.get(key,LEAGUES['mixed'])[0]}</b>",'']
    if note: lines += [f"ℹ️ {note}",'']
    if rows:
        for r in rows[:25]: lines.append(service.format_fixture(r)+'\n')
    else: lines.append('لا توجد مباريات متاحة ضمن هذا القسم اليوم.')
    await safe_edit(callback,'\n'.join(lines)[:3900],reply_markup=_kb(key))
