from __future__ import annotations

import html
import math
from datetime import datetime
from uuid import UUID
from zoneinfo import ZoneInfo

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.services.broadcasts import BroadcastService

router = Router(name="admin_broadcasts")
_PAGE_SIZE = 8
_DAMASCUS = ZoneInfo("Asia/Damascus")


class BroadcastAdminStates(StatesGroup):
    waiting_message = State()


def _admin(user_id: int, settings: Settings) -> bool:
    return int(user_id) in settings.super_admin_ids


def _uuid(value: str) -> UUID | None:
    try:
        return UUID(str(value))
    except Exception:
        return None


def _menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📣 رسالة جماعية جديدة", callback_data="admin:bcast:new")],
            [InlineKeyboardButton(text="📚 سجل الرسائل الجماعية", callback_data="admin:bcast:history:0")],
            [InlineKeyboardButton(text="⬅️ لوحة الإدارة", callback_data="admin:home")],
        ]
    )


def _draft_keyboard(cid: UUID) -> InlineKeyboardMarkup:
    sid = str(cid)
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ تأكيد الإرسال", callback_data=f"admin:bcast:confirm:{sid}")],
            [
                InlineKeyboardButton(text="👁️ عرض المعاينة", callback_data=f"admin:bcast:preview:{sid}"),
                InlineKeyboardButton(text="✏️ استبدال الرسالة", callback_data=f"admin:bcast:edit:{sid}"),
            ],
            [InlineKeyboardButton(text="❌ إلغاء", callback_data=f"admin:bcast:cancel:{sid}")],
        ]
    )


def _status_label(status: str) -> str:
    return {
        "draft": "📝 مسودة",
        "queued": "⏳ في الطابور",
        "running": "📤 جاري الإرسال",
        "stopping": "⏹️ جاري الإيقاف",
        "stopped": "⏹️ متوقفة",
        "completed": "✅ مكتملة",
        "failed": "❌ فشلت",
        "cancelled": "🚫 ملغاة",
    }.get(str(status), str(status))


def _delete_label(status: str) -> str:
    return {
        "none": "— لم يُطلب",
        "queued": "⏳ في طابور الحذف",
        "deleting": "🗑️ جاري الحذف",
        "completed": "✅ اكتملت محاولة الحذف",
        "failed": "⚠️ تعذر إكمال الحذف",
    }.get(str(status), str(status))


def _short_dt(value: object) -> str:
    if not isinstance(value, datetime):
        return "—"
    try:
        return value.astimezone(_DAMASCUS).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return value.strftime("%Y-%m-%d %H:%M")


def _content_label(message: Message) -> str:
    kind = getattr(message, "content_type", None)
    value = getattr(kind, "value", None) or str(kind or "message")
    labels = {
        "text": "نص", "photo": "صورة", "video": "فيديو", "animation": "GIF / حركة",
        "document": "ملف", "voice": "رسالة صوتية", "audio": "ملف صوتي", "sticker": "ملصق",
        "video_note": "فيديو دائري", "contact": "جهة اتصال", "location": "موقع",
    }
    return labels.get(str(value), str(value))[:64]


def _preview_text(message: Message) -> str:
    raw = str(message.text or message.caption or "").strip()
    if raw:
        return raw[:500]
    return f"[{_content_label(message)}]"


def _history_keyboard(rows: list[dict], *, page: int, total: int) -> InlineKeyboardMarkup:
    buttons: list[list[InlineKeyboardButton]] = []
    for item in rows:
        cid = str(item["id"])
        sent = int(item.get("sent_count") or 0)
        total_users = int(item.get("total_recipients") or 0)
        preview = str(item.get("preview_text") or "").replace("\n", " ").strip()
        if len(preview) > 18:
            preview = preview[:18] + "…"
        icon = "✅" if item.get("status") == "completed" else "⏹️" if item.get("status") == "stopped" else "📤" if item.get("status") in {"running","queued","stopping"} else "⚠️"
        label = f"{icon} {_short_dt(item.get('created_at'))} | {sent}/{total_users}"
        if preview:
            label += f" | {preview}"
        buttons.append([InlineKeyboardButton(text=label[:64], callback_data=f"admin:bcast:view:{cid}:{page}")])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ السابق", callback_data=f"admin:bcast:history:{page-1}"))
    if (page + 1) * _PAGE_SIZE < total:
        nav.append(InlineKeyboardButton(text="التالي ➡️", callback_data=f"admin:bcast:history:{page+1}"))
    if nav:
        buttons.append(nav)
    buttons.append([InlineKeyboardButton(text="📣 رسالة جديدة", callback_data="admin:bcast:new")])
    buttons.append([InlineKeyboardButton(text="⬅️ الرسائل الجماعية", callback_data="admin:bcast")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def _detail_text(c: dict) -> str:
    total = int(c.get("total_recipients") or 0)
    sent = int(c.get("sent_count") or 0)
    blocked = int(c.get("blocked_count") or 0)
    failed = int(c.get("failed_count") or 0)
    unknown = int(c.get("unknown_count") or 0)
    preview = html.escape(str(c.get("preview_text") or "—"))
    if len(preview) > 500:
        preview = preview[:500] + "…"
    lines = [
        "📣 <b>تفاصيل الحملة الجماعية</b>", "",
        f"🆔 <code>{c.get('id')}</code>",
        f"📅 الإنشاء: <b>{_short_dt(c.get('created_at'))}</b>",
        f"📊 الحالة: <b>{_status_label(str(c.get('status') or ''))}</b>",
        f"📝 النوع: <b>{html.escape(str(c.get('content_type') or 'رسالة'))}</b>", "",
        f"👥 المستهدفون: <b>{total:,}</b>",
        f"📤 وصل: <b>{sent:,}</b>",
        f"🚫 محظور/غير متاح: <b>{blocked:,}</b>",
        f"⚠️ فشل: <b>{failed:,}</b>",
        f"❓ غير مؤكد: <b>{unknown:,}</b>", "",
        f"🗑️ حالة الحذف: <b>{_delete_label(str(c.get('delete_status') or 'none'))}</b>",
        f"✅ محذوف: <b>{int(c.get('deleted_count') or 0):,}</b>",
        f"⚠️ تعذر حذفه: <b>{int(c.get('delete_failed_count') or 0):,}</b>", "",
        f"<b>المعاينة:</b>\n{preview}",
    ]
    if c.get("last_error"):
        lines.extend(["", f"<b>آخر خطأ:</b> <code>{html.escape(str(c['last_error'])[:500])}</code>"])
    if unknown:
        lines.extend(["", "⚠️ <b>غير مؤكد</b> يعني أن الاتصال انقطع بعد بدء طلب الإرسال؛ لا يعاد إرساله تلقائيًا لمنع تكرار الرسالة."])
    return "\n".join(lines)


def _detail_keyboard(c: dict, *, page: int) -> InlineKeyboardMarkup:
    cid = str(c["id"])
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(text="👁️ عرض الرسالة الأصلية", callback_data=f"admin:bcast:preview:{cid}")]
    ]
    status = str(c.get("status") or "")
    if status in {"queued", "running", "stopping"} and not c.get("stop_requested"):
        rows.append([InlineKeyboardButton(text="⏹️ إيقاف الإرسال", callback_data=f"admin:bcast:stop:{cid}")])
    sent = int(c.get("sent_count") or 0)
    delete_status = str(c.get("delete_status") or "none")
    if status in {"completed", "stopped", "failed"} and sent > 0 and delete_status not in {"queued", "deleting"}:
        label = "🔄 إعادة محاولة حذف المتعذر" if delete_status in {"completed", "failed"} and int(c.get("delete_failed_count") or 0) else "🗑️ حذف الرسالة لدى الجميع"
        rows.append([InlineKeyboardButton(text=label, callback_data=f"admin:bcast:delete:{cid}")])
    rows.append([InlineKeyboardButton(text="🔄 تحديث", callback_data=f"admin:bcast:view:{cid}:{page}")])
    rows.append([InlineKeyboardButton(text="⬅️ سجل الرسائل", callback_data=f"admin:bcast:history:{page}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin:bcast")
async def broadcast_home(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await state.clear()
    await safe_edit(
        callback,
        "📣 <b>الرسائل الجماعية</b>\n\n"
        "يمكن إرسال نفس رسالة Telegram للمستخدمين غير المحظورين مع معاينة وتأكيد قبل الإرسال.\n"
        "الحملات محفوظة بقاعدة البيانات ويمكن إيقافها ومراجعتها وحذف الرسالة المرسلة لاحقًا.",
        reply_markup=_menu(),
    )


@router.callback_query(F.data == "admin:bcast:new")
async def broadcast_new(callback: CallbackQuery, settings: Settings, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await state.clear()
    await state.set_state(BroadcastAdminStates.waiting_message)
    await safe_edit(
        callback,
        "📣 <b>رسالة جماعية جديدة</b>\n\n"
        "أرسل الآن الرسالة التي تريد إرسالها للمستخدمين.\n"
        "يدعم النص والصور والفيديو والملفات والملصقات والرسائل الصوتية مع الحفاظ على تنسيق الرسالة عبر Telegram Copy.\n\n"
        "🔒 لن يبدأ الإرسال قبل أن تظهر المعاينة وتضغط تأكيد.\n"
        "✅ يتم استهداف المستخدمين غير المحظورين وغير الحسابات الآلية فقط.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:bcast")]]),
    )


@router.message(BroadcastAdminStates.waiting_message)
async def broadcast_receive(
    message: Message, settings: Settings, broadcast_service: BroadcastService, state: FSMContext
) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings):
        return
    data = await state.get_data()
    old_id = _uuid(str(data.get("replace_campaign_id") or ""))
    if old_id is not None:
        await broadcast_service.cancel_draft(old_id, actor_id=message.from_user.id)
    cid = await broadcast_service.create_draft(
        admin_id=message.from_user.id,
        source_chat_id=message.chat.id,
        source_message_id=message.message_id,
        content_type=_content_label(message),
        preview_text=_preview_text(message),
    )
    count = await broadcast_service.eligible_count()
    estimated = max(1, math.ceil(max(1, count) / max(5, broadcast_service.per_minute)))
    await state.clear()
    await message.reply(
        "👁️ <b>معاينة قبل الإرسال</b>\n\n"
        "الرسالة التي أرسلتها أعلاه هي نفسها التي سيتم نسخها للمستخدمين.\n\n"
        f"👥 عدد المستهدفين الحالي: <b>{count:,}</b>\n"
        f"⚡ الحد المضبوط: <b>{broadcast_service.per_minute:,}</b> رسالة/دقيقة\n"
        f"⏱ تقدير تقريبي: <b>{estimated}</b> دقيقة\n\n"
        "تأكد من المحتوى ثم اضغط تأكيد.",
        reply_markup=_draft_keyboard(cid),
    )


@router.callback_query(F.data.regexp(r"^admin:bcast:preview:[0-9a-fA-F-]{36}$"))
async def broadcast_preview(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    cid = _uuid(str(callback.data).rsplit(":", 1)[-1])
    if cid is None:
        return
    c = await broadcast_service.get(cid)
    if c is None:
        await callback.answer("الحملة غير موجودة.", show_alert=True)
        return
    try:
        await callback.bot.copy_message(
            chat_id=callback.from_user.id,
            from_chat_id=int(c["source_chat_id"]),
            message_id=int(c["source_message_id"]),
        )
    except Exception:
        await callback.answer("تعذر عرض الرسالة الأصلية. ربما تم حذفها من محادثة الأدمن.", show_alert=True)


@router.callback_query(F.data.regexp(r"^admin:bcast:edit:[0-9a-fA-F-]{36}$"))
async def broadcast_edit(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    cid = _uuid(str(callback.data).rsplit(":", 1)[-1])
    if cid is None:
        return
    c = await broadcast_service.get(cid)
    if c is None or str(c.get("status")) != "draft" or int(c.get("created_by") or 0) != callback.from_user.id:
        await callback.answer("المسودة لم تعد قابلة للتعديل.", show_alert=True)
        return
    await broadcast_service.cancel_draft(cid, actor_id=callback.from_user.id)
    await state.set_state(BroadcastAdminStates.waiting_message)
    await state.update_data(replace_campaign_id=str(cid))
    await safe_edit(
        callback,
        "✏️ <b>استبدال الرسالة الجماعية</b>\n\nأرسل النسخة الجديدة الآن. لن يبدأ الإرسال حتى تؤكدها.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:bcast")]]),
    )


@router.callback_query(F.data.regexp(r"^admin:bcast:cancel:[0-9a-fA-F-]{36}$"))
async def broadcast_cancel(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    cid = _uuid(str(callback.data).rsplit(":", 1)[-1])
    if cid:
        await broadcast_service.cancel_draft(cid, actor_id=callback.from_user.id)
    await state.clear()
    await safe_edit(callback, "✅ تم إلغاء الرسالة الجماعية ولم يتم إرسال أي شيء.", reply_markup=_menu())


@router.callback_query(F.data.regexp(r"^admin:bcast:confirm:[0-9a-fA-F-]{36}$"))
async def broadcast_confirm(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService, state: FSMContext) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    cid = _uuid(str(callback.data).rsplit(":", 1)[-1])
    if cid is None or not isinstance(callback.message, Message):
        return
    c = await broadcast_service.confirm(
        cid,
        actor_id=callback.from_user.id,
        admin_chat_id=callback.message.chat.id,
        admin_status_message_id=callback.message.message_id,
    )
    await state.clear()
    if c is None:
        await callback.answer("المسودة غير موجودة أو ليست لك.", show_alert=True)
        return
    if str(c.get("status")) == "completed" and int(c.get("total_recipients") or 0) == 0:
        await safe_edit(callback, "⚠️ لا يوجد مستخدمون متاحون للإرسال الجماعي.", reply_markup=_menu())
        return
    total = int(c.get("total_recipients") or 0)
    estimated = max(1, math.ceil(max(1, total) / max(5, int(c.get("per_minute") or broadcast_service.per_minute))))
    await safe_edit(
        callback,
        "📤 <b>تمت إضافة الحملة إلى طابور الإرسال</b>\n\n"
        f"👥 Snapshot المستهدفين: <b>{total:,}</b>\n"
        f"⚡ الحد: <b>{int(c.get('per_minute') or broadcast_service.per_minute):,}</b> رسالة/دقيقة\n"
        f"⏱ تقدير تقريبي: <b>{estimated}</b> دقيقة\n"
        f"🆔 <code>{cid}</code>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⏹️ إيقاف الإرسال", callback_data=f"admin:bcast:stop:{cid}")],
            [InlineKeyboardButton(text="📚 تفاصيل الحملة", callback_data=f"admin:bcast:view:{cid}:0")],
        ]),
    )


@router.callback_query(F.data.regexp(r"^admin:bcast:history:\d+$"))
async def broadcast_history(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    page = max(0, int(str(callback.data).rsplit(":", 1)[-1]))
    rows, total = await broadcast_service.history(page=page, page_size=_PAGE_SIZE)
    if not rows and page > 0:
        page -= 1
        rows, total = await broadcast_service.history(page=page, page_size=_PAGE_SIZE)
    text = "📚 <b>سجل الرسائل الجماعية</b>\n\n"
    text += "لا توجد حملات مسجلة بعد." if not rows else f"إجمالي الحملات: <b>{total:,}</b>\nاختر حملة لعرض التفاصيل أو حذف الرسالة المرسلة."
    await safe_edit(callback, text, reply_markup=_history_keyboard(rows, page=page, total=total))


@router.callback_query(F.data.regexp(r"^admin:bcast:view:[0-9a-fA-F-]{36}:\d+$"))
async def broadcast_view(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    parts = str(callback.data).split(":")
    cid = _uuid(parts[-2])
    page = max(0, int(parts[-1]))
    if cid is None:
        return
    c = await broadcast_service.get(cid)
    if c is None:
        await callback.answer("الحملة غير موجودة.", show_alert=True)
        return
    await safe_edit(callback, _detail_text(c), reply_markup=_detail_keyboard(c, page=page))


@router.callback_query(F.data.regexp(r"^admin:bcast:stop:[0-9a-fA-F-]{36}$"))
async def broadcast_stop_confirm(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    cid = _uuid(str(callback.data).rsplit(":", 1)[-1])
    if cid is None:
        return
    c = await broadcast_service.get(cid)
    if c is None or str(c.get("status")) not in {"queued", "running", "stopping"}:
        await callback.answer("الحملة ليست قيد الإرسال.", show_alert=True)
        return
    await safe_edit(
        callback,
        "⚠️ <b>تأكيد إيقاف الإرسال؟</b>\n\n"
        "الإيقاف يمنع إرسال الرسالة للمتبقين فقط، ولا يحذف ما وصل بالفعل.\n"
        "قد تكتمل بضعة طلبات كانت قيد التنفيذ لحظة الضغط.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⏹️ نعم، أوقف", callback_data=f"admin:bcast:stopok:{cid}")],
            [InlineKeyboardButton(text="⬅️ رجوع", callback_data=f"admin:bcast:view:{cid}:0")],
        ]),
    )


@router.callback_query(F.data.regexp(r"^admin:bcast:stopok:[0-9a-fA-F-]{36}$"))
async def broadcast_stop(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    cid = _uuid(str(callback.data).rsplit(":", 1)[-1])
    if cid is None:
        return
    ok = await broadcast_service.request_stop(cid)
    c = await broadcast_service.get(cid)
    if not ok or c is None:
        await callback.answer("تعذر الإيقاف أو أن الحملة انتهت بالفعل.", show_alert=True)
        return
    await safe_edit(
        callback,
        "⏹️ <b>تم تسجيل طلب الإيقاف.</b>\n\nسيكمل فقط ما كان قيد التنفيذ ثم تتوقف الحملة.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📚 تفاصيل الحملة", callback_data=f"admin:bcast:view:{cid}:0")]]),
    )


@router.callback_query(F.data.regexp(r"^admin:bcast:delete:[0-9a-fA-F-]{36}$"))
async def broadcast_delete_confirm(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    cid = _uuid(str(callback.data).rsplit(":", 1)[-1])
    if cid is None:
        return
    c = await broadcast_service.get(cid)
    if c is None or str(c.get("status")) not in {"completed", "stopped", "failed"}:
        await callback.answer("لا يمكن حذف حملة ما زالت قيد الإرسال.", show_alert=True)
        return
    await safe_edit(
        callback,
        "🗑️ <b>تأكيد حذف الرسالة لدى المستخدمين؟</b>\n\n"
        f"سيحاول البوت حذف الرسائل التي سجّل Telegram أنها وصلت بنجاح: <b>{int(c.get('sent_count') or 0):,}</b>.\n"
        "لن يتم حذف أي رسالة أخرى للمستخدم، وقد يرفض Telegram حذف بعض الرسائل حسب حالتها.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🗑️ نعم، ابدأ الحذف", callback_data=f"admin:bcast:delok:{cid}")],
            [InlineKeyboardButton(text="⬅️ رجوع", callback_data=f"admin:bcast:view:{cid}:0")],
        ]),
    )


@router.callback_query(F.data.regexp(r"^admin:bcast:delok:[0-9a-fA-F-]{36}$"))
async def broadcast_delete(callback: CallbackQuery, settings: Settings, broadcast_service: BroadcastService) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    cid = _uuid(str(callback.data).rsplit(":", 1)[-1])
    if cid is None:
        return
    c = await broadcast_service.request_delete(cid)
    if c is None:
        await callback.answer("تعذر بدء الحذف. تأكد أن الإرسال انتهى.", show_alert=True)
        return
    await safe_edit(
        callback,
        "🗑️ <b>تمت إضافة مهمة الحذف إلى الطابور.</b>\n\n"
        f"📨 الرسائل المسجلة: <b>{int(c.get('delete_total') or 0):,}</b>\n"
        "يمكنك متابعة النتيجة من تفاصيل الحملة.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📚 تفاصيل الحملة", callback_data=f"admin:bcast:view:{cid}:0")]]),
    )
