from __future__ import annotations

import html

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.user_experience import normalize_support_contact
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin_support")


class SupportAdminStates(StatesGroup):
    waiting_value = State()


_LABELS = {
    "telegram": "✈️ Telegram",
    "whatsapp": "🟢 WhatsApp",
    "facebook": "🔵 Facebook",
    "ichancy": "🎰 دعم iChancy",
}


def _admin(user_id: int, settings: Settings) -> bool:
    return user_id in settings.super_admin_ids


def _menu(runtime: RuntimeSettingsService) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for kind, label in _LABELS.items():
        visible = runtime.get_bool(f"support.{kind}_visible", True)
        rows.append([
            InlineKeyboardButton(text=f"✏️ {label}", callback_data=f"admin:support:edit:{kind}"),
            InlineKeyboardButton(
                text="👁️ ظاهر" if visible else "🙈 مخفي",
                callback_data=f"admin:support:toggle:{kind}",
            ),
        ])
    rows.append([InlineKeyboardButton(text="⬅️ لوحة الإدارة", callback_data="admin:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _text(runtime: RuntimeSettingsService) -> str:
    lines = ["📞 <b>إعدادات التواصل</b>", "", "يمكن تعديل الرابط وإظهار/إخفاء كل وسيلة بشكل مستقل.", ""]
    for kind, label in _LABELS.items():
        url = str(runtime.get(f"support.{kind}_url", "") or "").strip()
        visible = runtime.get_bool(f"support.{kind}_visible", True)
        lines.append(f"{label}: {'👁️' if visible else '🙈'} <code>{html.escape(url or 'غير مضبوط')}</code>")
    return "\n".join(lines)


@router.callback_query(F.data == "admin:support")
async def support_home(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    await state.clear()
    await safe_edit(callback, _text(runtime_settings), reply_markup=_menu(runtime_settings))


@router.callback_query(F.data.regexp(r"^admin:support:toggle:(telegram|whatsapp|facebook|ichancy)$"))
async def support_toggle(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    kind = str(callback.data).rsplit(":", 1)[-1]
    new_value = not runtime_settings.get_bool(f"support.{kind}_visible", True)
    await runtime_settings.set(f"support.{kind}_visible", new_value, updated_by=callback.from_user.id)
    await safe_edit(callback, _text(runtime_settings), reply_markup=_menu(runtime_settings))


@router.callback_query(F.data.regexp(r"^admin:support:edit:(telegram|whatsapp|facebook|ichancy)$"))
async def support_edit(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    kind = str(callback.data).rsplit(":", 1)[-1]
    current = str(runtime_settings.get(f"support.{kind}_url", "") or "")
    await state.set_state(SupportAdminStates.waiting_value)
    await state.update_data(support_kind=kind)
    extra = {
        "telegram": "أرسل @username أو رابط t.me.",
        "whatsapp": "أرسل رقمًا دوليًا أو رابط wa.me.",
        "facebook": "أرسل رابط Facebook أو m.me.",
        "ichancy": "أرسل رابط صفحة/دردشة دعم iChancy.",
    }[kind]
    await safe_edit(
        callback,
        f"✏️ <b>{_LABELS[kind]}</b>\n\nالحالي: <code>{html.escape(current or 'غير مضبوط')}</code>\n\n{extra}\nأرسل <code>-</code> لمسح الرابط.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data="admin:support")]]),
    )


@router.message(SupportAdminStates.waiting_value, F.text)
async def support_edit_value(
    message: Message, settings: Settings, runtime_settings: RuntimeSettingsService, state: FSMContext
) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings):
        return
    data = await state.get_data()
    kind = str(data.get("support_kind") or "")
    if kind not in _LABELS:
        await state.clear()
        return
    raw = str(message.text or "").strip()
    if raw == "-":
        value = ""
    else:
        value, error = normalize_support_contact(kind, raw)
        if error or not value:
            await message.answer(f"❌ {html.escape(error or 'القيمة غير صحيحة.')}\nأرسل القيمة من جديد أو <code>-</code> للمسح.")
            return
    await runtime_settings.set(f"support.{kind}_url", value, updated_by=message.from_user.id)
    await state.clear()
    await message.answer("✅ تم حفظ وسيلة التواصل.\n\n" + _text(runtime_settings), reply_markup=_menu(runtime_settings))
