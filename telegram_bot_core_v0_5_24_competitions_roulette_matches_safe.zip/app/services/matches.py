from __future__ import annotations

import asyncio
import json
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import aiohttp

from app.services.runtime_settings import RuntimeSettingsService

DAMASCUS = ZoneInfo('Asia/Damascus')
LEAGUES: dict[str, tuple[str, int | None]] = {
    'laliga': ('الدوري الإسباني', 140),
    'epl': ('الدوري الإنجليزي', 39),
    'ucl': ('دوري أبطال أوروبا', 2),
    'uel': ('الدوري الأوروبي', 3),
    'seriea': ('الدوري الإيطالي', 135),
    'bundesliga': ('الدوري الألماني', 78),
    'ligue1': ('الدوري الفرنسي', 61),
    'mixed': ('أهم مباريات اليوم', None),
}


class MatchesService:
    def __init__(self, session: aiohttp.ClientSession, runtime: RuntimeSettingsService, *, api_key: str,
                 base_url: str, cache_minutes: int = 10) -> None:
        self.session=session; self.runtime=runtime; self.api_key=str(api_key or '').strip(); self.base_url=str(base_url).strip()
        self.cache_minutes=max(1,int(cache_minutes)); self._lock=asyncio.Lock(); self._memory: dict[str,tuple[datetime,list[dict]]] = {}

    async def today(self, league_key: str='mixed') -> tuple[list[dict], str | None]:
        if league_key not in LEAGUES: league_key='mixed'
        now=datetime.now(DAMASCUS); day=now.date().isoformat(); cache_key=f'football.cache.{day}'
        mem=self._memory.get(day)
        all_rows: list[dict] | None = None
        if mem and mem[0] > now:
            all_rows=mem[1]
        saved=self.runtime.get(cache_key)
        if all_rows is None and isinstance(saved, dict):
            try:
                expiry=datetime.fromisoformat(str(saved.get('expires_at')))
                if expiry.tzinfo is None: expiry=expiry.replace(tzinfo=DAMASCUS)
                rows=list(saved.get('fixtures') or [])
                if expiry>now:
                    self._memory[day]=(expiry,rows); all_rows=rows
            except Exception: pass
        note=None
        if all_rows is None:
            if not self.api_key:
                all_rows=list(saved.get('fixtures') or []) if isinstance(saved,dict) else []
                note='خدمة مباريات اليوم غير مفعلة حالياً.'
            else:
                async with self._lock:
                    mem=self._memory.get(day)
                    if mem and mem[0]>datetime.now(DAMASCUS):
                        all_rows=mem[1]
                    else:
                        try:
                            timeout=aiohttp.ClientTimeout(total=12,connect=4,sock_read=8)
                            async with self.session.get(self.base_url,params={'date':day,'timezone':'Asia/Damascus'},headers={'x-apisports-key':self.api_key},timeout=timeout) as resp:
                                if resp.status!=200: raise RuntimeError(f'football_http_{resp.status}')
                                payload=await resp.json(content_type=None)
                            all_rows=[]
                            known={v[1] for v in LEAGUES.values() if v[1] is not None}
                            for item in list(payload.get('response') or []):
                                fixture=item.get('fixture') or {}; teams=item.get('teams') or {}; league=item.get('league') or {}; goals=item.get('goals') or {}
                                league_id=league.get('id')
                                try: league_id=int(league_id)
                                except Exception: continue
                                all_rows.append({
                                    'id':fixture.get('id'),'date':fixture.get('date'),'status':(fixture.get('status') or {}).get('short'),
                                    'status_long':(fixture.get('status') or {}).get('long'),'home':(teams.get('home') or {}).get('name') or '-',
                                    'away':(teams.get('away') or {}).get('name') or '-','home_goals':goals.get('home'),'away_goals':goals.get('away'),
                                    'league':league.get('name') or '-','league_id':league_id,'mixed':league_id not in known,'round':league.get('round') or '',
                                })
                            expiry=datetime.now(DAMASCUS)+timedelta(minutes=self.cache_minutes)
                            await self.runtime.set(cache_key,{'expires_at':expiry.isoformat(),'fixtures':all_rows},updated_by=None)
                            self._memory[day]=(expiry,all_rows)
                        except Exception:
                            all_rows=list(saved.get('fixtures') or []) if isinstance(saved,dict) else []
                            note='تعذر تحديث المباريات حالياً؛ يتم عرض آخر بيانات محفوظة.' if all_rows else 'تعذر جلب مباريات اليوم حالياً.'
        if league_key=='mixed':
            rows=[r for r in (all_rows or []) if bool(r.get('mixed'))]
        else:
            league_id=LEAGUES[league_key][1]; rows=[r for r in (all_rows or []) if r.get('league_id')==league_id]
        rows.sort(key=lambda r:str(r.get('date') or ''))
        return rows,note

    @staticmethod
    def format_fixture(row: dict) -> str:
        date_raw=str(row.get('date') or '')
        try:
            dt=datetime.fromisoformat(date_raw.replace('Z','+00:00')).astimezone(DAMASCUS); time_text=dt.strftime('%H:%M')
        except Exception: time_text='--:--'
        status=str(row.get('status') or '')
        score=''
        if row.get('home_goals') is not None or row.get('away_goals') is not None:
            score=f" — {row.get('home_goals',0)} : {row.get('away_goals',0)}"
        state={'NS':'لم تبدأ','1H':'الشوط الأول','HT':'استراحة','2H':'الشوط الثاني','FT':'انتهت','AET':'بعد التمديد','PEN':'ركلات ترجيح'}.get(status,str(row.get('status_long') or ''))
        round_text=f"\n└ {row.get('round')}" if row.get('round') else ''
        return f"⚽ <b>{row.get('home')}</b> × <b>{row.get('away')}</b>{score}\n🕒 {time_text} • {state}\n🏆 {row.get('league')}{round_text}"
