from __future__ import annotations

import asyncio
from decimal import Decimal
from typing import Any

from app.repositories.runtime_settings import RuntimeSettingsRepository


DEFAULTS: dict[str, Any] = {
    "maintenance.enabled": False,
    "system.restore_lock": False,
    "maintenance.message": "🛠 البوت في وضع الصيانة حاليًا\n\nنعمل على بعض التحسينات. يرجى المحاولة مرة أخرى بعد انتهاء الصيانة.",
    "backup.auto_enabled": True,
    "backup.channel": "",
    "backup.last_auto_day": "",
    "backup.last_ok_at": "",
    "backup.last_error": "",
    "support.telegram_url": "",
    "support.telegram_visible": True,
    "support.whatsapp_url": "",
    "support.whatsapp_visible": True,
    "support.facebook_url": "",
    "support.facebook_visible": True,
    "support.ichancy_url": "",
    "support.ichancy_visible": True,
    "money.local_syp_wallet_multiplier": "100",
    "payments.api_provider": "api_syria",
    "alerts.ichancy_deposit_large": 0,
    "alerts.ichancy_withdraw_large": 0,
    "alerts.bot_deposit_large": 0,
    "alerts.bot_withdraw_large": 0,
    "ichancy.min_deposit": 20000,
    "ichancy.min_withdraw": 20000,
    "ichancy.username_prefix": "bot",
    "ichancy.enabled": True,
    "notify.ichancy_accounts": None,
    "notify.ichancy_operations": None,
    # Bot-wallet operations are deliberately split. Keep bot_operations only as
    # a legacy target for already-queued outbox rows from older versions.
    "notify.bot_deposits": None,
    "notify.bot_withdrawals": None,
    "notify.bot_operations": None,
    "deposit.syriatel.codes": "",
    "deposit.syriatel.min": None,
    "deposit.sham_syp.min": None,
    "deposit.sham_usd.min": None,
    "deposit.sham_usd.rate": None,
    "deposit.whish_money.min": None,
    "deposit.whish_money.rate": None,
    "deposit.binance_trc20.min": None,
    "deposit.binance_trc20.rate": None,
    "deposit.binance_bep20.min": None,
    "deposit.binance_bep20.rate": None,
    "deposit.sham.address_syp": "",
    "deposit.sham.address_usd": "",
    "withdraw.min_wallet": 50000,
    "withdraw.syriatel.min_wallet": None,
    "withdraw.syriatel.pin_enc": None,
    "withdraw.shamcash.pin_enc": None,
    "withdraw.shamcash.min_wallet": None,
    "withdraw.fee_pct": "0",
    "withdraw.hawala_fee_pct": "0",
    "withdraw.hawala_min_wallet": 1000000,
    "withdraw.syriatel.enabled": True,
    "withdraw.shamcash.enabled": True,
    "withdraw.hawala.enabled": True,
    "withdraw.usdt.enabled": True,
    "withdraw.usdt.trc20.enabled": True,
    "withdraw.usdt.bep20.enabled": True,
    "withdraw.usdt.rate": "11500",
    "withdraw.usdt.min_wallet": 50000,
    "bonus.syriatel_pct": "0",
    "bonus.sham_syp_pct": "0",
    "bonus.sham_usd_pct": "0",
    "bonus.binance_usdt_pct": "0",
    "bonus.whish_money_pct": "0",
    "bonus.deposit_tiers_enabled": True,
    "bonus.welcome_enabled": False,
    "bonus.welcome_mode": "instant",
    "bonus.welcome_amount": 0,
    "bonus.welcome_first_deposit_pct": "0",
    "bonus.welcome_enabled_since": None,
    "commission.withdraw_tiers_enabled": True,
    # reference-compatible cashback/referral/wheel defaults.
    "cashback.default_pct": "0",
    "cashback.min_turnover": 200000,
    "cashback.cycle_days": 7,
    "cashback.next_cycle_days": 0,
    "referral.mode": "direct",
    "referral.direct_pct": "4",
    "referral.level1_pct": "4",
    "referral.level2_pct": "2",
    "referral.level3_pct": "1",
    "referral.cycle_days": 10,
    "referral.min_active_refs": 3,
    "referral.active_min_deposit": 0,
    "referral.fixed_enabled": False,
    "referral.fixed_amount": 500,
    "referral.fixed_trigger": "verify",
    "wheel.min_deposit": 50000,
    "wheel.fixed_prize": 1000,
    "wheel.free_spin_enabled": False,
    "wheel.free_prize": 0,
    "wheel.free_spin_started_at": None,
    "gift.transfer_enabled": True,
    "gift.code_prefix": "TECNO",
    "gift.code_cooldown_minutes": 0,
    "notify.admin_events": None,
    "loyalty.enabled": True,
    "loyalty.earn_syp_per_point": 1000,
    "loyalty.min_deposit_syp": 50000,
}


class RuntimeSettingsService:
    """Small in-memory cache backed by PostgreSQL.

    Reads on hot UI paths are synchronous and do not add a DB round trip to every
    button. Admin changes are persisted first, then atomically reflected in cache.
    """

    def __init__(
        self,
        repository: RuntimeSettingsRepository,
        default_overrides: dict[str, Any] | None = None,
    ) -> None:
        self.repository = repository
        self._defaults: dict[str, Any] = {**DEFAULTS, **(default_overrides or {})}
        self._values: dict[str, Any] = dict(self._defaults)
        self._lock = asyncio.Lock()

    async def load(self) -> None:
        values = await self.repository.load_all()
        async with self._lock:
            self._values = {**self._defaults, **values}

    def get(self, key: str, default: Any = None) -> Any:
        if key in self._values:
            return self._values[key]
        return default

    def get_int(self, key: str, default: int = 0) -> int:
        try:
            return int(Decimal(str(self.get(key, default))))
        except Exception:
            return int(default)

    def get_decimal(self, key: str, default: Decimal | int | str = 0) -> Decimal:
        try:
            return Decimal(str(self.get(key, default)))
        except Exception:
            return Decimal(str(default))

    def get_bool(self, key: str, default: bool = False) -> bool:
        value = self.get(key, default)
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in {"1", "true", "yes", "on"}

    async def set(self, key: str, value: Any, *, updated_by: int | None) -> None:
        await self.repository.set(key, value, updated_by=updated_by)
        async with self._lock:
            self._values = {**self._values, key: value}
