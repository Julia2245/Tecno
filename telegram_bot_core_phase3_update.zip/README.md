# Telegram Bot Core — Phase 3

نواة عامة قابلة لإعادة الاستخدام لبوتات Telegram مبنية على **aiogram + PostgreSQL**، بدون أي اسم أو هوية بوت ثابتة داخل الكود.

## ما أصبح موجوداً

- Core async بالكامل مع callback ACK سريع وقياس latency.
- PostgreSQL عبر `asyncpg` وmigrations متسلسلة داخل schema مستقل `bot_core`.
- Wallet Core محمي: ledger append-only، idempotency، row locks، holds، وقيود سلامة على مستوى قاعدة البيانات.
- زر **شحن رصيد** مع محرك Deposits مستقل عن الـhandlers.
- لوحة أدمن أولية لمراجعة طلبات الشحن اليدوية.
- طلبات الشحن اليدوي يمكن إرسالها إلى قناة مراجعة مستقلة مثل البوت المرجعي عبر `DEPOSIT_MANUAL_REVIEW_CHAT_ID`، ومع fallback تلقائي إلى `SUPER_ADMINS` إذا فشل إرسال القناة.

## طرق الشحن في Phase 3

1. **Syriatel Cash**
   - `auto`: المستخدم يرسل رقم العملية فقط؛ يتم البحث عبر جميع أرقام الاستلام المضبوطة، والمبلغ يؤخذ من API Syria.
   - `manual`: رقم العملية → رقم الاستلام → المبلغ → تأكيد → مراجعة الأدمن.
2. **Sham Cash — SYP**
   - Auto أو Manual.
   - SYP وUSD يشتركان في namespace واحد لرقم العملية لمنع إعادة استخدام نفس العملية بتبديل العملة.
3. **Sham Cash — USD**
   - Auto أو Manual بنفس الحماية السابقة.
4. **Whish Money**
   - المبلغ → صورة إثبات داخل Telegram → تأكيد → مراجعة الأدمن.
   - لا يتم تنزيل الصورة إلى ملفات السيرفر.
   - `file_unique_id` يستخدم كبصمة إضافية لمنع اعتماد نفس الإثبات الناجح مرة ثانية.
5. **Binance USDT TRC20**
   - المبلغ → TxID → تحقق Read-only من Binance.
6. **Binance USDT BEP20**
   - نفس المحرك مع تحقق الشبكة والعنوان والمبلغ.
   - TRC20 وBEP20 يشتركان في namespace واحد للـTxID لمنع replay عبر تبديل الشبكة.

## قواعد الأمان المالي

- التحقق من المزود **لا يضيف رصيداً** بحد ذاته.
- في الشحن الآلي: إنشاء سجل الشحن + claim لرقم العملية + Wallet credit + Ledger + حالة success تتم ضمن **PostgreSQL transaction واحدة**.
- إذا فشل أي جزء قبل `COMMIT` ترجع العملية كلها للخلف.
- إذا حدث خطأ اتصال أثناء تأكيد `COMMIT`، لا يتم افتراض نجاح أو فشل؛ يتم reconciliation من السجل الثابت، وإعادة نفس TxID آمنة ولا تضيف الرصيد مرتين.
- `provider_scope + provider_tx` فريد، وclaims لا تعدل ولا تحذف بعد إنشائها.
- أي طلب manual لا يمكن اعتماده مرتين حتى مع ضغط أدمنين بنفس اللحظة (`FOR UPDATE` + Wallet idempotency).
- ضغط المستخدم على تأكيد مرتين لا ينشئ رصيداً أو طلباً مالياً مزدوجاً.
- جميع حسابات الأموال تستخدم `Decimal`، والرصيد النهائي SYP عدد صحيح بـROUND_HALF_UP؛ لا يوجد `float` في التسوية المالية.
- Sham SYP/USD يشتركان في claim واحد، وكذلك Binance TRC20/BEP20.
- العمليات القديمة عن بداية سجل هذا deployment لا تقبل تلقائياً. لا يوجد تاريخ hardcoded؛ يوجد cutover محفوظ في `deposit_runtime.started_at`.
- يوجد أيضاً حد عمر قابل للضبط للشحن الآلي (`AUTO_DEPOSIT_MAX_AGE_HOURS`، افتراضياً 168 ساعة) لتقليل خطر سرقة Tx قديم لم يُطالب به.
- إذا أعاد المزود تاريخاً بلا وقت دقيق، يفشل الاعتماد الآلي بشكل مغلق بدلاً من اختراع ساعة قد تجعل عملية قديمة تبدو جديدة.
- طلبات المزود التي يكون وقتها مفقوداً أو غير منطقي لا تعتمد تلقائياً.
- فشل/Timeout المزود لا يحجز TxID محلياً، فيستطيع المستخدم إعادة نفس الرقم لاحقاً.
- القيم المالية والهوية في `deposit_requests` تصبح immutable بعد الإنشاء، وسجل الأحداث append-only.
- قاعدة البيانات نفسها تتحقق عند COMMIT أن كل شحن ناجح مرتبط بعملية Wallet صحيحة لنفس المستخدم وبنفس القيمة.

> البونص في هذه المرحلة هو بونص الطريقة فقط. بنية السجل تحفظ `bonus_source` و`bonus_pct` لتوصيل سياسة البونص الكاملة لاحقاً (أول شحن / خاص / فئات / مسابقات) بدون تغيير المحرك المالي.

## الإعداد

انسخ `.env.example` إلى `.env`. كل طرق الشحن **Fail-closed**: لا تعمل إلا بعد ضبط بياناتها صراحة.

أهم المتغيرات:

```env
API_SYRIA_KEY=
SYRIATEL_CHARGE_MODE=off
SYRIATEL_CASH_CODES=
SHAM_CHARGE_MODE=off
SHAMCASH_ADDRESS_SYP=
SHAMCASH_ADDRESS_USD=
WHISH_MONEY_ENABLED=false
WHISH_MONEY_NUMBER=
BINANCE_DEPOSIT_ENABLED=false
BINANCE_API_KEY=
BINANCE_API_SECRET=
BINANCE_TRC20_ADDRESS=
BINANCE_BEP20_ADDRESS=
AUTO_DEPOSIT_MAX_AGE_HOURS=168
# DEPOSIT_NOTIFY_CHAT_ID=-100...
# DEPOSIT_MANUAL_REVIEW_CHAT_ID=-100...
```

لا ترفع `.env` إلى GitHub.

## الفحوص

```bash
python -m pytest -q
python -m scripts.wallet_audit
python -m scripts.deposit_audit
```

النتائج السليمة:

```text
WALLET AUDIT: OK
DEPOSIT AUDIT: OK
```

## قاعدة التطوير

أي مزود شحن جديد يجب أن يمر عبر `DepositService` و`WalletService`. الـTelegram Router لا يكتب إلى الرصيد ولا إلى ledger مباشرة، ولا يتم وضع أي سر API داخل الكود.
