from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from zoneinfo import ZoneInfo

import aiohttp

from app.core.deposits import DepositProviderUnavailable, DepositVerificationFailed, ProviderTransaction
from app.core.money import parse_decimal

_DAMASCUS = ZoneInfo("Asia/Damascus")


class ApiSyriaClient:
    """Read-only transaction lookup for Syriatel Cash and Sham Cash."""

    def __init__(self, session: aiohttp.ClientSession, *, base_url: str, api_key: str) -> None:
        self.session = session
        self.base_url = (base_url or "").strip().rstrip("/")
        self.api_key = (api_key or "").strip()

    @property
    def configured(self) -> bool:
        return bool(self.base_url and self.api_key)

    async def find_syriatel(self, tx: str, gsm: str) -> ProviderTransaction | None:
        payload = await self._find(resource="syriatel", tx=tx, gsm=gsm)
        if payload is None:
            return None
        obj = payload.get("transaction") or {}
        amount = self._amount(obj)
        return ProviderTransaction(
            provider="syriatel",
            tx_key=tx,
            amount=amount,
            currency="SYP",
            destination=gsm,
            occurred_at=self._parse_datetime(obj.get("date")),
            raw=dict(obj),
        )

    async def find_shamcash(self, tx: str, account_address: str) -> ProviderTransaction | None:
        payload = await self._find(
            resource="shamcash", tx=tx, account_address=account_address
        )
        if payload is None:
            return None
        obj = payload.get("transaction") or {}
        amount = self._amount(obj)
        currency = str(obj.get("currency") or "").strip().upper()
        if not currency:
            raise DepositVerificationFailed("provider currency is missing")
        return ProviderTransaction(
            provider="shamcash",
            tx_key=tx,
            amount=amount,
            currency=currency,
            destination=account_address,
            occurred_at=self._parse_datetime(obj.get("datetime") or obj.get("date")),
            raw=dict(obj),
        )

    async def _find(
        self,
        *,
        resource: str,
        tx: str,
        gsm: str | None = None,
        account_address: str | None = None,
    ) -> dict | None:
        if not self.configured:
            raise DepositProviderUnavailable("API Syria is not configured")

        params: dict[str, str] = {
            "resource": resource,
            "action": "find_tx",
            "tx": tx,
            "api_key": self.api_key,
        }
        if gsm:
            params["gsm"] = gsm
        if account_address:
            params["account_address"] = account_address
        headers = {"X-Api-Key": self.api_key, "Accept": "application/json"}

        try:
            async with self.session.get(
                self.base_url,
                params=params,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=25),
            ) as response:
                if response.status != 200:
                    raise DepositProviderUnavailable(f"api_syria_http_{response.status}")
                try:
                    data = await response.json(content_type=None)
                except Exception as exc:
                    raise DepositProviderUnavailable("api_syria_invalid_json") from exc
        except DepositProviderUnavailable:
            raise
        except (aiohttp.ClientError, TimeoutError) as exc:
            raise DepositProviderUnavailable("api_syria_network_error") from exc

        if not isinstance(data, dict):
            raise DepositProviderUnavailable("api_syria_unexpected_response")
        if not data.get("success"):
            # A provider-level failure is different from a confirmed not-found.
            raise DepositProviderUnavailable("api_syria_unsuccessful_response")
        payload = data.get("data") or {}
        if not isinstance(payload, dict):
            raise DepositProviderUnavailable("api_syria_invalid_payload")
        if not payload.get("found"):
            return None
        return payload

    @staticmethod
    def _amount(obj: dict) -> Decimal:
        try:
            amount = parse_decimal(obj.get("amount"))
        except ValueError as exc:
            raise DepositVerificationFailed("provider amount is invalid") from exc
        if amount <= 0:
            raise DepositVerificationFailed("provider amount must be positive")
        return amount

    @staticmethod
    def _parse_datetime(raw: object) -> datetime | None:
        text = str(raw or "").strip()
        if not text:
            return None
        # API Syria historically returned local Syrian timestamps without timezone.
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
            try:
                parsed = datetime.strptime(text, fmt)
                return parsed.replace(tzinfo=_DAMASCUS)
            except ValueError:
                continue
        # A calendar date without a time is not precise enough for an automatic
        # financial cutover check. Failing closed is safer than inventing a time
        # that could turn an old transfer into a valid fresh one.
        try:
            datetime.strptime(text, "%Y-%m-%d")
            return None
        except ValueError:
            pass
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=_DAMASCUS)
            return parsed
        except ValueError:
            return None
