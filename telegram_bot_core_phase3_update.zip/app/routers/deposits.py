from __future__ import annotations

import asyncio
import html
import logging
from decimal import Decimal
from uuid import UUID, uuid4

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from app.config import Settings
from app.core.deposits import (
    DepositAlreadyProcessed,
    DepositAlreadyUsed,
    DepositProviderUnavailable,
    DepositOutcomeUncertain,
    DepositRecord,
    DepositSettlement,
    DepositValidationError,
    DepositVerificationFailed,
)
from app.core.ui import safe_edit
from app.keyboards.deposits import (
    admin_pending_deposits_menu,
    deposit_back_menu,
    deposit_cancel_menu,
    deposit_confirm_menu,
    deposit_methods_menu,
    manual_review_menu,
    whish_photo_menu,
)
from app.services.deposits import DepositMethodConfig, DepositService

router = Router(name="deposits")
logger = logging.getLogger(__name__)


class DepositStates(StatesGroup):
    waiting_tx = State()
    waiting_target = State()
    waiting_amount = State()
    waiting_binance_tx = State()
    waiting_whish_photo = State()
    waiting_confirm = State()


def _money(value: Decimal | int) -> str:
    if isinstance(value, Decimal):
        if value == value.to_integral_value():
            return f"{int(value):,}"
        return format(value.normalize(), "f")
    return f"{int(value):,}"


def _method_details(cfg: DepositMethodConfig) -> str:
    lines = [f"<b>طريقة الشحن:</b> {html.escape(cfg.label)}"]
    if cfg.target:
        lines.append(f"<b>الحساب/العنوان:</b>\n<code>{html.escape(cfg.target)}</code>")
    lines.append(f"<b>الحد الأدنى:</b> {_money(cfg.minimum)} {cfg.currency}")
    lines.append(f"<b>التحويل للمحفظة:</b> 1 {cfg.currency} = {_money(cfg.rate)} SYP")
    if cfg.bonus_pct > 0:
        lines.append(f"<b>البونص الحالي:</b> {_money(cfg.bonus_pct)}%")
    return "\n\n".join(lines)


def _success_text(result: DepositSettlement) -> str:
    d = result.deposit
    if result.duplicate:
        return (
            "✅ <b>هذه العملية معتمدة مسبقاً</b>\n\n"
            "لم تتم إضافة الرصيد مرة ثانية.\n"
            f"🏦 رصيدك الحالي: <b>{result.balance_after:,} SYP</b>"
        )
    lines = [
        "✅ <b>تم شحن رصيدك بنجاح</b>",
        "",
        f"💳 الطريقة: {html.escape(_method_label(d.method))}",
        f"💰 المبلغ المحول: {_money(d.amount_input)} {d.currency}",
        f"➕ المبلغ الأساسي: {d.base_credit_syp:,} SYP",
    ]
    if d.bonus_credit_syp > 0:
        lines.append(f"🎁 البونص: {_money(d.bonus_pct)}% (+{d.bonus_credit_syp:,} SYP)")
    lines.extend(
        [
            f"✅ الإجمالي المضاف: <b>{d.total_credit_syp:,} SYP</b>",
            f"🏦 رصيدك الحالي: <b>{result.balance_after:,} SYP</b>",
        ]
    )
    return "\n".join(lines)


def _method_label(method: str) -> str:
    return {
        "syriatel": "سيرياتيل كاش",
        "sham_syp": "شام كاش – ليرة",
        "sham_usd": "شام كاش – دولار",
        "whish_money": "Whish Money",
        "binance_trc20": "Binance USDT TRC20",
        "binance_bep20": "Binance USDT BEP20",
    }.get(method, method)


def _manual_card(d: DepositRecord) -> str:
    lines = [
        "💳 <b>طلب شحن يدوي</b>",
        "",
        f"🆔 الطلب: <code>{d.id}</code>",
        f"👤 المستخدم: <code>{d.telegram_id}</code>",
        f"💳 الطريقة: {html.escape(_method_label(d.method))}",
    ]
    if d.provider_tx and d.method != "whish_money":
        lines.append(f"🧾 رقم العملية: <code>{html.escape(d.provider_tx)}</code>")
    elif d.provider_tx and d.method == "whish_money":
        lines.append(f"🔐 بصمة الإثبات: <code>{html.escape(d.provider_tx)}</code>")
    if d.target_ref:
        lines.append(f"📥 الحساب المستلم: <code>{html.escape(d.target_ref)}</code>")
    lines.extend(
        [
            f"💰 المبلغ: {_money(d.amount_input)} {d.currency}",
            f"➕ الأساسي: {d.base_credit_syp:,} SYP",
        ]
    )
    if d.bonus_credit_syp:
        lines.append(f"🎁 البونص: {d.bonus_credit_syp:,} SYP")
    lines.append(f"✅ الإجمالي عند الاعتماد: <b>{d.total_credit_syp:,} SYP</b>")
    return "\n".join(lines)


async def _edit_review_message(callback: CallbackQuery, text: str, *, reply_markup=None) -> None:
    message = callback.message
    if not isinstance(message, Message):
        return
    if message.photo:
        await message.edit_caption(caption=text, reply_markup=reply_markup)
    else:
        await message.edit_text(text, reply_markup=reply_markup)


async def _send_manual_review_message(bot: Bot, chat_id: int, deposit: DepositRecord) -> None:
    text = _manual_card(deposit)
    markup = manual_review_menu(str(deposit.id))
    if deposit.proof_file_id:
        await bot.send_photo(chat_id, photo=deposit.proof_file_id, caption=text, reply_markup=markup)
    else:
        await bot.send_message(chat_id, text, reply_markup=markup)


async def _notify_manual_admins(bot: Bot, settings: Settings, deposit: DepositRecord) -> None:
    # Match the reference-bot workflow when a review channel is configured, but
    # fall back to direct super-admin notifications so a Telegram channel problem
    # never hides a pending financial request.
    review_chat_id = settings.deposit_manual_review_chat_id
    if review_chat_id:
        try:
            await _send_manual_review_message(bot, review_chat_id, deposit)
            return
        except Exception:
            logger.warning(
                "Could not notify manual-deposit review chat %s; falling back to admins",
                review_chat_id,
                exc_info=True,
            )

    if not settings.super_admin_ids:
        logger.error("Manual deposit %s is pending but no review destination is configured", deposit.id)
        return

    async def send(admin_id: int):
        try:
            await _send_manual_review_message(bot, admin_id, deposit)
        except Exception:
            logger.debug("Could not notify manual-deposit admin %s", admin_id, exc_info=True)

    await asyncio.gather(*(send(admin_id) for admin_id in settings.super_admin_ids))


async def _notify_deposit_channel(bot: Bot, settings: Settings, text: str) -> None:
    target = settings.deposit_notify_chat_id
    if not target:
        return
    last_error: Exception | None = None
    for attempt, delay in ((1, 0), (2, 1), (3, 3)):
        if delay:
            await asyncio.sleep(delay)
        try:
            await asyncio.wait_for(bot.send_message(target, text), timeout=12)
            return
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            last_error = exc
            logger.warning(
                "Deposit channel notification attempt %s/3 failed target=%s",
                attempt,
                target,
                exc_info=True,
            )

    diagnostic = (
        "⚠️ تعذر إرسال إشعار عملية الشحن إلى قناة العمليات بعد 3 محاولات.\n"
        f"القناة: <code>{target}</code>\n"
        f"السبب: <code>{html.escape(str(last_error or 'unknown')[:300])}</code>\n\n"
        "العملية المالية نفسها لم تتغير بسبب فشل الإشعار."
    )
    for admin_id in settings.super_admin_ids:
        try:
            await bot.send_message(admin_id, diagnostic)
        except Exception:
            logger.debug("Could not send deposit-channel diagnostic to admin %s", admin_id, exc_info=True)


async def _clear_to_methods(callback: CallbackQuery, state: FSMContext, service: DepositService) -> None:
    await state.clear()
    await safe_edit(
        callback,
        "💳 <b>شحن رصيد البوت</b>\n\nاختر طريقة الشحن:",
        reply_markup=deposit_methods_menu(service),
    )


@router.callback_query(F.data == "deposit:methods")
async def methods_callback(callback: CallbackQuery, state: FSMContext, deposit_service: DepositService) -> None:
    await _clear_to_methods(callback, state, deposit_service)


@router.callback_query(F.data.startswith("deposit:method:"))
async def choose_method_callback(
    callback: CallbackQuery,
    state: FSMContext,
    deposit_service: DepositService,
) -> None:
    method = (callback.data or "").split(":", 2)[2]
    try:
        cfg = deposit_service.method_config(method)
    except DepositValidationError:
        await safe_edit(callback, "❌ طريقة الشحن غير معروفة.", reply_markup=deposit_back_menu())
        return
    if not cfg.enabled:
        await safe_edit(
            callback,
            f"⚠️ الشحن عبر <b>{html.escape(cfg.label)}</b> غير متاح حالياً.",
            reply_markup=deposit_back_menu(),
        )
        return

    await state.clear()
    await state.update_data(method=method)
    if cfg.mode == "manual":
        await state.update_data(request_key=f"manual:{uuid4().hex}")

    if method == "syriatel":
        codes = deposit_service.settings.syriatel_codes
        codes_text = "\n".join(f"• <code>{html.escape(code)}</code>" for code in codes)
        text = (
            "📱 <b>شحن عبر سيرياتيل كاش</b>\n\n"
            f"حوّل إلى أحد الأرقام التالية:\n{codes_text or '—'}\n\n"
            f"الحد الأدنى: <b>{_money(cfg.minimum)} SYP</b>\n\n"
        )
        if cfg.mode == "auto":
            text += "بعد التحويل أرسل <b>رقم العملية فقط</b>.\nسيتم جلب المبلغ والتحقق منه تلقائياً."
        else:
            text += "بعد التحويل أرسل <b>رقم العملية</b> وسنكمل بيانات الطلب للمراجعة اليدوية."
        await safe_edit(callback, text, reply_markup=deposit_cancel_menu())
        await state.set_state(DepositStates.waiting_tx)
        return

    if method in {"sham_syp", "sham_usd"}:
        text = (
            f"💵 <b>{html.escape(cfg.label)}</b>\n\n"
            f"حوّل إلى الحساب:\n<code>{html.escape(cfg.target or '')}</code>\n\n"
            f"الحد الأدنى: <b>{_money(cfg.minimum)} {cfg.currency}</b>\n"
            f"كل 1 {cfg.currency} = <b>{_money(cfg.rate)} SYP</b> بالمحفظة.\n\n"
        )
        if cfg.mode == "auto":
            text += "بعد التحويل أرسل <b>رقم العملية فقط</b>.\nالمبلغ والعملة سيتم قراءتهما من مزود الخدمة."
        else:
            text += "بعد التحويل أرسل <b>رقم العملية</b>."
        await safe_edit(callback, text, reply_markup=deposit_cancel_menu())
        await state.set_state(DepositStates.waiting_tx)
        return

    if method == "whish_money":
        await safe_edit(
            callback,
            "💸 <b>شحن Whish Money</b>\n\n"
            f"حوّل إلى الرقم:\n<code>{html.escape(cfg.target or '')}</code>\n\n"
            f"الحد الأدنى: <b>{_money(cfg.minimum)} USD</b>\n"
            f"كل 1 USD = <b>{_money(cfg.rate)} SYP</b>\n\n"
            "👇 أرسل المبلغ المحول بالدولار.",
            reply_markup=deposit_cancel_menu(),
        )
        await state.set_state(DepositStates.waiting_amount)
        return

    if method in {"binance_trc20", "binance_bep20"}:
        await safe_edit(
            callback,
            f"🪙 <b>{html.escape(cfg.label)}</b>\n\n"
            f"الشبكة: <b>{html.escape(cfg.network or '')}</b>\n"
            f"العنوان:\n<code>{html.escape(cfg.target or '')}</code>\n\n"
            f"الحد الأدنى: <b>{_money(cfg.minimum)} USDT</b>\n"
            f"كل 1 USDT = <b>{_money(cfg.rate)} SYP</b>\n\n"
            "👇 أرسل مبلغ USDT الذي حولته.",
            reply_markup=deposit_cancel_menu(),
        )
        await state.set_state(DepositStates.waiting_amount)
        return


@router.callback_query(F.data == "deposit:cancel")
async def cancel_callback(callback: CallbackQuery, state: FSMContext, deposit_service: DepositService) -> None:
    await state.clear()
    await safe_edit(
        callback,
        "❌ تم إلغاء عملية الشحن.",
        reply_markup=deposit_methods_menu(deposit_service),
    )


@router.message(DepositStates.waiting_tx, F.text)
async def transaction_message(message: Message, state: FSMContext, deposit_service: DepositService) -> None:
    data = await state.get_data()
    method = str(data.get("method") or "")
    try:
        cfg = deposit_service.method_config(method)
        tx = deposit_service.normalize_numeric_tx(message.text or "")
    except DepositValidationError as exc:
        await message.answer(f"❌ {html.escape(str(exc))}\n\nأرسل رقم العملية من جديد.", reply_markup=deposit_cancel_menu())
        return

    await state.update_data(tx=tx)
    if cfg.mode == "manual":
        if method == "syriatel":
            codes = deposit_service.settings.syriatel_codes
            await message.answer(
                "📥 أرسل رقم سيرياتيل الذي قمت بالتحويل إليه:\n\n"
                + "\n".join(f"• <code>{html.escape(code)}</code>" for code in codes),
                reply_markup=deposit_cancel_menu(),
            )
            await state.set_state(DepositStates.waiting_target)
            return
        await message.answer(
            f"💰 أرسل مبلغ الشحن بـ <b>{cfg.currency}</b>.",
            reply_markup=deposit_cancel_menu(),
        )
        await state.set_state(DepositStates.waiting_amount)
        return

    status = await message.answer("⏳ <b>جاري التحقق من العملية...</b>")
    try:
        if method == "syriatel":
            result = await deposit_service.auto_syriatel(message.from_user.id, tx)
        elif method in {"sham_syp", "sham_usd"}:
            result = await deposit_service.auto_sham(message.from_user.id, method, tx)
        else:
            raise DepositValidationError("المسار غير صالح.")
    except (DepositValidationError, DepositVerificationFailed) as exc:
        await state.clear()
        await status.edit_text(f"❌ {html.escape(str(exc))}", reply_markup=deposit_back_menu())
        return
    except DepositAlreadyUsed:
        await state.clear()
        await status.edit_text(
            "❌ رقم العملية مستخدم أو محجوز مسبقاً ولا يمكن اعتماده مرة ثانية.",
            reply_markup=deposit_back_menu(),
        )
        return
    except DepositProviderUnavailable:
        # Verification never reached local settlement, so the same TxID is safe to retry.
        await status.edit_text(
            "⚠️ تعذر الاتصال بخدمة التحقق حالياً.\n"
            "<b>لم يتم حجز رقم العملية محلياً.</b>\n"
            "أرسل نفس رقم العملية من جديد بعد قليل.",
            reply_markup=deposit_cancel_menu(),
        )
        return
    except DepositOutcomeUncertain:
        # A DB connection can fail while COMMIT is being acknowledged. Never claim
        # success or failure until the immutable provider claim is re-read.
        await status.edit_text(
            "⚠️ <b>تعذر تأكيد النتيجة النهائية للعملية.</b>\n\n"
            "لا تقم بتحويل مبلغ جديد. أرسل <b>نفس رقم العملية</b> مرة أخرى بعد قليل؛ "
            "النظام سيعرض الرصيد المعتمد إن كانت العملية قد نجحت ولن يضيفها مرتين.",
            reply_markup=deposit_cancel_menu(),
        )
        return
    except Exception:
        logger.exception("Unexpected automatic deposit failure method=%s user=%s", method, message.from_user.id)
        await status.edit_text(
            "⚠️ حدث خطأ داخلي أثناء التحقق.\n"
            "لا تقم بتحويل مبلغ جديد. أعد إرسال <b>نفس رقم العملية</b> بعد قليل؛ "
            "الحماية المالية تمنع احتسابها مرتين.",
            reply_markup=deposit_cancel_menu(),
        )
        return

    await state.clear()
    await status.edit_text(_success_text(result), reply_markup=deposit_back_menu())
    if not result.duplicate:
        asyncio.create_task(
            _notify_deposit_channel(
                message.bot,
                deposit_service.settings,
                f"✅ شحن ناجح\n👤 <code>{message.from_user.id}</code>\n💳 {_method_label(result.deposit.method)}\n🧾 <code>{html.escape(result.deposit.provider_tx or '-')}</code>\n➕ {result.deposit.total_credit_syp:,} SYP",
            )
        )


@router.message(DepositStates.waiting_target, F.text)
async def target_message(message: Message, state: FSMContext, deposit_service: DepositService) -> None:
    try:
        value = deposit_service.normalize_numeric_tx(message.text or "")
    except DepositValidationError:
        value = ""
    if value not in deposit_service.settings.syriatel_codes:
        await message.answer("❌ الرقم غير موجود ضمن أرقام الاستلام. أرسله من جديد.", reply_markup=deposit_cancel_menu())
        return
    await state.update_data(target_ref=value)
    await message.answer("💰 أرسل مبلغ الشحن بالليرة السورية.", reply_markup=deposit_cancel_menu())
    await state.set_state(DepositStates.waiting_amount)


@router.message(DepositStates.waiting_amount, F.text)
async def amount_message(message: Message, state: FSMContext, deposit_service: DepositService) -> None:
    data = await state.get_data()
    method = str(data.get("method") or "")
    try:
        cfg = deposit_service.method_config(method)
        amount = deposit_service.normalize_amount(message.text or "")
        if amount < cfg.minimum:
            raise DepositValidationError(f"المبلغ أقل من الحد الأدنى ({_money(cfg.minimum)} {cfg.currency}).")
        deposit_service.credit_preview(method, amount)
    except DepositValidationError as exc:
        await message.answer(f"❌ {html.escape(str(exc))}\n\nأرسل المبلغ من جديد.", reply_markup=deposit_cancel_menu())
        return

    await state.update_data(amount=str(amount))
    if method == "whish_money":
        await message.answer(
            "📷 <b>أرسل الآن صورة إشعار التحويل</b>\n\n"
            "تُستخدم الصورة للمراجعة داخل Telegram فقط ولا يتم تنزيلها إلى ملفات السيرفر.",
            reply_markup=whish_photo_menu(),
        )
        await state.set_state(DepositStates.waiting_whish_photo)
        return
    if method in {"binance_trc20", "binance_bep20"}:
        await message.answer(
            f"🪙 المبلغ: <b>{_money(amount)} USDT</b>\n\n👇 أرسل TxID / Transaction Hash كما يظهر في Binance.",
            reply_markup=deposit_cancel_menu(),
        )
        await state.set_state(DepositStates.waiting_binance_tx)
        return

    _, _, total = deposit_service.credit_preview(method, amount)
    lines = [
        "💳 <b>تأكيد طلب الشحن اليدوي</b>",
        "",
        f"الطريقة: {html.escape(cfg.label)}",
        f"رقم العملية: <code>{html.escape(str(data.get('tx') or ''))}</code>",
    ]
    if method == "syriatel":
        lines.append(f"الرقم المحول إليه: <code>{html.escape(str(data.get('target_ref') or ''))}</code>")
    lines.extend([
        f"المبلغ: {_money(amount)} {cfg.currency}",
        f"الإجمالي بعد الاعتماد: <b>{total:,} SYP</b>",
    ])
    await message.answer("\n".join(lines), reply_markup=deposit_confirm_menu())
    await state.set_state(DepositStates.waiting_confirm)


@router.message(DepositStates.waiting_binance_tx, F.text)
async def binance_tx_message(message: Message, state: FSMContext, deposit_service: DepositService) -> None:
    data = await state.get_data()
    method = str(data.get("method") or "")
    try:
        cfg = deposit_service.method_config(method)
        tx = deposit_service.normalize_binance_tx(message.text or "")
        amount = Decimal(str(data.get("amount")))
    except (DepositValidationError, ArithmeticError, ValueError):
        await message.answer("❌ TxID غير صحيح. أرسله من جديد كما يظهر في Binance.", reply_markup=deposit_cancel_menu())
        return
    await state.update_data(tx=tx)
    _, _, total = deposit_service.credit_preview(method, amount)
    await message.answer(
        "🪙 <b>تأكيد شحن Binance</b>\n\n"
        f"الشبكة: {html.escape(cfg.network or '')}\n"
        f"TxID: <code>{html.escape(tx)}</code>\n"
        f"المبلغ: {_money(amount)} USDT\n"
        f"الإجمالي المتوقع: <b>{total:,} SYP</b>\n\n"
        "عند التأكيد سيتم التحقق من Binance قبل إضافة أي رصيد.",
        reply_markup=deposit_confirm_menu(),
    )
    await state.set_state(DepositStates.waiting_confirm)


@router.message(DepositStates.waiting_whish_photo, F.photo)
async def whish_photo_message(message: Message, state: FSMContext, deposit_service: DepositService) -> None:
    data = await state.get_data()
    amount = Decimal(str(data.get("amount")))
    photo_id = message.photo[-1].file_id
    photo_unique_id = message.photo[-1].file_unique_id
    await state.update_data(proof_file_id=photo_id, proof_unique_id=photo_unique_id)
    base, bonus, total = deposit_service.credit_preview("whish_money", amount)
    await message.answer(
        "✅ تم استلام صورة التحويل\n\n"
        f"💰 المبلغ: {_money(amount)} USD\n"
        f"➕ الأساسي: {base:,} SYP\n"
        + (f"🎁 البونص: {bonus:,} SYP\n" if bonus else "")
        + f"✅ الإجمالي بعد الاعتماد: <b>{total:,} SYP</b>",
        reply_markup=deposit_confirm_menu(),
    )
    await state.set_state(DepositStates.waiting_confirm)


@router.message(DepositStates.waiting_whish_photo)
async def whish_photo_invalid(message: Message) -> None:
    await message.answer("❌ يجب إرسال صورة إشعار التحويل فقط.", reply_markup=whish_photo_menu())


@router.callback_query(F.data == "deposit:whish:back_amount")
async def whish_back_amount(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    request_key = data.get("request_key")
    await state.set_data({"method": "whish_money", "request_key": request_key})
    await state.set_state(DepositStates.waiting_amount)
    await safe_edit(callback, "💸 <b>Whish Money</b>\n\n👇 أرسل المبلغ المحول بالدولار من جديد.", reply_markup=deposit_cancel_menu())


@router.callback_query(F.data == "deposit:confirm")
async def confirm_callback(
    callback: CallbackQuery,
    state: FSMContext,
    deposit_service: DepositService,
    settings: Settings,
) -> None:
    data = await state.get_data()
    method = str(data.get("method") or "")
    if not method:
        await safe_edit(callback, "⚠️ انتهت جلسة الشحن. ابدأ من جديد.", reply_markup=deposit_back_menu())
        return

    await safe_edit(callback, "⏳ <b>جاري معالجة الطلب...</b>")

    if method in {"binance_trc20", "binance_bep20"}:
        try:
            amount = Decimal(str(data.get("amount"))) if data.get("amount") is not None else None
            if amount is None:
                raise DepositValidationError("المبلغ غير موجود.")
            result = await deposit_service.auto_binance(
                callback.from_user.id,
                method,
                amount=amount,
                tx_raw=str(data.get("tx") or ""),
            )
        except (DepositValidationError, DepositVerificationFailed) as exc:
            await state.clear()
            await safe_edit(callback, f"❌ {html.escape(str(exc))}", reply_markup=deposit_back_menu())
            return
        except DepositAlreadyUsed:
            await state.clear()
            await safe_edit(callback, "❌ رمز العملية مستخدم أو محجوز مسبقاً.", reply_markup=deposit_back_menu())
            return
        except DepositProviderUnavailable:
            await safe_edit(
                callback,
                "⚠️ تعذر الوصول إلى Binance حالياً.\n"
                "<b>لم يتم حجز TxID محلياً.</b> يمكنك إعادة التأكيد بنفس البيانات بعد قليل.",
                reply_markup=deposit_confirm_menu(),
            )
            return
        except DepositOutcomeUncertain:
            await safe_edit(
                callback,
                "⚠️ <b>تعذر تأكيد النتيجة النهائية.</b>\n\n"
                "لا ترسل حوالة جديدة. أعد التأكيد بنفس TxID بعد قليل؛ إذا كانت العملية قد اعتمدت "
                "فسيعرضها النظام بدون إضافة ثانية.",
                reply_markup=deposit_confirm_menu(),
            )
            return
        except Exception:
            logger.exception("Unexpected Binance deposit failure method=%s user=%s", method, callback.from_user.id)
            await safe_edit(
                callback,
                "⚠️ حدث خطأ داخلي أثناء التحقق. لا ترسل حوالة جديدة؛ أعد التأكيد بنفس TxID بعد قليل.",
                reply_markup=deposit_confirm_menu(),
            )
            return

        await state.clear()
        await safe_edit(callback, _success_text(result), reply_markup=deposit_back_menu())
        if not result.duplicate:
            asyncio.create_task(
                _notify_deposit_channel(
                    callback.bot,
                    settings,
                    f"✅ شحن Binance ناجح\n👤 <code>{callback.from_user.id}</code>\n🧾 <code>{html.escape(result.deposit.provider_tx or '-')}</code>\n➕ {result.deposit.total_credit_syp:,} SYP",
                )
            )
        return

    try:
        amount = Decimal(str(data.get("amount"))) if data.get("amount") is not None else None
        if amount is None:
            raise DepositValidationError("المبلغ غير موجود.")
        creation = await deposit_service.create_manual_request(
            callback.from_user.id,
            method,
            amount=amount,
            tx_raw=str(data.get("tx") or "") or None,
            target_ref=str(data.get("target_ref") or "") or None,
            proof_file_id=str(data.get("proof_file_id") or "") or None,
            proof_unique_id=str(data.get("proof_unique_id") or "") or None,
            request_key=str(data.get("request_key") or "") or None,
        )
    except DepositValidationError as exc:
        await state.clear()
        await safe_edit(callback, f"❌ {html.escape(str(exc))}", reply_markup=deposit_back_menu())
        return
    except DepositAlreadyUsed:
        await state.clear()
        await safe_edit(callback, "❌ رقم العملية أو إثبات التحويل مستخدم أو محجوز مسبقاً.", reply_markup=deposit_back_menu())
        return
    except DepositOutcomeUncertain:
        await safe_edit(
            callback,
            "⚠️ تعذر تأكيد حفظ الطلب. أعد الضغط على <b>تأكيد</b> بنفس البيانات؛ "
            "مفتاح الطلب يمنع إنشاء طلبين عند التكرار.",
            reply_markup=deposit_confirm_menu(),
        )
        return
    except Exception:
        logger.exception("Unexpected manual deposit creation failure method=%s user=%s", method, callback.from_user.id)
        await safe_edit(
            callback,
            "⚠️ حدث خطأ داخلي أثناء تسجيل الطلب. أعد التأكيد بنفس البيانات؛ لن يتم إنشاء طلبين متطابقين.",
            reply_markup=deposit_confirm_menu(),
        )
        return

    await state.clear()
    await safe_edit(
        callback,
        "✅ <b>تم استلام طلب الشحن</b>\n\n"
        "تم تسجيله بشكل آمن وسيتم إشعارك فور اعتماد الطلب أو رفضه.\n"
        f"🆔 رقم الطلب: <code>{creation.deposit.id}</code>",
        reply_markup=deposit_back_menu(),
    )
    if not creation.duplicate:
        await _notify_manual_admins(callback.bot, settings, creation.deposit)


@router.callback_query(F.data == "admin:deposits:pending")
async def admin_pending_callback(
    callback: CallbackQuery,
    settings: Settings,
    deposit_service: DepositService,
) -> None:
    if callback.from_user.id not in settings.super_admin_ids:
        return
    rows = await deposit_service.pending_manual(limit=50)
    if not rows:
        await safe_edit(callback, "💳 <b>طلبات الشحن اليدوي</b>\n\n✅ لا توجد طلبات معلقة حالياً.", reply_markup=admin_pending_deposits_menu([]))
        return
    items = [
        (str(d.id), f"#{str(d.id)[:8]} • {_method_label(d.method)} • {_money(d.amount_input)} {d.currency}")
        for d in rows[:20]
    ]
    await safe_edit(
        callback,
        f"💳 <b>طلبات الشحن اليدوي</b>\n\nالمعلقة: <b>{len(rows)}</b>\nاختر طلباً للمراجعة:",
        reply_markup=admin_pending_deposits_menu(items),
    )


@router.callback_query(F.data.startswith("deposit:admin:view:"))
async def admin_view_callback(
    callback: CallbackQuery,
    settings: Settings,
    deposit_service: DepositService,
) -> None:
    if callback.from_user.id not in settings.super_admin_ids:
        return
    deposit_id = (callback.data or "").rsplit(":", 1)[-1]
    try:
        deposit = await deposit_service.repository.get(UUID(deposit_id))
    except ValueError:
        deposit = None
    if deposit is None:
        await safe_edit(callback, "❌ الطلب غير موجود.", reply_markup=admin_pending_deposits_menu([]))
        return
    markup = manual_review_menu(str(deposit.id)) if deposit.status == "manual_pending" else admin_pending_deposits_menu([])
    if deposit.proof_file_id and isinstance(callback.message, Message):
        try:
            await callback.message.answer_photo(
                photo=deposit.proof_file_id,
                caption=_manual_card(deposit),
                reply_markup=markup,
            )
            return
        except Exception:
            logger.exception("Could not display manual deposit proof deposit=%s", deposit.id)
    await safe_edit(callback, _manual_card(deposit), reply_markup=markup)


@router.callback_query(F.data.startswith("deposit:admin:approve:"))
async def admin_approve_callback(
    callback: CallbackQuery,
    settings: Settings,
    deposit_service: DepositService,
) -> None:
    if callback.from_user.id not in settings.super_admin_ids:
        return
    deposit_id = (callback.data or "").rsplit(":", 1)[-1]
    try:
        result = await deposit_service.approve_manual(deposit_id, callback.from_user.id)
    except (DepositAlreadyProcessed, ValueError):
        await _edit_review_message(callback, "⚠️ هذا الطلب تمت معالجته مسبقاً.")
        return
    except DepositOutcomeUncertain:
        await _edit_review_message(
            callback,
            "⚠️ <b>تعذر تأكيد نتيجة الاعتماد.</b>\n\n"
            "لا تضف رصيداً يدوياً. افتح الطلب/أعد المحاولة؛ النظام سيتحقق من السجل المالي قبل أي إضافة جديدة.",
            reply_markup=manual_review_menu(deposit_id),
        )
        return
    except Exception:
        logger.exception("Unexpected manual deposit approval failure deposit=%s admin=%s", deposit_id, callback.from_user.id)
        await _edit_review_message(
            callback,
            "⚠️ حدث خطأ أثناء الاعتماد. لا تنفذ أي إضافة يدوية؛ أعد المحاولة من نفس الطلب.",
            reply_markup=manual_review_menu(deposit_id),
        )
        return
    await _edit_review_message(
        callback,
        _manual_card(result.deposit) + f"\n\n✅ <b>تم الاعتماد</b>\nالرصيد بعد العملية: {result.balance_after:,} SYP",
    )
    try:
        await callback.bot.send_message(result.deposit.telegram_id, _success_text(result), reply_markup=deposit_back_menu())
    except Exception:
        logger.debug("Could not notify user about approved deposit", exc_info=True)
    asyncio.create_task(
        _notify_deposit_channel(
            callback.bot,
            settings,
            f"✅ اعتماد شحن يدوي\n👤 <code>{result.deposit.telegram_id}</code>\n👮 <code>{callback.from_user.id}</code>\n➕ {result.deposit.total_credit_syp:,} SYP",
        )
    )


@router.callback_query(F.data.startswith("deposit:admin:reject:"))
async def admin_reject_callback(
    callback: CallbackQuery,
    settings: Settings,
    deposit_service: DepositService,
) -> None:
    if callback.from_user.id not in settings.super_admin_ids:
        return
    deposit_id = (callback.data or "").rsplit(":", 1)[-1]
    try:
        deposit = await deposit_service.reject_manual(deposit_id, callback.from_user.id)
    except (DepositAlreadyProcessed, ValueError):
        await _edit_review_message(callback, "⚠️ هذا الطلب تمت معالجته مسبقاً.")
        return
    except Exception:
        logger.exception("Unexpected manual deposit rejection failure deposit=%s admin=%s", deposit_id, callback.from_user.id)
        await _edit_review_message(
            callback,
            "⚠️ تعذر تأكيد رفض الطلب. أعد فتحه من قائمة الطلبات قبل أي إجراء آخر.",
            reply_markup=manual_review_menu(deposit_id),
        )
        return
    await _edit_review_message(callback, _manual_card(deposit) + "\n\n❌ <b>تم رفض الطلب</b>")
    try:
        await callback.bot.send_message(
            deposit.telegram_id,
            "❌ <b>تم رفض طلب الشحن</b>\n\nلم تتم إضافة أي رصيد إلى محفظتك. يمكنك التواصل مع الدعم عند الحاجة.",
            reply_markup=deposit_back_menu(),
        )
    except Exception:
        logger.debug("Could not notify user about rejected deposit", exc_info=True)
