from __future__ import annotations

from uuid import UUID

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.core.emojis import SUCCESS_EMOJI_ID


def admin_ichancy_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏦 الكاشيرة الحالية", callback_data="admin:ichancy:cashier")],
        [InlineKeyboardButton(text="🔄 استبدال الكاشيرة", callback_data="admin:ichancy:replace")],
        [InlineKeyboardButton(text="⚠️ عمليات تحتاج مراجعة", callback_data="admin:ichancy:review")],
        [InlineKeyboardButton(text="📚 سجلات الكاشيرات القديمة", callback_data="admin:ichancy:old")],
        [
            InlineKeyboardButton(text="📥 حد الشحن", callback_data="admin:ichancy:setting:ichancy.min_deposit"),
            InlineKeyboardButton(text="📤 حد السحب", callback_data="admin:ichancy:setting:ichancy.min_withdraw"),
        ],
        [InlineKeyboardButton(text="🏷 بادئة الحسابات", callback_data="admin:ichancy:setting:ichancy.username_prefix")],
        [InlineKeyboardButton(text="⬅️ لوحة الإدارة", callback_data="admin:home")],
    ])


def staged_cashier_menu(cashier_id: UUID) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⚠️ بدء استبدال الكاشيرة", callback_data=f"admin:ichancy:replace:start:{cashier_id}")],
        [InlineKeyboardButton(text="⬅️ إدارة iChancy", callback_data="admin:ichancy")],
    ])


def replacement_menu(replacement_id: UUID, status: str) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    if status == "blocked":
        rows.append([InlineKeyboardButton(text="🔄 إعادة فحص المشاكل المؤكدة", callback_data=f"admin:ichancy:replace:retry:{replacement_id}")])
    if status == "ready":
        rows.append([InlineKeyboardButton(text="اعتماد الكاشيرة الجديدة", callback_data=f"admin:ichancy:replace:finalize:{replacement_id}", icon_custom_emoji_id=SUCCESS_EMOJI_ID)])
    rows.append([InlineKeyboardButton(text="🔄 تحديث الحالة", callback_data=f"admin:ichancy:replace:view:{replacement_id}")])
    rows.append([InlineKeyboardButton(text="⬅️ إدارة iChancy", callback_data="admin:ichancy")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def old_records_menu(record_ids: list[tuple[UUID, str, int | None, bool]]) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for record_id, username, balance, compensated in record_ids:
        bal = "؟" if balance is None else f"{balance:,}"
        mark = "✅" if compensated else "📦"
        rows.append([InlineKeyboardButton(text=f"{mark} {username} • {bal}", callback_data=f"admin:ichancy:old:view:{record_id}")])
    rows.append([InlineKeyboardButton(text="🔎 بحث جديد", callback_data="admin:ichancy:old")])
    rows.append([InlineKeyboardButton(text="⬅️ إدارة iChancy", callback_data="admin:ichancy")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def old_record_actions(record_id: UUID, *, can_compensate: bool) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    if can_compensate:
        rows.append([InlineKeyboardButton(text="💰 تعويض المستخدم", callback_data=f"admin:ichancy:old:compensate:{record_id}")])
    rows.append([InlineKeyboardButton(text="⬅️ السجلات القديمة", callback_data="admin:ichancy:old")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def review_jobs_menu(job_ids: list[tuple[UUID, str, int, int]]) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    labels = {
        "deposit": "📥 شحن",
        "withdraw": "📤 سحب",
        "retirement_withdraw": "🔄 تصفية",
    }
    for job_id, operation_type, telegram_id, amount in job_ids:
        label = labels.get(operation_type, operation_type)
        rows.append([InlineKeyboardButton(
            text=f"⚠️ {label} • {amount:,} • {telegram_id}",
            callback_data=f"admin:ichancy:review:view:{job_id}",
        )])
    rows.append([InlineKeyboardButton(text="🔄 تحديث", callback_data="admin:ichancy:review")])
    rows.append([InlineKeyboardButton(text="⬅️ إدارة iChancy", callback_data="admin:ichancy")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def review_job_actions(job_id: UUID) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="تأكدت أن العملية تمت",
            callback_data=f"admin:ichancy:review:done:{job_id}",
            icon_custom_emoji_id=SUCCESS_EMOJI_ID,
        )],
        [InlineKeyboardButton(
            text="↩️ تأكدت أن العملية لم تتم",
            callback_data=f"admin:ichancy:review:notdone:{job_id}",
        )],
        [InlineKeyboardButton(text="⬅️ عمليات تحتاج مراجعة", callback_data="admin:ichancy:review")],
    ])
