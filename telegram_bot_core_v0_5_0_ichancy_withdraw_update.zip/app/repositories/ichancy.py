from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

import asyncpg

from app.core.db import Database


@dataclass(frozen=True, slots=True)
class CashierRecord:
    id: UUID
    generation: int
    label: str | None
    api_username_cipher: str
    api_password_cipher: str
    parent_id: str
    currency: str
    base_url: str
    gateway_url: str
    gateway_secret_cipher: str | None
    status: str


@dataclass(frozen=True, slots=True)
class AccountRecord:
    id: UUID
    telegram_id: int
    cashier_id: UUID
    sequence_no: int
    username: str
    password_cipher: str
    email: str | None
    player_id: str
    status: str
    balance_at_retirement: int | None
    retirement_check_status: str | None
    settlement_status: str
    compensated_amount: int


@dataclass(frozen=True, slots=True)
class CreationRecord:
    id: UUID
    telegram_id: int
    cashier_id: UUID
    sequence_no: int
    requested_name: str
    normalized_name: str
    final_username: str
    password_cipher: str
    email: str
    status: str
    player_id: str | None
    last_error: str | None


class IchancyRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def get_active_cashier(self) -> CashierRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM bot_core.ichancy_cashiers WHERE status='active' LIMIT 1")
        return self._cashier(row) if row else None

    async def get_cashier(self, cashier_id: UUID) -> CashierRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM bot_core.ichancy_cashiers WHERE id=$1", cashier_id)
        return self._cashier(row) if row else None

    async def bootstrap_cashier(
        self,
        *,
        username_cipher: str,
        password_cipher: str,
        parent_id: str,
        currency: str,
        base_url: str,
        gateway_url: str,
        gateway_secret_cipher: str | None,
    ) -> CashierRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow("SELECT * FROM bot_core.ichancy_cashiers WHERE status='active' LIMIT 1 FOR UPDATE")
                if row:
                    return self._cashier(row)
                row = await conn.fetchrow(
                    """
                    INSERT INTO bot_core.ichancy_cashiers(
                        id,label,api_username_cipher,api_password_cipher,parent_id,currency,
                        base_url,gateway_url,gateway_secret_cipher,status,last_test_ok,last_tested_at,activated_at
                    )
                    VALUES($1,'bootstrap',$2,$3,$4,$5,$6,$7,$8,'active',NULL,NULL,NOW())
                    RETURNING *
                    """,
                    uuid4(), username_cipher, password_cipher, parent_id, currency,
                    base_url, gateway_url or None, gateway_secret_cipher,
                )
        return self._cashier(row)


    async def create_staged_cashier(
        self,
        *,
        label: str | None,
        username_cipher: str,
        password_cipher: str,
        parent_id: str,
        currency: str,
        base_url: str,
        gateway_url: str,
        gateway_secret_cipher: str | None,
        created_by: int,
    ) -> CashierRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO bot_core.ichancy_cashiers(
                    id,label,api_username_cipher,api_password_cipher,parent_id,currency,
                    base_url,gateway_url,gateway_secret_cipher,status,created_by
                ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'staged',$10)
                RETURNING *
                """,
                uuid4(), (label or None), username_cipher, password_cipher, parent_id, currency,
                base_url, (gateway_url or None), gateway_secret_cipher, created_by,
            )
        return self._cashier(row)

    async def list_cashiers(self, limit: int = 20) -> list[CashierRecord]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM bot_core.ichancy_cashiers ORDER BY generation DESC LIMIT $1",
                max(1, min(100, int(limit))),
            )
        return [self._cashier(r) for r in rows]

    async def get_account(self, account_id: UUID) -> AccountRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM bot_core.ichancy_accounts WHERE id=$1", account_id)
        return self._account(row) if row else None

    async def get_active_account(self, telegram_id: int) -> AccountRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM bot_core.ichancy_accounts WHERE telegram_id=$1 AND status='active' LIMIT 1",
                telegram_id,
            )
        return self._account(row) if row else None

    async def get_inflight_creation(self, telegram_id: int) -> CreationRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM bot_core.ichancy_account_creations
                WHERE telegram_id=$1 AND status IN ('creating','uncertain')
                ORDER BY created_at DESC LIMIT 1
                """,
                telegram_id,
            )
        return self._creation(row) if row else None

    async def begin_creation(
        self,
        *,
        telegram_id: int,
        cashier_id: UUID,
        requested_name: str,
        normalized_name: str,
        prefix: str,
        password_cipher: str,
        email_factory,
        username_factory,
    ) -> CreationRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # Serialize account creation per Telegram user and against cashier
                # replacement. Cashier is locked first to match replacement lock order.
                cashier = await conn.fetchrow(
                    "SELECT id,status FROM bot_core.ichancy_cashiers WHERE id=$1 FOR UPDATE",
                    cashier_id,
                )
                if not cashier or str(cashier["status"]) != "active":
                    raise ValueError("ICHANCY_CASHIER_NOT_ACTIVE")
                user_row = await conn.fetchrow(
                    "SELECT telegram_id FROM bot_core.users WHERE telegram_id=$1 FOR UPDATE",
                    telegram_id,
                )
                if not user_row:
                    raise ValueError("USER_NOT_FOUND")
                account = await conn.fetchrow(
                    "SELECT id FROM bot_core.ichancy_accounts WHERE telegram_id=$1 AND status='active' FOR UPDATE",
                    telegram_id,
                )
                if account:
                    raise ValueError("ICHANCY_ACCOUNT_EXISTS")
                current = await conn.fetchrow(
                    """
                    SELECT * FROM bot_core.ichancy_account_creations
                    WHERE telegram_id=$1 AND status IN ('creating','uncertain')
                    ORDER BY created_at DESC LIMIT 1 FOR UPDATE
                    """,
                    telegram_id,
                )
                if current:
                    return self._creation(current)
                sequence_no = int(await conn.fetchval("SELECT nextval('bot_core.ichancy_username_seq')"))
                username = username_factory(prefix, sequence_no, normalized_name)
                email = email_factory(username, telegram_id, sequence_no)
                row = await conn.fetchrow(
                    """
                    INSERT INTO bot_core.ichancy_account_creations(
                        id,telegram_id,cashier_id,sequence_no,requested_name,normalized_name,
                        final_username,password_cipher,email,status
                    ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'creating')
                    RETURNING *
                    """,
                    uuid4(), telegram_id, cashier_id, sequence_no, requested_name, normalized_name,
                    username, password_cipher, email,
                )
        return self._creation(row)

    async def mark_creation_failed(self, creation_id: UUID, error: str) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.ichancy_account_creations
                SET status='failed',last_error=$2,updated_at=NOW(),finished_at=NOW()
                WHERE id=$1 AND status IN ('creating','uncertain')
                """,
                creation_id, error[:1200],
            )

    async def mark_creation_uncertain(self, creation_id: UUID, error: str) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.ichancy_account_creations
                SET status='uncertain',last_error=$2,updated_at=NOW()
                WHERE id=$1 AND status='creating'
                """,
                creation_id, error[:1200],
            )

    async def finalize_creation(
        self,
        *,
        creation_id: UUID,
        player_id: str,
        notification_text: str,
    ) -> AccountRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                creation = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_account_creations WHERE id=$1 FOR UPDATE",
                    creation_id,
                )
                if creation is None:
                    raise ValueError("ICHANCY_CREATION_NOT_FOUND")
                existing = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_accounts WHERE creation_id=$1",
                    creation_id,
                )
                if existing:
                    return self._account(existing)
                other_active = await conn.fetchrow(
                    "SELECT id FROM bot_core.ichancy_accounts WHERE telegram_id=$1 AND status='active' FOR UPDATE",
                    int(creation["telegram_id"]),
                )
                if other_active:
                    raise ValueError("ICHANCY_ACCOUNT_EXISTS")
                account_id = uuid4()
                row = await conn.fetchrow(
                    """
                    INSERT INTO bot_core.ichancy_accounts(
                        id,telegram_id,cashier_id,creation_id,sequence_no,username,
                        password_cipher,email,player_id,status
                    ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'active')
                    RETURNING *
                    """,
                    account_id, int(creation["telegram_id"]), creation["cashier_id"], creation_id,
                    int(creation["sequence_no"]), str(creation["final_username"]),
                    str(creation["password_cipher"]), str(creation["email"]), str(player_id),
                )
                await conn.execute(
                    """
                    UPDATE bot_core.ichancy_account_creations
                    SET status='created',player_id=$2,last_error=NULL,updated_at=NOW(),finished_at=NOW()
                    WHERE id=$1
                    """,
                    creation_id, str(player_id),
                )
                await conn.execute(
                    """
                    INSERT INTO bot_core.notification_outbox(id,event_key,target_key,text,parse_mode)
                    VALUES($1,$2,'notify.ichancy_accounts',$3,'HTML')
                    ON CONFLICT(event_key) DO NOTHING
                    """,
                    uuid4(), f"ichancy-account-created:{account_id}", notification_text,
                )
        return self._account(row)

    async def update_cashier_test(self, cashier_id: UUID, *, ok: bool, error: str | None) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.ichancy_cashiers
                SET last_tested_at=NOW(),last_test_ok=$2,last_test_error=$3
                WHERE id=$1
                """,
                cashier_id, ok, (error[:1200] if error else None),
            )

    @staticmethod
    def _cashier(row: asyncpg.Record) -> CashierRecord:
        return CashierRecord(
            id=row["id"], generation=int(row["generation"]),
            label=str(row["label"]) if row["label"] is not None else None,
            api_username_cipher=str(row["api_username_cipher"]), api_password_cipher=str(row["api_password_cipher"]),
            parent_id=str(row["parent_id"] or ""), currency=str(row["currency"]), base_url=str(row["base_url"]),
            gateway_url=str(row["gateway_url"] or ""),
            gateway_secret_cipher=str(row["gateway_secret_cipher"]) if row["gateway_secret_cipher"] is not None else None,
            status=str(row["status"]),
        )

    @staticmethod
    def _account(row: asyncpg.Record) -> AccountRecord:
        return AccountRecord(
            id=row["id"], telegram_id=int(row["telegram_id"]), cashier_id=row["cashier_id"], sequence_no=int(row["sequence_no"]),
            username=str(row["username"]), password_cipher=str(row["password_cipher"]), email=str(row["email"]) if row["email"] else None,
            player_id=str(row["player_id"]), status=str(row["status"]),
            balance_at_retirement=int(row["balance_at_retirement"]) if row["balance_at_retirement"] is not None else None,
            retirement_check_status=str(row["retirement_check_status"]) if row["retirement_check_status"] else None,
            settlement_status=str(row["settlement_status"]), compensated_amount=int(row["compensated_amount"] or 0),
        )

    @staticmethod
    def _creation(row: asyncpg.Record) -> CreationRecord:
        return CreationRecord(
            id=row["id"], telegram_id=int(row["telegram_id"]), cashier_id=row["cashier_id"], sequence_no=int(row["sequence_no"]),
            requested_name=str(row["requested_name"]), normalized_name=str(row["normalized_name"]), final_username=str(row["final_username"]),
            password_cipher=str(row["password_cipher"]), email=str(row["email"]), status=str(row["status"]),
            player_id=str(row["player_id"]) if row["player_id"] else None,
            last_error=str(row["last_error"]) if row["last_error"] else None,
        )
