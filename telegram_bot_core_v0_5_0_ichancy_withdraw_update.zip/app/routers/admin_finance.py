from __future__ import annotations

import html
from decimal import Decimal
from uuid import UUID

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.emojis import PROCESSING, SUCCESS
from app.core.withdrawals import WithdrawStateError, WithdrawValidationError
from app.services.runtime_settings import RuntimeSettingsService
from app.services.deposits import DepositService
from app.services.withdrawals import WithdrawService

router = Router(name="admin_finance")


class AdminFinanceStates(StatesGroup):
    waiting_setting = State()


def _admin(user_id: int, settings: Settings) -> bool:
    return user_id in settings.super_admin_ids


def _finance_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="💳 إدارة الشحن", callback_data="admin:finance:deposits"),
            InlineKeyboardButton(text="💸 إدارة السحب", callback_data="admin:finance:withdraws"),
        ],
        [InlineKeyboardButton(text="💱 معامل العملة المحلية", callback_data="admin:setting:money.local_syp_wallet_multiplier")],
        [InlineKeyboardButton(text="🚨 تنبيهات المبالغ الكبيرة", callback_data="admin:finance:alerts")],
        [InlineKeyboardButton(text="📢 قنوات العمليات", callback_data="admin:finance:channels")],
        [InlineKeyboardButton(text="⬅️ لوحة الإدارة", callback_data="admin:home")],
    ])


def _withdraw_admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 طلبات السحب المعلقة", callback_data="admin:withdraws:pending")],
        [InlineKeyboardButton(text="📏 الحد الأدنى للسحب", callback_data="admin:setting:withdraw.min_wallet")],
        [InlineKeyboardButton(text="💸 عمولة السحب", callback_data="admin:setting:withdraw.fee_pct")],
        [InlineKeyboardButton(text="💸 عمولة الحوالات", callback_data="admin:setting:withdraw.hawala_fee_pct")],
        [InlineKeyboardButton(text="💵 سعر USDT للسحب", callback_data="admin:setting:withdraw.usdt.rate")],
        [InlineKeyboardButton(text="⬅️ إدارة الشحن والسحب", callback_data="admin:finance")],
    ])


def _alerts_menu(runtime: RuntimeSettingsService) -> InlineKeyboardMarkup:
    specs = [
        ("alerts.ichancy_deposit_large", "شحن iChancy"),
        ("alerts.ichancy_withdraw_large", "سحب iChancy"),
        ("alerts.bot_deposit_large", "شحن البوت"),
        ("alerts.bot_withdraw_large", "سحب البوت"),
    ]
    rows = []
    for key, label in specs:
        value = runtime.get_int(key, 0)
        shown = f"{value:,}" if value > 0 else "متوقف"
        rows.append([InlineKeyboardButton(text=f"🚨 {label}: {shown}", callback_data=f"admin:setting:{key}")])
    rows.append([InlineKeyboardButton(text="⬅️ رجوع", callback_data="admin:finance")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _channels_menu(runtime: RuntimeSettingsService) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="👤 قناة حسابات iChancy", callback_data="admin:setting:notify.ichancy_accounts")],
        [InlineKeyboardButton(text="🎰 قناة عمليات iChancy", callback_data="admin:setting:notify.ichancy_operations")],
        [InlineKeyboardButton(text="💳 قناة عمليات البوت", callback_data="admin:setting:notify.bot_operations")],
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="admin:finance")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


_SETTING_META = {
    "money.local_syp_wallet_multiplier": ("معامل تحويل العملة المحلية إلى رصيد المحفظة", "decimal", "admin:finance"),
    "alerts.ichancy_deposit_large": ("حد تنبيه شحن iChancy الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "alerts.ichancy_withdraw_large": ("حد تنبيه سحب iChancy الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "alerts.bot_deposit_large": ("حد تنبيه شحن البوت الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "alerts.bot_withdraw_large": ("حد تنبيه سحب البوت الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "notify.ichancy_accounts": ("معرف قناة حسابات iChancy", "chat", "admin:finance:channels"),
    "notify.ichancy_operations": ("معرف قناة عمليات iChancy", "chat", "admin:finance:channels"),
    "notify.bot_operations": ("معرف قناة عمليات البوت", "chat", "admin:finance:channels"),
    "withdraw.min_wallet": ("الحد الأدنى لسحب رصيد البوت", "positive_int", "admin:finance:withdraws"),
    "withdraw.hawala_min_wallet": ("الحد الأدنى لسحب الحوالة", "positive_int", "admin:finance:withdraws"),
    "withdraw.usdt.min_wallet": ("الحد الأدنى لسحب USDT من رصيد المحفظة", "positive_int", "admin:finance:withdraws"),
    "withdraw.fee_pct": ("عمولة السحب %", "pct", "admin:finance:withdraws"),
    "withdraw.hawala_fee_pct": ("عمولة الحوالات %", "pct", "admin:finance:withdraws"),
    "withdraw.usdt.rate": ("سعر USDT للسحب مقابل رصيد المحفظة", "decimal", "admin:finance:withdraws"),
}


@router.callback_query(F.data == "admin:finance")
async def finance_home(callback: CallbackQuery, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    await safe_edit(callback, "💳 <b>إدارة الشحن والسحب</b>\n\nاختر القسم:", reply_markup=_finance_menu())


@router.callback_query(F.data == "admin:finance:deposits")
async def deposits_admin(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService
) -> None:
    if not _admin(callback.from_user.id, settings): return
    mult = runtime_settings.get_decimal("money.local_syp_wallet_multiplier", 100)
    sy_mode = deposit_service._runtime_mode("deposit.syriatel.mode", deposit_service.settings.syriatel_charge_mode)
    sh_mode = deposit_service._runtime_mode("deposit.sham.mode", deposit_service.settings.sham_charge_mode)
    whish = deposit_service._runtime_enabled("deposit.whish.enabled", deposit_service.settings.whish_money_enabled)
    binance = deposit_service._runtime_enabled("deposit.binance.enabled", deposit_service.settings.binance_deposit_enabled)
    await safe_edit(
        callback,
        "💳 <b>إدارة الشحن</b>\n\n"
        f"💱 العملة المحلية: <b>1 = {mult}</b> رصيد بالمحفظة\n"
        "المعامل مشترك بين شام كاش ليرة وسيرياتيل كاش فقط.\n\n"
        f"📱 سيرياتيل: <b>{sy_mode.upper()}</b>\n"
        f"💵 شام كاش: <b>{sh_mode.upper()}</b>\n"
        f"💸 Whish: <b>{'مفعل' if whish else 'متوقف'}</b>\n"
        f"🪙 Binance: <b>{'مفعل' if binance else 'متوقف'}</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="📱 سيرياتيل Auto", callback_data="admin:deposit:mode:syriatel:auto"),
                InlineKeyboardButton(text="Manual", callback_data="admin:deposit:mode:syriatel:manual"),
                InlineKeyboardButton(text="Off", callback_data="admin:deposit:mode:syriatel:off"),
            ],
            [
                InlineKeyboardButton(text="💵 شام Auto", callback_data="admin:deposit:mode:sham:auto"),
                InlineKeyboardButton(text="Manual", callback_data="admin:deposit:mode:sham:manual"),
                InlineKeyboardButton(text="Off", callback_data="admin:deposit:mode:sham:off"),
            ],
            [InlineKeyboardButton(text=f"💸 Whish: {'✅' if whish else '❌'}", callback_data="admin:deposit:toggle:whish")],
            [InlineKeyboardButton(text=f"🪙 Binance: {'✅' if binance else '❌'}", callback_data="admin:deposit:toggle:binance")],
            [InlineKeyboardButton(text="📋 طلبات الشحن اليدوي", callback_data="admin:deposits:pending")],
            [InlineKeyboardButton(text="💱 تعديل معامل العملة", callback_data="admin:setting:money.local_syp_wallet_multiplier")],
            [InlineKeyboardButton(text="⬅️ رجوع", callback_data="admin:finance")],
        ]),
    )


@router.callback_query(F.data.regexp(r"^admin:deposit:mode:(syriatel|sham):(auto|manual|off)$"))
async def set_deposit_mode(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService
) -> None:
    if not _admin(callback.from_user.id, settings): return
    parts = str(callback.data).split(":")
    provider, mode = parts[-2], parts[-1]
    await runtime_settings.set(f"deposit.{provider}.mode", mode, updated_by=callback.from_user.id)
    await deposits_admin(callback, settings, runtime_settings, deposit_service)


@router.callback_query(F.data.regexp(r"^admin:deposit:toggle:(whish|binance)$"))
async def toggle_deposit_method(
    callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService
) -> None:
    if not _admin(callback.from_user.id, settings): return
    name = str(callback.data).rsplit(":", 1)[-1]
    if name == "whish":
        key, fallback = "deposit.whish.enabled", deposit_service.settings.whish_money_enabled
    else:
        key, fallback = "deposit.binance.enabled", deposit_service.settings.binance_deposit_enabled
    await runtime_settings.set(key, not runtime_settings.get_bool(key, fallback), updated_by=callback.from_user.id)
    await deposits_admin(callback, settings, runtime_settings, deposit_service)


@router.callback_query(F.data == "admin:finance:withdraws")
async def withdraws_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    rows = [
        [InlineKeyboardButton(text="📋 طلبات السحب المعلقة", callback_data="admin:withdraws:pending")],
    ]
    for method, label in (("syriatel","سيرياتيل"),("shamcash","شام كاش"),("hawala","حوالة"),("usdt","USDT")):
        enabled = runtime_settings.get_bool(f"withdraw.{method}.enabled", True)
        rows.append([InlineKeyboardButton(text=f"{'✅' if enabled else '❌'} {label}", callback_data=f"admin:withdraw:toggle:{method}")])
    trc = runtime_settings.get_bool("withdraw.usdt.trc20.enabled", True)
    bep = runtime_settings.get_bool("withdraw.usdt.bep20.enabled", True)
    rows.append([
        InlineKeyboardButton(text=f"{'✅' if trc else '❌'} TRC20", callback_data="admin:withdraw:network:TRC20"),
        InlineKeyboardButton(text=f"{'✅' if bep else '❌'} BEP20", callback_data="admin:withdraw:network:BEP20"),
    ])
    rows.extend([
        [InlineKeyboardButton(text="📏 الحد الأدنى للسحب", callback_data="admin:setting:withdraw.min_wallet")],
        [InlineKeyboardButton(text="📏 حد الحوالة", callback_data="admin:setting:withdraw.hawala_min_wallet")],
        [InlineKeyboardButton(text="📏 حد USDT", callback_data="admin:setting:withdraw.usdt.min_wallet")],
        [InlineKeyboardButton(text="💸 عمولة السحب", callback_data="admin:setting:withdraw.fee_pct")],
        [InlineKeyboardButton(text="💸 عمولة الحوالات", callback_data="admin:setting:withdraw.hawala_fee_pct")],
        [InlineKeyboardButton(text="💵 سعر USDT للسحب", callback_data="admin:setting:withdraw.usdt.rate")],
        [InlineKeyboardButton(text="⬅️ إدارة الشحن والسحب", callback_data="admin:finance")],
    ])
    await safe_edit(callback, "💸 <b>إدارة السحب</b>", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.regexp(r"^admin:withdraw:toggle:(syriatel|shamcash|hawala|usdt)$"))
async def toggle_withdraw_method(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    method = str(callback.data).rsplit(":",1)[-1]
    key = f"withdraw.{method}.enabled"
    await runtime_settings.set(key, not runtime_settings.get_bool(key, True), updated_by=callback.from_user.id)
    await withdraws_admin(callback, settings, runtime_settings)


@router.callback_query(F.data.regexp(r"^admin:withdraw:network:(TRC20|BEP20)$"))
async def toggle_withdraw_network(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    network = str(callback.data).rsplit(":", 1)[-1].lower()
    key = f"withdraw.usdt.{network}.enabled"
    await runtime_settings.set(key, not runtime_settings.get_bool(key, True), updated_by=callback.from_user.id)
    await withdraws_admin(callback, settings, runtime_settings)


@router.callback_query(F.data == "admin:finance:alerts")
async def alerts_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await safe_edit(
        callback,
        "🚨 <b>تنبيهات المبالغ الكبيرة</b>\n\n"
        "التنبيه يظهر داخل نفس إشعار العملية بعبارة <b>🚨 مبلغ كبير</b> ولا يتم إرسال رسالة مستقلة.",
        reply_markup=_alerts_menu(runtime_settings),
    )


@router.callback_query(F.data == "admin:finance:channels")
async def channels_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await safe_edit(callback, "📢 <b>قنوات الإشعارات</b>\n\nالإشعارات محفوظة في Outbox ولا تضيع عند الانقطاع أو إعادة التشغيل.", reply_markup=_channels_menu(runtime_settings))


@router.callback_query(F.data.startswith("admin:setting:"))
async def setting_start(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    key = str(callback.data or "")[len("admin:setting:"):]
    meta = _SETTING_META.get(key)
    if not meta:
        return
    label, kind, return_cb = meta
    current = runtime_settings.get(key)
    await state.update_data(setting_key=key, setting_kind=kind, setting_label=label, setting_return=return_cb)
    await state.set_state(AdminFinanceStates.waiting_setting)
    await safe_edit(
        callback,
        f"✏️ <b>{html.escape(label)}</b>\n\nالقيمة الحالية: <code>{html.escape(str(current))}</code>\n\nأرسل القيمة الجديدة الآن.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ إلغاء", callback_data=return_cb)]]),
    )


@router.message(AdminFinanceStates.waiting_setting, F.text)
async def setting_value(message: Message, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data(); key = str(data.get("setting_key") or ""); kind = str(data.get("setting_kind") or "")
    raw = (message.text or "").strip()
    try:
        if kind == "positive_int":
            value = int(raw.replace(",", ""))
            if value <= 0:
                raise ValueError
        elif kind == "int0":
            value = int(raw.replace(",", ""))
            if value < 0:
                raise ValueError
        elif kind == "decimal":
            value = Decimal(raw.replace(",", ""))
            if value <= 0:
                raise ValueError
            value = format(value.normalize(), "f")
        elif kind == "pct":
            value = Decimal(raw)
            if not (Decimal("0") <= value <= Decimal("100")):
                raise ValueError
            value = format(value.normalize(), "f")
        elif kind == "chat":
            if raw.lower() in {"off","0","تعطيل","الغاء","إلغاء"}:
                value = None
            else:
                value = int(raw) if raw.lstrip("-").isdigit() else raw
        else:
            raise ValueError
    except Exception:
        await message.answer("❌ القيمة غير صالحة. أرسل قيمة صحيحة.")
        return
    await runtime_settings.set(key, value, updated_by=message.from_user.id)
    await state.clear()
    await message.answer(f"✅ تم حفظ الإعداد.\n<code>{html.escape(key)}</code> = <code>{html.escape(str(value))}</code>")


def _deposit_method_label(method: str) -> str:
    return {
        "syriatel": "سيرياتيل كاش",
        "sham_syp": "شام كاش – ليرة",
        "sham_usd": "شام كاش – دولار",
        "whish_money": "Whish Money",
        "binance_trc20": "Binance USDT TRC20",
        "binance_bep20": "Binance USDT BEP20",
    }.get(str(method or ""), str(method or "-") or "-")


def _withdraw_card(rec, last_deposits=()) -> str:
    text = (
        "💸 <b>طلب سحب</b>\n\n"
        f"🧾 <code>{rec.id}</code>\n"
        f"👤 <code>{rec.telegram_id}</code>\n"
        f"💳 الطريقة: <b>{html.escape(rec.method)}</b>\n"
        f"💰 المحفظة: <code>{rec.amount_wallet:,}</code>\n"
        f"💸 العمولة: <code>{rec.fee_wallet:,}</code>\n"
        f"📤 المستحق: <code>{rec.payout_amount} {rec.payout_currency}</code>\n"
        + (f"👤 اسم الحساب: <b>{html.escape(rec.receiver_name)}</b>\n" if rec.method == "shamcash" and rec.receiver_name else "")
        + f"📍 المستلم: <code>{html.escape(rec.receiver)}</code>\n"
        f"📌 الحالة: <b>{html.escape(rec.status)}</b>"
        + (f"\n⚠️ {html.escape(rec.last_error)}" if rec.last_error else "")
    )
    items = list(last_deposits or ())[:3]
    if items:
        text += "\n\n🟢 <b>آخر 3 عمليات شحن ناجحة</b>"
        for index, dep in enumerate(items, 1):
            bonus = int(dep.bonus_credit_syp or 0)
            text += (
                f"\n{index}) {_deposit_method_label(dep.method)} — "
                f"<code>{dep.total_credit_syp:,}</code>"
                f" | بونص: <code>{bonus:,}</code>"
            )
    else:
        text += "\n\n🟢 <b>آخر 3 عمليات شحن ناجحة</b>\nلا توجد عمليات ناجحة مسجلة."
    return text


def _withdraw_actions(rec) -> InlineKeyboardMarkup:
    rows = []
    if rec.status == "pending":
        if rec.method in {"syriatel","shamcash"}:
            rows.append([InlineKeyboardButton(text="⚡ تنفيذ آلي", callback_data=f"admin:withdraw:execute:{rec.id}")])
        rows.append([InlineKeyboardButton(text="✅ تأكيد تم الدفع", callback_data=f"admin:withdraw:paid:{rec.id}")])
        rows.append([InlineKeyboardButton(text="❌ رفض الطلب", callback_data=f"admin:withdraw:reject:{rec.id}")])
    elif rec.status == "provider_success":
        rows.append([InlineKeyboardButton(text="✅ تثبيت العملية محلياً", callback_data=f"admin:withdraw:paid:{rec.id}")])
    elif rec.status == "processing":
        rows.append([InlineKeyboardButton(text="⚠️ النتيجة قيد الحسم", callback_data=f"admin:withdraw:view:{rec.id}")])
    elif rec.status == "needs_review":
        rows.append([InlineKeyboardButton(text="✅ تأكيد أنها تمت", callback_data=f"admin:withdraw:paid:{rec.id}")])
        rows.append([InlineKeyboardButton(text="↩️ تأكيد أنها لم تتم", callback_data=f"admin:withdraw:notpaid:{rec.id}")])
    rows.append([InlineKeyboardButton(text="⬅️ الطلبات", callback_data="admin:withdraws:pending")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin:withdraws:pending")
async def pending_withdraws(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    items = await withdraw_service.repository.list_pending(30)
    rows = [[InlineKeyboardButton(text=f"{r.method} • {r.amount_wallet:,} • {r.status}", callback_data=f"admin:withdraw:view:{r.id}")] for r in items]
    rows.append([InlineKeyboardButton(text="⬅️ إدارة السحب", callback_data="admin:finance:withdraws")])
    await safe_edit(callback, f"📋 <b>طلبات السحب المعلقة</b>\n\nالعدد: {len(items)}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("admin:withdraw:view:"))
async def view_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    try: wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    except Exception: return
    rec = await withdraw_service.repository.get(wid)
    if not rec:
        await safe_edit(callback, "❌ الطلب غير موجود.")
        return
    last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
    await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions(rec))


@router.callback_query(F.data.startswith("admin:withdraw:execute:"))
async def execute_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    await safe_edit(callback, f"{PROCESSING} <b>جاري تنفيذ السحب عبر المزود...</b>\nلن يتم إرسال POST مالي ثانٍ إذا أصبحت النتيجة غير مؤكدة.")
    try:
        rec = await withdraw_service.execute_auto(wid, callback.from_user.id)
        await safe_edit(callback, f"{SUCCESS} تم تنفيذ السحب واعتماده بنجاح.", reply_markup=_withdraw_actions(rec))
    except (WithdrawValidationError, WithdrawStateError) as exc:
        rec = await withdraw_service.repository.get(wid)
        await safe_edit(callback, f"⚠️ {html.escape(str(exc))}" + ("\n\n" + _withdraw_card(rec) if rec else ""), reply_markup=_withdraw_actions(rec) if rec else None)


@router.callback_query(F.data.startswith("admin:withdraw:paid:"))
async def paid_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    try:
        rec = await withdraw_service.confirm_paid(wid, callback.from_user.id)
        await safe_edit(callback, "✅ تم اعتماد الطلب كمدفوع وتثبيت الخصم من الرصيد.", reply_markup=_withdraw_actions(rec))
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}")


@router.callback_query(F.data.startswith("admin:withdraw:notpaid:"))
async def notpaid_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    try:
        rec = await withdraw_service.confirm_not_paid(wid, callback.from_user.id)
        await safe_edit(callback, "↩️ تم تأكيد أن التحويل لم يتم. عاد الطلب إلى الانتظار بدون تحرير الحجز.", reply_markup=_withdraw_actions(rec))
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}")


@router.callback_query(F.data.startswith("admin:withdraw:reject:"))
async def reject_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    try:
        await withdraw_service.reject_admin(wid, callback.from_user.id, "rejected by admin")
        await safe_edit(callback, "❌ تم رفض الطلب وإعادة المبلغ المحجوز إلى المستخدم.")
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}")
