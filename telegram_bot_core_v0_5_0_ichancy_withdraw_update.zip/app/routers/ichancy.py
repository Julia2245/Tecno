from __future__ import annotations

import html
import logging
from urllib.parse import quote

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from app.config import Settings
from app.core.emojis import LOADING, PROCESSING, SUCCESS
from app.core.ui import safe_edit
from app.keyboards.ichancy import (
    back_to_ichancy,
    cancel_to_ichancy,
    full_deposit_confirm,
    ichancy_menu,
    website_open,
    replacement_wait_menu,
)
from app.providers.ichancy import IchancyDefiniteError, IchancyTemporaryError
from app.services.ichancy_accounts import IchancyAccountsService
from app.services.ichancy_jobs import IchancyJobError, IchancyJobService
from app.services.runtime_settings import RuntimeSettingsService
from app.services.wallet import WalletService
from app.repositories.ichancy_replacements import CashierReplacementRepository

router = Router(name="ichancy")
logger = logging.getLogger(__name__)


class IchancyStates(StatesGroup):
    waiting_name = State()
    waiting_deposit_amount = State()
    waiting_withdraw_amount = State()


def _parse_int(raw: str) -> int | None:
    trans = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
    value = str(raw or "").translate(trans).replace(",", "").replace("٬", "").replace(" ", "").strip()
    if not value.isdigit():
        return None
    try:
        amount = int(value)
    except Exception:
        return None
    return amount if amount > 0 else None


async def _menu_text(user_id: int, accounts: IchancyAccountsService, runtime: RuntimeSettingsService) -> tuple[str, bool]:
    account = await accounts.active_account(user_id)
    if account is None:
        return (
            "🎰 <b>iChancy</b>\n\n"
            "لا يوجد حساب iChancy نشط مرتبط بحسابك حالياً.\n"
            "يمكنك إنشاء حساب جديد من الزر أدناه.",
            False,
        )
    return (
        "🎰 <b>iChancy</b>\n\n"
        f"👤 الحساب: <code>{html.escape(account.username)}</code>\n"
        f"🎮 Player ID: <code>{html.escape(account.player_id)}</code>\n\n"
        f"الحد الأدنى للشحن: <b>{runtime.get_int('ichancy.min_deposit', 20000):,}</b>\n"
        f"الحد الأدنى للسحب: <b>{runtime.get_int('ichancy.min_withdraw', 20000):,}</b>",
        True,
    )


@router.callback_query(F.data == "ichancy:menu")
async def menu_cb(
    callback: CallbackQuery,
    state: FSMContext,
    ichancy_accounts: IchancyAccountsService,
    runtime_settings: RuntimeSettingsService,
    replacement_repository: CashierReplacementRepository,
) -> None:
    await state.clear()
    replacement = await replacement_repository.get_open()
    if replacement:
        await safe_edit(
            callback,
            "🔄 <b>يتم حالياً تحديث نظام iChancy</b>\n\n"
            "حسابات الكاشيرة القديمة قيد الفحص والتصفية بأمان. "
            "بعد اكتمال التحديث ستتمكن من إنشاء حساب جديد مرتبط بالكاشيرة الجديدة.",
            reply_markup=replacement_wait_menu(),
        )
        return
    text, has = await _menu_text(callback.from_user.id, ichancy_accounts, runtime_settings)
    await safe_edit(callback, text, reply_markup=ichancy_menu(has_account=has))


@router.callback_query(F.data == "ichancy:cancel")
async def cancel_cb(
    callback: CallbackQuery,
    state: FSMContext,
    ichancy_accounts: IchancyAccountsService,
    runtime_settings: RuntimeSettingsService,
    replacement_repository: CashierReplacementRepository,
) -> None:
    await state.clear()
    if await replacement_repository.get_open():
        await safe_edit(callback, "❌ تم إلغاء العملية.\n\n🔄 يتم حالياً تحديث نظام iChancy. حاول بعد اكتمال استبدال الكاشيرة.", reply_markup=replacement_wait_menu())
        return
    text, has = await _menu_text(callback.from_user.id, ichancy_accounts, runtime_settings)
    await safe_edit(callback, "❌ تم إلغاء العملية.\n\n" + text, reply_markup=ichancy_menu(has_account=has))


@router.callback_query(F.data == "ichancy:create")
async def create_start(callback: CallbackQuery, state: FSMContext, ichancy_accounts: IchancyAccountsService, replacement_repository: CashierReplacementRepository) -> None:
    if await replacement_repository.get_open():
        await safe_edit(callback, "🔄 يتم حالياً استبدال كاشيرة iChancy. إنشاء الحسابات الجديدة متوقف مؤقتاً حتى اكتمال التصفية.", reply_markup=replacement_wait_menu())
        return
    if await ichancy_accounts.active_account(callback.from_user.id):
        await safe_edit(callback, "✅ لديك حساب iChancy نشط بالفعل.", reply_markup=back_to_ichancy())
        return
    await state.set_state(IchancyStates.waiting_name)
    await safe_edit(
        callback,
        "👤 <b>إنشاء حساب iChancy</b>\n\n"
        "أرسل اسمك فقط. يمكن كتابته بالعربي أو الإنكليزي.\n"
        "سيقوم البوت بتحويل الاسم وتجهيز اسم الحساب وكلمة المرور تلقائياً.",
        reply_markup=cancel_to_ichancy(),
    )


@router.message(IchancyStates.waiting_name, F.text)
async def create_name(
    message: Message,
    state: FSMContext,
    ichancy_accounts: IchancyAccountsService,
    outbox_worker,
) -> None:
    if message.from_user is None:
        return
    name = (message.text or "").strip()
    if not name:
        await message.answer("❌ أرسل اسماً صالحاً.", reply_markup=cancel_to_ichancy())
        return
    if len(name) > 120:
        await message.answer("❌ الاسم طويل جداً. أرسل اسماً أقصر.", reply_markup=cancel_to_ichancy())
        return
    status = await message.answer(f"{LOADING} <b>جاري إنشاء حساب iChancy...</b>\nيرجى الانتظار قليلاً.")
    label = " ".join(x for x in [message.from_user.first_name, message.from_user.last_name] if x).strip()
    if not label:
        label = f"@{message.from_user.username}" if message.from_user.username else str(message.from_user.id)
    try:
        result = await ichancy_accounts.create_account(message.from_user.id, name, user_label=label)
    except IchancyDefiniteError as exc:
        await status.edit_text(f"❌ {html.escape(str(exc))}", reply_markup=back_to_ichancy())
        await state.clear()
        return
    except IchancyTemporaryError as exc:
        await status.edit_text(
            "⚠️ <b>تعذر تأكيد إنشاء الحساب حالياً.</b>\n\n"
            f"{html.escape(str(exc))}\n"
            "لا تحاول إنشاء أسماء مختلفة؛ أعد المحاولة لاحقاً وسيقوم النظام أولاً بالبحث عن نفس الحساب قبل إرسال طلب جديد.",
            reply_markup=back_to_ichancy(),
        )
        await state.clear()
        return
    except Exception:
        logger.exception("iChancy account creation failed user=%s", message.from_user.id)
        await status.edit_text("⚠️ حدث خطأ مؤقت أثناء إنشاء الحساب. حاول لاحقاً.", reply_markup=back_to_ichancy())
        await state.clear()
        return

    await state.clear()
    outbox_worker.wake()
    await status.edit_text(
        f"{SUCCESS} <b>تم إنشاء حساب iChancy بنجاح</b>\n\n"
        f"👤 اسم الحساب:\n<code>{html.escape(result.account.username)}</code>\n\n"
        f"🔐 كلمة المرور:\n<code>{html.escape(result.password)}</code>\n\n"
        "احتفظ بمعلومات حسابك في مكان آمن.",
        reply_markup=ichancy_menu(has_account=True),
    )


@router.callback_query(F.data == "ichancy:account")
async def account_info(callback: CallbackQuery, ichancy_accounts: IchancyAccountsService) -> None:
    account = await ichancy_accounts.active_account(callback.from_user.id)
    if account is None:
        await safe_edit(callback, "❌ لا يوجد حساب iChancy نشط.", reply_markup=back_to_ichancy())
        return
    try:
        password = await ichancy_accounts.account_password(account)
    except Exception:
        password = "غير متاح"
    await safe_edit(
        callback,
        "ℹ️ <b>معلومات حساب iChancy</b>\n\n"
        f"👤 اسم الحساب:\n<code>{html.escape(account.username)}</code>\n\n"
        f"🔐 كلمة المرور:\n<code>{html.escape(password)}</code>\n\n"
        f"🎮 Player ID:\n<code>{html.escape(account.player_id)}</code>",
        reply_markup=back_to_ichancy(),
    )


@router.callback_query(F.data == "ichancy:website")
async def website_cb(callback: CallbackQuery, ichancy_accounts: IchancyAccountsService, settings: Settings) -> None:
    account = await ichancy_accounts.active_account(callback.from_user.id)
    if account is None:
        await safe_edit(callback, "❌ لا يوجد حساب iChancy نشط.", reply_markup=back_to_ichancy())
        return
    await safe_edit(callback, f"{LOADING} <b>جاري تسجيل الدخول إلى حساب iChancy...</b>")
    try:
        token = await ichancy_accounts.website_token(callback.from_user.id)
    except Exception:
        logger.exception("iChancy direct website login failed user=%s", callback.from_user.id)
        token = None
    if not token:
        await safe_edit(
            callback,
            "❌ تعذر تسجيل الدخول التلقائي حالياً. حاول لاحقاً.",
            reply_markup=back_to_ichancy(),
        )
        return
    sep = "&" if "?" in settings.ichancy_website_url else "?"
    url = f"{settings.ichancy_website_url}{sep}auth_token={quote(token, safe='')}"
    await safe_edit(
        callback,
        f"{SUCCESS} <b>تم تسجيل الدخول بنجاح!</b>\n"
        "اضغط على الزر أدناه لفتح حسابك مباشرة.\n\n"
        "⚠️ في حال لم يفتح الموقع، استخدم VPN على دولة سنغافورة ثم حاول مرة أخرى.",
        reply_markup=website_open(url),
    )


@router.callback_query(F.data == "ichancy:deposit")
async def deposit_start(
    callback: CallbackQuery,
    state: FSMContext,
    ichancy_accounts: IchancyAccountsService,
    wallet_service: WalletService,
    runtime_settings: RuntimeSettingsService,
) -> None:
    if not await ichancy_accounts.active_account(callback.from_user.id):
        await safe_edit(callback, "❌ أنشئ حساب iChancy أولاً.", reply_markup=back_to_ichancy())
        return
    balance = await wallet_service.get_balance(callback.from_user.id)
    available = int(balance.available if balance else 0)
    minimum = runtime_settings.get_int("ichancy.min_deposit", 20000)
    if available < minimum:
        await safe_edit(
            callback,
            f"❌ الحد الأدنى للشحن هو <b>{minimum:,}</b>.\nرصيدك المتاح: <b>{available:,}</b>.",
            reply_markup=back_to_ichancy(),
        )
        return
    await state.set_state(IchancyStates.waiting_deposit_amount)
    await safe_edit(
        callback,
        "💳 <b>شحن رصيد حساب iChancy</b>\n\n"
        f"رصيد محفظتك المتاح: <b>{available:,}</b>\n"
        f"الحد الأدنى: <b>{minimum:,}</b>\n\n"
        "أرسل المبلغ الذي تريد شحنه.",
        reply_markup=cancel_to_ichancy(),
    )


@router.message(IchancyStates.waiting_deposit_amount, F.text)
async def deposit_amount(message: Message, state: FSMContext, ichancy_jobs: IchancyJobService) -> None:
    if message.from_user is None:
        return
    amount = _parse_int(message.text or "")
    if amount is None:
        await message.answer("❌ المبلغ غير صحيح. أرسل أرقام فقط.", reply_markup=cancel_to_ichancy())
        return
    status = await message.answer(f"{PROCESSING} <b>جاري تجهيز عملية الشحن...</b>")
    try:
        job = await ichancy_jobs.create_deposit_job(message.from_user.id, amount)
    except IchancyJobError as exc:
        await status.edit_text(f"❌ {html.escape(str(exc))}", reply_markup=back_to_ichancy())
        await state.clear()
        return
    await state.clear()
    await status.edit_text(
        f"{PROCESSING} <b>تم استلام عملية الشحن وجاري تنفيذها بأمان.</b>\n\n"
        f"💰 المبلغ: <code>{job.amount:,}</code>\n"
        f"🧾 رقم العملية: <code>{job.id}</code>\n\n"
        "سيصلك إشعار عند اكتمال العملية.",
        reply_markup=back_to_ichancy(),
    )


@router.callback_query(F.data == "ichancy:deposit_all")
async def deposit_all_start(
    callback: CallbackQuery,
    wallet_service: WalletService,
    runtime_settings: RuntimeSettingsService,
    ichancy_accounts: IchancyAccountsService,
) -> None:
    if not await ichancy_accounts.active_account(callback.from_user.id):
        await safe_edit(callback, "❌ أنشئ حساب iChancy أولاً.", reply_markup=back_to_ichancy())
        return
    balance = await wallet_service.get_balance(callback.from_user.id)
    available = int(balance.available if balance else 0)
    minimum = runtime_settings.get_int("ichancy.min_deposit", 20000)
    if available < minimum:
        await safe_edit(callback, f"❌ رصيدك المتاح {available:,} وهو أقل من الحد الأدنى {minimum:,}.", reply_markup=back_to_ichancy())
        return
    await safe_edit(
        callback,
        "⚡ <b>شحن كامل الرصيد</b>\n\n"
        f"سيتم شحن كامل الرصيد المتاح: <b>{available:,}</b>\n\n"
        "عند التأكيد سيعيد النظام قراءة الرصيد وحجز القيمة داخل معاملة آمنة.",
        reply_markup=full_deposit_confirm(),
    )


@router.callback_query(F.data == "ichancy:deposit_all:confirm")
async def deposit_all_confirm(callback: CallbackQuery, ichancy_jobs: IchancyJobService) -> None:
    await safe_edit(callback, f"{PROCESSING} <b>جاري تجهيز شحن كامل الرصيد...</b>")
    try:
        job = await ichancy_jobs.create_deposit_job(callback.from_user.id, None, full_balance=True)
    except IchancyJobError as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}", reply_markup=back_to_ichancy())
        return
    await safe_edit(
        callback,
        f"{PROCESSING} <b>تم استلام العملية وجاري تنفيذها بأمان.</b>\n\n"
        f"💰 المبلغ المحجوز: <code>{job.amount:,}</code>\n"
        f"🧾 رقم العملية: <code>{job.id}</code>",
        reply_markup=back_to_ichancy(),
    )


@router.callback_query(F.data == "ichancy:withdraw")
async def withdraw_start(
    callback: CallbackQuery,
    state: FSMContext,
    ichancy_accounts: IchancyAccountsService,
    runtime_settings: RuntimeSettingsService,
) -> None:
    if not await ichancy_accounts.active_account(callback.from_user.id):
        await safe_edit(callback, "❌ أنشئ حساب iChancy أولاً.", reply_markup=back_to_ichancy())
        return
    minimum = runtime_settings.get_int("ichancy.min_withdraw", 20000)
    await state.set_state(IchancyStates.waiting_withdraw_amount)
    await safe_edit(
        callback,
        "💸 <b>سحب رصيد من iChancy</b>\n\n"
        f"الحد الأدنى للسحب: <b>{minimum:,}</b>\n\n"
        "أرسل المبلغ الذي تريد سحبه إلى محفظة البوت.",
        reply_markup=cancel_to_ichancy(),
    )


@router.message(IchancyStates.waiting_withdraw_amount, F.text)
async def withdraw_amount(message: Message, state: FSMContext, ichancy_jobs: IchancyJobService) -> None:
    if message.from_user is None:
        return
    amount = _parse_int(message.text or "")
    if amount is None:
        await message.answer("❌ المبلغ غير صحيح. أرسل أرقام فقط.", reply_markup=cancel_to_ichancy())
        return
    status = await message.answer(f"{PROCESSING} <b>جاري تجهيز عملية السحب...</b>")
    try:
        job = await ichancy_jobs.create_withdraw_job(message.from_user.id, amount)
    except IchancyJobError as exc:
        await status.edit_text(f"❌ {html.escape(str(exc))}", reply_markup=back_to_ichancy())
        await state.clear()
        return
    await state.clear()
    await status.edit_text(
        f"{PROCESSING} <b>تم استلام عملية السحب وجاري تنفيذها بأمان.</b>\n\n"
        f"💰 المبلغ: <code>{job.amount:,}</code>\n"
        f"🧾 رقم العملية: <code>{job.id}</code>\n\n"
        "سيصلك إشعار عند اكتمال العملية.",
        reply_markup=back_to_ichancy(),
    )
