from __future__ import annotations

import asyncio
import html
import logging
from uuid import uuid4

from app.core.wallet import InsufficientFunds
from app.providers.ichancy import (
    IchancyClient,
    IchancyDefiniteError,
    IchancyTemporaryError,
    IchancyTransferUncertain,
    extract_cashier_balance,
    extract_player_balance_value,
)
from app.repositories.ichancy import IchancyRepository
from app.repositories.ichancy_jobs import IchancyJob, IchancyJobRepository
from app.services.ichancy_accounts import IchancyAccountsService
from app.services.outbox import NotificationOutboxWorker
from app.services.runtime_settings import RuntimeSettingsService
from app.services.wallet import WalletService

logger = logging.getLogger(__name__)


class IchancyJobError(RuntimeError):
    pass


class IchancyJobService:
    def __init__(
        self,
        jobs: IchancyJobRepository,
        accounts: IchancyRepository,
        account_service: IchancyAccountsService,
        wallet: WalletService,
        runtime: RuntimeSettingsService,
        outbox_worker: NotificationOutboxWorker | None = None,
    ) -> None:
        self.jobs = jobs
        self.accounts = accounts
        self.account_service = account_service
        self.wallet = wallet
        self.runtime = runtime
        self.outbox_worker = outbox_worker
        self._wake = asyncio.Event()
        self._stop = asyncio.Event()

    def wake(self) -> None:
        self._wake.set()

    def stop(self) -> None:
        self._stop.set(); self._wake.set()

    async def create_deposit_job(self, telegram_id: int, amount: int | None, *, full_balance: bool = False) -> IchancyJob:
        account = await self.accounts.get_active_account(telegram_id)
        if account is None:
            raise IchancyJobError("لا يوجد حساب iChancy نشط")
        min_amount = max(1, self.runtime.get_int("ichancy.min_deposit", 20000))
        request_id = uuid4()
        source = "full_balance" if full_balance else "normal"
        pool = self.jobs.db.require_pool()
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    # Lock the cashier before the wallet so cashier replacement and
                    # a new user financial job cannot cross each other mid-flight.
                    cashier = await conn.fetchrow(
                        "SELECT id,status FROM bot_core.ichancy_cashiers WHERE id=$1 FOR UPDATE",
                        account.cashier_id,
                    )
                    acc = await conn.fetchrow(
                        "SELECT id,status,cashier_id FROM bot_core.ichancy_accounts WHERE id=$1 FOR UPDATE",
                        account.id,
                    )
                    if not cashier or str(cashier["status"]) != "active" or not acc or str(acc["status"]) != "active":
                        raise IchancyJobError("نظام iChancy قيد التحديث حالياً. حاول لاحقاً.")
                    active = await conn.fetchval(
                        """
                        SELECT 1 FROM bot_core.ichancy_jobs
                        WHERE telegram_id=$1 AND status IN ('queued','executing','remote_success','reconciling')
                        LIMIT 1
                        """,
                        telegram_id,
                    )
                    if active:
                        raise IchancyJobError("لديك عملية iChancy قيد التنفيذ حالياً")
                    locked_balance = await self.wallet.get_balance_in_transaction(conn, telegram_id)
                    available = int(locked_balance.available)
                    chosen = available if full_balance else int(amount or 0)
                    if chosen < min_amount:
                        raise IchancyJobError(f"الحد الأدنى لشحن iChancy هو {min_amount:,}")
                    if chosen > available:
                        raise IchancyJobError("رصيد المحفظة غير كافٍ")
                    _, hold = await self.wallet.create_hold_in_transaction(
                        conn, telegram_id, chosen,
                        idempotency_key=f"ichancy-deposit-hold:{request_id}",
                        reason="ichancy_deposit_reserve",
                        actor_telegram_id=telegram_id,
                        metadata={"source": source, "job_request_id": str(request_id)},
                    )
                    job = await self.jobs.create_job_in_transaction(
                        conn,
                        telegram_id=telegram_id, account_id=account.id, cashier_id=account.cashier_id,
                        operation_type="deposit", source=source, amount=chosen,
                        idempotency_key=f"ichancy-deposit:{request_id}", wallet_hold_id=hold.id,
                    )
        except InsufficientFunds as exc:
            raise IchancyJobError("رصيد المحفظة غير كافٍ") from exc
        except IchancyJobError:
            raise
        except Exception as exc:
            # The DB transaction owns both hold and job, so any failure rolls both back.
            if "ux_ichancy_one_active_job_per_user" in str(exc):
                raise IchancyJobError("لديك عملية iChancy قيد التنفيذ حالياً") from exc
            raise
        self.wake()
        return job

    async def create_withdraw_job(self, telegram_id: int, amount: int) -> IchancyJob:
        account = await self.accounts.get_active_account(telegram_id)
        if account is None:
            raise IchancyJobError("لا يوجد حساب iChancy نشط")
        min_amount = max(1, self.runtime.get_int("ichancy.min_withdraw", 20000))
        amount = int(amount)
        if amount < min_amount:
            raise IchancyJobError(f"الحد الأدنى لسحب iChancy هو {min_amount:,}")
        try:
            job = await self.jobs.create_job(
                telegram_id=telegram_id, account_id=account.id, cashier_id=account.cashier_id,
                operation_type="withdraw", source="normal", amount=amount,
                idempotency_key=f"ichancy-withdraw:{uuid4()}", wallet_hold_id=None,
            )
        except ValueError as exc:
            if str(exc) == "ICHANCY_ACCOUNT_NOT_ACTIVE":
                raise IchancyJobError("نظام iChancy قيد التحديث حالياً. حاول لاحقاً.") from exc
            raise
        except Exception as exc:
            if "ux_ichancy_one_active_job_per_user" in str(exc):
                raise IchancyJobError("لديك عملية iChancy قيد التنفيذ حالياً") from exc
            raise
        self.wake()
        return job

    async def run_worker(self, poll_seconds: float = 2.0, reconcile_delay: float = 8.0) -> None:
        while not self._stop.is_set():
            did_work = False
            try:
                job = await self.jobs.claim_next()
                if job:
                    did_work = True
                    await self._execute(job)
                reconciling = await self.jobs.list_reconciling(limit=5)
                for item in reconciling:
                    if item.status == "remote_success":
                        did_work = True
                        await self._finish_remote_success(item)
                    elif item.status == "reconciling":
                        did_work = True
                        await self._reconcile(item)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("iChancy worker loop failed")
            if did_work:
                await asyncio.sleep(0)
                continue
            self._wake.clear()
            try:
                await asyncio.wait_for(self._wake.wait(), timeout=poll_seconds)
            except asyncio.TimeoutError:
                pass
            if reconcile_delay > poll_seconds:
                await asyncio.sleep(0)

    async def _client_for(self, job: IchancyJob) -> tuple[IchancyClient, object, object]:
        account = await self.accounts.get_active_account(job.telegram_id)
        if account is None or account.id != job.account_id:
            # Retiring accounts can be used by replacement jobs; fetch direct row.
            pool = self.accounts.db.require_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow("SELECT * FROM bot_core.ichancy_accounts WHERE id=$1", job.account_id)
            if not row:
                raise IchancyDefiniteError("حساب iChancy المرتبط بالعملية غير موجود")
            account = self.accounts._account(row)
        cashier = await self.accounts.get_cashier(job.cashier_id)
        if cashier is None:
            raise IchancyDefiniteError("كاشيرة العملية غير موجودة")
        return self.account_service._client(cashier), account, cashier

    async def _read_balances(self, client: IchancyClient, player_id: str) -> tuple[int, int | None]:
        player_resp, cashier_resp = await asyncio.gather(
            client.get_player_balance(player_id), client.get_agent_all_wallets()
        )
        player = extract_player_balance_value(player_resp)
        if player is None:
            raise IchancyTemporaryError("تعذر قراءة رصيد اللاعب")
        cashier = extract_cashier_balance(cashier_resp, client.credentials.currency)
        return int(player), cashier

    async def _execute(self, job: IchancyJob) -> None:
        try:
            client, account, _ = await self._client_for(job)
            player_before, cashier_before = await self._read_balances(client, account.player_id)
            if job.operation_type in {"withdraw", "retirement_withdraw"} and player_before < job.amount:
                await self._definite_fail(job, "رصيد حساب iChancy غير كافٍ")
                return
            if job.operation_type == "deposit" and cashier_before is not None and cashier_before < job.amount:
                await self._definite_fail(job, "رصيد كاشيرة iChancy غير كافٍ")
                return
            job = await self.jobs.set_snapshots(job.id, player_before=player_before, cashier_before=cashier_before)
            comment = f"bot:{job.id}"
            if job.operation_type == "deposit":
                payload = await client.deposit_to_player(account.player_id, job.amount, comment)
            else:
                payload = await client.withdraw_from_player(account.player_id, job.amount, comment)
            await self.jobs.mark_remote_success(job.id, payload)
            latest = await self.jobs.get(job.id)
            if latest:
                await self._finish_remote_success(latest)
        except IchancyTemporaryError as exc:
            await self.jobs.requeue(job.id, str(exc))
        except IchancyDefiniteError as exc:
            await self._definite_fail(job, str(exc))
        except IchancyTransferUncertain as exc:
            await self.jobs.mark_reconciling(job.id, str(exc))
            if self.outbox_worker:
                self.outbox_worker.wake()
        except Exception as exc:
            logger.exception("Unexpected iChancy job execution failure job=%s", job.id)
            await self.jobs.mark_reconciling(job.id, f"{type(exc).__name__}: {exc}")
            if self.outbox_worker:
                self.outbox_worker.wake()

    async def _definite_fail(self, job: IchancyJob, error: str) -> None:
        pool = self.jobs.db.require_pool()
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    current_row = await conn.fetchrow(
                        "SELECT * FROM bot_core.ichancy_jobs WHERE id=$1 FOR UPDATE", job.id
                    )
                    if not current_row:
                        return
                    current = self.jobs._job(current_row)
                    if current.status == "failed":
                        return
                    if current.status not in {"queued", "executing", "reconciling"}:
                        return
                    if current.operation_type == "deposit" and current.wallet_hold_id:
                        await self.wallet.release_hold_in_transaction(
                            conn,
                            current.wallet_hold_id,
                            idempotency_key=f"ichancy-deposit-release:{current.id}",
                            reason="ichancy_deposit_failed",
                            actor_telegram_id=current.telegram_id,
                            metadata={"job_id": str(current.id), "error": error[:300]},
                        )
                    await self.jobs.fail_in_transaction(conn, current.id, error)
        except Exception:
            logger.exception("Failed to atomically close definite iChancy failure job=%s", job.id)
            await self.jobs.mark_reconciling(
                job.id, f"provider failed but local close needs review: {error}"
            )
            if self.outbox_worker:
                self.outbox_worker.wake()
            return
        if self.outbox_worker:
            self.outbox_worker.wake()

    async def _finish_remote_success(self, job: IchancyJob) -> None:
        if job.status not in {"remote_success", "reconciling"}:
            return
        client, account, _ = await self._client_for(job)
        player_after = cashier_after = None
        try:
            player_after, cashier_after = await self._read_balances(client, account.player_id)
        except Exception:
            pass
        await self._settle_local(job, account.username, account.player_id, player_after, cashier_after)

    async def _settle_local(self, job: IchancyJob, username: str, player_id: str, player_after: int | None, cashier_after: int | None) -> None:
        pool = self.jobs.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                current_row = await conn.fetchrow("SELECT * FROM bot_core.ichancy_jobs WHERE id=$1 FOR UPDATE", job.id)
                if not current_row:
                    raise IchancyJobError("job missing")
                current = self.jobs._job(current_row)
                if current.status == "success":
                    return
                if current.status not in {"remote_success","reconciling"}:
                    raise IchancyJobError(f"cannot settle job in {current.status}")
                if current.operation_type == "deposit":
                    if not current.wallet_hold_id:
                        raise IchancyJobError("deposit hold missing")
                    mutation, _ = await self.wallet.capture_hold_in_transaction(
                        conn, current.wallet_hold_id,
                        idempotency_key=f"ichancy-deposit-capture:{current.id}",
                        reason="ichancy_deposit_success",
                        actor_telegram_id=current.telegram_id,
                        metadata={"job_id": str(current.id), "player_id": player_id},
                    )
                    balance_after = mutation.balance_after.available
                else:
                    mutation = await self.wallet.credit_in_transaction(
                        conn, current.telegram_id, current.amount,
                        idempotency_key=f"ichancy-withdraw-credit:{current.id}",
                        reason="ichancy_withdraw_success" if current.operation_type == "withdraw" else "ichancy_retirement_withdraw_success",
                        actor_telegram_id=current.telegram_id,
                        metadata={"job_id": str(current.id), "player_id": player_id},
                    )
                    balance_after = mutation.balance_after.available
                text = self._notification_text(current, username, player_id, balance_after, player_after, cashier_after)
                await self.jobs.finalize_success(
                    conn, job_id=current.id, wallet_operation_id=mutation.operation_id,
                    player_after=player_after, cashier_after=cashier_after, notification_text=text,
                )
        if self.outbox_worker:
            self.outbox_worker.wake()

    async def _reconcile(self, job: IchancyJob) -> None:
        if job.player_balance_before is None:
            await self.jobs.fail(job.id, "لا توجد لقطة رصيد سابقة تسمح بالمطابقة الآمنة")
            return
        try:
            client, account, _ = await self._client_for(job)
            player_after, cashier_after = await self._read_balances(client, account.player_id)
        except Exception:
            return
        before = int(job.player_balance_before)
        amount = int(job.amount)
        # Ambiguous financial POSTs are reconciled only from the exact two-sided
        # delta (player + cashier), matching the hardened reference behavior.
        # Inequalities are unsafe because gameplay or another cashier operation
        # could otherwise create a false positive and duplicate wallet money.
        if job.cashier_balance_before is None or cashier_after is None:
            return
        cashier_before = int(job.cashier_balance_before)
        if job.operation_type == "deposit":
            confirmed = (player_after - before == amount) and (cashier_before - cashier_after == amount)
        else:
            confirmed = (before - player_after == amount) and (cashier_after - cashier_before == amount)
        if confirmed:
            await self.jobs.mark_remote_success(job.id, {"reconciled": True, "player_after": player_after, "cashier_after": cashier_after})
            latest = await self.jobs.get(job.id)
            if latest:
                await self._settle_local(latest, account.username, account.player_id, player_after, cashier_after)

    async def confirm_review_done(self, job_id, admin_id: int) -> IchancyJob:
        job = await self.jobs.get(job_id)
        if job is None:
            raise IchancyJobError("عملية iChancy غير موجودة")
        if job.status == "success":
            return job
        if job.status != "reconciling":
            raise IchancyJobError(f"العملية ليست بحالة مراجعة: {job.status}")
        client, account, _ = await self._client_for(job)
        player_after = cashier_after = None
        try:
            player_after, cashier_after = await self._read_balances(client, account.player_id)
        except Exception:
            pass
        await self.jobs.mark_remote_success(
            job.id,
            {"manual_admin_confirmation": True, "admin_id": int(admin_id)},
        )
        latest = await self.jobs.get(job.id)
        if latest is None:
            raise IchancyJobError("تعذر إعادة تحميل العملية")
        await self._settle_local(latest, account.username, account.player_id, player_after, cashier_after)
        done = await self.jobs.get(job.id)
        if done is None:
            raise IchancyJobError("تعذر تثبيت العملية محلياً")
        return done

    async def confirm_review_not_done(self, job_id, admin_id: int) -> IchancyJob:
        pool = self.jobs.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_jobs WHERE id=$1 FOR UPDATE", job_id
                )
                if row is None:
                    raise IchancyJobError("عملية iChancy غير موجودة")
                job = self.jobs._job(row)
                if job.status == "failed":
                    return job
                if job.status != "reconciling":
                    raise IchancyJobError(f"العملية ليست بحالة مراجعة: {job.status}")
                if job.operation_type == "deposit" and job.wallet_hold_id:
                    await self.wallet.release_hold_in_transaction(
                        conn,
                        job.wallet_hold_id,
                        idempotency_key=f"ichancy-deposit-review-release:{job.id}",
                        reason="ichancy_deposit_confirmed_not_executed",
                        actor_telegram_id=admin_id,
                        metadata={"job_id": str(job.id), "admin_id": int(admin_id)},
                    )
                failed = await self.jobs.fail_in_transaction(
                    conn, job.id, f"confirmed not executed by admin {int(admin_id)}"
                )
        if self.outbox_worker:
            self.outbox_worker.wake()
        return failed

    def _notification_text(self, job: IchancyJob, username: str, player_id: str, wallet_balance_after: int, player_after: int | None, cashier_after: int | None) -> str:
        if job.operation_type == "deposit":
            title = "💳 <b>شحن iChancy ناجح</b>"
            threshold = self.runtime.get_int("alerts.ichancy_deposit_large", 0)
        else:
            title = "💸 <b>سحب iChancy ناجح</b>"
            threshold = self.runtime.get_int("alerts.ichancy_withdraw_large", 0)
        if threshold > 0 and job.amount >= threshold:
            title = title.replace("</b>", " — 🚨 مبلغ كبير</b>")
        before_p = "غير متاح" if job.player_balance_before is None else f"{job.player_balance_before:,}"
        after_p = "غير متاح" if player_after is None else f"{player_after:,}"
        before_c = "غير متاح" if job.cashier_balance_before is None else f"{job.cashier_balance_before:,}"
        after_c = "غير متاح" if cashier_after is None else f"{cashier_after:,}"
        return (
            f"{title}\n\n"
            f"🆔 Telegram ID: <code>{job.telegram_id}</code>\n"
            f"🎰 الحساب: <code>{html.escape(username)}</code>\n"
            f"🎮 Player ID: <code>{html.escape(player_id)}</code>\n"
            f"💰 المبلغ: <code>{job.amount:,}</code>\n"
            f"🧾 رقم العملية: <code>{job.id}</code>\n\n"
            f"🎮 رصيد اللاعب: <code>{before_p}</code> → <code>{after_p}</code>\n"
            f"🏦 رصيد الكاشيرة: <code>{before_c}</code> → <code>{after_c}</code>\n"
            f"💼 محفظة البوت بعد العملية: <code>{wallet_balance_after:,}</code>"
        )
