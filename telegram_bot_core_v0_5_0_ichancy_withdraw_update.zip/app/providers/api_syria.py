from __future__ import annotations

import asyncio
from datetime import datetime
from decimal import Decimal
from zoneinfo import ZoneInfo

import aiohttp

from app.core.deposits import DepositProviderUnavailable, DepositVerificationFailed, ProviderTransaction
from app.core.money import parse_decimal

_DAMASCUS = ZoneInfo("Asia/Damascus")


class ApiSyriaClient:
    """Read-only transaction lookup for Syriatel Cash and Sham Cash."""

    def __init__(self, session: aiohttp.ClientSession, *, base_url: str, api_key: str) -> None:
        self.session = session
        self.base_url = (base_url or "").strip().rstrip("/")
        self.api_key = (api_key or "").strip()

    @property
    def configured(self) -> bool:
        return bool(self.base_url and self.api_key)

    async def find_syriatel(self, tx: str, gsm: str) -> ProviderTransaction | None:
        payload = await self._find(resource="syriatel", tx=tx, gsm=gsm)
        if payload is None:
            return None
        obj = payload.get("transaction") or {}
        amount = self._amount(obj)
        return ProviderTransaction(
            provider="syriatel",
            tx_key=tx,
            amount=amount,
            currency="SYP",
            destination=gsm,
            occurred_at=self._parse_datetime(obj.get("date")),
            raw=dict(obj),
        )

    async def find_shamcash(self, tx: str, account_address: str) -> ProviderTransaction | None:
        payload = await self._find(
            resource="shamcash", tx=tx, account_address=account_address
        )
        if payload is None:
            return None
        obj = payload.get("transaction") or {}
        amount = self._amount(obj)
        currency = str(obj.get("currency") or "").strip().upper()
        if not currency:
            raise DepositVerificationFailed("provider currency is missing")
        return ProviderTransaction(
            provider="shamcash",
            tx_key=tx,
            amount=amount,
            currency=currency,
            destination=account_address,
            occurred_at=self._parse_datetime(obj.get("datetime") or obj.get("date")),
            raw=dict(obj),
        )


    async def list_accounts(self) -> dict:
        return await self._generic_get({"resource": "accounts", "action": "list"})

    async def syriatel_balance(self, gsm: str) -> tuple[str, Decimal]:
        data = await self._generic_get({"resource": "syriatel", "action": "balance", "gsm": gsm})
        info = data.get("data") or {}
        source = str(info.get("cash_code") or info.get("gsm") or gsm).strip()
        try:
            balance = parse_decimal(info.get("balance") or 0)
        except ValueError as exc:
            raise DepositProviderUnavailable("api_syria_invalid_balance") from exc
        return source, balance

    async def resolve_shamcash_recipient_name(self, *, source: str, receiver: str) -> str:
        """Best-effort read-only ShamCash name lookup from provider history.

        Unknown addresses are still valid; this method never probes with a transfer.
        """
        wanted = str(receiver or "").strip().casefold()
        if not wanted or not source:
            return ""
        checks = (("outgoing_logs", "outgoing"), ("logs", "incoming"))
        for action, direction in checks:
            try:
                data = await self._generic_get({"resource": "shamcash", "action": action, "account_address": source})
            except Exception:
                continue
            payload = data.get("data") or {}
            items = payload.get("items") or [] if isinstance(payload, dict) else []
            for item in items if isinstance(items, list) else []:
                if not isinstance(item, dict):
                    continue
                other = str(
                    item.get("account") or item.get("to") or item.get("to_address") or item.get("receiver")
                    or item.get("from") or item.get("from_address") or item.get("sender") or ""
                ).strip()
                if other.casefold() != wanted:
                    continue
                keys = ("to_name", "receiver_name", "recipient_name", "toName") if direction == "outgoing" else ("from_name", "sender_name", "source_name", "fromName")
                for key in keys:
                    name = str(item.get(key) or "").strip()
                    if name and name != "-":
                        return name
        return ""

    async def transfer_syriatel(self, *, source: str, receiver: str, amount: Decimal, pin_code: str) -> dict:
        return await self._financial_post(
            {"resource": "syriatel", "action": "transfer_cash"},
            {"gsm": source, "to_gsm": receiver, "amount": self._decimal_text(amount), "pin_code": pin_code},
        )

    async def transfer_shamcash(self, *, source: str, receiver: str, amount: Decimal, currency: str = "SYP") -> dict:
        return await self._financial_post(
            {"resource": "shamcash", "action": "transfer"},
            {"account_address": source, "receive_key": receiver, "amount": self._decimal_text(amount), "currency": currency, "note": "مبروك"},
        )

    async def _generic_get(self, params: dict[str, str]) -> dict:
        if not self.configured:
            raise DepositProviderUnavailable("API Syria is not configured")
        merged = dict(params)
        merged["api_key"] = self.api_key
        headers = {"X-Api-Key": self.api_key, "Accept": "application/json"}
        try:
            async with self.session.get(self.base_url, params=merged, headers=headers, timeout=aiohttp.ClientTimeout(total=25)) as response:
                try:
                    data = await response.json(content_type=None)
                except Exception as exc:
                    raise DepositProviderUnavailable("api_syria_invalid_json") from exc
                if response.status != 200:
                    raise DepositProviderUnavailable(f"api_syria_http_{response.status}")
        except DepositProviderUnavailable:
            raise
        except (aiohttp.ClientError, TimeoutError) as exc:
            raise DepositProviderUnavailable("api_syria_network_error") from exc
        if not isinstance(data, dict) or data.get("success") is False:
            raise DepositProviderUnavailable(str((data or {}).get("error") if isinstance(data, dict) else "api_syria_unsuccessful"))
        return data

    async def _financial_post(self, params: dict[str, str], form: dict[str, str]) -> dict:
        if not self.configured:
            raise ApiSyriaFinancialDefiniteError("API Syria is not configured")
        merged = dict(params)
        merged["api_key"] = self.api_key
        headers = {
            "X-Api-Key": self.api_key,
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        try:
            # Exactly one financial POST. No network/5xx retry here.
            async with self.session.post(
                self.base_url, params=merged, data=form, headers=headers,
                timeout=aiohttp.ClientTimeout(total=35),
            ) as response:
                text = await response.text()
                try:
                    data = await response.json(content_type=None)
                except Exception as exc:
                    if response.status >= 500 or response.status == 200:
                        raise ApiSyriaFinancialUncertain(f"non-json HTTP {response.status}: {text[:300]}") from exc
                    raise ApiSyriaFinancialDefiniteError(f"HTTP {response.status}: {text[:300]}") from exc
                if response.status == 429:
                    raise ApiSyriaFinancialDefiniteError("API Syria rate limit")
                if response.status >= 500:
                    raise ApiSyriaFinancialUncertain(f"HTTP {response.status}: {text[:300]}")
                if response.status >= 400:
                    raise ApiSyriaFinancialDefiniteError(str(data.get("error") or data.get("message") or f"HTTP {response.status}"))
                if not isinstance(data, dict):
                    raise ApiSyriaFinancialUncertain("unexpected financial response")
                if data.get("success") is False:
                    raise ApiSyriaFinancialDefiniteError(str(data.get("error") or data.get("message") or "provider rejected transfer"))
                return data
        except (ApiSyriaFinancialDefiniteError, ApiSyriaFinancialUncertain):
            raise
        except (aiohttp.ClientError, asyncio.TimeoutError, TimeoutError) as exc:
            raise ApiSyriaFinancialUncertain(f"financial network outcome uncertain: {exc}") from exc

    @staticmethod
    def _decimal_text(value: Decimal) -> str:
        if value == value.to_integral_value():
            return str(int(value))
        return format(value.normalize(), "f")

    async def _find(
        self,
        *,
        resource: str,
        tx: str,
        gsm: str | None = None,
        account_address: str | None = None,
    ) -> dict | None:
        if not self.configured:
            raise DepositProviderUnavailable("API Syria is not configured")

        params: dict[str, str] = {
            "resource": resource,
            "action": "find_tx",
            "tx": tx,
            "api_key": self.api_key,
        }
        if gsm:
            params["gsm"] = gsm
        if account_address:
            params["account_address"] = account_address
        headers = {"X-Api-Key": self.api_key, "Accept": "application/json"}

        try:
            async with self.session.get(
                self.base_url,
                params=params,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=25),
            ) as response:
                if response.status != 200:
                    raise DepositProviderUnavailable(f"api_syria_http_{response.status}")
                try:
                    data = await response.json(content_type=None)
                except Exception as exc:
                    raise DepositProviderUnavailable("api_syria_invalid_json") from exc
        except DepositProviderUnavailable:
            raise
        except (aiohttp.ClientError, TimeoutError) as exc:
            raise DepositProviderUnavailable("api_syria_network_error") from exc

        if not isinstance(data, dict):
            raise DepositProviderUnavailable("api_syria_unexpected_response")
        if not data.get("success"):
            # A provider-level failure is different from a confirmed not-found.
            raise DepositProviderUnavailable("api_syria_unsuccessful_response")
        payload = data.get("data") or {}
        if not isinstance(payload, dict):
            raise DepositProviderUnavailable("api_syria_invalid_payload")
        if not payload.get("found"):
            return None
        return payload

    @staticmethod
    def _amount(obj: dict) -> Decimal:
        try:
            amount = parse_decimal(obj.get("amount"))
        except ValueError as exc:
            raise DepositVerificationFailed("provider amount is invalid") from exc
        if amount <= 0:
            raise DepositVerificationFailed("provider amount must be positive")
        return amount

    @staticmethod
    def _parse_datetime(raw: object) -> datetime | None:
        text = str(raw or "").strip()
        if not text:
            return None
        # API Syria historically returned local Syrian timestamps without timezone.
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
            try:
                parsed = datetime.strptime(text, fmt)
                return parsed.replace(tzinfo=_DAMASCUS)
            except ValueError:
                continue
        # A calendar date without a time is not precise enough for an automatic
        # financial cutover check. Failing closed is safer than inventing a time
        # that could turn an old transfer into a valid fresh one.
        try:
            datetime.strptime(text, "%Y-%m-%d")
            return None
        except ValueError:
            pass
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=_DAMASCUS)
            return parsed
        except ValueError:
            return None


class ApiSyriaFinancialError(RuntimeError):
    pass


class ApiSyriaFinancialDefiniteError(ApiSyriaFinancialError):
    """Provider definitely rejected the transfer; safe to leave request pending."""


class ApiSyriaFinancialUncertain(ApiSyriaFinancialError):
    """Transfer may have executed. Never repeat the POST without reconciliation."""
