from __future__ import annotations

import os
from decimal import Decimal
from datetime import datetime

import pytest

os.environ.setdefault("BOT_TOKEN", "123456:test-token")
os.environ.setdefault("DATABASE_URL", "postgresql://u:p@localhost/db")

from app.config import Settings
from app.core.deposits import DepositValidationError
from app.core.money import percent_amount, wallet_syp_amount
from app.services.deposits import DepositService
from app.providers.api_syria import ApiSyriaClient


class DummyProvider:
    configured = True


@pytest.fixture
def service() -> DepositService:
    settings = Settings(
        SYRIATEL_CHARGE_MODE="auto",
        SYRIATEL_CASH_CODES="73000000,73111111",
        API_SYRIA_KEY="test",
        SHAM_CHARGE_MODE="auto",
        SHAMCASH_ADDRESS_SYP="sham-syp",
        SHAMCASH_ADDRESS_USD="sham-usd",
        WHISH_MONEY_ENABLED=True,
        WHISH_MONEY_NUMBER="+000000000",
        BINANCE_DEPOSIT_ENABLED=True,
        BINANCE_API_KEY="key",
        BINANCE_API_SECRET="secret",
        BINANCE_TRC20_ADDRESS="T-address",
        BINANCE_BEP20_ADDRESS="0x-address",
    )
    return DepositService(  # type: ignore[arg-type]
        repository=None,
        wallet_service=None,
        settings=settings,
        api_syria=DummyProvider(),
        binance=DummyProvider(),
    )


def test_numeric_tx_normalizes_arabic_and_persian_digits(service: DepositService) -> None:
    assert service.normalize_numeric_tx(" ١٢٣ ٤٥٦ ") == "123456"
    assert service.normalize_numeric_tx("۱۲۳۴۵۶") == "123456"


def test_numeric_tx_rejects_non_numeric(service: DepositService) -> None:
    with pytest.raises(DepositValidationError):
        service.normalize_numeric_tx("12A456")


def test_amount_uses_decimal_and_supports_arabic_separator(service: DepositService) -> None:
    assert service.normalize_amount("١٢٫٥") == Decimal("12.5")
    assert service.normalize_amount("۱۲,۵") == Decimal("12.5")
    assert service.normalize_amount("12.50") == Decimal("12.50")


def test_amount_does_not_misread_thousands_comma(service: DepositService) -> None:
    assert service.normalize_amount("25,000") == Decimal("25000")
    assert service.normalize_amount("1,234,567.89") == Decimal("1234567.89")


def test_amount_rejects_more_than_eight_meaningful_decimals(service: DepositService) -> None:
    with pytest.raises(DepositValidationError):
        service.normalize_amount("1.123456789")


def test_rounding_is_deterministic_half_up() -> None:
    assert wallet_syp_amount(Decimal("1.005"), Decimal("100")) == 101
    assert percent_amount(101, Decimal("5")) == 5


def test_sham_methods_share_one_provider_transaction_namespace(service: DepositService) -> None:
    assert service.method_config("sham_syp").provider_scope == "shamcash"
    assert service.method_config("sham_usd").provider_scope == "shamcash"


def test_binance_networks_share_one_provider_transaction_namespace(service: DepositService) -> None:
    assert service.method_config("binance_trc20").provider_scope == "binance_usdt"
    assert service.method_config("binance_bep20").provider_scope == "binance_usdt"


def test_whish_uses_proof_claim_namespace(service: DepositService) -> None:
    assert service.method_config("whish_money").provider_scope == "whish_proof"


def test_offchain_binance_tx_normalization(service: DepositService) -> None:
    assert service.normalize_binance_tx("Off-chain transfer 123456789") == "123456789"


def test_api_syria_date_only_timestamp_fails_closed() -> None:
    assert ApiSyriaClient._parse_datetime("2026-10-09") is None


def test_api_syria_precise_timestamp_uses_damascus_timezone() -> None:
    parsed = ApiSyriaClient._parse_datetime("2026-10-09 12:34:56")
    assert parsed is not None
    assert parsed.tzinfo is not None
    assert parsed.year == 2026 and parsed.month == 10 and parsed.day == 9
