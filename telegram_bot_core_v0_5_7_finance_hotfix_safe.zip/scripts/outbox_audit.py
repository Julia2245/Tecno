from __future__ import annotations

import asyncio
from pathlib import Path

from app.config import get_settings
from app.core.db import Database

PROJECT_ROOT = Path(__file__).resolve().parent.parent


async def run() -> int:
    settings = get_settings()
    db = Database(settings.database_url, min_size=1, max_size=2, command_timeout=settings.pg_command_timeout)
    await db.connect()
    try:
        await db.apply_migrations(PROJECT_ROOT / "migrations")
        pool = db.require_pool()
        async with pool.acquire() as conn:
            malformed = await conn.fetch(
                """
                SELECT id,event_key,target_key,target_chat_id,status,attempts,sent_at,telegram_message_id
                FROM bot_core.notification_outbox
                WHERE ((target_key IS NOT NULL)::int + (target_chat_id IS NOT NULL)::int) <> 1
                   OR attempts < 0
                   OR (status='sent' AND (sent_at IS NULL OR telegram_message_id IS NULL))
                   OR (status<>'sent' AND sent_at IS NOT NULL)
                ORDER BY created_at
                """
            )
            duplicate_events = await conn.fetch(
                """
                SELECT event_key,COUNT(*)::bigint AS n
                FROM bot_core.notification_outbox
                GROUP BY event_key HAVING COUNT(*)<>1
                """
            )
            missing_targets = await conn.fetch(
                """
                SELECT o.id,o.event_key,o.target_key
                FROM bot_core.notification_outbox o
                LEFT JOIN bot_core.runtime_settings s ON s.key=o.target_key
                WHERE o.status IN ('pending','sending') AND o.target_key IS NOT NULL
                  AND (s.key IS NULL OR s.value IS NULL OR s.value='null'::jsonb OR s.value='0'::jsonb OR s.value='""'::jsonb)
                ORDER BY o.created_at
                LIMIT 100
                """
            )
            summary = await conn.fetchrow(
                """
                SELECT COUNT(*)::bigint AS total,
                       COUNT(*) FILTER (WHERE status='pending')::bigint AS pending,
                       COUNT(*) FILTER (WHERE status='sending')::bigint AS sending,
                       COUNT(*) FILTER (WHERE status='sent')::bigint AS sent,
                       COUNT(*) FILTER (WHERE status='paused')::bigint AS paused,
                       COALESCE(MAX(attempts),0)::int AS max_attempts
                FROM bot_core.notification_outbox
                """
            )

        failed = False
        for row in malformed:
            failed = True
            print("outbox invariant mismatch:", dict(row))
        for row in duplicate_events:
            failed = True
            print("outbox duplicate event:", dict(row))
        if failed:
            print("OUTBOX AUDIT: FAILED")
            return 2
        print("OUTBOX AUDIT: OK")
        print("summary:", dict(summary or {}))
        if missing_targets:
            print(f"warning: {len(missing_targets)} pending notification(s) have an unconfigured target")
            for row in missing_targets[:10]:
                print("  unconfigured target:", dict(row))
        return 0
    finally:
        await db.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
