from __future__ import annotations

import asyncio
from pathlib import Path

from app.config import get_settings
from app.core.db import Database

PROJECT_ROOT = Path(__file__).resolve().parent.parent


async def run() -> int:
    settings = get_settings()
    db = Database(settings.database_url, min_size=1, max_size=2, command_timeout=settings.pg_command_timeout)
    await db.connect()
    try:
        await db.apply_migrations(PROJECT_ROOT / "migrations")
        pool = db.require_pool()
        async with pool.acquire() as conn:
            multiple_active_cashiers = await conn.fetch(
                """
                SELECT COUNT(*)::int AS n
                FROM bot_core.ichancy_cashiers
                WHERE status='active'
                HAVING COUNT(*) > 1
                """
            )
            bad_active_accounts = await conn.fetch(
                """
                SELECT a.id,a.telegram_id,a.username,a.status,c.id AS cashier_id,c.status AS cashier_status
                FROM bot_core.ichancy_accounts a
                JOIN bot_core.ichancy_cashiers c ON c.id=a.cashier_id
                WHERE a.status='active' AND c.status<>'active'
                ORDER BY a.created_at
                """
            )
            bad_deposit_jobs = await conn.fetch(
                """
                SELECT j.id,j.telegram_id,j.amount,j.status,j.wallet_hold_id,j.wallet_operation_id,
                       h.status AS hold_status,h.amount AS hold_amount,h.closed_by_operation_id,
                       o.operation_type,o.idempotency_key
                FROM bot_core.ichancy_jobs j
                LEFT JOIN bot_core.wallet_holds h ON h.id=j.wallet_hold_id
                LEFT JOIN bot_core.wallet_operations o ON o.id=j.wallet_operation_id
                WHERE j.operation_type='deposit' AND j.status='success'
                  AND (
                       j.wallet_hold_id IS NULL OR j.wallet_operation_id IS NULL
                    OR h.id IS NULL OR h.status<>'captured' OR h.amount<>j.amount
                    OR h.closed_by_operation_id<>j.wallet_operation_id
                    OR o.id IS NULL OR o.operation_type<>'hold_capture'
                    OR o.idempotency_key<>( 'ichancy-deposit-capture:' || j.id::text )
                  )
                ORDER BY j.created_at
                """
            )
            bad_credit_jobs = await conn.fetch(
                """
                SELECT j.id,j.telegram_id,j.operation_type,j.amount,j.status,j.wallet_operation_id,
                       o.operation_type AS wallet_operation_type,o.idempotency_key,
                       l.available_delta,a.telegram_id AS ledger_user,a.asset_code,a.bucket
                FROM bot_core.ichancy_jobs j
                LEFT JOIN bot_core.wallet_operations o ON o.id=j.wallet_operation_id
                LEFT JOIN bot_core.wallet_ledger l ON l.operation_id=o.id
                LEFT JOIN bot_core.wallet_accounts a ON a.id=l.account_id
                WHERE j.operation_type IN ('withdraw','retirement_withdraw') AND j.status='success'
                  AND (
                       j.wallet_operation_id IS NULL OR o.id IS NULL OR o.operation_type<>'credit'
                    OR l.id IS NULL OR l.available_delta<>j.amount
                    OR a.telegram_id<>j.telegram_id OR a.asset_code<>'SYP' OR a.bucket<>'cash'
                    OR o.idempotency_key<>( 'ichancy-withdraw-credit:' || j.id::text )
                  )
                ORDER BY j.created_at
                """
            )
            failed_deposit_holds = await conn.fetch(
                """
                SELECT j.id,j.telegram_id,j.amount,j.status,h.status AS hold_status,h.amount AS hold_amount
                FROM bot_core.ichancy_jobs j
                JOIN bot_core.wallet_holds h ON h.id=j.wallet_hold_id
                WHERE j.operation_type='deposit' AND j.status='failed'
                  AND (h.status<>'released' OR h.amount<>j.amount)
                ORDER BY j.created_at
                """
            )
            bad_completed_replacements = await conn.fetch(
                """
                SELECT x.id,x.total_withdrawn,x.total_wallet_credited,
                       oc.status AS old_cashier_status,nc.status AS new_cashier_status,
                       COUNT(r.id) FILTER (WHERE r.classification IN (
                         'unchecked','checking','withdrawable','settling','rechecking','check_failed','review'
                       ))::int AS unresolved
                FROM bot_core.ichancy_cashier_replacements x
                JOIN bot_core.ichancy_cashiers oc ON oc.id=x.old_cashier_id
                JOIN bot_core.ichancy_cashiers nc ON nc.id=x.new_cashier_id
                LEFT JOIN bot_core.ichancy_retirement_records r ON r.replacement_id=x.id
                WHERE x.status='completed'
                GROUP BY x.id,x.total_withdrawn,x.total_wallet_credited,oc.status,nc.status
                HAVING x.total_withdrawn<>x.total_wallet_credited
                    OR oc.status<>'retired' OR nc.status<>'active'
                    OR COUNT(r.id) FILTER (WHERE r.classification IN (
                         'unchecked','checking','withdrawable','settling','rechecking','check_failed','review'
                       )) > 0
                """
            )
            bad_compensations = await conn.fetch(
                """
                SELECT r.id,r.telegram_id,r.compensated_amount,r.compensation_wallet_operation_id,
                       o.operation_type,o.idempotency_key,l.available_delta,a.telegram_id AS ledger_user
                FROM bot_core.ichancy_retirement_records r
                LEFT JOIN bot_core.wallet_operations o ON o.id=r.compensation_wallet_operation_id
                LEFT JOIN bot_core.wallet_ledger l ON l.operation_id=o.id
                LEFT JOIN bot_core.wallet_accounts a ON a.id=l.account_id
                WHERE r.compensated_amount>0
                  AND (
                       r.compensation_wallet_operation_id IS NULL OR o.id IS NULL OR o.operation_type<>'credit'
                    OR o.idempotency_key<>( 'ichancy-retired-compensation:' || r.id::text )
                    OR l.id IS NULL OR l.available_delta<>r.compensated_amount
                    OR a.telegram_id<>r.telegram_id
                  )
                ORDER BY r.created_at
                """
            )
            summary = await conn.fetchrow(
                """
                SELECT
                  (SELECT COUNT(*) FROM bot_core.ichancy_accounts)::bigint AS accounts,
                  (SELECT COUNT(*) FROM bot_core.ichancy_jobs)::bigint AS jobs,
                  (SELECT COUNT(*) FROM bot_core.ichancy_jobs WHERE status='success')::bigint AS successful_jobs,
                  (SELECT COUNT(*) FROM bot_core.ichancy_jobs WHERE status IN ('queued','executing','remote_success','reconciling'))::bigint AS active_jobs,
                  (SELECT COUNT(*) FROM bot_core.ichancy_cashier_replacements)::bigint AS replacements,
                  (SELECT COUNT(*) FROM bot_core.ichancy_retirement_records)::bigint AS retirement_records
                """
            )

        failures = {
            "multiple active cashiers": multiple_active_cashiers,
            "active account / cashier state": bad_active_accounts,
            "successful deposit wallet link": bad_deposit_jobs,
            "successful withdraw wallet credit": bad_credit_jobs,
            "failed deposit hold": failed_deposit_holds,
            "completed cashier replacement": bad_completed_replacements,
            "retirement compensation": bad_compensations,
        }
        failed = False
        for label, rows in failures.items():
            for row in rows:
                failed = True
                print(f"{label} mismatch:", dict(row))
        if failed:
            print("ICHANCY AUDIT: FAILED")
            return 2
        print("ICHANCY AUDIT: OK")
        print("summary:", dict(summary or {}))
        return 0
    finally:
        await db.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
