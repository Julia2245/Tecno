from __future__ import annotations

import compileall
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

REQUIRED_FILES = [
    ROOT / "migrations/0001_core.sql",
    ROOT / "migrations/0002_wallet_core.sql",
    ROOT / "migrations/0003_deposit_core.sql",
    ROOT / "migrations/0004_runtime_outbox_ichancy.sql",
    ROOT / "migrations/0005_withdraw_core.sql",
    ROOT / "migrations/0006_ichancy_reconciliation.sql",
    ROOT / "migrations/0007_split_bot_operation_channels.sql",
    ROOT / "migrations/0008_shamcash_address_cleanup.sql",
    ROOT / "app/services/ichancy_jobs.py",
    ROOT / "app/services/ichancy_replacements.py",
    ROOT / "app/services/withdrawals.py",
    ROOT / "app/services/outbox.py",
]

FORBIDDEN_BRANDS = re.compile(r"\b(?:julia|professor|naya)\b", re.I)
CUSTOM_EMOJI_IDS = {
    "loading": "5386367538735104399",
    "processing": "5884447890960552542",
    "success": "5796205953913196373",
}


def iter_source_files():
    for base in (ROOT / "app", ROOT / "scripts", ROOT / "migrations"):
        for path in base.rglob("*"):
            if path.is_file() and path.suffix in {".py", ".sql"}:
                yield path


def main() -> int:
    failures: list[str] = []

    for path in REQUIRED_FILES:
        if not path.exists():
            failures.append(f"missing required file: {path.relative_to(ROOT)}")

    if not compileall.compile_dir(ROOT / "app", quiet=1):
        failures.append("Python compile failed under app/")
    if not compileall.compile_dir(ROOT / "scripts", quiet=1):
        failures.append("Python compile failed under scripts/")

    for path in iter_source_files():
        if path.resolve() == Path(__file__).resolve():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if FORBIDDEN_BRANDS.search(text):
            failures.append(f"hardcoded bot brand found: {path.relative_to(ROOT)}")

    emoji_text = (ROOT / "app/core/emojis.py").read_text(encoding="utf-8")
    for label, emoji_id in CUSTOM_EMOJI_IDS.items():
        if emoji_id not in emoji_text:
            failures.append(f"missing custom emoji id ({label}): {emoji_id}")

    # Financial wallet writes must stay behind the WalletRepository boundary.
    direct_wallet_write = re.compile(
        r"(?:UPDATE\s+bot_core\.wallet_accounts|INSERT\s+INTO\s+bot_core\.wallet_(?:accounts|ledger|operations|holds))",
        re.I,
    )
    for path in (ROOT / "app").rglob("*.py"):
        if path.name == "wallet.py" and path.parent.name == "repositories":
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if direct_wallet_write.search(text):
            failures.append(f"direct wallet DB write outside WalletRepository: {path.relative_to(ROOT)}")

    m4 = (ROOT / "migrations/0004_runtime_outbox_ichancy.sql").read_text(encoding="utf-8")
    for required in (
        "notification_outbox",
        "ichancy_username_seq",
        "ichancy_jobs",
        "ichancy_cashier_replacements",
        "ichancy_retirement_records",
        "ux_ichancy_one_active_job_per_user",
    ):
        if required not in m4:
            failures.append(f"0004 migration missing contract: {required}")

    m5 = (ROOT / "migrations/0005_withdraw_core.sql").read_text(encoding="utf-8")
    for required in (
        "provider_success",
        "needs_review",
        "ux_withdraw_one_active_per_user",
        "withdraw_identity_guard",
    ):
        if required not in m5:
            failures.append(f"0005 migration missing contract: {required}")


    m6 = (ROOT / "migrations/0006_ichancy_reconciliation.sql").read_text(encoding="utf-8")
    for required in (
        "provider_reference",
        "financial_post_started_at",
        "reconcile_attempt_count",
        "reconcile_next_at",
        "result_message_id",
        "ux_ichancy_job_provider_reference",
    ):
        if required not in m6:
            failures.append(f"0006 migration missing contract: {required}")

    if failures:
        print("PROJECT PREFLIGHT: FAILED")
        for failure in failures:
            print(" -", failure)
        return 2

    print("PROJECT PREFLIGHT: OK")
    print(" - source compiles")
    print(" - required migrations/files exist")
    print(" - custom emoji ids present")
    print(" - no forbidden bot brands in source/migrations")
    print(" - wallet DB writes remain isolated")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
