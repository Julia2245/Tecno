from __future__ import annotations

import asyncio
from pathlib import Path

from app.config import get_settings
from app.core.db import Database

PROJECT_ROOT = Path(__file__).resolve().parent.parent


async def run() -> int:
    settings = get_settings()
    db = Database(settings.database_url, min_size=1, max_size=2, command_timeout=settings.pg_command_timeout)
    await db.connect()
    try:
        await db.apply_migrations(PROJECT_ROOT / "migrations")
        pool = db.require_pool()
        async with pool.acquire() as conn:
            # Audit is strictly read-only. Runtime startup recovery is responsible
            # for moving interrupted provider POSTs to needs_review.
            stale_processing = await conn.fetch(
                """
                SELECT id,telegram_id,method,processing_at,last_error
                FROM bot_core.withdraw_requests
                WHERE status='processing' AND processing_at < NOW() - INTERVAL '3 minutes'
                ORDER BY processing_at
                """
            )
            success_mismatch = await conn.fetch(
                """
                SELECT w.id,w.telegram_id,w.amount_wallet,w.status,w.wallet_hold_id,w.wallet_operation_id,
                       h.status AS hold_status,h.amount AS hold_amount,h.closed_by_operation_id,
                       o.operation_type,o.idempotency_key
                FROM bot_core.withdraw_requests w
                LEFT JOIN bot_core.wallet_holds h ON h.id=w.wallet_hold_id
                LEFT JOIN bot_core.wallet_operations o ON o.id=w.wallet_operation_id
                WHERE w.status='success'
                  AND (
                       w.wallet_operation_id IS NULL OR h.id IS NULL OR h.status<>'captured'
                    OR h.amount<>w.amount_wallet OR h.closed_by_operation_id<>w.wallet_operation_id
                    OR o.id IS NULL OR o.operation_type<>'hold_capture'
                    OR o.idempotency_key<>( 'withdraw-capture:' || w.id::text )
                  )
                ORDER BY w.created_at
                """
            )
            open_hold_mismatch = await conn.fetch(
                """
                SELECT w.id,w.telegram_id,w.status,w.amount_wallet,h.status AS hold_status,h.amount AS hold_amount
                FROM bot_core.withdraw_requests w
                LEFT JOIN bot_core.wallet_holds h ON h.id=w.wallet_hold_id
                WHERE w.status IN ('pending','processing','provider_success','needs_review')
                  AND (h.id IS NULL OR h.status<>'active' OR h.amount<>w.amount_wallet)
                ORDER BY w.created_at
                """
            )
            closed_hold_mismatch = await conn.fetch(
                """
                SELECT w.id,w.telegram_id,w.status,w.amount_wallet,h.status AS hold_status,h.amount AS hold_amount
                FROM bot_core.withdraw_requests w
                LEFT JOIN bot_core.wallet_holds h ON h.id=w.wallet_hold_id
                WHERE w.status IN ('rejected','cancelled')
                  AND (h.id IS NULL OR h.status<>'released' OR h.amount<>w.amount_wallet)
                ORDER BY w.created_at
                """
            )
            provider_success_mismatch = await conn.fetch(
                """
                SELECT id,telegram_id,method,status,source_ref,provider_reference,provider_payload
                FROM bot_core.withdraw_requests
                WHERE status='provider_success'
                  AND source_ref IS NULL
                ORDER BY created_at
                """
            )
            terminal_fields = await conn.fetch(
                """
                SELECT id,telegram_id,status,wallet_operation_id,finished_at
                FROM bot_core.withdraw_requests
                WHERE (status='success' AND (wallet_operation_id IS NULL OR finished_at IS NULL))
                   OR (status IN ('rejected','cancelled') AND finished_at IS NULL)
                   OR (status NOT IN ('success') AND wallet_operation_id IS NOT NULL)
                ORDER BY created_at
                """
            )
            success_outbox = await conn.fetch(
                """
                SELECT w.id,w.telegram_id
                FROM bot_core.withdraw_requests w
                LEFT JOIN bot_core.notification_outbox c ON c.event_key=('bot-withdraw-success:' || w.id::text)
                LEFT JOIN bot_core.notification_outbox u ON u.event_key=('bot-withdraw-user-success:' || w.id::text)
                WHERE w.status='success' AND (c.id IS NULL OR u.id IS NULL)
                ORDER BY w.created_at
                """
            )
            summary = await conn.fetchrow(
                """
                SELECT COUNT(*)::bigint AS total,
                       COUNT(*) FILTER (WHERE status='pending')::bigint AS pending,
                       COUNT(*) FILTER (WHERE status='processing')::bigint AS processing,
                       COUNT(*) FILTER (WHERE status='provider_success')::bigint AS provider_success,
                       COUNT(*) FILTER (WHERE status='needs_review')::bigint AS needs_review,
                       COUNT(*) FILTER (WHERE status='success')::bigint AS success,
                       COUNT(*) FILTER (WHERE status='rejected')::bigint AS rejected,
                       COUNT(*) FILTER (WHERE status='cancelled')::bigint AS cancelled
                FROM bot_core.withdraw_requests
                """
            )

        failures = {
            "stale processing (startup recovery did not resolve)": stale_processing,
            "success capture": success_mismatch,
            "open request hold": open_hold_mismatch,
            "closed request hold": closed_hold_mismatch,
            "provider success evidence": provider_success_mismatch,
            "terminal fields": terminal_fields,
            "success notifications": success_outbox,
        }
        failed = False
        for label, rows in failures.items():
            for row in rows:
                failed = True
                print(f"{label} mismatch:", dict(row))
        if failed:
            print("WITHDRAW AUDIT: FAILED")
            return 2
        print("WITHDRAW AUDIT: OK")
        print("summary:", dict(summary or {}))
        return 0
    finally:
        await db.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
