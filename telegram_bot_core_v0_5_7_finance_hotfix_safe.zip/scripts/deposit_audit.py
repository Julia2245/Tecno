from __future__ import annotations

import asyncio
from pathlib import Path

from app.config import get_settings
from app.core.db import Database

PROJECT_ROOT = Path(__file__).resolve().parent.parent


async def run() -> int:
    settings = get_settings()
    db = Database(
        settings.database_url,
        min_size=1,
        max_size=2,
        command_timeout=settings.pg_command_timeout,
    )
    await db.connect()
    try:
        await db.apply_migrations(PROJECT_ROOT / "migrations")
        pool = db.require_pool()
        async with pool.acquire() as conn:
            wallet_links = await conn.fetch(
                """
                SELECT
                    d.id, d.telegram_id, d.method, d.status, d.total_credit_syp,
                    o.idempotency_key, o.operation_type,
                    l.available_delta,
                    a.telegram_id AS ledger_telegram_id,
                    a.asset_code, a.bucket
                FROM bot_core.deposit_requests d
                LEFT JOIN bot_core.wallet_operations o ON o.id=d.wallet_operation_id
                LEFT JOIN bot_core.wallet_ledger l ON l.operation_id=o.id
                LEFT JOIN bot_core.wallet_accounts a ON a.id=l.account_id
                WHERE d.status='success'
                  AND (
                       o.id IS NULL
                    OR o.operation_type <> 'credit'
                    OR o.idempotency_key <> ('deposit:' || d.id::text)
                    OR l.id IS NULL
                    OR l.available_delta <> d.total_credit_syp
                    OR a.telegram_id <> d.telegram_id
                    OR a.asset_code <> 'SYP'
                    OR a.bucket <> 'cash'
                  )
                ORDER BY d.created_at
                """
            )
            claim_mismatches = await conn.fetch(
                """
                SELECT d.id, d.telegram_id, d.method, d.status,
                       d.provider_scope, d.provider_tx, c.deposit_id AS claim_owner
                FROM bot_core.deposit_requests d
                LEFT JOIN bot_core.deposit_tx_claims c
                  ON c.provider_scope=d.provider_scope
                 AND c.provider_tx=d.provider_tx
                WHERE d.provider_scope IS NOT NULL
                  AND d.provider_tx IS NOT NULL
                  AND (c.deposit_id IS NULL OR c.deposit_id <> d.id)
                ORDER BY d.created_at
                """
            )
            duplicate_claim_owners = await conn.fetch(
                """
                SELECT provider_scope, provider_tx, COUNT(*)::BIGINT AS n
                FROM bot_core.deposit_tx_claims
                GROUP BY provider_scope, provider_tx
                HAVING COUNT(*) <> 1
                """
            )
            bad_terminal_rows = await conn.fetch(
                """
                SELECT id, telegram_id, method, status, wallet_operation_id, settled_at
                FROM bot_core.deposit_requests
                WHERE (status='success' AND (wallet_operation_id IS NULL OR settled_at IS NULL))
                   OR (status<>'success' AND (wallet_operation_id IS NOT NULL OR settled_at IS NOT NULL))
                ORDER BY created_at
                """
            )
            totals = await conn.fetchrow(
                """
                SELECT
                    COUNT(*)::BIGINT AS total_requests,
                    COUNT(*) FILTER (WHERE status='success')::BIGINT AS success_count,
                    COALESCE(SUM(total_credit_syp) FILTER (WHERE status='success'),0)::BIGINT AS credited_total,
                    COUNT(*) FILTER (WHERE status='manual_pending')::BIGINT AS manual_pending,
                    COUNT(*) FILTER (WHERE status='rejected')::BIGINT AS rejected_count
                FROM bot_core.deposit_requests
                """
            )

        failures = {
            "wallet link": wallet_links,
            "provider claim": claim_mismatches,
            "claim uniqueness": duplicate_claim_owners,
            "terminal state": bad_terminal_rows,
        }
        failed = False
        for label, rows in failures.items():
            for row in rows:
                failed = True
                print(f"{label} mismatch:", dict(row))

        if failed:
            print("DEPOSIT AUDIT: FAILED")
            return 2

        print("DEPOSIT AUDIT: OK")
        print("summary:", dict(totals or {}))
        return 0
    finally:
        await db.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
