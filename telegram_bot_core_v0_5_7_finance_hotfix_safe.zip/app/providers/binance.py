from __future__ import annotations

import asyncio
import hashlib
import hmac
import re
import time
from datetime import datetime, timezone
from decimal import Decimal
from urllib.parse import urlencode

import aiohttp

from app.core.deposits import DepositProviderUnavailable, ProviderTransaction
from app.core.money import parse_decimal

_OFFCHAIN_TXID_RE = re.compile(
    r"^(?:off[\s-]*chain\s+transfer\s*[:#-]?\s*)?(\d{6,40})$",
    re.IGNORECASE,
)


def normalize_binance_txid(raw: str) -> str:
    value = " ".join(str(raw or "").strip().split())
    match = _OFFCHAIN_TXID_RE.fullmatch(value)
    if match:
        return match.group(1)
    return value.lower()


def binance_txid_variants(raw: str) -> list[str]:
    original = " ".join(str(raw or "").strip().split())
    canonical = normalize_binance_txid(original)
    out: list[str] = []
    for value in (original, canonical, f"Off-chain transfer {canonical}" if canonical.isdigit() else ""):
        if value and value not in out:
            out.append(value)
    return out


class BinanceDepositClient:
    """Minimal read-only Binance deposit verifier using one shared HTTP session."""

    _time_cache: dict[str, tuple[int, float]] = {}
    _time_lock = asyncio.Lock()

    def __init__(
        self,
        session: aiohttp.ClientSession,
        *,
        api_key: str,
        api_secret: str,
        base_url: str,
    ) -> None:
        self.session = session
        self.api_key = (api_key or "").strip()
        self.api_secret = (api_secret or "").strip()
        self.base_url = (base_url or "https://api.binance.com").strip().rstrip("/")

    @property
    def configured(self) -> bool:
        return bool(self.api_key and self.api_secret)

    async def verify_usdt_deposit(
        self,
        *,
        txid: str,
        expected_network: str,
        expected_address: str,
        expected_amount: Decimal,
    ) -> ProviderTransaction:
        if not self.configured:
            raise DepositProviderUnavailable("Binance API is not configured")

        wanted = normalize_binance_txid(txid)
        rows: list[dict] = []
        seen: set[tuple[str, str]] = set()
        last_error: str | None = None

        for query in binance_txid_variants(txid):
            try:
                result = await self._deposit_history({"coin": "USDT", "txId": query, "status": 1, "includeSource": "false"})
            except DepositProviderUnavailable as exc:
                last_error = str(exc)
                continue
            for item in result:
                key = (str(item.get("txId") or item.get("txID") or ""), str(item.get("insertTime") or item.get("completeTime") or ""))
                if key not in seen:
                    seen.add(key)
                    rows.append(item)

        if not rows:
            try:
                rows = await self._deposit_history({"coin": "USDT", "status": 1, "includeSource": "false"})
            except DepositProviderUnavailable as exc:
                last_error = str(exc)

        if not rows:
            if last_error:
                raise DepositProviderUnavailable(last_error)
            raise LookupError("binance_tx_not_found")

        network = expected_network.strip().upper()
        address = expected_address.strip()
        for item in rows:
            item_tx = normalize_binance_txid(str(item.get("txId") or item.get("txID") or ""))
            if item_tx != wanted:
                continue
            if str(item.get("coin") or "").strip().upper() != "USDT":
                continue
            try:
                status = int(item.get("status", -1))
            except (TypeError, ValueError):
                status = -1
            if status != 1:
                continue
            if str(item.get("network") or "").strip().upper() != network:
                continue
            item_address = str(item.get("address") or "").strip()
            if address:
                # Binance internal/off-chain transfers can omit the destination
                # address because the authenticated history is already account-
                # scoped. External deposits must expose and match it. TRON Base58
                # is case-sensitive; EVM/BSC addresses are compared case-insensitively.
                is_offchain = wanted.isdigit()
                if not item_address and not is_offchain:
                    continue
                if item_address:
                    if network in {"BSC", "BEP20"}:
                        if item_address.lower() != address.lower():
                            continue
                    elif item_address != address:
                        continue
            try:
                amount = parse_decimal(item.get("amount"))
            except ValueError:
                continue
            if amount != expected_amount:
                raise ValueError("binance_amount_mismatch")
            occurred_at = None
            raw_ms = item.get("insertTime") or item.get("completeTime")
            try:
                if raw_ms is not None:
                    occurred_at = datetime.fromtimestamp(int(raw_ms) / 1000, tz=timezone.utc)
            except (ValueError, TypeError, OSError):
                occurred_at = None
            return ProviderTransaction(
                provider="binance",
                tx_key=wanted,
                amount=amount,
                currency="USDT",
                destination=item_address or address or None,
                network=network,
                occurred_at=occurred_at,
                raw=dict(item),
            )

        raise LookupError("binance_tx_not_matching")

    async def _deposit_history(self, params: dict) -> list[dict]:
        data = await self._signed_get("/sapi/v1/capital/deposit/hisrec", params)
        if not isinstance(data, list):
            raise DepositProviderUnavailable("binance_unexpected_response")
        return [dict(x) for x in data if isinstance(x, dict)]

    def _sign(self, params: dict) -> str:
        query = urlencode(params, doseq=True)
        return hmac.new(
            self.api_secret.encode("utf-8"), query.encode("utf-8"), hashlib.sha256
        ).hexdigest()

    async def _server_offset_ms(self, *, force: bool = False) -> int:
        key = self.base_url.lower()
        now = time.monotonic()
        cached = self._time_cache.get(key)
        if not force and cached and now - cached[1] < 300:
            return cached[0]
        async with self._time_lock:
            cached = self._time_cache.get(key)
            now = time.monotonic()
            if not force and cached and now - cached[1] < 300:
                return cached[0]
            try:
                start = time.time_ns() // 1_000_000
                async with self.session.get(
                    f"{self.base_url}/api/v3/time",
                    headers={"Accept": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as response:
                    data = await response.json(content_type=None)
                    finish = time.time_ns() // 1_000_000
                if response.status == 200 and isinstance(data, dict) and data.get("serverTime") is not None:
                    offset = int(data["serverTime"]) - ((start + finish) // 2)
                    self._time_cache[key] = (offset, time.monotonic())
                    return offset
            except Exception:
                pass
            cached = self._time_cache.get(key)
            return cached[0] if cached else 0

    async def _signed_get(self, path: str, base_params: dict) -> object:
        last_status = 0
        last_data: object = None
        for attempt in range(2):
            params = dict(base_params)
            params["recvWindow"] = 10000
            params["timestamp"] = (time.time_ns() // 1_000_000) + await self._server_offset_ms(force=attempt == 1)
            params["signature"] = self._sign(params)
            try:
                async with self.session.get(
                    f"{self.base_url}{path}",
                    params=params,
                    headers={"X-MBX-APIKEY": self.api_key, "Accept": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=25),
                ) as response:
                    last_status = response.status
                    try:
                        last_data = await response.json(content_type=None)
                    except Exception as exc:
                        raise DepositProviderUnavailable("binance_invalid_json") from exc
            except DepositProviderUnavailable:
                raise
            except (aiohttp.ClientError, TimeoutError) as exc:
                raise DepositProviderUnavailable("binance_network_error") from exc
            if last_status == 200:
                return last_data
            code = last_data.get("code") if isinstance(last_data, dict) else None
            message = str(last_data.get("msg") if isinstance(last_data, dict) else last_data or "")
            if attempt == 0 and (code == -1021 or "timestamp" in message.lower()):
                continue
            raise DepositProviderUnavailable(f"binance_http_{last_status}:{message[:120]}")
        raise DepositProviderUnavailable(f"binance_http_{last_status}")
