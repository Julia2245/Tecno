from __future__ import annotations

import asyncio
import json
import uuid

import websockets


async def fetch_ichancy_auth_token(
    username: str,
    password: str,
    *,
    ws_url: str,
    origin: str,
    site_id: int,
    source: int,
) -> str | None:
    async with websockets.connect(
        ws_url,
        additional_headers={"Origin": origin},
        open_timeout=10,
        close_timeout=5,
    ) as ws:
        await ws.send(json.dumps({
            "command": "request_session",
            "params": {"language": "eng", "site_id": int(site_id), "source": int(source)},
            "rid": str(uuid.uuid4()),
        }))
        await asyncio.wait_for(ws.recv(), timeout=10)
        await ws.send(json.dumps({
            "command": "login",
            "params": {"username": username, "password": password},
            "rid": str(uuid.uuid4()),
        }))
        raw = await asyncio.wait_for(ws.recv(), timeout=10)
        response = json.loads(raw)
        data = response.get("data") if isinstance(response, dict) else None
        token = data.get("auth_token") if isinstance(data, dict) else None
        return str(token) if token else None
