from __future__ import annotations

import asyncio
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

import aiohttp


class IchancyError(RuntimeError):
    pass


class IchancyDefiniteError(IchancyError):
    """Provider definitely rejected the request; financial POST did not succeed."""


class IchancyTemporaryError(IchancyError):
    """Definite temporary rejection safe to retry later (connect/rate limit)."""


class IchancyTransferUncertain(IchancyError):
    """Financial request may have executed; never repeat blindly."""


def extract_player_balance_value(resp: Any) -> int | None:
    def num(value: Any) -> int | None:
        if value is None or isinstance(value, bool):
            return None
        try:
            dec = Decimal(str(value).replace(",", "").strip())
        except Exception:
            return None
        if dec < 0:
            return int(dec)
        return int(dec)

    def walk(node: Any) -> int | None:
        direct = num(node)
        if direct is not None and not isinstance(node, (dict, list, tuple)):
            return direct
        if isinstance(node, dict):
            for key in (
                "balance", "playerBalance", "currentBalance", "amount", "value",
                "Balance", "PlayerBalance", "CurrentBalance", "Amount", "Value",
            ):
                if key in node:
                    got = num(node.get(key))
                    if got is not None:
                        return got
            for key in ("data", "result", "payload", "item", "player"):
                if key in node:
                    got = walk(node.get(key))
                    if got is not None:
                        return got
            for value in node.values():
                got = walk(value)
                if got is not None:
                    return got
        elif isinstance(node, (list, tuple)):
            for value in node:
                got = walk(value)
                if got is not None:
                    return got
        return None

    return walk(resp)


def extract_cashier_balance(resp: Any, preferred_currency: str = "SYP") -> int | None:
    result = (resp or {}).get("result") if isinstance(resp, dict) else None
    records: list[dict[str, Any]] = []
    if isinstance(result, list):
        records = [x for x in result if isinstance(x, dict)]
    elif isinstance(result, dict):
        if isinstance(result.get("records"), list):
            records = [x for x in result["records"] if isinstance(x, dict)]
        else:
            records = [result]
    if not records:
        return None
    wanted = preferred_currency.upper().strip()
    chosen = next((x for x in records if str(x.get("currencyCode") or "").upper().strip() == wanted), records[0])
    for key in ("balance", "availability"):
        try:
            return int(Decimal(str(chosen.get(key)).replace(",", "").strip()))
        except Exception:
            continue
    return None


@dataclass(frozen=True, slots=True)
class IchancyCredentials:
    username: str
    password: str
    parent_id: str
    currency: str
    base_url: str
    gateway_url: str = ""
    gateway_secret: str = ""


class IchancyClient:
    """Async iChancy agent client.

    Read-only calls may retry transient failures. Financial calls send at most one
    business POST after auth (except one proven 401/auth-expired retry), matching
    the hardened financial safety behaviour.
    """

    def __init__(self, session: aiohttp.ClientSession, credentials: IchancyCredentials) -> None:
        self.session = session
        self.credentials = credentials
        self._access_token: str | None = None
        self._refresh_token: str | None = None
        self._auth_lock = asyncio.Lock()

    @property
    def configured(self) -> bool:
        return bool(self.credentials.username and self.credentials.password)

    def _url(self, endpoint: str) -> str:
        endpoint = endpoint.lstrip("/")
        gateway = self.credentials.gateway_url.rstrip("/")
        if gateway:
            return f"{gateway}/ichancy/{endpoint}"
        return f"{self.credentials.base_url.rstrip('/')}/{endpoint}"

    def _headers(self, *, auth: bool = True) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Origin": self.credentials.base_url.rstrip("/"),
            "Referer": f"{self.credentials.base_url.rstrip('/')}/dashboard",
            "User-Agent": "Mozilla/5.0 TelegramBotCore/1.0",
        }
        if auth and self._access_token:
            headers["Authorization"] = f"Bearer {self._access_token}"
        if self.credentials.gateway_url and self.credentials.gateway_secret:
            headers["X-Gateway-Secret"] = self.credentials.gateway_secret
        return headers

    @staticmethod
    def _error_text(data: dict[str, Any]) -> str:
        notif = data.get("notification")
        if isinstance(notif, list) and notif:
            first = notif[0]
            return str(first.get("content") if isinstance(first, dict) else first)
        if isinstance(notif, dict):
            return str(notif.get("content") or "خطأ غير معروف")
        return str(data.get("message") or "خطأ غير معروف")

    async def _json_response(self, resp: aiohttp.ClientResponse, *, financial: bool) -> dict[str, Any]:
        text = await resp.text()
        try:
            data = await resp.json(content_type=None)
        except Exception as exc:
            if financial:
                raise IchancyTransferUncertain(f"non-json financial response HTTP {resp.status}: {text[:300]}") from exc
            raise IchancyError(f"non-json response HTTP {resp.status}: {text[:300]}") from exc
        if not isinstance(data, dict):
            if financial:
                raise IchancyTransferUncertain("financial response is not an object")
            raise IchancyError("response is not an object")
        return data

    async def _sign_in_locked(self) -> None:
        if not self.configured:
            raise IchancyDefiniteError("بيانات كاشيرة iChancy غير مضبوطة")
        url = self._url("global/api/UserApi/signIn")
        payload = {"username": self.credentials.username, "password": self.credentials.password}
        last: Exception | None = None
        for attempt in range(3):
            try:
                async with self.session.post(url, json=payload, headers=self._headers(auth=False)) as resp:
                    data = await self._json_response(resp, financial=False)
                    if resp.status >= 500:
                        raise IchancyTemporaryError(f"HTTP {resp.status}")
                    if resp.status >= 400:
                        raise IchancyDefiniteError(f"HTTP {resp.status}: {self._error_text(data)}")
                    if not data.get("status") or not data.get("result"):
                        raise IchancyDefiniteError(self._error_text(data))
                    result = data["result"]
                    self._access_token = str(result.get("accessToken") or "") or None
                    self._refresh_token = str(result.get("refreshToken") or "") or None
                    if not self._access_token:
                        raise IchancyDefiniteError("لم يرجع iChancy access token صالح")
                    return
            except IchancyDefiniteError:
                raise
            except Exception as exc:
                last = exc
                if attempt < 2:
                    await asyncio.sleep(0.6 * (attempt + 1))
        raise IchancyTemporaryError(f"تعذر تسجيل دخول الكاشيرة: {last}")

    async def _ensure_auth(self) -> None:
        if self._access_token:
            return
        async with self._auth_lock:
            if not self._access_token:
                await self._sign_in_locked()

    async def _read_request(self, endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        await self._ensure_auth()
        url = self._url(endpoint)
        last: Exception | None = None
        for attempt in range(3):
            try:
                async with self.session.post(url, json=payload, headers=self._headers()) as resp:
                    data = await self._json_response(resp, financial=False)
                    if resp.status == 401 or str(data.get("result")).lower() == "ex":
                        self._access_token = None
                        await self._ensure_auth()
                        if attempt < 2:
                            continue
                    if resp.status == 429 or resp.status >= 500:
                        raise IchancyTemporaryError(f"HTTP {resp.status}")
                    if resp.status >= 400 or data.get("status") is False or data.get("result") is False:
                        raise IchancyDefiniteError(self._error_text(data))
                    return data
            except IchancyDefiniteError:
                raise
            except Exception as exc:
                last = exc
                if attempt < 2:
                    await asyncio.sleep(0.6 * (attempt + 1))
        raise IchancyTemporaryError(str(last or "iChancy temporarily unavailable"))

    async def _financial_request(self, endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        await self._ensure_auth()
        url = self._url(endpoint)

        async def post_once() -> tuple[aiohttp.ClientResponse, dict[str, Any]]:
            try:
                resp = await self.session.post(url, json=payload, headers=self._headers())
            except aiohttp.ClientConnectorError as exc:
                raise IchancyTemporaryError(f"connect failed before financial request: {exc}") from exc
            except (asyncio.TimeoutError, aiohttp.ClientConnectionError) as exc:
                raise IchancyTransferUncertain(f"financial transport outcome uncertain: {exc}") from exc
            data = await self._json_response(resp, financial=True)
            return resp, data

        resp, data = await post_once()
        try:
            if resp.status == 401 or str(data.get("result")).lower() == "ex":
                # Explicit auth rejection is definite: refresh and make one authenticated request.
                self._access_token = None
                await self._ensure_auth()
                resp.release()
                resp, data = await post_once()
                if resp.status == 401:
                    raise IchancyDefiniteError("توكن iChancy مرفوض بعد إعادة تسجيل الدخول")
            if resp.status == 429:
                # The financial POST already reached the remote HTTP stack. Without
                # a provider guarantee that a 429 is emitted before business
                # processing, replaying the same transfer is unsafe. Reconcile only.
                raise IchancyTransferUncertain("financial HTTP 429; outcome requires reconciliation")
            if resp.status >= 500:
                raise IchancyTransferUncertain(f"financial HTTP {resp.status}")
            if resp.status >= 400:
                raise IchancyDefiniteError(f"HTTP {resp.status}: {self._error_text(data)}")
            if data.get("status") is False or data.get("result") is False:
                raise IchancyDefiniteError(self._error_text(data))
            return data
        finally:
            resp.release()

    async def test_cashier(self) -> tuple[int | None, dict[str, Any]]:
        resp = await self.get_agent_all_wallets()
        return extract_cashier_balance(resp, self.credentials.currency), resp

    async def create_player(self, *, email: str, login: str, password: str) -> dict[str, Any]:
        """Create one player without blind transport retries.

        A lost response may mean the remote account was already created. The caller
        reconciles by the deterministic username before any later retry. Only a
        proven authentication rejection is safe to refresh and send once more.
        """
        await self._ensure_auth()
        endpoint = "global/api/UserApi/registerPlayer"
        url = self._url(endpoint)
        payload = {"player": {"email": email, "login": login, "password": password, "parentId": self.credentials.parent_id or None}}

        async def post_once() -> tuple[aiohttp.ClientResponse, dict[str, Any]]:
            try:
                resp = await self.session.post(url, json=payload, headers=self._headers())
            except aiohttp.ClientConnectorError as exc:
                raise IchancyTemporaryError(f"connect failed before account creation: {exc}") from exc
            except (asyncio.TimeoutError, aiohttp.ClientConnectionError) as exc:
                raise IchancyTemporaryError(f"account creation outcome uncertain: {exc}") from exc
            data = await self._json_response(resp, financial=False)
            return resp, data

        resp, data = await post_once()
        try:
            if resp.status == 401 or str(data.get("result")).lower() == "ex":
                self._access_token = None
                await self._ensure_auth()
                resp.release()
                resp, data = await post_once()
            if resp.status == 429 or resp.status >= 500:
                raise IchancyTemporaryError(f"account creation HTTP {resp.status}; reconcile before retry")
            if resp.status >= 400 or data.get("status") is False or data.get("result") is False:
                raise IchancyDefiniteError(self._error_text(data))
            result = data.get("result")
            if result not in (None, "", 0, False, 1, "1", True, "True") and not isinstance(result, (dict, list)):
                return data
        finally:
            resp.release()

        player_id = await self.get_player_id_by_username(login)
        if player_id:
            data["result"] = player_id
        return data

    async def get_player_id_by_username(self, username: str) -> str | None:
        username = username.strip()
        if not username:
            return None
        wanted = username.lower()
        for outer in range(6):
            start = 0
            for _ in range(6):
                data = await self._read_request(
                    "global/api/UserApi/getPlayersForCurrentAgent",
                    {"start": start, "limit": 50, "filter": {"withoutTotalCount": {"action": "=", "value": True}, "userName": {"action": "like", "value": username, "valueLabel": username}}, "isNextPage": False},
                )
                result = data.get("result") or {}
                records = result.get("records") or [] if isinstance(result, dict) else []
                for rec in records:
                    if not isinstance(rec, dict):
                        continue
                    rec_user = str(rec.get("username") or rec.get("userName") or "").strip().lower()
                    if rec_user == wanted:
                        pid = rec.get("playerId") or rec.get("id")
                        return str(pid) if pid is not None else None
                if not records:
                    break
                start += 50
            if outer < 5:
                await asyncio.sleep(1.5)
        return None

    async def get_player_balance(self, player_id: str) -> dict[str, Any]:
        return await self._read_request("global/api/UserApi/getPlayerBalanceById", {"playerId": str(player_id)})

    async def get_agent_all_wallets(self) -> dict[str, Any]:
        return await self._read_request("global/api/UserApi/getAgentAllWallets", {})

    async def deposit_to_player(self, player_id: str, amount: int, comment: str = "") -> dict[str, Any]:
        return await self._financial_request(
            "global/api/UserApi/depositToPlayer",
            {"playerId": str(player_id), "amount": int(amount), "comment": comment, "currencyCode": self.credentials.currency, "currency": self.credentials.currency, "moneyStatus": 5},
        )

    async def withdraw_from_player(self, player_id: str, amount: int, comment: str = "") -> dict[str, Any]:
        return await self._financial_request(
            "global/api/UserApi/withdrawFromPlayer",
            {"playerId": str(player_id), "amount": -abs(int(amount)), "comment": comment, "currencyCode": self.credentials.currency, "currency": self.credentials.currency, "moneyStatus": 5},
        )
