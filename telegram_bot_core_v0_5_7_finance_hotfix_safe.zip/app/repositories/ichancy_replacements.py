from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from uuid import UUID, uuid4

import asyncpg

from app.core.db import Database


@dataclass(frozen=True, slots=True)
class ReplacementRecord:
    id: UUID
    old_cashier_id: UUID
    new_cashier_id: UUID
    status: str
    min_withdraw_snapshot: int
    total_accounts: int
    checked_accounts: int
    zero_accounts: int
    below_minimum_accounts: int
    withdrawable_accounts: int
    failed_checks: int
    settled_accounts: int
    review_accounts: int
    total_balance_snapshot: int
    total_withdrawn: int
    total_wallet_credited: int
    progress_chat_id: int | None
    progress_message_id: int | None
    created_by: int
    created_at: datetime
    updated_at: datetime
    finished_at: datetime | None


@dataclass(frozen=True, slots=True)
class RetirementRecord:
    id: UUID
    replacement_id: UUID
    account_id: UUID
    telegram_id: int
    player_id: str
    username: str
    balance_snapshot: int | None
    final_balance_snapshot: int | None
    classification: str
    check_error: str | None
    settlement_job_id: UUID | None
    settlement_attempt: int
    compensated_amount: int
    compensation_wallet_operation_id: UUID | None
    checked_at: datetime | None
    settled_at: datetime | None
    created_at: datetime


class CashierReplacementRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def get(self, replacement_id: UUID) -> ReplacementRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM bot_core.ichancy_cashier_replacements WHERE id=$1", replacement_id
            )
        return self._replacement(row) if row else None

    async def get_open(self) -> ReplacementRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM bot_core.ichancy_cashier_replacements
                WHERE status IN ('preparing','checking','settling','ready','blocked')
                ORDER BY created_at DESC LIMIT 1
                """
            )
        return self._replacement(row) if row else None

    async def create(
        self,
        *,
        new_cashier_id: UUID,
        min_withdraw: int,
        created_by: int,
        progress_chat_id: int | None,
        progress_message_id: int | None,
    ) -> ReplacementRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                existing = await conn.fetchrow(
                    """
                    SELECT * FROM bot_core.ichancy_cashier_replacements
                    WHERE status IN ('preparing','checking','settling','ready','blocked')
                    ORDER BY created_at DESC LIMIT 1 FOR UPDATE
                    """
                )
                if existing:
                    return self._replacement(existing)
                old = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_cashiers WHERE status='active' LIMIT 1 FOR UPDATE"
                )
                if not old:
                    raise ValueError("NO_ACTIVE_ICHANCY_CASHIER")
                new = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_cashiers WHERE id=$1 FOR UPDATE", new_cashier_id
                )
                if not new or str(new["status"]) != "staged":
                    raise ValueError("NEW_CASHIER_NOT_STAGED")
                if not bool(new["last_test_ok"]):
                    raise ValueError("NEW_CASHIER_NOT_TESTED")
                active_jobs = int(await conn.fetchval(
                    """
                    SELECT COUNT(*) FROM bot_core.ichancy_jobs
                    WHERE cashier_id=$1 AND status IN ('queued','executing','remote_success','reconciling')
                    """,
                    old["id"],
                ) or 0)
                if active_jobs:
                    raise ValueError("ACTIVE_ICHANCY_JOBS")
                inflight_creations = int(await conn.fetchval(
                    """
                    SELECT COUNT(*) FROM bot_core.ichancy_account_creations
                    WHERE cashier_id=$1 AND status IN ('creating','uncertain')
                    """,
                    old["id"],
                ) or 0)
                if inflight_creations:
                    raise ValueError("ACTIVE_ICHANCY_ACCOUNT_CREATIONS")
                rid = uuid4()
                row = await conn.fetchrow(
                    """
                    INSERT INTO bot_core.ichancy_cashier_replacements(
                        id,old_cashier_id,new_cashier_id,status,min_withdraw_snapshot,
                        created_by,progress_chat_id,progress_message_id
                    ) VALUES($1,$2,$3,'checking',$4,$5,$6,$7)
                    RETURNING *
                    """,
                    rid, old["id"], new_cashier_id, int(min_withdraw), created_by,
                    progress_chat_id, progress_message_id,
                )
                await conn.execute(
                    "UPDATE bot_core.ichancy_cashiers SET status='retiring' WHERE id=$1 AND status='active'",
                    old["id"],
                )
                await conn.execute(
                    "UPDATE bot_core.ichancy_accounts SET status='retiring' WHERE cashier_id=$1 AND status='active'",
                    old["id"],
                )
                accounts = await conn.fetch(
                    "SELECT id,telegram_id,player_id,username FROM bot_core.ichancy_accounts WHERE cashier_id=$1 AND status='retiring'",
                    old["id"],
                )
                if accounts:
                    await conn.executemany(
                        """
                        INSERT INTO bot_core.ichancy_retirement_records(
                            id,replacement_id,account_id,telegram_id,player_id,username
                        ) VALUES($1,$2,$3,$4,$5,$6)
                        ON CONFLICT(replacement_id,account_id) DO NOTHING
                        """,
                        [(uuid4(), rid, a["id"], int(a["telegram_id"]), str(a["player_id"]), str(a["username"])) for a in accounts],
                    )
                total = int(await conn.fetchval(
                    "SELECT COUNT(*) FROM bot_core.ichancy_retirement_records WHERE replacement_id=$1", rid
                ) or 0)
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_cashier_replacements
                    SET total_accounts=$2,updated_at=NOW()
                    WHERE id=$1 RETURNING *
                    """,
                    rid, total,
                )
        return self._replacement(row)

    async def set_progress_message(self, replacement_id: UUID, *, chat_id: int, message_id: int) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.ichancy_cashier_replacements
                SET progress_chat_id=$2,progress_message_id=$3,updated_at=NOW()
                WHERE id=$1
                """,
                replacement_id, chat_id, message_id,
            )

    async def touch_progress_edit(self, replacement_id: UUID) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                "UPDATE bot_core.ichancy_cashier_replacements SET last_progress_edit_at=NOW() WHERE id=$1",
                replacement_id,
            )

    async def claim_needs_check(self, replacement_id: UUID) -> RetirementRecord | None:
        """Claim one balance-check row.

        `unchecked` is the first retirement snapshot. `rechecking` is a mandatory
        post-settlement balance check so a changed player balance cannot leave money
        silently behind on the old cashier.
        """
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    WITH candidate AS (
                        SELECT id FROM bot_core.ichancy_retirement_records
                        WHERE replacement_id=$1 AND classification IN ('unchecked','rechecking')
                        ORDER BY CASE WHEN classification='rechecking' THEN 0 ELSE 1 END,created_at,id
                        FOR UPDATE SKIP LOCKED LIMIT 1
                    )
                    UPDATE bot_core.ichancy_retirement_records r
                    SET classification='checking',check_error=NULL
                    FROM candidate c WHERE r.id=c.id
                    RETURNING r.*
                    """,
                    replacement_id,
                )
        return self._retirement(row) if row else None

    async def mark_check(
        self,
        record_id: UUID,
        *,
        classification: str,
        balance: int | None,
        error: str | None = None,
    ) -> RetirementRecord:
        if classification not in {"zero","below_minimum","withdrawable","check_failed"}:
            raise ValueError("invalid classification")
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                current = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_retirement_records WHERE id=$1 FOR UPDATE", record_id
                )
                if not current:
                    raise ValueError("RETIREMENT_RECORD_NOT_FOUND")
                if str(current["classification"]) != "checking":
                    return self._retirement(current)

                had_settlement = bool(await conn.fetchval(
                    "SELECT EXISTS(SELECT 1 FROM bot_core.ichancy_retirement_settlements WHERE retirement_record_id=$1)",
                    record_id,
                ))
                final_classification = classification
                next_job_id = current["settlement_job_id"]
                next_attempt = int(current["settlement_attempt"] or 1)
                initial_balance = current["balance_snapshot"]
                final_balance = current["final_balance_snapshot"]

                if classification == "check_failed":
                    # Preserve both money snapshots on failed reads. We never treat an
                    # unreadable balance as zero.
                    pass
                elif had_settlement:
                    final_balance = int(balance or 0)
                    if int(balance or 0) == 0:
                        final_classification = "settled"
                    elif classification == "below_minimum":
                        final_classification = "residual_below_minimum"
                    elif classification == "withdrawable":
                        # A balance remained/grew after the previous withdrawal. Queue a
                        # new immutable settlement attempt using the freshly read amount.
                        next_job_id = None
                        next_attempt += 1
                    elif classification == "zero":
                        final_classification = "settled"
                else:
                    if balance is not None:
                        initial_balance = int(balance)
                        final_balance = int(balance)

                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_retirement_records
                    SET classification=$2,balance_snapshot=$3,final_balance_snapshot=$4,
                        settlement_job_id=$5,settlement_attempt=$6,check_error=$7,checked_at=NOW()
                    WHERE id=$1
                    RETURNING *
                    """,
                    record_id, final_classification, initial_balance, final_balance, next_job_id, next_attempt,
                    (error[:1200] if error else None),
                )
                settlement_status = "none"
                if final_classification == "zero":
                    settlement_status = "not_needed"
                elif final_classification in {"below_minimum","residual_below_minimum"}:
                    settlement_status = "pending"
                elif final_classification == "settled":
                    settlement_status = "automatic"
                elif final_classification in {"withdrawable","checking"}:
                    settlement_status = "pending"
                elif final_classification == "check_failed":
                    settlement_status = "review" if had_settlement else "none"
                await conn.execute(
                    """
                    UPDATE bot_core.ichancy_accounts
                    SET balance_at_retirement=$2,retirement_checked_at=CASE WHEN $2 IS NULL THEN retirement_checked_at ELSE NOW() END,
                        retirement_check_status=$3,settlement_status=$4
                    WHERE id=$1
                    """,
                    row["account_id"], final_balance, final_classification, settlement_status,
                )
        return self._retirement(row)

    async def list_withdrawable_unqueued(self, replacement_id: UUID, limit: int = 20) -> list[RetirementRecord]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.ichancy_retirement_records
                WHERE replacement_id=$1 AND classification='withdrawable' AND settlement_job_id IS NULL
                ORDER BY created_at,id LIMIT $2
                """,
                replacement_id, max(1, min(100, int(limit))),
            )
        return [self._retirement(r) for r in rows]

    async def link_settlement_job(self, record_id: UUID, job_id: UUID) -> RetirementRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_retirement_records WHERE id=$1 FOR UPDATE", record_id
                )
                if not row:
                    raise ValueError("RETIREMENT_RECORD_NOT_FOUND")
                if str(row["classification"]) not in {"withdrawable","settling"}:
                    return self._retirement(row)
                job = await conn.fetchrow(
                    "SELECT id,amount FROM bot_core.ichancy_jobs WHERE id=$1 FOR UPDATE", job_id
                )
                if not job:
                    raise ValueError("ICHANCY_JOB_NOT_FOUND")
                await conn.execute(
                    """
                    INSERT INTO bot_core.ichancy_retirement_settlements(
                        id,retirement_record_id,attempt,job_id,planned_amount
                    ) VALUES($1,$2,$3,$4,$5)
                    ON CONFLICT(retirement_record_id,attempt) DO NOTHING
                    """,
                    uuid4(), record_id, int(row["settlement_attempt"] or 1), job_id, int(job["amount"]),
                )
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_retirement_records
                    SET settlement_job_id=COALESCE(settlement_job_id,$2),classification='settling'
                    WHERE id=$1 AND classification IN ('withdrawable','settling')
                    RETURNING *
                    """,
                    record_id, job_id,
                )
                await conn.execute(
                    "UPDATE bot_core.ichancy_accounts SET settlement_status='pending' WHERE id=$1",
                    row["account_id"],
                )
        return self._retirement(row)

    async def sync_jobs(self, replacement_id: UUID) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # Never call a retirement settled from the provider POST alone. After
                # every successful withdrawal we re-read the player balance; this catches
                # a balance that changed between the initial snapshot and execution.
                await conn.execute(
                    """
                    UPDATE bot_core.ichancy_retirement_records r
                    SET classification='rechecking',settled_at=COALESCE(settled_at,NOW()),check_error=NULL
                    FROM bot_core.ichancy_jobs j
                    WHERE r.replacement_id=$1 AND r.settlement_job_id=j.id
                      AND r.classification='settling' AND j.status='success'
                    """,
                    replacement_id,
                )
                await conn.execute(
                    """
                    UPDATE bot_core.ichancy_accounts a
                    SET settlement_status='pending'
                    FROM bot_core.ichancy_retirement_records r
                    JOIN bot_core.ichancy_jobs j ON j.id=r.settlement_job_id
                    WHERE r.replacement_id=$1 AND r.account_id=a.id AND j.status='success'
                    """,
                    replacement_id,
                )
                await conn.execute(
                    """
                    UPDATE bot_core.ichancy_retirement_records r
                    SET classification='review',check_error=COALESCE(j.last_error,'settlement job failed')
                    FROM bot_core.ichancy_jobs j
                    WHERE r.replacement_id=$1 AND r.settlement_job_id=j.id
                      AND r.classification='settling' AND j.status='failed'
                    """,
                    replacement_id,
                )
                await conn.execute(
                    """
                    UPDATE bot_core.ichancy_accounts a
                    SET settlement_status='review'
                    FROM bot_core.ichancy_retirement_records r
                    WHERE r.replacement_id=$1 AND r.account_id=a.id AND r.classification='review'
                    """,
                    replacement_id,
                )

    async def retry_failed_checks(self, replacement_id: UUID) -> int:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # Failed reads are retried from the correct phase. If this account has
                # already had a settlement attempt, recheck its *current* remaining
                # balance; otherwise repeat the first snapshot.
                a = await conn.execute(
                    """
                    UPDATE bot_core.ichancy_retirement_records r
                    SET classification=CASE WHEN EXISTS(
                            SELECT 1 FROM bot_core.ichancy_retirement_settlements s
                            WHERE s.retirement_record_id=r.id
                        ) THEN 'rechecking' ELSE 'unchecked' END,
                        check_error=NULL,checked_at=NULL
                    WHERE r.replacement_id=$1 AND r.classification='check_failed'
                    """,
                    replacement_id,
                )
                b = await conn.execute(
                    """
                    UPDATE bot_core.ichancy_retirement_records r
                    SET classification=CASE WHEN EXISTS(
                            SELECT 1 FROM bot_core.ichancy_retirement_settlements s
                            WHERE s.retirement_record_id=r.id
                        ) THEN 'rechecking' ELSE 'unchecked' END,
                        check_error=NULL,checked_at=NULL,
                        settlement_job_id=NULL,settlement_attempt=settlement_attempt+1
                    WHERE r.replacement_id=$1 AND r.classification='review'
                    """,
                    replacement_id,
                )
        return int(a.split()[-1]) + int(b.split()[-1])

    async def refresh_stats(self, replacement_id: UUID) -> ReplacementRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    SELECT
                        COUNT(*)::int AS total,
                        COUNT(*) FILTER (WHERE classification NOT IN ('unchecked','checking'))::int AS checked,
                        COUNT(*) FILTER (WHERE classification='zero')::int AS zeros,
                        COUNT(*) FILTER (WHERE classification IN ('below_minimum','residual_below_minimum'))::int AS below,
                        COUNT(*) FILTER (WHERE classification IN ('withdrawable','settling','rechecking','settled','residual_below_minimum','review')
                            AND EXISTS(SELECT 1 FROM bot_core.ichancy_retirement_settlements s WHERE s.retirement_record_id=ichancy_retirement_records.id))::int AS withdrawable,
                        COUNT(*) FILTER (WHERE classification='check_failed')::int AS failed,
                        COUNT(*) FILTER (WHERE classification IN ('settled','residual_below_minimum')
                            AND EXISTS(SELECT 1 FROM bot_core.ichancy_retirement_settlements s WHERE s.retirement_record_id=ichancy_retirement_records.id))::int AS settled,
                        COUNT(*) FILTER (WHERE classification='review')::int AS review,
                        COUNT(*) FILTER (WHERE classification IN ('unchecked','checking','rechecking'))::int AS unchecked,
                        COUNT(*) FILTER (WHERE classification='settling')::int AS settling,
                        COUNT(*) FILTER (WHERE classification='withdrawable')::int AS awaiting_queue,
                        COALESCE(SUM(balance_snapshot),0)::bigint AS total_balance
                    FROM bot_core.ichancy_retirement_records WHERE replacement_id=$1
                    """,
                    replacement_id,
                )
                success_sums = await conn.fetchrow(
                    """
                    SELECT COALESCE(SUM(j.amount),0)::bigint AS remote_total,
                           COALESCE(SUM(j.amount) FILTER (WHERE j.wallet_operation_id IS NOT NULL),0)::bigint AS wallet_total
                    FROM bot_core.ichancy_retirement_settlements s
                    JOIN bot_core.ichancy_retirement_records r ON r.id=s.retirement_record_id
                    JOIN bot_core.ichancy_jobs j ON j.id=s.job_id
                    WHERE r.replacement_id=$1 AND j.status='success'
                    """,
                    replacement_id,
                )
                if int(row["unchecked"]) > 0:
                    status = "checking"
                elif int(row["failed"]) > 0 or int(row["review"]) > 0:
                    status = "blocked"
                elif int(row["settling"]) > 0 or int(row["awaiting_queue"]) > 0:
                    status = "settling"
                else:
                    status = "ready"
                updated = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_cashier_replacements
                    SET status=CASE WHEN status='completed' THEN status ELSE $2 END,
                        total_accounts=$3,checked_accounts=$4,zero_accounts=$5,
                        below_minimum_accounts=$6,withdrawable_accounts=$7,failed_checks=$8,
                        settled_accounts=$9,review_accounts=$10,total_balance_snapshot=$11,
                        total_withdrawn=$12,total_wallet_credited=$13,updated_at=NOW()
                    WHERE id=$1 RETURNING *
                    """,
                    replacement_id, status, int(row["total"]), int(row["checked"]), int(row["zeros"]),
                    int(row["below"]), int(row["withdrawable"]), int(row["failed"]), int(row["settled"]),
                    int(row["review"]), int(row["total_balance"]), int(success_sums["remote_total"] or 0),
                    int(success_sums["wallet_total"] or 0),
                )
        return self._replacement(updated)

    async def finalize(self, replacement_id: UUID, admin_id: int) -> ReplacementRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                repl = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_cashier_replacements WHERE id=$1 FOR UPDATE", replacement_id
                )
                if not repl:
                    raise ValueError("REPLACEMENT_NOT_FOUND")
                if str(repl["status"]) != "ready":
                    raise ValueError("REPLACEMENT_NOT_READY")
                if int(repl["total_withdrawn"]) != int(repl["total_wallet_credited"]):
                    raise ValueError("REPLACEMENT_MONEY_MISMATCH")
                active_jobs = int(await conn.fetchval(
                    """
                    SELECT COUNT(*) FROM bot_core.ichancy_jobs j
                    JOIN bot_core.ichancy_retirement_records r ON r.settlement_job_id=j.id
                    WHERE r.replacement_id=$1 AND j.status IN ('queued','executing','remote_success','reconciling')
                    """,
                    replacement_id,
                ) or 0)
                if active_jobs:
                    raise ValueError("REPLACEMENT_ACTIVE_JOBS")
                await conn.execute(
                    "UPDATE bot_core.ichancy_cashiers SET status='retired',retired_at=NOW() WHERE id=$1 AND status='retiring'",
                    repl["old_cashier_id"],
                )
                activated = await conn.execute(
                    "UPDATE bot_core.ichancy_cashiers SET status='active',activated_at=NOW() WHERE id=$1 AND status='staged'",
                    repl["new_cashier_id"],
                )
                if activated.split()[-1] != "1":
                    raise ValueError("NEW_CASHIER_ACTIVATION_FAILED")
                await conn.execute(
                    "UPDATE bot_core.ichancy_accounts SET status='retired',retired_at=NOW() WHERE cashier_id=$1 AND status='retiring'",
                    repl["old_cashier_id"],
                )
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_cashier_replacements
                    SET status='completed',finished_at=NOW(),updated_at=NOW()
                    WHERE id=$1 RETURNING *
                    """,
                    replacement_id,
                )
        return self._replacement(row)

    async def list_old_for_user(self, telegram_id: int, limit: int = 30) -> list[RetirementRecord]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT r.* FROM bot_core.ichancy_retirement_records r
                JOIN bot_core.ichancy_cashier_replacements x ON x.id=r.replacement_id
                WHERE r.telegram_id=$1 AND x.status='completed'
                ORDER BY r.created_at DESC LIMIT $2
                """,
                telegram_id, max(1, min(100, int(limit))),
            )
        return [self._retirement(r) for r in rows]

    async def get_retirement(self, record_id: UUID) -> RetirementRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM bot_core.ichancy_retirement_records WHERE id=$1", record_id)
        return self._retirement(row) if row else None

    @staticmethod
    def _replacement(row: asyncpg.Record) -> ReplacementRecord:
        return ReplacementRecord(
            id=row["id"], old_cashier_id=row["old_cashier_id"], new_cashier_id=row["new_cashier_id"],
            status=str(row["status"]), min_withdraw_snapshot=int(row["min_withdraw_snapshot"]),
            total_accounts=int(row["total_accounts"]), checked_accounts=int(row["checked_accounts"]),
            zero_accounts=int(row["zero_accounts"]), below_minimum_accounts=int(row["below_minimum_accounts"]),
            withdrawable_accounts=int(row["withdrawable_accounts"]), failed_checks=int(row["failed_checks"]),
            settled_accounts=int(row["settled_accounts"]), review_accounts=int(row["review_accounts"]),
            total_balance_snapshot=int(row["total_balance_snapshot"]), total_withdrawn=int(row["total_withdrawn"]),
            total_wallet_credited=int(row["total_wallet_credited"]),
            progress_chat_id=int(row["progress_chat_id"]) if row["progress_chat_id"] is not None else None,
            progress_message_id=int(row["progress_message_id"]) if row["progress_message_id"] is not None else None,
            created_by=int(row["created_by"]), created_at=row["created_at"], updated_at=row["updated_at"], finished_at=row["finished_at"],
        )

    @staticmethod
    def _retirement(row: asyncpg.Record) -> RetirementRecord:
        return RetirementRecord(
            id=row["id"], replacement_id=row["replacement_id"], account_id=row["account_id"],
            telegram_id=int(row["telegram_id"]), player_id=str(row["player_id"]), username=str(row["username"]),
            balance_snapshot=int(row["balance_snapshot"]) if row["balance_snapshot"] is not None else None,
            final_balance_snapshot=int(row["final_balance_snapshot"]) if row["final_balance_snapshot"] is not None else None,
            classification=str(row["classification"]), check_error=str(row["check_error"]) if row["check_error"] else None,
            settlement_job_id=row["settlement_job_id"], settlement_attempt=int(row["settlement_attempt"] or 1), compensated_amount=int(row["compensated_amount"] or 0),
            compensation_wallet_operation_id=row["compensation_wallet_operation_id"], checked_at=row["checked_at"],
            settled_at=row["settled_at"], created_at=row["created_at"],
        )
