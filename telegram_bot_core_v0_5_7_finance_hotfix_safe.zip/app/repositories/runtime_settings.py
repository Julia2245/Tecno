from __future__ import annotations

import json
from typing import Any

from app.core.db import Database


class RuntimeSettingsRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def load_all(self) -> dict[str, Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT key,value FROM bot_core.runtime_settings")
        return {str(row["key"]): row["value"] for row in rows}

    async def set(self, key: str, value: Any, *, updated_by: int | None) -> None:
        pool = self.db.require_pool()
        payload = json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO bot_core.runtime_settings(key,value,updated_by)
                VALUES($1,$2::jsonb,$3)
                ON CONFLICT(key) DO UPDATE
                SET value=EXCLUDED.value, updated_by=EXCLUDED.updated_by, updated_at=NOW()
                """,
                key,
                payload,
                updated_by,
            )
