from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping
from uuid import UUID, uuid4

import asyncpg

from app.core.db import Database
from app.core.ichancy_reconciliation import build_provider_reference



@dataclass(frozen=True, slots=True)
class IchancyJob:
    id: UUID
    telegram_id: int
    account_id: UUID
    cashier_id: UUID
    operation_type: str
    source: str
    amount: int
    status: str
    idempotency_key: str
    provider_reference: str | None
    wallet_hold_id: UUID | None
    wallet_operation_id: UUID | None
    player_balance_before: int | None
    player_balance_after: int | None
    cashier_balance_before: int | None
    cashier_balance_after: int | None
    attempt_count: int
    reconcile_attempt_count: int
    last_error: str | None
    created_at: datetime
    claimed_at: datetime | None
    financial_post_started_at: datetime | None
    remote_success_at: datetime | None
    reconcile_started_at: datetime | None
    reconcile_next_at: datetime | None
    finished_at: datetime | None
    result_chat_id: int | None
    result_message_id: int | None
    result_message_status: str | None


class IchancyJobRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def active_for_user(self, telegram_id: int) -> IchancyJob | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM bot_core.ichancy_jobs
                WHERE telegram_id=$1 AND status IN ('queued','executing','remote_success','reconciling')
                ORDER BY created_at DESC LIMIT 1
                """,
                telegram_id,
            )
        return self._job(row) if row else None

    async def create_job(
        self,
        *,
        telegram_id: int,
        account_id: UUID,
        cashier_id: UUID,
        operation_type: str,
        source: str,
        amount: int,
        idempotency_key: str,
        wallet_hold_id: UUID | None,
    ) -> IchancyJob:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                return await self.create_job_in_transaction(
                    conn,
                    telegram_id=telegram_id,
                    account_id=account_id,
                    cashier_id=cashier_id,
                    operation_type=operation_type,
                    source=source,
                    amount=amount,
                    idempotency_key=idempotency_key,
                    wallet_hold_id=wallet_hold_id,
                )

    async def create_job_in_transaction(
        self,
        conn: asyncpg.Connection,
        *,
        telegram_id: int,
        account_id: UUID,
        cashier_id: UUID,
        operation_type: str,
        source: str,
        amount: int,
        idempotency_key: str,
        wallet_hold_id: UUID | None,
    ) -> IchancyJob:
        """Create a durable iChancy job inside a caller-owned transaction."""
        if operation_type not in {"deposit", "withdraw", "retirement_withdraw"}:
            raise ValueError("INVALID_ICHANCY_OPERATION")
        if int(amount) <= 0:
            raise ValueError("INVALID_ICHANCY_AMOUNT")

        cashier = await conn.fetchrow(
            "SELECT id,status FROM bot_core.ichancy_cashiers WHERE id=$1 FOR UPDATE",
            cashier_id,
        )
        if not cashier:
            raise ValueError("ICHANCY_CASHIER_NOT_FOUND")
        account = await conn.fetchrow(
            "SELECT id,telegram_id,cashier_id,status FROM bot_core.ichancy_accounts WHERE id=$1 FOR UPDATE",
            account_id,
        )
        if not account or int(account["telegram_id"]) != int(telegram_id) or account["cashier_id"] != cashier_id:
            raise ValueError("ICHANCY_ACCOUNT_MISMATCH")
        if operation_type == "retirement_withdraw":
            if str(cashier["status"]) != "retiring" or str(account["status"]) != "retiring":
                raise ValueError("ICHANCY_RETIREMENT_ACCOUNT_NOT_ACTIVE")
        else:
            if str(cashier["status"]) != "active" or str(account["status"]) != "active":
                raise ValueError("ICHANCY_ACCOUNT_NOT_ACTIVE")

        existing = await conn.fetchrow(
            "SELECT * FROM bot_core.ichancy_jobs WHERE idempotency_key=$1 FOR UPDATE",
            idempotency_key,
        )
        if existing:
            return self._job(existing)

        job_id = uuid4()
        provider_reference = build_provider_reference(operation_type, job_id)
        row = await conn.fetchrow(
            """
            INSERT INTO bot_core.ichancy_jobs(
                id,telegram_id,account_id,cashier_id,operation_type,source,amount,status,
                idempotency_key,provider_reference,wallet_hold_id
            ) VALUES($1,$2,$3,$4,$5,$6,$7,'queued',$8,$9,$10)
            RETURNING *
            """,
            job_id, telegram_id, account_id, cashier_id, operation_type, source,
            amount, idempotency_key, provider_reference, wallet_hold_id,
        )
        await self.add_event(
            conn,
            row["id"],
            "queued",
            {"source": source, "amount": amount, "provider_reference": provider_reference},
        )
        return self._job(row)

    async def claim_next(self) -> IchancyJob | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # A worker crash while executing is ambiguous. Never replay the
                # financial POST; move it to read-only reconciliation instead.
                await conn.execute(
                    """
                    UPDATE bot_core.ichancy_jobs
                    SET status='reconciling',
                        last_error=COALESCE(last_error,'worker interrupted while executing'),
                        reconcile_started_at=COALESCE(reconcile_started_at,NOW()),
                        reconcile_next_at=COALESCE(reconcile_next_at,NOW()),
                        updated_at=NOW()
                    WHERE status='executing' AND claimed_at < NOW() - INTERVAL '2 minutes'
                    """
                )
                row = await conn.fetchrow(
                    """
                    WITH candidate AS (
                        SELECT id FROM bot_core.ichancy_jobs
                        WHERE status='queued'
                        ORDER BY created_at,id
                        FOR UPDATE SKIP LOCKED
                        LIMIT 1
                    )
                    UPDATE bot_core.ichancy_jobs j
                    SET status='executing',claimed_at=NOW(),attempt_count=attempt_count+1,updated_at=NOW()
                    FROM candidate c
                    WHERE j.id=c.id
                    RETURNING j.*
                    """
                )
                if row:
                    await self.add_event(conn, row["id"], "claimed", {"attempt": int(row["attempt_count"])})
        return self._job(row) if row else None

    async def list_reconciling(self, limit: int = 10) -> list[IchancyJob]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.ichancy_jobs
                WHERE status='remote_success'
                   OR (status='reconciling' AND reconcile_next_at IS NOT NULL AND reconcile_next_at <= NOW())
                ORDER BY CASE WHEN status='remote_success' THEN 0 ELSE 1 END, updated_at,id
                LIMIT $1
                """,
                max(1, min(50, int(limit))),
            )
        return [self._job(r) for r in rows]

    async def list_needs_review(self, limit: int = 30) -> list[IchancyJob]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.ichancy_jobs
                WHERE status='reconciling' AND reconcile_next_at IS NULL
                ORDER BY updated_at,id LIMIT $1
                """,
                max(1, min(100, int(limit))),
            )
        return [self._job(r) for r in rows]

    async def set_snapshots(self, job_id: UUID, *, player_before: int, cashier_before: int | None) -> IchancyJob:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_jobs
                    SET player_balance_before=COALESCE(player_balance_before,$2),
                        cashier_balance_before=COALESCE(cashier_balance_before,$3),updated_at=NOW()
                    WHERE id=$1 AND status='executing'
                    RETURNING *
                    """,
                    job_id, player_before, cashier_before,
                )
                if row:
                    await self.add_event(conn, job_id, "snapshots", {"player_before": player_before, "cashier_before": cashier_before})
        if not row:
            raise ValueError("ICHANCY_JOB_NOT_EXECUTING")
        return self._job(row)

    async def mark_financial_post_started(self, job_id: UUID) -> IchancyJob:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_jobs
                    SET financial_post_started_at=COALESCE(financial_post_started_at,NOW()),updated_at=NOW()
                    WHERE id=$1 AND status='executing'
                    RETURNING *
                    """,
                    job_id,
                )
                if row:
                    await self.add_event(
                        conn,
                        job_id,
                        "financial_post_started",
                        {"provider_reference": row["provider_reference"]},
                    )
        if not row:
            raise ValueError("ICHANCY_JOB_NOT_EXECUTING")
        return self._job(row)

    async def mark_remote_success(self, job_id: UUID, payload: Mapping[str, Any]) -> IchancyJob:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_jobs
                    SET status='remote_success',remote_payload=$2::jsonb,remote_success_at=NOW(),
                        reconcile_next_at=NULL,last_error=NULL,updated_at=NOW()
                    WHERE id=$1 AND status IN ('executing','reconciling')
                    RETURNING *
                    """,
                    job_id, json.dumps(dict(payload), ensure_ascii=False, separators=(",", ":"), default=str),
                )
                if row:
                    await self.add_event(conn, job_id, "remote_success", {"provider_reference": row["provider_reference"]})
        if not row:
            current = await self.get(job_id)
            if current and current.status in {"remote_success", "success"}:
                return current
            raise ValueError("ICHANCY_JOB_REMOTE_STATE_CONFLICT")
        return self._job(row)

    async def mark_reconciling(self, job_id: UUID, error: str, *, delay_seconds: int) -> IchancyJob:
        pool = self.db.require_pool()
        delay = max(1, int(delay_seconds))
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_jobs
                    SET status='reconciling',last_error=$2,
                        reconcile_started_at=COALESCE(reconcile_started_at,NOW()),
                        reconcile_next_at=COALESCE(reconcile_next_at,NOW() + ($3 * INTERVAL '1 second')),
                        updated_at=NOW()
                    WHERE id=$1 AND status IN ('executing','reconciling')
                    RETURNING *
                    """,
                    job_id, error[:1200], delay,
                )
                if row:
                    await self.add_event(
                        conn,
                        job_id,
                        "reconciling",
                        {"error": error[:500], "provider_reference": row["provider_reference"]},
                    )
                    if str(row["operation_type"]) != "retirement_withdraw":
                        progress_text = (
                            "⏳ <b>جاري التأكد من نتيجة الشحن...</b>\n\nلا تعِد المحاولة حالياً."
                            if str(row["operation_type"]) == "deposit"
                            else "⏳ <b>جاري التأكد من نتيجة السحب...</b>\n\nلا تعِد المحاولة حالياً."
                        )
                        await conn.execute(
                            """
                            INSERT INTO bot_core.notification_outbox(
                                id,event_key,target_chat_id,text,parse_mode,next_attempt_at
                            ) VALUES($1,$2,$3,$4,'HTML',NOW() + INTERVAL '12 seconds')
                            ON CONFLICT(event_key) DO NOTHING
                            """,
                            uuid4(), f"ichancy-job-user-review:{job_id}", int(row["telegram_id"]), progress_text,
                        )
        if not row:
            current = await self.get(job_id)
            if current:
                return current
            raise ValueError("ICHANCY_JOB_NOT_FOUND")
        return self._job(row)

    async def record_reconcile_attempt(
        self,
        job_id: UUID,
        *,
        error: str,
        player_after: int | None,
        cashier_after: int | None,
        delay_seconds: int,
        max_attempts: int,
    ) -> IchancyJob:
        pool = self.db.require_pool()
        delay = max(1, int(delay_seconds))
        max_attempts = max(1, int(max_attempts))
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_jobs
                    SET reconcile_attempt_count=reconcile_attempt_count+1,
                        player_balance_after=COALESCE($2,player_balance_after),
                        cashier_balance_after=COALESCE($3,cashier_balance_after),
                        last_error=$4,
                        reconcile_next_at=CASE
                            WHEN reconcile_attempt_count + 1 >= $5 THEN NULL
                            ELSE NOW() + ($6 * INTERVAL '1 second')
                        END,
                        updated_at=NOW()
                    WHERE id=$1 AND status='reconciling'
                    RETURNING *
                    """,
                    job_id, player_after, cashier_after, error[:1200], max_attempts, delay,
                )
                if row:
                    await self.add_event(
                        conn,
                        job_id,
                        "reconcile_attempt",
                        {
                            "attempt": int(row["reconcile_attempt_count"]),
                            "player_after": player_after,
                            "cashier_after": cashier_after,
                            "error": error[:500],
                        },
                    )
                    if row["reconcile_next_at"] is None:
                        await self.add_event(
                            conn,
                            job_id,
                            "review_required",
                            {"provider_reference": row["provider_reference"]},
                        )
                        if str(row["operation_type"]) != "retirement_withdraw":
                            await conn.execute(
                                """
                                INSERT INTO bot_core.notification_outbox(id,event_key,target_key,text,parse_mode)
                                VALUES($1,$2,'notify.ichancy_operations',$3,'HTML')
                                ON CONFLICT(event_key) DO NOTHING
                                """,
                                uuid4(), f"ichancy-job-review-required:{job_id}",
                                "⚠️ <b>عملية iChancy تحتاج مراجعة</b>\n\n"
                                f"🧾 رقم العملية: <code>{job_id}</code>\n"
                                f"🔖 مرجع المزود: <code>{row['provider_reference'] or '-'}</code>\n"
                                f"👤 Telegram ID: <code>{int(row['telegram_id'])}</code>\n"
                                f"💰 المبلغ: <code>{int(row['amount']):,}</code>\n"
                                f"🔁 محاولات المطابقة: <code>{int(row['reconcile_attempt_count'])}</code>\n\n"
                                "لم تتم إعادة إرسال أي تحويل مالي إلى iChancy.",
                            )
        if not row:
            current = await self.get(job_id)
            if current:
                return current
            raise ValueError("ICHANCY_JOB_NOT_FOUND")
        return self._job(row)

    async def requeue(self, job_id: UUID, error: str) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    """
                    UPDATE bot_core.ichancy_jobs
                    SET status='queued',claimed_at=NULL,last_error=$2,
                        player_balance_before=NULL,cashier_balance_before=NULL,
                        financial_post_started_at=NULL,updated_at=NOW()
                    WHERE id=$1 AND status='executing'
                    """,
                    job_id, error[:1200],
                )
                await self.add_event(conn, job_id, "requeued", {"error": error[:500]})

    async def fail_in_transaction(
        self,
        conn: asyncpg.Connection,
        job_id: UUID,
        error: str,
    ) -> IchancyJob:
        row = await conn.fetchrow(
            """
            UPDATE bot_core.ichancy_jobs
            SET status='failed',last_error=$2,finished_at=NOW(),reconcile_next_at=NULL,updated_at=NOW()
            WHERE id=$1 AND status IN ('queued','executing','reconciling')
            RETURNING *
            """,
            job_id, error[:1200],
        )
        if row:
            await self.add_event(conn, job_id, "failed", {"error": error[:500]})
            if str(row["operation_type"]) != "retirement_withdraw":
                op = str(row["operation_type"])
                if op == "deposit":
                    user_text = "❌ <b>تعذر شحن حسابك حالياً.</b>\n\nتمت إعادة المبلغ المحجوز إلى محفظتك."
                else:
                    user_text = "❌ <b>تعذر سحب رصيد حسابك حالياً.</b>\n\nلم يتم تنفيذ التحويل."
                await conn.execute(
                    """
                    INSERT INTO bot_core.notification_outbox(
                        id,event_key,target_chat_id,text,parse_mode,next_attempt_at
                    ) VALUES($1,$2,$3,$4,'HTML',NOW() + INTERVAL '12 seconds')
                    ON CONFLICT(event_key) DO NOTHING
                    """,
                    uuid4(), f"ichancy-job-user-failed:{job_id}", int(row["telegram_id"]), user_text,
                )
            return self._job(row)
        current = await conn.fetchrow(
            "SELECT * FROM bot_core.ichancy_jobs WHERE id=$1 FOR UPDATE", job_id
        )
        if current:
            return self._job(current)
        raise ValueError("ICHANCY_JOB_NOT_FOUND")

    async def fail(self, job_id: UUID, error: str) -> IchancyJob:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                return await self.fail_in_transaction(conn, job_id, error)

    async def finalize_success(
        self,
        conn: asyncpg.Connection,
        *,
        job_id: UUID,
        wallet_operation_id: UUID,
        player_after: int | None,
        cashier_after: int | None,
        notification_text: str,
    ) -> IchancyJob:
        row = await conn.fetchrow(
            """
            UPDATE bot_core.ichancy_jobs
            SET status='success',wallet_operation_id=$2,player_balance_after=$3,cashier_balance_after=$4,
                finished_at=NOW(),reconcile_next_at=NULL,updated_at=NOW(),last_error=NULL
            WHERE id=$1 AND status IN ('remote_success','reconciling')
            RETURNING *
            """,
            job_id, wallet_operation_id, player_after, cashier_after,
        )
        if row is None:
            current = await conn.fetchrow("SELECT * FROM bot_core.ichancy_jobs WHERE id=$1 FOR UPDATE", job_id)
            if current and current["status"] == "success":
                return self._job(current)
            raise ValueError("ICHANCY_JOB_FINALIZE_CONFLICT")
        await self.add_event(conn, job_id, "success", {"wallet_operation_id": str(wallet_operation_id)})
        await conn.execute(
            """
            INSERT INTO bot_core.notification_outbox(id,event_key,target_key,text,parse_mode)
            VALUES($1,$2,'notify.ichancy_operations',$3,'HTML')
            ON CONFLICT(event_key) DO NOTHING
            """,
            uuid4(), f"ichancy-job-success:{job_id}", notification_text,
        )
        op = str(row["operation_type"])
        user_text = "✅ <b>تم شحن حسابك بنجاح.</b>" if op == "deposit" else "✅ <b>تم سحب رصيد حسابك بنجاح.</b>"
        await conn.execute(
            """
            INSERT INTO bot_core.notification_outbox(
                id,event_key,target_chat_id,text,parse_mode,next_attempt_at
            ) VALUES($1,$2,$3,$4,'HTML',NOW() + INTERVAL '12 seconds')
            ON CONFLICT(event_key) DO NOTHING
            """,
            uuid4(), f"ichancy-job-user-success:{job_id}", int(row["telegram_id"]), user_text,
        )
        return self._job(row)

    async def get(self, job_id: UUID) -> IchancyJob | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM bot_core.ichancy_jobs WHERE id=$1", job_id)
        return self._job(row) if row else None

    async def attach_result_message(self, job_id: UUID, *, chat_id: int, message_id: int) -> IchancyJob:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_jobs
                    SET result_chat_id=$2,result_message_id=$3,result_message_status='progress',updated_at=NOW()
                    WHERE id=$1
                    RETURNING *
                    """,
                    job_id, int(chat_id), int(message_id),
                )
                if row:
                    await self.add_event(conn, job_id, "result_message_attached", {"chat_id": int(chat_id), "message_id": int(message_id)})
        if not row:
            raise ValueError("ICHANCY_JOB_NOT_FOUND")
        return self._job(row)

    async def list_pending_result_message_updates(self, limit: int = 20) -> list[IchancyJob]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.ichancy_jobs
                WHERE result_chat_id IS NOT NULL AND result_message_id IS NOT NULL
                  AND status IN ('reconciling','success','failed')
                  AND result_message_status IS DISTINCT FROM status
                ORDER BY updated_at,id
                LIMIT $1
                """,
                max(1, min(100, int(limit))),
            )
        return [self._job(r) for r in rows]

    async def mark_result_message_synced(self, job_id: UUID, status: str) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_jobs
                    SET result_message_status=$2,updated_at=NOW()
                    WHERE id=$1
                    RETURNING id
                    """,
                    job_id, status,
                )
                if row:
                    await self.add_event(conn, job_id, "result_message_synced", {"status": status})

    async def pause_user_result_notifications(self, job_id: UUID) -> None:
        """Pause delayed user fallback notices after the original message was edited."""
        pool = self.db.require_pool()
        keys = [
            f"ichancy-job-user-review:{job_id}",
            f"ichancy-job-user-success:{job_id}",
            f"ichancy-job-user-failed:{job_id}",
        ]
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.notification_outbox
                SET status='paused', locked_at=NULL, last_error='inline result delivered'
                WHERE event_key = ANY($1::text[]) AND status='pending'
                """,
                keys,
            )

    async def add_event(self, conn: asyncpg.Connection, job_id: UUID, event_type: str, details: Mapping[str, Any]) -> None:
        await conn.execute(
            "INSERT INTO bot_core.ichancy_job_events(job_id,event_type,details) VALUES($1,$2,$3::jsonb)",
            job_id, event_type, json.dumps(dict(details), ensure_ascii=False, separators=(",", ":"), default=str),
        )

    @staticmethod
    def _job(row: asyncpg.Record) -> IchancyJob:
        return IchancyJob(
            id=row["id"], telegram_id=int(row["telegram_id"]), account_id=row["account_id"], cashier_id=row["cashier_id"],
            operation_type=str(row["operation_type"]), source=str(row["source"]), amount=int(row["amount"]), status=str(row["status"]),
            idempotency_key=str(row["idempotency_key"]), provider_reference=str(row["provider_reference"]) if row["provider_reference"] else None,
            wallet_hold_id=row["wallet_hold_id"], wallet_operation_id=row["wallet_operation_id"],
            player_balance_before=int(row["player_balance_before"]) if row["player_balance_before"] is not None else None,
            player_balance_after=int(row["player_balance_after"]) if row["player_balance_after"] is not None else None,
            cashier_balance_before=int(row["cashier_balance_before"]) if row["cashier_balance_before"] is not None else None,
            cashier_balance_after=int(row["cashier_balance_after"]) if row["cashier_balance_after"] is not None else None,
            attempt_count=int(row["attempt_count"]), reconcile_attempt_count=int(row["reconcile_attempt_count"] or 0),
            last_error=str(row["last_error"]) if row["last_error"] else None,
            created_at=row["created_at"], claimed_at=row["claimed_at"], financial_post_started_at=row["financial_post_started_at"],
            remote_success_at=row["remote_success_at"], reconcile_started_at=row["reconcile_started_at"],
            reconcile_next_at=row["reconcile_next_at"], finished_at=row["finished_at"],
            result_chat_id=int(row["result_chat_id"]) if row["result_chat_id"] is not None else None,
            result_message_id=int(row["result_message_id"]) if row["result_message_id"] is not None else None,
            result_message_status=str(row["result_message_status"]) if row["result_message_status"] else None,
        )
