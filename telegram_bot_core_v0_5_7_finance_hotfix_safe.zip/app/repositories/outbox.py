from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from uuid import UUID, uuid4

import asyncpg

from app.core.db import Database


@dataclass(frozen=True, slots=True)
class OutboxItem:
    id: UUID
    event_key: str
    target_key: str | None
    target_chat_id: int | None
    text: str
    parse_mode: str
    attempts: int
    created_at: datetime


class OutboxRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def enqueue(
        self,
        *,
        event_key: str,
        target_key: str | None = None,
        target_chat_id: int | None = None,
        text: str = "",
        parse_mode: str = "HTML",
        conn: asyncpg.Connection | None = None,
    ) -> UUID | None:
        async def _do(c: asyncpg.Connection) -> UUID | None:
            row = await c.fetchrow(
                """
                INSERT INTO bot_core.notification_outbox(id,event_key,target_key,target_chat_id,text,parse_mode)
                VALUES($1,$2,$3,$4,$5,$6)
                ON CONFLICT(event_key) DO NOTHING
                RETURNING id
                """,
                uuid4(), event_key, target_key, target_chat_id, text, parse_mode,
            )
            return row["id"] if row else None

        if conn is not None:
            return await _do(conn)
        pool = self.db.require_pool()
        async with pool.acquire() as c:
            return await _do(c)

    async def claim_next(self) -> OutboxItem | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    WITH candidate AS (
                        SELECT id
                        FROM bot_core.notification_outbox
                        WHERE (
                            (status='pending' AND next_attempt_at <= NOW())
                            OR (status='sending' AND locked_at < NOW() - INTERVAL '2 minutes')
                        )
                        ORDER BY created_at,id
                        FOR UPDATE SKIP LOCKED
                        LIMIT 1
                    )
                    UPDATE bot_core.notification_outbox o
                    SET status='sending', locked_at=NOW(), attempts=attempts+1
                    FROM candidate c
                    WHERE o.id=c.id
                    RETURNING o.*
                    """
                )
        if not row:
            return None
        return OutboxItem(
            id=row["id"], event_key=str(row["event_key"]), target_key=(str(row["target_key"]) if row["target_key"] else None),
            target_chat_id=(int(row["target_chat_id"]) if row["target_chat_id"] is not None else None), text=str(row["text"]), parse_mode=str(row["parse_mode"]), attempts=int(row["attempts"]),
            created_at=row["created_at"],
        )

    async def mark_sent(self, item_id: UUID, telegram_message_id: int) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.notification_outbox
                SET status='sent', sent_at=NOW(), telegram_message_id=$2, locked_at=NULL, last_error=NULL
                WHERE id=$1 AND status='sending'
                """,
                item_id, telegram_message_id,
            )

    async def retry(self, item_id: UUID, error: str, delay_seconds: int) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.notification_outbox
                SET status='pending', locked_at=NULL, last_error=$2,
                    next_attempt_at=NOW() + ($3::text || ' seconds')::interval
                WHERE id=$1
                """,
                item_id, error[:1200], max(1, int(delay_seconds)),
            )

    async def pending_count(self) -> int:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return int(await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.notification_outbox WHERE status IN ('pending','sending')"
            ) or 0)
