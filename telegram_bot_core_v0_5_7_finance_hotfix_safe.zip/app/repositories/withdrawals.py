from __future__ import annotations

import json
from decimal import Decimal
from typing import Any, Mapping
from uuid import UUID, uuid4

import asyncpg

from app.core.db import Database
from app.core.withdrawals import WithdrawNotFound, WithdrawRecord, WithdrawStateError


class WithdrawRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def create(
        self,
        *,
        telegram_id: int,
        method: str,
        amount_wallet: int,
        fee_pct: Decimal,
        fee_wallet: int,
        net_wallet: int,
        payout_amount: Decimal,
        payout_currency: str,
        exchange_rate: Decimal | None,
        receiver: str,
        receiver_name: str | None,
        network: str | None,
        wallet_hold_id: UUID,
        withdraw_id: UUID | None = None,
    ) -> WithdrawRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                return await self.create_in_transaction(
                    conn, telegram_id=telegram_id, method=method, amount_wallet=amount_wallet,
                    fee_pct=fee_pct, fee_wallet=fee_wallet, net_wallet=net_wallet,
                    payout_amount=payout_amount, payout_currency=payout_currency, exchange_rate=exchange_rate,
                    receiver=receiver, receiver_name=receiver_name, network=network,
                    wallet_hold_id=wallet_hold_id, withdraw_id=withdraw_id,
                )

    async def create_in_transaction(
        self,
        conn: asyncpg.Connection,
        *,
        telegram_id: int,
        method: str,
        amount_wallet: int,
        fee_pct: Decimal,
        fee_wallet: int,
        net_wallet: int,
        payout_amount: Decimal,
        payout_currency: str,
        exchange_rate: Decimal | None,
        receiver: str,
        receiver_name: str | None,
        network: str | None,
        wallet_hold_id: UUID,
        withdraw_id: UUID | None = None,
    ) -> WithdrawRecord:
        row = await conn.fetchrow(
            """
            INSERT INTO bot_core.withdraw_requests(
                id,telegram_id,method,amount_wallet,fee_pct,fee_wallet,net_wallet,
                payout_amount,payout_currency,exchange_rate,receiver,receiver_name,network,
                status,wallet_hold_id
            ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'pending',$14)
            RETURNING *
            """,
            withdraw_id or uuid4(), telegram_id, method, amount_wallet, fee_pct, fee_wallet, net_wallet,
            payout_amount, payout_currency, exchange_rate, receiver, receiver_name, network, wallet_hold_id,
        )
        await self.add_event(conn, row["id"], "created", telegram_id, {"method": method})
        return self._record(row)

    async def get(self, withdraw_id: UUID) -> WithdrawRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM bot_core.withdraw_requests WHERE id=$1", withdraw_id)
        return self._record(row) if row else None

    async def active_for_user(self, telegram_id: int) -> WithdrawRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM bot_core.withdraw_requests
                WHERE telegram_id=$1 AND status IN ('pending','processing','provider_success','needs_review')
                ORDER BY created_at DESC LIMIT 1
                """,
                telegram_id,
            )
        return self._record(row) if row else None

    async def list_pending(self, limit: int = 50) -> list[WithdrawRecord]:
        await self.recover_stale_processing()
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.withdraw_requests
                WHERE status IN ('pending','processing','provider_success','needs_review')
                ORDER BY created_at,id LIMIT $1
                """,
                max(1, min(100, int(limit))),
            )
        return [self._record(r) for r in rows]

    async def list_by_status(self, status: str, limit: int = 50) -> list[WithdrawRecord]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.withdraw_requests
                WHERE status=$1
                ORDER BY updated_at DESC,id DESC LIMIT $2
                """,
                str(status), max(1, min(100, int(limit))),
            )
        return [self._record(r) for r in rows]

    async def list_recent_terminal(self, limit: int = 50) -> list[WithdrawRecord]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.withdraw_requests
                WHERE status IN ('success','rejected','cancelled')
                ORDER BY COALESCE(finished_at,updated_at) DESC,id DESC LIMIT $1
                """,
                max(1, min(100, int(limit))),
            )
        return [self._record(r) for r in rows]

    async def recover_stale_processing(self, older_than_seconds: int = 180) -> int:
        """Move interrupted in-flight provider calls to manual review.

        `provider_success` is intentionally excluded: once the provider has explicitly
        confirmed payment, local finalization is safe to retry without another POST.
        """
        seconds = max(30, min(3600, int(older_than_seconds)))
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE bot_core.withdraw_requests
                SET status='needs_review',
                    last_error=COALESCE(last_error,'execution interrupted; provider outcome requires review'),
                    updated_at=NOW()
                WHERE status='processing'
                  AND processing_at < NOW() - ($1::int * INTERVAL '1 second')
                """,
                seconds,
            )
        return int(result.split()[-1])

    async def claim_for_processing(self, withdraw_id: UUID, admin_id: int) -> WithdrawRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # An interrupted financial execution is never made pending again automatically.
                await conn.execute(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='needs_review',last_error=COALESCE(last_error,'execution interrupted; outcome requires review'),updated_at=NOW()
                    WHERE status='processing' AND processing_at < NOW() - INTERVAL '3 minutes'
                    """
                )
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='processing',processing_by=$2,processing_at=NOW(),updated_at=NOW(),last_error=NULL
                    WHERE id=$1 AND status='pending'
                    RETURNING *
                    """,
                    withdraw_id, admin_id,
                )
                if row is None:
                    current = await conn.fetchrow("SELECT * FROM bot_core.withdraw_requests WHERE id=$1 FOR UPDATE", withdraw_id)
                    if not current:
                        raise WithdrawNotFound(str(withdraw_id))
                    raise WithdrawStateError(str(current["status"]))
                await self.add_event(conn, withdraw_id, "processing", admin_id, {})
        return self._record(row)

    async def revert_pending(self, withdraw_id: UUID, admin_id: int, error: str) -> WithdrawRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='pending',processing_by=NULL,processing_at=NULL,last_error=$3,updated_at=NOW()
                    WHERE id=$1 AND status='processing' AND processing_by=$2
                    RETURNING *
                    """,
                    withdraw_id, admin_id, error[:1200],
                )
                if not row:
                    raise WithdrawStateError("processing claim no longer owned")
                await self.add_event(conn, withdraw_id, "execution_failed_definite", admin_id, {"error": error[:500]})
        return self._record(row)

    async def mark_needs_review(self, withdraw_id: UUID, admin_id: int, error: str, payload: Mapping[str, Any] | None = None) -> WithdrawRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='needs_review',last_error=$3,provider_payload=$4::jsonb,updated_at=NOW()
                    WHERE id=$1 AND status='processing' AND processing_by=$2
                    RETURNING *
                    """,
                    withdraw_id, admin_id, error[:1200],
                    json.dumps(dict(payload or {}), ensure_ascii=False, separators=(",", ":"), default=str),
                )
                if not row:
                    raise WithdrawStateError("processing claim no longer owned")
                await self.add_event(conn, withdraw_id, "needs_review", admin_id, {"error": error[:500]})
        return self._record(row)

    async def set_provider_success(self, withdraw_id: UUID, admin_id: int, *, source_ref: str | None, provider_reference: str | None, payload: Mapping[str, Any] | None) -> WithdrawRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='provider_success',source_ref=$3,provider_reference=$4,provider_payload=$5::jsonb,
                        last_error=NULL,updated_at=NOW()
                    WHERE id=$1 AND status='processing' AND processing_by=$2
                    RETURNING *
                    """,
                    withdraw_id, admin_id, source_ref, provider_reference,
                    json.dumps(dict(payload or {}), ensure_ascii=False, separators=(",", ":"), default=str),
                )
                if not row:
                    raise WithdrawStateError("processing claim no longer owned")
                await self.add_event(conn, withdraw_id, "provider_success", admin_id, {"provider_reference": provider_reference or ""})
        return self._record(row)

    async def finalize_success(
        self,
        conn: asyncpg.Connection,
        *,
        withdraw_id: UUID,
        admin_id: int,
        wallet_operation_id: UUID,
        notification_text: str,
        user_text: str,
    ) -> WithdrawRecord:
        row = await conn.fetchrow(
            """
            UPDATE bot_core.withdraw_requests
            SET status='success',wallet_operation_id=$3,reviewed_by=$2,finished_at=NOW(),updated_at=NOW(),last_error=NULL
            WHERE id=$1 AND status IN ('processing','provider_success','needs_review')
            RETURNING *
            """,
            withdraw_id, admin_id, wallet_operation_id,
        )
        if row is None:
            current = await conn.fetchrow("SELECT * FROM bot_core.withdraw_requests WHERE id=$1 FOR UPDATE", withdraw_id)
            if current and current["status"] == "success":
                return self._record(current)
            raise WithdrawStateError("withdraw cannot be finalized")
        await self.add_event(conn, withdraw_id, "success", admin_id, {"wallet_operation_id": str(wallet_operation_id)})
        await conn.execute(
            """
            INSERT INTO bot_core.notification_outbox(id,event_key,target_key,text,parse_mode)
            VALUES($1,$2,'notify.bot_withdrawals',$3,'HTML') ON CONFLICT(event_key) DO NOTHING
            """,
            uuid4(), f"bot-withdraw-success:{withdraw_id}", notification_text,
        )
        await conn.execute(
            """
            INSERT INTO bot_core.notification_outbox(id,event_key,target_chat_id,text,parse_mode)
            VALUES($1,$2,$3,$4,'HTML') ON CONFLICT(event_key) DO NOTHING
            """,
            uuid4(), f"bot-withdraw-user-success:{withdraw_id}", int(row["telegram_id"]), user_text,
        )
        return self._record(row)

    async def reject(self, withdraw_id: UUID, admin_id: int, error: str) -> WithdrawRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='rejected',reviewed_by=$2,last_error=$3,finished_at=NOW(),updated_at=NOW()
                    WHERE id=$1 AND status='pending'
                    RETURNING *
                    """,
                    withdraw_id, admin_id, error[:1200],
                )
                if not row:
                    current = await conn.fetchrow("SELECT * FROM bot_core.withdraw_requests WHERE id=$1", withdraw_id)
                    if not current:
                        raise WithdrawNotFound(str(withdraw_id))
                    raise WithdrawStateError(str(current["status"]))
                await self.add_event(conn, withdraw_id, "rejected", admin_id, {"error": error[:500]})
        return self._record(row)

    async def cancel(self, withdraw_id: UUID, telegram_id: int) -> WithdrawRecord:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='cancelled',last_error='cancelled by user',finished_at=NOW(),updated_at=NOW()
                    WHERE id=$1 AND telegram_id=$2 AND status='pending'
                    RETURNING *
                    """,
                    withdraw_id, telegram_id,
                )
                if not row:
                    raise WithdrawStateError("request is no longer cancellable")
                await self.add_event(conn, withdraw_id, "cancelled", telegram_id, {})
        return self._record(row)

    async def add_event(self, conn: asyncpg.Connection, withdraw_id: UUID, event_type: str, actor: int | None, details: Mapping[str, Any]) -> None:
        await conn.execute(
            "INSERT INTO bot_core.withdraw_events(withdraw_id,event_type,actor_telegram_id,details) VALUES($1,$2,$3,$4::jsonb)",
            withdraw_id, event_type, actor,
            json.dumps(dict(details), ensure_ascii=False, separators=(",", ":"), default=str),
        )

    @staticmethod
    def _record(row: asyncpg.Record) -> WithdrawRecord:
        return WithdrawRecord(
            id=row["id"], telegram_id=int(row["telegram_id"]), method=str(row["method"]), amount_wallet=int(row["amount_wallet"]),
            fee_pct=Decimal(row["fee_pct"]), fee_wallet=int(row["fee_wallet"]), net_wallet=int(row["net_wallet"]),
            payout_amount=Decimal(row["payout_amount"]), payout_currency=str(row["payout_currency"]),
            exchange_rate=Decimal(row["exchange_rate"]) if row["exchange_rate"] is not None else None,
            receiver=str(row["receiver"]), receiver_name=str(row["receiver_name"]) if row["receiver_name"] else None,
            network=str(row["network"]) if row["network"] else None, source_ref=str(row["source_ref"]) if row["source_ref"] else None,
            status=str(row["status"]), wallet_hold_id=row["wallet_hold_id"], wallet_operation_id=row["wallet_operation_id"],
            provider_reference=str(row["provider_reference"]) if row["provider_reference"] else None,
            last_error=str(row["last_error"]) if row["last_error"] else None,
            processing_by=int(row["processing_by"]) if row["processing_by"] else None,
            reviewed_by=int(row["reviewed_by"]) if row["reviewed_by"] else None,
            created_at=row["created_at"], updated_at=row["updated_at"], finished_at=row["finished_at"],
        )
