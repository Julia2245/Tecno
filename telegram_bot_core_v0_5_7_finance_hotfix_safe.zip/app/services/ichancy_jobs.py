from __future__ import annotations

import asyncio
import html
import logging
from typing import Any
from uuid import uuid4

from app.core.wallet import InsufficientFunds
from app.core.ichancy_reconciliation import reconciliation_confirmed
from app.keyboards.ichancy import back_to_ichancy
from app.providers.ichancy import (
    IchancyClient,
    IchancyDefiniteError,
    IchancyTemporaryError,
    IchancyTransferUncertain,
    extract_cashier_balance,
    extract_player_balance_value,
)
from app.repositories.ichancy import IchancyRepository
from app.repositories.ichancy_jobs import IchancyJob, IchancyJobRepository
from app.services.ichancy_accounts import IchancyAccountsService
from app.services.outbox import NotificationOutboxWorker
from app.services.runtime_settings import RuntimeSettingsService
from app.services.wallet import WalletService

logger = logging.getLogger(__name__)


class IchancyJobError(RuntimeError):
    pass



class IchancyJobService:
    def __init__(
        self,
        jobs: IchancyJobRepository,
        accounts: IchancyRepository,
        account_service: IchancyAccountsService,
        wallet: WalletService,
        runtime: RuntimeSettingsService,
        outbox_worker: NotificationOutboxWorker | None = None,
        bot: Any | None = None,
    ) -> None:
        self.jobs = jobs
        self.accounts = accounts
        self.account_service = account_service
        self.wallet = wallet
        self.runtime = runtime
        self.outbox_worker = outbox_worker
        self.bot = bot
        self._wake = asyncio.Event()
        self._stop = asyncio.Event()
        self._reconcile_delay_seconds = 8.0

    def wake(self) -> None:
        self._wake.set()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()

    async def create_deposit_job(
        self,
        telegram_id: int,
        amount: int | None,
        *,
        full_balance: bool = False,
    ) -> IchancyJob:
        account = await self.accounts.get_active_account(telegram_id)
        if account is None:
            raise IchancyJobError("لا يوجد حساب iChancy نشط")
        min_amount = max(1, self.runtime.get_int("ichancy.min_deposit", 20000))
        request_id = uuid4()
        source = "full_balance" if full_balance else "normal"
        pool = self.jobs.db.require_pool()
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    cashier = await conn.fetchrow(
                        "SELECT id,status FROM bot_core.ichancy_cashiers WHERE id=$1 FOR UPDATE",
                        account.cashier_id,
                    )
                    acc = await conn.fetchrow(
                        "SELECT id,status,cashier_id FROM bot_core.ichancy_accounts WHERE id=$1 FOR UPDATE",
                        account.id,
                    )
                    if not cashier or str(cashier["status"]) != "active" or not acc or str(acc["status"]) != "active":
                        raise IchancyJobError("نظام iChancy قيد التحديث حالياً. حاول لاحقاً.")
                    active = await conn.fetchval(
                        """
                        SELECT 1 FROM bot_core.ichancy_jobs
                        WHERE telegram_id=$1 AND status IN ('queued','executing','remote_success','reconciling')
                        LIMIT 1
                        """,
                        telegram_id,
                    )
                    if active:
                        raise IchancyJobError("لديك عملية iChancy قيد التنفيذ حالياً")
                    locked_balance = await self.wallet.get_balance_in_transaction(conn, telegram_id)
                    available = int(locked_balance.available)
                    chosen = available if full_balance else int(amount or 0)
                    if chosen < min_amount:
                        raise IchancyJobError(f"الحد الأدنى لشحن iChancy هو {min_amount:,}")
                    if chosen > available:
                        raise IchancyJobError("رصيد المحفظة غير كافٍ")
                    _, hold = await self.wallet.create_hold_in_transaction(
                        conn,
                        telegram_id,
                        chosen,
                        idempotency_key=f"ichancy-deposit-hold:{request_id}",
                        reason="ichancy_deposit_reserve",
                        actor_telegram_id=telegram_id,
                        metadata={"source": source, "job_request_id": str(request_id)},
                    )
                    job = await self.jobs.create_job_in_transaction(
                        conn,
                        telegram_id=telegram_id,
                        account_id=account.id,
                        cashier_id=account.cashier_id,
                        operation_type="deposit",
                        source=source,
                        amount=chosen,
                        idempotency_key=f"ichancy-deposit:{request_id}",
                        wallet_hold_id=hold.id,
                    )
        except InsufficientFunds as exc:
            raise IchancyJobError("رصيد المحفظة غير كافٍ") from exc
        except IchancyJobError:
            raise
        except Exception as exc:
            if "ux_ichancy_one_active_job_per_user" in str(exc):
                raise IchancyJobError("لديك عملية iChancy قيد التنفيذ حالياً") from exc
            raise
        self.wake()
        return job


    async def precheck_withdraw_balance(self, telegram_id: int, amount: int) -> int:
        """Read the live player balance before a user withdrawal job is created.

        This is only a UX/preflight check. `_execute` performs the authoritative
        second balance read immediately before the financial POST.
        """
        amount = int(amount)
        min_amount = max(1, self.runtime.get_int("ichancy.min_withdraw", 20000))
        if amount < min_amount:
            raise IchancyJobError(f"الحد الأدنى لسحب iChancy هو {min_amount:,}")
        if await self.jobs.active_for_user(telegram_id):
            raise IchancyJobError("لديك عملية iChancy قيد التنفيذ حالياً")
        account = await self.accounts.get_active_account(telegram_id)
        if account is None:
            raise IchancyJobError("لا يوجد حساب iChancy نشط")
        cashier = await self.accounts.get_cashier(account.cashier_id)
        if cashier is None or cashier.status != "active":
            raise IchancyJobError("نظام iChancy قيد التحديث حالياً. حاول لاحقاً.")
        client = self.account_service._client(cashier)
        try:
            payload = await client.get_player_balance(account.player_id)
            balance = extract_player_balance_value(payload)
        except IchancyDefiniteError as exc:
            raise IchancyJobError(str(exc)) from exc
        except Exception as exc:
            raise IchancyJobError("تعذر التحقق من رصيد حسابك على iChancy حالياً. حاول بعد قليل.") from exc
        if balance is None:
            raise IchancyJobError("تعذر التحقق من رصيد حسابك على iChancy حالياً. حاول بعد قليل.")
        live_balance = int(balance)
        if live_balance < amount:
            raise IchancyJobError(
                f"رصيد حسابك على iChancy غير كافٍ لإتمام عملية السحب. رصيدك المتاح: {live_balance:,}"
            )
        return live_balance

    async def create_withdraw_job(self, telegram_id: int, amount: int) -> IchancyJob:
        account = await self.accounts.get_active_account(telegram_id)
        if account is None:
            raise IchancyJobError("لا يوجد حساب iChancy نشط")
        min_amount = max(1, self.runtime.get_int("ichancy.min_withdraw", 20000))
        amount = int(amount)
        if amount < min_amount:
            raise IchancyJobError(f"الحد الأدنى لسحب iChancy هو {min_amount:,}")
        try:
            job = await self.jobs.create_job(
                telegram_id=telegram_id,
                account_id=account.id,
                cashier_id=account.cashier_id,
                operation_type="withdraw",
                source="normal",
                amount=amount,
                idempotency_key=f"ichancy-withdraw:{uuid4()}",
                wallet_hold_id=None,
            )
        except ValueError as exc:
            if str(exc) == "ICHANCY_ACCOUNT_NOT_ACTIVE":
                raise IchancyJobError("نظام iChancy قيد التحديث حالياً. حاول لاحقاً.") from exc
            raise
        except Exception as exc:
            if "ux_ichancy_one_active_job_per_user" in str(exc):
                raise IchancyJobError("لديك عملية iChancy قيد التنفيذ حالياً") from exc
            raise
        self.wake()
        return job

    async def attach_user_message(self, job_id, *, chat_id: int, message_id: int) -> None:
        await self.jobs.attach_result_message(job_id, chat_id=chat_id, message_id=message_id)
        self.wake()

    async def run_worker(self, poll_seconds: float = 2.0, reconcile_delay: float = 8.0) -> None:
        self._reconcile_delay_seconds = max(2.0, float(reconcile_delay))
        while not self._stop.is_set():
            did_work = False
            try:
                job = await self.jobs.claim_next()
                if job:
                    did_work = True
                    await self._execute(job)

                reconciling = await self.jobs.list_reconciling(limit=5)
                for item in reconciling:
                    if item.status == "remote_success":
                        did_work = True
                        await self._finish_remote_success(item)
                    elif item.status == "reconciling":
                        did_work = True
                        await self._reconcile(item)

                pending_messages = await self.jobs.list_pending_result_message_updates(limit=10)
                for item in pending_messages:
                    if await self._sync_user_message(item):
                        did_work = True
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("iChancy worker loop failed")

            if did_work:
                await asyncio.sleep(0)
                continue
            self._wake.clear()
            try:
                await asyncio.wait_for(self._wake.wait(), timeout=max(0.2, float(poll_seconds)))
            except asyncio.TimeoutError:
                pass

    async def wait_for_terminal(
        self,
        job_id,
        *,
        timeout_seconds: float = 10.0,
        poll_seconds: float = 0.25,
    ) -> IchancyJob | None:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + max(0.1, float(timeout_seconds))
        delay = max(0.05, float(poll_seconds))
        while loop.time() < deadline:
            current = await self.jobs.get(job_id)
            if current is None:
                return None
            if current.status in {"success", "failed"}:
                return current
            await asyncio.sleep(delay)
        current = await self.jobs.get(job_id)
        if current is not None and current.status in {"success", "failed"}:
            return current
        return None

    async def mark_inline_result_delivered(self, job_id) -> None:
        await self.jobs.pause_user_result_notifications(job_id)

    async def _client_for(self, job: IchancyJob) -> tuple[IchancyClient, object, object]:
        account = await self.accounts.get_active_account(job.telegram_id)
        if account is None or account.id != job.account_id:
            pool = self.accounts.db.require_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_accounts WHERE id=$1",
                    job.account_id,
                )
            if not row:
                raise IchancyDefiniteError("حساب iChancy المرتبط بالعملية غير موجود")
            account = self.accounts._account(row)
        cashier = await self.accounts.get_cashier(job.cashier_id)
        if cashier is None:
            raise IchancyDefiniteError("كاشيرة العملية غير موجودة")
        return self.account_service._client(cashier), account, cashier

    async def _read_balances(self, client: IchancyClient, player_id: str) -> tuple[int, int | None]:
        player_resp, cashier_resp = await asyncio.gather(
            client.get_player_balance(player_id),
            client.get_agent_all_wallets(),
        )
        player = extract_player_balance_value(player_resp)
        if player is None:
            raise IchancyTemporaryError("تعذر قراءة رصيد اللاعب")
        cashier = extract_cashier_balance(cashier_resp, client.credentials.currency)
        return int(player), cashier

    def _reconcile_delay(self) -> int:
        return max(2, int(round(self._reconcile_delay_seconds)))

    def _reconcile_max_attempts(self) -> int:
        return max(1, min(20, self.runtime.get_int("ichancy.reconcile_max_attempts", 5)))

    async def _execute(self, job: IchancyJob) -> None:
        post_started = False
        try:
            client, account, _ = await self._client_for(job)
            player_before, cashier_before = await self._read_balances(client, account.player_id)
            if job.operation_type in {"withdraw", "retirement_withdraw"} and player_before < job.amount:
                await self._definite_fail(job, "رصيد حساب iChancy غير كافٍ")
                return
            if job.operation_type == "deposit" and cashier_before is not None and cashier_before < job.amount:
                await self._definite_fail(job, "رصيد كاشيرة iChancy غير كافٍ")
                return

            job = await self.jobs.set_snapshots(
                job.id,
                player_before=player_before,
                cashier_before=cashier_before,
            )
            job = await self.jobs.mark_financial_post_started(job.id)
            post_started = True
            comment = job.provider_reference or f"bot:{job.id}"

            if job.operation_type == "deposit":
                payload = await client.deposit_to_player(account.player_id, job.amount, comment)
            else:
                payload = await client.withdraw_from_player(account.player_id, job.amount, comment)

            await self.jobs.mark_remote_success(
                job.id,
                {"provider_reference": comment, "response": payload},
            )
            latest = await self.jobs.get(job.id)
            if latest:
                await self._finish_remote_success(latest)
        except IchancyTemporaryError as exc:
            # This class is reserved for failures known to occur before a financial
            # business POST (auth/read/connect-before-send), so a bounded retry is safe.
            if int(job.attempt_count) >= 3:
                await self._definite_fail(job, f"تعذر التحقق من iChancy بعد عدة محاولات: {exc}")
            else:
                await self.jobs.requeue(job.id, str(exc))
        except IchancyDefiniteError as exc:
            await self._definite_fail(job, str(exc))
        except IchancyTransferUncertain as exc:
            current = await self.jobs.mark_reconciling(
                job.id,
                str(exc),
                delay_seconds=self._reconcile_delay(),
            )
            await self._sync_user_message(current)
            if self.outbox_worker:
                self.outbox_worker.wake()
        except Exception as exc:
            logger.exception("Unexpected iChancy job execution failure job=%s", job.id)
            if not post_started:
                await self._definite_fail(job, f"تعذر تجهيز عملية iChancy: {type(exc).__name__}")
                return
            current = await self.jobs.mark_reconciling(
                job.id,
                f"{type(exc).__name__}: {exc}",
                delay_seconds=self._reconcile_delay(),
            )
            await self._sync_user_message(current)
            if self.outbox_worker:
                self.outbox_worker.wake()

    async def _definite_fail(self, job: IchancyJob, error: str) -> None:
        pool = self.jobs.db.require_pool()
        failed: IchancyJob | None = None
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    current_row = await conn.fetchrow(
                        "SELECT * FROM bot_core.ichancy_jobs WHERE id=$1 FOR UPDATE",
                        job.id,
                    )
                    if not current_row:
                        return
                    current = self.jobs._job(current_row)
                    if current.status == "failed":
                        failed = current
                    elif current.status not in {"queued", "executing", "reconciling"}:
                        return
                    else:
                        if current.operation_type == "deposit" and current.wallet_hold_id:
                            await self.wallet.release_hold_in_transaction(
                                conn,
                                current.wallet_hold_id,
                                idempotency_key=f"ichancy-deposit-release:{current.id}",
                                reason="ichancy_deposit_failed",
                                actor_telegram_id=current.telegram_id,
                                metadata={"job_id": str(current.id), "error": error[:300]},
                            )
                        failed = await self.jobs.fail_in_transaction(conn, current.id, error)
        except Exception:
            logger.exception("Failed to atomically close definite iChancy failure job=%s", job.id)
            current = await self.jobs.mark_reconciling(
                job.id,
                f"provider failed but local close needs review: {error}",
                delay_seconds=self._reconcile_delay(),
            )
            await self._sync_user_message(current)
            if self.outbox_worker:
                self.outbox_worker.wake()
            return

        if failed:
            await self._sync_user_message(failed)
        if self.outbox_worker:
            self.outbox_worker.wake()

    async def _finish_remote_success(self, job: IchancyJob) -> None:
        if job.status not in {"remote_success", "reconciling"}:
            return
        client, account, _ = await self._client_for(job)
        player_after = cashier_after = None
        try:
            player_after, cashier_after = await self._read_balances(client, account.player_id)
        except Exception:
            pass
        await self._settle_local(
            job,
            account.username,
            account.player_id,
            player_after,
            cashier_after,
        )

    async def _settle_local(
        self,
        job: IchancyJob,
        username: str,
        player_id: str,
        player_after: int | None,
        cashier_after: int | None,
    ) -> None:
        pool = self.jobs.db.require_pool()
        done: IchancyJob | None = None
        async with pool.acquire() as conn:
            async with conn.transaction():
                current_row = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_jobs WHERE id=$1 FOR UPDATE",
                    job.id,
                )
                if not current_row:
                    raise IchancyJobError("job missing")
                current = self.jobs._job(current_row)
                if current.status == "success":
                    done = current
                else:
                    if current.status not in {"remote_success", "reconciling"}:
                        raise IchancyJobError(f"cannot settle job in {current.status}")
                    if current.operation_type == "deposit":
                        if not current.wallet_hold_id:
                            raise IchancyJobError("deposit hold missing")
                        mutation, _ = await self.wallet.capture_hold_in_transaction(
                            conn,
                            current.wallet_hold_id,
                            idempotency_key=f"ichancy-deposit-capture:{current.id}",
                            reason="ichancy_deposit_success",
                            actor_telegram_id=current.telegram_id,
                            metadata={"job_id": str(current.id), "player_id": player_id},
                        )
                        balance_after = mutation.balance_after.available
                    else:
                        mutation = await self.wallet.credit_in_transaction(
                            conn,
                            current.telegram_id,
                            current.amount,
                            idempotency_key=f"ichancy-withdraw-credit:{current.id}",
                            reason=(
                                "ichancy_withdraw_success"
                                if current.operation_type == "withdraw"
                                else "ichancy_retirement_withdraw_success"
                            ),
                            actor_telegram_id=current.telegram_id,
                            metadata={"job_id": str(current.id), "player_id": player_id},
                        )
                        balance_after = mutation.balance_after.available
                    text = self._notification_text(
                        current,
                        username,
                        player_id,
                        balance_after,
                        player_after,
                        cashier_after,
                    )
                    done = await self.jobs.finalize_success(
                        conn,
                        job_id=current.id,
                        wallet_operation_id=mutation.operation_id,
                        player_after=player_after,
                        cashier_after=cashier_after,
                        notification_text=text,
                    )
        if done:
            await self._sync_user_message(done)
        if self.outbox_worker:
            self.outbox_worker.wake()

    async def _reconcile(self, job: IchancyJob) -> None:
        await self._sync_user_message(job)
        if job.player_balance_before is None:
            # Current and previous safe versions always store snapshots before a
            # financial POST. No snapshot therefore means no transfer was sent.
            await self._definite_fail(job, "لم يبدأ التحويل المالي وتم إلغاء العملية بأمان")
            return

        player_after: int | None = None
        cashier_after: int | None = None
        try:
            client, account, _ = await self._client_for(job)
            player_after, cashier_after = await self._read_balances(client, account.player_id)
        except Exception as exc:
            current = await self.jobs.record_reconcile_attempt(
                job.id,
                error=f"تعذر قراءة أرصدة المطابقة: {type(exc).__name__}: {exc}",
                player_after=None,
                cashier_after=None,
                delay_seconds=self._reconcile_delay(),
                max_attempts=self._reconcile_max_attempts(),
            )
            if current.reconcile_next_at is None and self.outbox_worker:
                self.outbox_worker.wake()
            return

        if job.cashier_balance_before is None or cashier_after is None:
            current = await self.jobs.record_reconcile_attempt(
                job.id,
                error="تعذر إثبات النتيجة لأن لقطة رصيد الكاشيرة غير مكتملة",
                player_after=player_after,
                cashier_after=cashier_after,
                delay_seconds=self._reconcile_delay(),
                max_attempts=self._reconcile_max_attempts(),
            )
            if current.reconcile_next_at is None and self.outbox_worker:
                self.outbox_worker.wake()
            return

        confirmed = reconciliation_confirmed(
            job.operation_type,
            amount=job.amount,
            player_before=int(job.player_balance_before),
            player_after=int(player_after),
            cashier_before=int(job.cashier_balance_before),
            cashier_after=int(cashier_after),
        )
        if confirmed:
            await self.jobs.mark_remote_success(
                job.id,
                {
                    "reconciled": True,
                    "provider_reference": job.provider_reference,
                    "player_after": player_after,
                    "cashier_after": cashier_after,
                },
            )
            latest = await self.jobs.get(job.id)
            if latest:
                await self._settle_local(
                    latest,
                    account.username,
                    account.player_id,
                    player_after,
                    cashier_after,
                )
            return

        current = await self.jobs.record_reconcile_attempt(
            job.id,
            error="لم تتطابق فروقات رصيد اللاعب والكاشيرة مع مبلغ العملية حتى الآن",
            player_after=player_after,
            cashier_after=cashier_after,
            delay_seconds=self._reconcile_delay(),
            max_attempts=self._reconcile_max_attempts(),
        )
        if current.reconcile_next_at is None and self.outbox_worker:
            self.outbox_worker.wake()

    async def confirm_review_done(self, job_id, admin_id: int) -> IchancyJob:
        job = await self.jobs.get(job_id)
        if job is None:
            raise IchancyJobError("عملية iChancy غير موجودة")
        if job.status == "success":
            return job
        if job.status != "reconciling":
            raise IchancyJobError(f"العملية ليست بحالة مراجعة: {job.status}")
        client, account, _ = await self._client_for(job)
        player_after = cashier_after = None
        try:
            player_after, cashier_after = await self._read_balances(client, account.player_id)
        except Exception:
            pass
        await self.jobs.mark_remote_success(
            job.id,
            {
                "manual_admin_confirmation": True,
                "admin_id": int(admin_id),
                "provider_reference": job.provider_reference,
            },
        )
        latest = await self.jobs.get(job.id)
        if latest is None:
            raise IchancyJobError("تعذر إعادة تحميل العملية")
        await self._settle_local(
            latest,
            account.username,
            account.player_id,
            player_after,
            cashier_after,
        )
        done = await self.jobs.get(job.id)
        if done is None:
            raise IchancyJobError("تعذر تثبيت العملية محلياً")
        return done

    async def confirm_review_not_done(self, job_id, admin_id: int) -> IchancyJob:
        pool = self.jobs.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT * FROM bot_core.ichancy_jobs WHERE id=$1 FOR UPDATE",
                    job_id,
                )
                if row is None:
                    raise IchancyJobError("عملية iChancy غير موجودة")
                job = self.jobs._job(row)
                if job.status == "failed":
                    failed = job
                else:
                    if job.status != "reconciling":
                        raise IchancyJobError(f"العملية ليست بحالة مراجعة: {job.status}")
                    if job.operation_type == "deposit" and job.wallet_hold_id:
                        await self.wallet.release_hold_in_transaction(
                            conn,
                            job.wallet_hold_id,
                            idempotency_key=f"ichancy-deposit-review-release:{job.id}",
                            reason="ichancy_deposit_confirmed_not_executed",
                            actor_telegram_id=admin_id,
                            metadata={"job_id": str(job.id), "admin_id": int(admin_id)},
                        )
                    failed = await self.jobs.fail_in_transaction(
                        conn,
                        job.id,
                        f"confirmed not executed by admin {int(admin_id)}",
                    )
        await self._sync_user_message(failed)
        if self.outbox_worker:
            self.outbox_worker.wake()
        return failed

    async def _sync_user_message(self, job: IchancyJob) -> bool:
        if self.bot is None or job.result_chat_id is None or job.result_message_id is None:
            return False
        if job.result_message_status == job.status:
            return False
        if job.operation_type == "retirement_withdraw":
            return False

        if job.status == "reconciling":
            if job.operation_type == "deposit":
                text = "⏳ <b>جاري التأكد من نتيجة الشحن...</b>\n\nلا تعِد المحاولة حالياً."
            else:
                text = "⏳ <b>جاري التأكد من نتيجة السحب...</b>\n\nلا تعِد المحاولة حالياً."
        elif job.status == "success":
            text = (
                "✅ <b>تم شحن حسابك بنجاح.</b>"
                if job.operation_type == "deposit"
                else "✅ <b>تم سحب رصيد حسابك بنجاح.</b>"
            )
        elif job.status == "failed":
            if job.operation_type == "deposit":
                text = "❌ <b>تعذر شحن حسابك حالياً.</b>\n\nتمت إعادة المبلغ المحجوز إلى محفظتك."
            elif "رصيد حساب iChancy غير كاف" in str(job.last_error or ""):
                text = "❌ <b>رصيد حسابك على iChancy غير كافٍ لإتمام عملية السحب.</b>"
            else:
                text = "❌ <b>تعذر سحب رصيد حسابك حالياً.</b>\n\nلم يتم تنفيذ التحويل."
        else:
            return False

        try:
            await self.bot.edit_message_text(
                chat_id=job.result_chat_id,
                message_id=job.result_message_id,
                text=text,
                reply_markup=back_to_ichancy(),
                parse_mode="HTML",
            )
        except Exception as exc:
            logger.warning(
                "Could not sync iChancy user message job=%s status=%s: %s",
                job.id,
                job.status,
                exc,
            )
            return False

        await self.jobs.mark_result_message_synced(job.id, job.status)
        await self.jobs.pause_user_result_notifications(job.id)
        return True

    def _notification_text(
        self,
        job: IchancyJob,
        username: str,
        player_id: str,
        wallet_balance_after: int,
        player_after: int | None,
        cashier_after: int | None,
    ) -> str:
        if job.operation_type == "deposit":
            title = "💳 <b>شحن iChancy ناجح</b>"
            threshold = self.runtime.get_int("alerts.ichancy_deposit_large", 0)
        else:
            title = "💸 <b>سحب iChancy ناجح</b>"
            threshold = self.runtime.get_int("alerts.ichancy_withdraw_large", 0)
        if threshold > 0 and job.amount >= threshold:
            title = title.replace("</b>", " — 🚨 مبلغ كبير</b>")
        before_p = "غير متاح" if job.player_balance_before is None else f"{job.player_balance_before:,}"
        after_p = "غير متاح" if player_after is None else f"{player_after:,}"
        before_c = "غير متاح" if job.cashier_balance_before is None else f"{job.cashier_balance_before:,}"
        after_c = "غير متاح" if cashier_after is None else f"{cashier_after:,}"
        reference = html.escape(job.provider_reference or f"bot:{job.id}")
        return (
            f"{title}\n\n"
            f"🆔 Telegram ID: <code>{job.telegram_id}</code>\n"
            f"🎰 الحساب: <code>{html.escape(username)}</code>\n"
            f"🎮 Player ID: <code>{html.escape(player_id)}</code>\n"
            f"💰 المبلغ: <code>{job.amount:,}</code>\n"
            f"🧾 رقم العملية: <code>{job.id}</code>\n"
            f"🔖 مرجع iChancy: <code>{reference}</code>\n\n"
            f"🎮 رصيد اللاعب: <code>{before_p}</code> → <code>{after_p}</code>\n"
            f"🏦 رصيد الكاشيرة: <code>{before_c}</code> → <code>{after_c}</code>\n"
            f"💼 محفظة البوت بعد العملية: <code>{wallet_balance_after:,}</code>"
        )
