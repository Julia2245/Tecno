from __future__ import annotations

import asyncio
import html
import logging
import time
from uuid import UUID

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest

from app.keyboards.admin_ichancy import replacement_menu
from app.providers.ichancy import extract_player_balance_value
from app.repositories.ichancy import IchancyRepository
from app.repositories.ichancy_jobs import IchancyJobRepository
from app.repositories.ichancy_replacements import CashierReplacementRepository, ReplacementRecord, RetirementRecord
from app.repositories.outbox import OutboxRepository
from app.services.ichancy_accounts import IchancyAccountsService
from app.services.ichancy_jobs import IchancyJobService
from app.services.outbox import NotificationOutboxWorker
from app.services.runtime_settings import RuntimeSettingsService
from app.services.wallet import WalletService

logger = logging.getLogger(__name__)


class CashierReplacementError(RuntimeError):
    pass


class CashierReplacementService:
    def __init__(
        self,
        repository: CashierReplacementRepository,
        accounts: IchancyRepository,
        account_service: IchancyAccountsService,
        jobs_repository: IchancyJobRepository,
        jobs_service: IchancyJobService,
        wallet: WalletService,
        runtime: RuntimeSettingsService,
        outbox_repository: OutboxRepository,
        outbox_worker: NotificationOutboxWorker | None,
        bot: Bot,
    ) -> None:
        self.repository = repository
        self.accounts = accounts
        self.account_service = account_service
        self.jobs_repository = jobs_repository
        self.jobs_service = jobs_service
        self.wallet = wallet
        self.runtime = runtime
        self.outbox_repository = outbox_repository
        self.outbox_worker = outbox_worker
        self.bot = bot
        self._stop = asyncio.Event()
        self._wake = asyncio.Event()
        self._last_progress_edit = 0.0

    def stop(self) -> None:
        self._stop.set(); self._wake.set()

    def wake(self) -> None:
        self._wake.set()

    async def start(
        self,
        *,
        new_cashier_id: UUID,
        admin_id: int,
        progress_chat_id: int | None,
        progress_message_id: int | None,
    ) -> ReplacementRecord:
        minimum = max(1, self.runtime.get_int("ichancy.min_withdraw", 20000))
        try:
            rec = await self.repository.create(
                new_cashier_id=new_cashier_id,
                min_withdraw=minimum,
                created_by=admin_id,
                progress_chat_id=progress_chat_id,
                progress_message_id=progress_message_id,
            )
        except ValueError as exc:
            mapping = {
                "NO_ACTIVE_ICHANCY_CASHIER": "لا توجد كاشيرة iChancy نشطة لاستبدالها.",
                "NEW_CASHIER_NOT_STAGED": "الكاشيرة الجديدة ليست بحالة جاهزة للاستبدال.",
                "NEW_CASHIER_NOT_TESTED": "يجب اختبار الكاشيرة الجديدة بنجاح أولاً.",
                "ACTIVE_ICHANCY_JOBS": "يوجد عمليات iChancy مالية قيد التنفيذ. انتظر حتى تُحسم قبل الاستبدال.",
                "ACTIVE_ICHANCY_ACCOUNT_CREATIONS": "يوجد إنشاء حساب iChancy قيد التنفيذ على الكاشيرة الحالية. انتظر حتى يكتمل أولاً.",
            }
            raise CashierReplacementError(mapping.get(str(exc), str(exc))) from exc
        self.wake()
        await self.update_progress(rec, force=True)
        return rec

    async def run_worker(self, poll_seconds: float = 1.0) -> None:
        while not self._stop.is_set():
            did_work = False
            try:
                replacement = await self.repository.get_open()
                if replacement:
                    did_work = await self._process(replacement)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Cashier replacement worker failed")
            if did_work:
                await asyncio.sleep(0)
                continue
            self._wake.clear()
            try:
                await asyncio.wait_for(self._wake.wait(), timeout=poll_seconds)
            except asyncio.TimeoutError:
                pass

    async def _process(self, replacement: ReplacementRecord) -> bool:
        did_work = False
        await self.repository.sync_jobs(replacement.id)

        record = await self.repository.claim_needs_check(replacement.id)
        if record:
            did_work = True
            await self._check_one(replacement, record)

        # Queue already-classified withdrawable balances. Stable idempotency keys
        # make this safe after worker restart.
        for item in await self.repository.list_withdrawable_unqueued(replacement.id, limit=10):
            did_work = True
            try:
                job = await self.jobs_repository.create_job(
                    telegram_id=item.telegram_id,
                    account_id=item.account_id,
                    cashier_id=replacement.old_cashier_id,
                    operation_type="retirement_withdraw",
                    source=f"cashier_replacement:{replacement.id}",
                    amount=int(item.balance_snapshot or 0),
                    idempotency_key=f"cashier-replacement-withdraw:{replacement.id}:{item.account_id}:attempt:{item.settlement_attempt}",
                    wallet_hold_id=None,
                )
                await self.repository.link_settlement_job(item.id, job.id)
                self.jobs_service.wake()
            except Exception as exc:
                logger.exception("Could not queue retirement settlement record=%s", item.id)
                # Keep it discoverable for retry; do not pretend the money was settled.
                await self._mark_review_direct(item.id, f"queue settlement failed: {type(exc).__name__}: {exc}")

        await self.repository.sync_jobs(replacement.id)
        refreshed = await self.repository.refresh_stats(replacement.id)
        await self.update_progress(refreshed, force=refreshed.status in {"ready", "blocked"})
        return did_work

    async def _check_one(self, replacement: ReplacementRecord, record: RetirementRecord) -> None:
        try:
            account = await self.accounts.get_account(record.account_id)
            cashier = await self.accounts.get_cashier(replacement.old_cashier_id)
            if account is None or cashier is None:
                raise RuntimeError("الحساب أو الكاشيرة القديمة غير موجودة")
            response = await self.account_service._client(cashier).get_player_balance(account.player_id)
            balance = extract_player_balance_value(response)
            if balance is None or balance < 0:
                raise RuntimeError("تعذر قراءة رصيد صالح")
            if balance == 0:
                classification = "zero"
            elif balance < replacement.min_withdraw_snapshot:
                classification = "below_minimum"
            else:
                classification = "withdrawable"
            await self.repository.mark_check(record.id, classification=classification, balance=int(balance))
        except Exception as exc:
            await self.repository.mark_check(
                record.id, classification="check_failed", balance=None,
                error=f"{type(exc).__name__}: {exc}",
            )

    async def _mark_review_direct(self, record_id: UUID, error: str) -> None:
        pool = self.repository.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE bot_core.ichancy_retirement_records
                SET classification='review',check_error=$2 WHERE id=$1
                """,
                record_id, error[:1200],
            )

    async def retry_failed(self, replacement_id: UUID) -> ReplacementRecord:
        await self.repository.retry_failed_checks(replacement_id)
        rec = await self.repository.refresh_stats(replacement_id)
        self.wake()
        await self.update_progress(rec, force=True)
        return rec

    async def finalize(self, replacement_id: UUID, admin_id: int) -> ReplacementRecord:
        rec = await self.repository.refresh_stats(replacement_id)
        if rec.status != "ready":
            raise CashierReplacementError("الاستبدال غير جاهز للاعتماد النهائي بعد.")
        try:
            done = await self.repository.finalize(replacement_id, admin_id)
        except ValueError as exc:
            raise CashierReplacementError(str(exc)) from exc
        await self.update_progress(done, force=True)
        return done

    async def compensate(self, record_id: UUID, admin_id: int) -> RetirementRecord:
        pool = self.repository.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    SELECT r.*,x.status AS replacement_status
                    FROM bot_core.ichancy_retirement_records r
                    JOIN bot_core.ichancy_cashier_replacements x ON x.id=r.replacement_id
                    WHERE r.id=$1 FOR UPDATE OF r
                    """,
                    record_id,
                )
                if not row:
                    raise CashierReplacementError("السجل القديم غير موجود.")
                if str(row["replacement_status"]) != "completed":
                    raise CashierReplacementError("لا يمكن التعويض قبل اكتمال استبدال الكاشيرة.")
                if str(row["classification"]) not in {"below_minimum", "residual_below_minimum"}:
                    raise CashierReplacementError("هذا السجل لا يحتوي رصيداً متبقياً أقل من حد السحب.")
                amount = int(row["final_balance_snapshot"] if row["final_balance_snapshot"] is not None else (row["balance_snapshot"] or 0))
                if amount <= 0:
                    raise CashierReplacementError("لا يوجد رصيد صالح للتعويض.")
                if row["compensation_wallet_operation_id"] is not None:
                    return self.repository._retirement(row)
                mutation = await self.wallet.credit_in_transaction(
                    conn, int(row["telegram_id"]), amount,
                    idempotency_key=f"ichancy-retired-compensation:{record_id}",
                    reason="ichancy_retired_account_compensation",
                    actor_telegram_id=admin_id,
                    metadata={"retirement_record_id": str(record_id), "replacement_id": str(row["replacement_id"])},
                )
                updated = await conn.fetchrow(
                    """
                    UPDATE bot_core.ichancy_retirement_records
                    SET compensated_amount=$2,compensation_wallet_operation_id=$3,settled_at=COALESCE(settled_at,NOW())
                    WHERE id=$1 RETURNING *
                    """,
                    record_id, amount, mutation.operation_id,
                )
                await conn.execute(
                    """
                    UPDATE bot_core.ichancy_accounts
                    SET compensated_amount=$2,compensation_wallet_operation_id=$3,settlement_status='manual_compensated'
                    WHERE id=$1
                    """,
                    row["account_id"], amount, mutation.operation_id,
                )
                await self.outbox_repository.enqueue(
                    event_key=f"ichancy-retired-compensation-user:{record_id}",
                    target_chat_id=int(row["telegram_id"]),
                    text=(
                        "✅ <b>تمت إعادة رصيد من حساب iChancy قديم إلى محفظتك</b>\n\n"
                        f"💰 المبلغ: <code>{amount:,}</code>\n"
                        f"🎰 الحساب القديم: <code>{html.escape(str(row['username']))}</code>"
                    ),
                    conn=conn,
                )
        if self.outbox_worker:
            self.outbox_worker.wake()
        return self.repository._retirement(updated)

    def progress_text(self, rec: ReplacementRecord) -> str:
        if rec.status == "completed":
            title = "✅ <b>اكتمل استبدال كاشيرة iChancy</b>"
        elif rec.status == "ready":
            title = "✅ <b>الفحص والتصفية اكتملتا — جاهز للاعتماد</b>"
        elif rec.status == "blocked":
            title = "⚠️ <b>استبدال الكاشيرة يحتاج مراجعة</b>"
        elif rec.status == "settling":
            title = "💰 <b>جاري تصفية الحسابات المؤهلة...</b>"
        else:
            title = "🔄 <b>جاري فحص حسابات الكاشيرة القديمة...</b>"
        return (
            f"{title}\n\n"
            f"👥 الحسابات: <code>{rec.checked_accounts:,}/{rec.total_accounts:,}</code>\n"
            f"✅ رصيد صفر: <code>{rec.zero_accounts:,}</code>\n"
            f"🟡 أقل من الحد ({rec.min_withdraw_snapshot:,}): <code>{rec.below_minimum_accounts:,}</code>\n"
            f"🟢 حققت حد السحب: <code>{rec.withdrawable_accounts:,}</code>\n"
            f"💳 تمت التصفية للمحافظ: <code>{rec.settled_accounts:,}</code>\n"
            f"⚠️ فشل الفحص: <code>{rec.failed_checks:,}</code>\n"
            f"🛑 تحتاج مراجعة: <code>{rec.review_accounts:,}</code>\n\n"
            f"💰 مجموع الأرصدة المرصودة: <code>{rec.total_balance_snapshot:,}</code>\n"
            f"📤 المسحوب من iChancy: <code>{rec.total_withdrawn:,}</code>\n"
            f"💼 المضاف للمحافظ: <code>{rec.total_wallet_credited:,}</code>\n\n"
            "لن يتم حذف أي حساب قديم؛ السجلات تبقى محفوظة للبحث والتعويض اليدوي عند الحاجة."
        )

    async def update_progress(self, rec: ReplacementRecord, *, force: bool = False) -> None:
        if not rec.progress_chat_id or not rec.progress_message_id:
            return
        now = time.monotonic()
        if not force and now - self._last_progress_edit < 1.5:
            return
        self._last_progress_edit = now
        try:
            await self.bot.edit_message_text(
                chat_id=rec.progress_chat_id,
                message_id=rec.progress_message_id,
                text=self.progress_text(rec),
                reply_markup=replacement_menu(rec.id, rec.status),
                parse_mode="HTML",
            )
            await self.repository.touch_progress_edit(rec.id)
        except TelegramBadRequest as exc:
            if "message is not modified" not in str(exc).lower():
                logger.warning("Could not update replacement progress message", exc_info=True)
        except Exception:
            logger.warning("Could not update replacement progress message", exc_info=True)
