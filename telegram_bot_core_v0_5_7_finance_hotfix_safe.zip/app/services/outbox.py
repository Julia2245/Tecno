from __future__ import annotations

import asyncio
import logging

from aiogram import Bot
from aiogram.exceptions import TelegramRetryAfter

from app.repositories.outbox import OutboxRepository
from app.services.runtime_settings import RuntimeSettingsService

logger = logging.getLogger(__name__)


class NotificationOutboxWorker:
    def __init__(self, repository: OutboxRepository, runtime: RuntimeSettingsService, bot: Bot) -> None:
        self.repository = repository
        self.runtime = runtime
        self.bot = bot
        self._stop = asyncio.Event()
        self._wake = asyncio.Event()

    def wake(self) -> None:
        self._wake.set()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()

    async def run(self) -> None:
        while not self._stop.is_set():
            item = await self.repository.claim_next()
            if item is None:
                self._wake.clear()
                try:
                    await asyncio.wait_for(self._wake.wait(), timeout=5)
                except asyncio.TimeoutError:
                    pass
                continue

            target = item.target_chat_id if item.target_chat_id is not None else self.runtime.get(str(item.target_key or ""))
            if target in (None, "", 0, "0"):
                await self.repository.retry(item.id, f"notification target {item.target_key} is not configured", 60)
                continue
            try:
                chat_id = int(str(target).strip()) if str(target).lstrip("-").isdigit() else str(target).strip()
                msg = await self.bot.send_message(
                    chat_id=chat_id,
                    text=item.text,
                    parse_mode=None if item.parse_mode == "plain" else item.parse_mode,
                )
                await self.repository.mark_sent(item.id, int(msg.message_id))
            except TelegramRetryAfter as exc:
                await self.repository.retry(item.id, f"Telegram 429: {exc}", int(exc.retry_after) + 1)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                delay = min(900, max(5, 2 ** min(item.attempts, 9)))
                logger.warning("Outbox send failed event=%s attempt=%s", item.event_key, item.attempts, exc_info=True)
                await self.repository.retry(item.id, f"{type(exc).__name__}: {exc}", delay)
