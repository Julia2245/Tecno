from __future__ import annotations

import asyncio
import logging
from time import perf_counter
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError
from aiogram.types import CallbackQuery

logger = logging.getLogger(__name__)


async def _ack_callback(event: CallbackQuery, data: dict[str, Any]) -> None:
    """Acknowledge a callback without serialising the screen render behind it."""
    ack_started = perf_counter()
    try:
        await event.answer(cache_time=0)
        data["callback_acknowledged"] = True
    except (TelegramBadRequest, TelegramNetworkError):
        # ACK is UX-only. A Telegram/API hiccup must never stop the real handler.
        logger.debug("Callback ACK failed", exc_info=True)
        data["callback_acknowledged"] = False
    except Exception:
        # Keep this middleware fail-open for UI navigation. Business/financial
        # safety never depends on callback acknowledgement.
        logger.debug("Unexpected callback ACK failure", exc_info=True)
        data["callback_acknowledged"] = False
    finally:
        data["callback_ack_ms"] = (perf_counter() - ack_started) * 1000


class FastCallbackAckMiddleware(BaseMiddleware):
    """Start Telegram callback ACK and the handler at the same time.

    Older Phase-1 behaviour awaited ``answerCallbackQuery`` before entering the
    handler. That is safe, but it puts two Telegram API round trips in series:

        answerCallbackQuery -> editMessageText

    Navigation now runs them concurrently, so the screen edit is sent
    immediately instead of waiting for the ACK request to return first.

    This middleware is UX-only. It is never a financial lock and never replaces
    PostgreSQL idempotency/transactions. A handler that must own the callback
    answer can use ``manual_callback_ack=True``.
    """

    async def __call__(
        self,
        handler: Callable[[CallbackQuery, dict[str, Any]], Awaitable[Any]],
        event: CallbackQuery,
        data: dict[str, Any],
    ) -> Any:
        handler_object = data.get("handler")
        flags = getattr(handler_object, "flags", {}) or {}
        manual_ack = bool(flags.get("manual_callback_ack", False))

        if manual_ack:
            return await handler(event, data)

        # Important performance detail: do NOT await ACK before the handler.
        # The Telegram session has a connection pool, so the ACK and screen edit
        # can be in flight concurrently.
        ack_task = asyncio.create_task(_ack_callback(event, data), name="telegram-callback-ack")
        data["callback_ack_task"] = ack_task
        data["callback_ack_parallel"] = True

        try:
            return await handler(event, data)
        finally:
            # Do not leak background tasks. Usually ACK has already completed by
            # the time the edit request returns, so this adds no user-visible
            # latency. Even if it is slower, the screen edit was already sent.
            try:
                await ack_task
            except asyncio.CancelledError:
                raise
            except Exception:
                # _ack_callback is intentionally fail-open, but keep a final
                # guard so a future refactor cannot block callback handling.
                logger.debug("Callback ACK task failed", exc_info=True)
