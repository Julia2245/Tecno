from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.services.deposits import DepositService
from app.core.emojis import BOT_DEPOSIT_EMOJI_ID, SHAM_CASH_EMOJI_ID, SYRIATEL_CASH_EMOJI_ID


def deposit_methods_menu(service: DepositService) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    icons = {
        "syriatel": ("سيرياتيل كاش", SYRIATEL_CASH_EMOJI_ID),
        "sham_syp": ("شام كاش – ليرة", SHAM_CASH_EMOJI_ID),
        "sham_usd": ("شام كاش – دولار", SHAM_CASH_EMOJI_ID),
        "whish_money": ("💸 Whish Money", BOT_DEPOSIT_EMOJI_ID),
        "binance_trc20": ("🪙 Binance USDT TRC20", BOT_DEPOSIT_EMOJI_ID),
        "binance_bep20": ("🪙 Binance USDT BEP20", BOT_DEPOSIT_EMOJI_ID),
    }
    for cfg in service.all_methods():
        suffix = "" if cfg.enabled else " — متوقف"
        label, icon_id = icons.get(cfg.method, (cfg.label, BOT_DEPOSIT_EMOJI_ID))
        rows.append([
            InlineKeyboardButton(
                text=f"{label}{suffix}",
                callback_data=f"deposit:method:{cfg.method}",
                icon_custom_emoji_id=icon_id,
            )
        ])
    rows.append([InlineKeyboardButton(text="⬅️ الرئيسية", callback_data="core:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def deposit_back_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ طرق الشحن", callback_data="deposit:methods")],
            [InlineKeyboardButton(text="🏠 الرئيسية", callback_data="core:home")],
        ]
    )


def deposit_cancel_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="❌ إلغاء العملية", callback_data="deposit:cancel")],
            [InlineKeyboardButton(text="⬅️ طرق الشحن", callback_data="deposit:methods")],
        ]
    )


def deposit_confirm_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ تأكيد", callback_data="deposit:confirm"),
                InlineKeyboardButton(text="❌ إلغاء", callback_data="deposit:cancel"),
            ],
            [InlineKeyboardButton(text="⬅️ طرق الشحن", callback_data="deposit:methods")],
        ]
    )


def whish_photo_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ تعديل المبلغ", callback_data="deposit:whish:back_amount")],
            [InlineKeyboardButton(text="❌ إلغاء العملية", callback_data="deposit:cancel")],
        ]
    )


def manual_review_menu(deposit_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ اعتماد", callback_data=f"deposit:admin:approve:{deposit_id}"),
                InlineKeyboardButton(text="❌ رفض", callback_data=f"deposit:admin:reject:{deposit_id}"),
            ]
        ]
    )


def admin_pending_deposits_menu(items: list[tuple[str, str]]) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for deposit_id, label in items:
        rows.append([
            InlineKeyboardButton(text=label, callback_data=f"deposit:admin:view:{deposit_id}")
        ])
    rows.append([InlineKeyboardButton(text="⬅️ لوحة الإدارة", callback_data="admin:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
