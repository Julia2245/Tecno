from __future__ import annotations

from uuid import UUID


def build_provider_reference(operation_type: str, job_id: UUID) -> str:
    prefix = {
        "deposit": "D",
        "withdraw": "W",
        "retirement_withdraw": "R",
    }.get(operation_type, "X")
    return f"TEC-{prefix}-{job_id.hex.upper()}"


def reconciliation_confirmed(
    operation_type: str,
    *,
    amount: int,
    player_before: int,
    player_after: int,
    cashier_before: int,
    cashier_after: int,
) -> bool:
    """Require the exact player/cashier delta before settling an uncertain POST."""
    amount = int(amount)
    if operation_type == "deposit":
        return (int(player_after) - int(player_before) == amount) and (
            int(cashier_before) - int(cashier_after) == amount
        )
    return (int(player_before) - int(player_after) == amount) and (
        int(cashier_after) - int(cashier_before) == amount
    )
