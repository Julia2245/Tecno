from __future__ import annotations

import re
import secrets
import string
import unicodedata

_COMMON_NAMES = {
    "احمد": "ahmad",
    "أحمد": "ahmad",
    "احمد": "ahmad",
    "محمد": "mohammad",
    "محمود": "mahmoud",
    "علي": "ali",
    "حسين": "hussein",
    "حسن": "hassan",
    "عبدالله": "abdullah",
    "عبد الله": "abdullah",
    "عبدالرحمن": "abd_alrahman",
    "عبد الرحمن": "abd_alrahman",
    "عمر": "omar",
    "خالد": "khaled",
    "يوسف": "yousef",
    "مصطفى": "mostafa",
    "سامي": "sami",
    "سامر": "samer",
    "فارس": "fares",
    "نور": "nour",
}

_AR_MAP = {
    "ا": "a", "أ": "a", "إ": "i", "آ": "a", "ٱ": "a",
    "ب": "b", "ت": "t", "ث": "th", "ج": "j", "ح": "h", "خ": "kh",
    "د": "d", "ذ": "dh", "ر": "r", "ز": "z", "س": "s", "ش": "sh",
    "ص": "s", "ض": "d", "ط": "t", "ظ": "z", "ع": "a", "غ": "gh",
    "ف": "f", "ق": "q", "ك": "k", "ل": "l", "م": "m", "ن": "n",
    "ه": "h", "ة": "a", "و": "w", "ؤ": "w", "ي": "y", "ى": "a", "ئ": "y",
    "ء": "", "ﻻ": "la", "لا": "la",
}

_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_DIACRITICS = re.compile(r"[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed]")
_UNDERSCORES = re.compile(r"_+")


def normalize_person_name(raw: str, *, max_length: int = 24) -> str:
    text = unicodedata.normalize("NFKC", str(raw or "")).translate(_DIGITS)
    text = _DIACRITICS.sub("", text).replace("ـ", "").strip()
    if not text:
        return "user"

    exact = _COMMON_NAMES.get(text)
    if exact:
        return exact[:max_length]

    # Resolve common Arabic names token-by-token before falling back to a
    # deterministic character transliteration. This keeps natural spellings
    # such as "أحمد محمد" -> "ahmad_mohammad" while still accepting names
    # that are not present in the common-name dictionary.
    pieces: list[str] = []
    for token in re.split(r"[\s_.-]+", text):
        token = token.strip()
        if not token:
            continue
        known = _COMMON_NAMES.get(token)
        if known:
            pieces.append(known)
            continue
        out: list[str] = []
        for ch in token:
            if ch in _AR_MAP:
                out.append(_AR_MAP[ch])
            elif "a" <= ch.lower() <= "z" or ch.isdigit():
                out.append(ch.lower())
            # Emoji / unsupported punctuation is deliberately ignored.
        piece = re.sub(r"[^a-z0-9]", "", "".join(out).lower())
        if piece:
            pieces.append(piece)

    slug = "_".join(pieces)
    slug = re.sub(r"[^a-z0-9_]", "", slug.lower())
    slug = _UNDERSCORES.sub("_", slug).strip("_")
    return (slug or "user")[:max_length].rstrip("_") or "user"


def normalize_prefix(raw: str) -> str:
    prefix = re.sub(r"[^a-z0-9]", "", str(raw or "bot").lower())
    return prefix[:16] or "bot"


def build_username(prefix: str, sequence_no: int, normalized_name: str, *, max_length: int = 48) -> str:
    base = f"{normalize_prefix(prefix)}{int(sequence_no)}_"
    room = max(1, max_length - len(base))
    suffix = normalize_person_name(normalized_name, max_length=room)
    return f"{base}{suffix}"[:max_length]


def generate_password(length: int = 14) -> str:
    length = max(10, min(32, int(length)))
    alphabet = string.ascii_letters + string.digits
    while True:
        value = "".join(secrets.choice(alphabet) for _ in range(length))
        if any(c.islower() for c in value) and any(c.isupper() for c in value) and any(c.isdigit() for c in value):
            return value
