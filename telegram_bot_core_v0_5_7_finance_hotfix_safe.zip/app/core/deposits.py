from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from uuid import UUID


class DepositError(RuntimeError):
    pass


class DepositValidationError(DepositError):
    pass


class DepositAlreadyUsed(DepositError):
    def __init__(self, message: str = "provider transaction already used", *, deposit_id: UUID | None = None, telegram_id: int | None = None, status: str | None = None) -> None:
        super().__init__(message)
        self.deposit_id = deposit_id
        self.telegram_id = telegram_id
        self.status = status


class DepositAlreadyProcessed(DepositError):
    def __init__(self, message: str = "deposit already processed", *, status: str | None = None) -> None:
        super().__init__(message)
        self.status = status


class DepositNotFound(DepositError):
    pass


class DepositProviderUnavailable(DepositError):
    pass


class DepositOutcomeUncertain(DepositError):
    """The financial outcome could not be proven after an infrastructure failure."""


class DepositVerificationFailed(DepositError):
    pass


@dataclass(slots=True, frozen=True)
class ProviderTransaction:
    provider: str
    tx_key: str
    amount: Decimal
    currency: str
    destination: str | None = None
    network: str | None = None
    occurred_at: datetime | None = None
    raw: dict | None = None


@dataclass(slots=True, frozen=True)
class DepositRecord:
    id: UUID
    telegram_id: int
    method: str
    request_key: str | None
    provider_scope: str | None
    provider_tx: str | None
    amount_input: Decimal
    currency: str
    rate: Decimal
    bonus_pct: Decimal
    bonus_source: str
    base_credit_syp: int
    bonus_credit_syp: int
    total_credit_syp: int
    status: str
    target_ref: str | None
    proof_file_id: str | None
    wallet_operation_id: UUID | None
    created_at: datetime
    updated_at: datetime
    settled_at: datetime | None
    reviewed_by: int | None
    review_note: str | None


@dataclass(slots=True, frozen=True)
class DepositSettlement:
    deposit: DepositRecord
    duplicate: bool
    balance_after: int


@dataclass(slots=True, frozen=True)
class ManualDepositCreation:
    deposit: DepositRecord
    duplicate: bool
