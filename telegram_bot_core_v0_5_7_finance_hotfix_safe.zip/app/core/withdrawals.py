from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from uuid import UUID


class WithdrawError(RuntimeError):
    pass


class WithdrawNotFound(WithdrawError):
    pass


class WithdrawStateError(WithdrawError):
    pass


class WithdrawValidationError(WithdrawError):
    pass


class WithdrawOutcomeUncertain(WithdrawError):
    pass


@dataclass(frozen=True, slots=True)
class WithdrawRecord:
    id: UUID
    telegram_id: int
    method: str
    amount_wallet: int
    fee_pct: Decimal
    fee_wallet: int
    net_wallet: int
    payout_amount: Decimal
    payout_currency: str
    exchange_rate: Decimal | None
    receiver: str
    receiver_name: str | None
    network: str | None
    source_ref: str | None
    status: str
    wallet_hold_id: UUID
    wallet_operation_id: UUID | None
    provider_reference: str | None
    last_error: str | None
    processing_by: int | None
    reviewed_by: int | None
    created_at: datetime
    updated_at: datetime
    finished_at: datetime | None
