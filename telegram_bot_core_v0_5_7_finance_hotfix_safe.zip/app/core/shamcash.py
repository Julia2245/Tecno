from __future__ import annotations

import re

# Addresses are opaque provider identifiers, but copied values sometimes arrive
# wrapped in quotes or split across lines.  Those presentation characters must
# never become part of the identifier sent to API Syria.
_SHAM_DECORATION_RE = re.compile(r"[\s\"'“”‘’]+", re.UNICODE)


def normalize_shamcash_address(value: object) -> str:
    """Return a canonical Sham Cash address without copy/paste decoration."""
    return _SHAM_DECORATION_RE.sub("", str(value or ""))
