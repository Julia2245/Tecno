from __future__ import annotations

from cryptography.fernet import Fernet, InvalidToken


class CredentialCipher:
    def __init__(self, key: str) -> None:
        clean = str(key or "").strip().encode("ascii", "strict")
        if not clean:
            raise ValueError("ICHANCY_CREDENTIALS_KEY is required for iChancy credentials")
        self._fernet = Fernet(clean)

    def encrypt(self, value: str) -> str:
        return self._fernet.encrypt(value.encode("utf-8")).decode("ascii")

    def decrypt(self, value: str) -> str:
        try:
            return self._fernet.decrypt(value.encode("ascii")).decode("utf-8")
        except InvalidToken as exc:
            raise ValueError("Stored iChancy credential cannot be decrypted with current key") from exc
