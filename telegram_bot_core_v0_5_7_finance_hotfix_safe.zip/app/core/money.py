from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


ZERO = Decimal("0")
HUNDRED = Decimal("100")


def parse_decimal(value: object) -> Decimal:
    try:
        result = Decimal(str(value).strip())
    except (InvalidOperation, ValueError, TypeError, AttributeError) as exc:
        raise ValueError("invalid decimal") from exc
    if not result.is_finite():
        raise ValueError("non-finite decimal")
    return result


def wallet_syp_amount(amount: Decimal, rate: Decimal) -> int:
    """Convert provider units to integer SYP wallet units deterministically."""
    value = (amount * rate).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    if value <= 0:
        raise ValueError("wallet credit must be positive")
    return int(value)


def percent_amount(base: int, pct: Decimal) -> int:
    if base < 0:
        raise ValueError("base cannot be negative")
    if pct < ZERO or pct > HUNDRED:
        raise ValueError("percentage out of range")
    value = (Decimal(base) * pct / HUNDRED).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return int(value)
