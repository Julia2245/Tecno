from __future__ import annotations

from html import escape

# Central custom-emoji registry shared across the bot identity.
# Keep IDs here only so UI identity can change without touching business logic.
ICHANCY_EMOJI_ID = "5994683681220861528"
SHAM_CASH_EMOJI_ID = "5996853812231413145"
SYRIATEL_CASH_EMOJI_ID = "5994366253072916034"
BOT_WITHDRAW_EMOJI_ID = "5994385322727709668"
BOT_DEPOSIT_EMOJI_ID = "5377548235709619284"
WHEEL_EMOJI_ID = "5321057299664480450"
GIFT_CODE_EMOJI_ID = "5278560792998854087"
CONTESTS_EMOJI_ID = "5454037226679718826"
OFFERS_EMOJI_ID = "5452010672130902785"
SUPPORT_EMOJI_ID = "5454204635914981438"

LOADING_EMOJI_ID = "5386367538735104399"
PROCESSING_EMOJI_ID = "5884447890960552542"
SUCCESS_EMOJI_ID = "5796205953913196373"


def custom_emoji(emoji_id: str, fallback: str) -> str:
    """Telegram HTML custom emoji with a readable fallback glyph."""
    return f'<tg-emoji emoji-id="{escape(str(emoji_id))}">{escape(fallback)}</tg-emoji>'


ICHANCY = custom_emoji(ICHANCY_EMOJI_ID, "🎰")
SHAM_CASH = custom_emoji(SHAM_CASH_EMOJI_ID, "💵")
SYRIATEL_CASH = custom_emoji(SYRIATEL_CASH_EMOJI_ID, "📱")
BOT_WITHDRAW = custom_emoji(BOT_WITHDRAW_EMOJI_ID, "💸")
BOT_DEPOSIT = custom_emoji(BOT_DEPOSIT_EMOJI_ID, "💳")
LOADING = custom_emoji(LOADING_EMOJI_ID, "⏳")
PROCESSING = custom_emoji(PROCESSING_EMOJI_ID, "🔄")
SUCCESS = custom_emoji(SUCCESS_EMOJI_ID, "✅")
