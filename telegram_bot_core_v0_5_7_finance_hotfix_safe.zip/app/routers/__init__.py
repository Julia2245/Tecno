from aiogram import Router

from . import admin, admin_finance, admin_ichancy, deposits, errors, ichancy, performance, start, withdrawals


def build_root_router() -> Router:
    root = Router(name="root")
    root.include_router(start.router)
    root.include_router(performance.router)
    root.include_router(admin.router)
    root.include_router(admin_finance.router)
    root.include_router(admin_ichancy.router)
    root.include_router(deposits.router)
    root.include_router(withdrawals.router)
    root.include_router(ichancy.router)
    # Register at the parent so failures from every child router are covered.
    root.errors.register(errors.global_error_handler)
    return root
