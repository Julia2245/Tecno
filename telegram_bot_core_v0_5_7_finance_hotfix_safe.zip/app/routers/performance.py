from __future__ import annotations

from time import perf_counter

from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.config import Settings
from app.core.ui import safe_edit
from app.keyboards.common import main_menu

router = Router(name="performance")


@router.callback_query(F.data == "core:latency")
async def latency_callback(
    callback: CallbackQuery,
    settings: Settings,
    update_received_perf: float,
    callback_ack_parallel: bool = False,
) -> None:
    # This is the time from dispatcher receipt until the screen handler begins.
    # Telegram-client -> Telegram-server latency happens before this point and
    # cannot be measured from the bot process itself.
    dispatch_ms = (perf_counter() - update_received_perf) * 1000
    ack_mode = "بالتوازي مع تحديث الشاشة ✅" if callback_ack_parallel else "تقليدي"

    # Send the screen edit immediately. We intentionally do not wait for ACK
    # timing here; doing so would recreate the serial round-trip bottleneck the
    # performance patch removes.
    await safe_edit(
        callback,
        "⚡ <b>اختبار الاستجابة</b>\n\n"
        f"الوصول لمنطق الشاشة: <code>{dispatch_ms:.1f} ms</code>\n"
        f"تأكيد الزر: <b>{ack_mode}</b>\n\n"
        "النسخة الحالية ترسل تأكيد الزر وتحديث الشاشة بنفس الوقت، "
        "بدلاً من انتظار الأول ثم إرسال الثاني.\n\n"
        "ملاحظة: زمن شبكة جهازك إلى Telegram لا يمكن قياسه من داخل السيرفر.",
        reply_markup=main_menu(is_admin=callback.from_user.id in settings.super_admin_ids),
    )
