from __future__ import annotations

import html
from decimal import Decimal

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from app.core.emojis import PROCESSING, SUCCESS
from app.core.ui import safe_edit
from app.core.withdrawals import WithdrawValidationError
from app.keyboards.withdrawals import (
    cancel_menu,
    confirm_menu,
    hawala_companies,
    methods_menu,
    usdt_networks,
)
from app.services.withdrawals import WithdrawService
from app.services.wallet import WalletService

router = Router(name="withdrawals")


class WithdrawStates(StatesGroup):
    waiting_amount = State()
    waiting_network = State()
    waiting_receiver = State()
    waiting_hawala_name = State()
    waiting_hawala_phone = State()
    waiting_confirm = State()


def _parse_int(raw: str) -> int | None:
    trans = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
    value = str(raw or "").translate(trans).replace(",", "").replace("٬", "").replace(" ", "").strip()
    if not value.isdigit():
        return None
    value_i = int(value)
    return value_i if value_i > 0 else None


def _normalize_phone(raw: str) -> str:
    trans = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
    return str(raw or "").translate(trans).replace(" ", "").replace("-", "").strip()


def _fmt_decimal(value: Decimal) -> str:
    return str(int(value)) if value == value.to_integral_value() else format(value.normalize(), "f")


def _method_label(method: str, data: dict) -> str:
    if method == "hawala":
        company = str(data.get("hawala_company") or "harm")
        return "حوالة هرم" if company == "harm" else "حوالة الفؤاد"
    if method == "usdt":
        return f"USDT {data.get('network') or ''}".strip()
    return {"syriatel": "سيرياتيل كاش", "shamcash": "شام كاش"}.get(method, method)


def _confirmation_text(data: dict) -> str:
    method = str(data.get("method") or "")
    amount = int(data.get("amount") or 0)
    fee_wallet = int(data.get("fee_wallet") or 0)
    payout = Decimal(str(data.get("payout") or "0"))
    currency = str(data.get("payout_currency") or "")
    receiver = str(data.get("receiver") or "")
    receiver_name = str(data.get("receiver_name") or "")
    label = _method_label(method, data)
    name_line = f"👤 اسم الحساب: <b>{html.escape(receiver_name)}</b>\n" if method == "shamcash" and receiver_name else ""
    warning = "\n\n⚠️ تأكد من الشبكة والعنوان؛ تحويلات العملات الرقمية لا يمكن إلغاؤها بعد الإرسال." if method == "usdt" else ""
    return (
        "✅ <b>تأكيد طلب السحب</b>\n\n"
        f"💳 الطريقة: <b>{html.escape(label)}</b>\n"
        f"💰 المبلغ من المحفظة: <code>{amount:,}</code>\n"
        f"💸 العمولة: <code>{fee_wallet:,}</code>\n"
        f"📤 المبلغ المستحق: <code>{_fmt_decimal(payout)} {html.escape(currency)}</code>\n"
        + name_line
        + f"📍 المستلم: <code>{html.escape(receiver)}</code>"
        + warning
    )


async def _show_confirmation(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    await state.set_state(WithdrawStates.waiting_confirm)
    await message.answer(_confirmation_text(data), reply_markup=confirm_menu())


@router.callback_query(F.data == "withdraw:methods")
async def methods_cb(callback: CallbackQuery, state: FSMContext, withdraw_service: WithdrawService) -> None:
    await state.clear()
    await safe_edit(callback, "💸 <b>سحب رصيد البوت</b>\n\nاختر طريقة السحب:", reply_markup=methods_menu(withdraw_service))


@router.callback_query(F.data == "withdraw:cancel")
async def cancel_cb(callback: CallbackQuery, state: FSMContext, withdraw_service: WithdrawService) -> None:
    await state.clear()
    await safe_edit(callback, "❌ تم إلغاء طلب السحب.", reply_markup=methods_menu(withdraw_service))


@router.callback_query(F.data.startswith("withdraw:method:"))
async def method_cb(callback: CallbackQuery, state: FSMContext, withdraw_service: WithdrawService, wallet_service: WalletService) -> None:
    method = str(callback.data or "").rsplit(":", 1)[-1]
    if method not in {"syriatel", "shamcash", "hawala", "usdt"} or not withdraw_service.method_enabled(method):
        await safe_edit(callback, "❌ طريقة السحب متوقفة حالياً.", reply_markup=methods_menu(withdraw_service))
        return
    bal = await wallet_service.get_balance(callback.from_user.id)
    available = int(bal.available if bal else 0)
    minimum = withdraw_service.minimum(method)
    if available < minimum:
        await safe_edit(
            callback,
            f"❌ رصيدك المتاح <b>{available:,}</b> أقل من الحد الأدنى <b>{minimum:,}</b>.",
            reply_markup=methods_menu(withdraw_service),
        )
        return
    await state.clear()
    await state.update_data(method=method)

    if method == "shamcash":
        # Resolve/display ShamCash identity before asking for the amount.
        await state.set_state(WithdrawStates.waiting_receiver)
        await safe_edit(
            callback,
            "💵 <b>سحب شام كاش</b>\n\n"
            f"الحد الأدنى: <b>{minimum:,}</b>\n\n"
            "👇 أرسل عنوان حساب شام كاش الآن.",
            reply_markup=cancel_menu(),
        )
        return

    if method == "hawala":
        await safe_edit(callback, "🏦 <b>اختر شركة الحوالة</b>", reply_markup=hawala_companies())
        return

    if method == "usdt" and not (withdraw_service.network_enabled("TRC20") or withdraw_service.network_enabled("BEP20")):
        await safe_edit(callback, "❌ جميع شبكات سحب USDT متوقفة حالياً.", reply_markup=methods_menu(withdraw_service))
        return

    await state.set_state(WithdrawStates.waiting_amount)
    await safe_edit(
        callback,
        "💸 <b>أدخل مبلغ السحب من محفظة البوت</b>\n\n"
        f"الرصيد المتاح: <b>{available:,}</b>\n"
        f"الحد الأدنى: <b>{minimum:,}</b>",
        reply_markup=cancel_menu(),
    )


@router.callback_query(F.data.startswith("withdraw:hawala:"))
async def hawala_company_cb(callback: CallbackQuery, state: FSMContext, withdraw_service: WithdrawService, wallet_service: WalletService) -> None:
    company = str(callback.data or "").rsplit(":", 1)[-1]
    if company not in {"harm", "fouad"} or not withdraw_service.method_enabled("hawala"):
        return
    bal = await wallet_service.get_balance(callback.from_user.id)
    available = int(bal.available if bal else 0)
    minimum = withdraw_service.minimum("hawala")
    if available < minimum:
        await safe_edit(callback, f"❌ رصيدك أقل من حد الحوالة <b>{minimum:,}</b>.", reply_markup=methods_menu(withdraw_service))
        await state.clear()
        return
    await state.update_data(method="hawala", hawala_company=company)
    await state.set_state(WithdrawStates.waiting_amount)
    company_label = "هرم" if company == "harm" else "الفؤاد"
    await safe_edit(
        callback,
        f"💸 <b>حوالة {company_label}</b>\n\n"
        f"الرصيد المتاح: <b>{available:,}</b>\n"
        f"الحد الأدنى: <b>{minimum:,}</b>\n\n"
        "👇 أرسل مبلغ السحب من محفظة البوت.",
        reply_markup=cancel_menu(),
    )


@router.message(WithdrawStates.waiting_amount, F.text)
async def amount_msg(message: Message, state: FSMContext, withdraw_service: WithdrawService, wallet_service: WalletService) -> None:
    if message.from_user is None:
        return
    amount = _parse_int(message.text or "")
    if amount is None:
        await message.answer("❌ المبلغ غير صحيح. أرسل أرقام فقط.", reply_markup=cancel_menu())
        return
    data = await state.get_data()
    method = str(data.get("method") or "")
    try:
        pct, fee, net, payout, currency, rate = withdraw_service.preview(method, amount)
    except WithdrawValidationError as exc:
        await message.answer(f"❌ {html.escape(str(exc))}", reply_markup=cancel_menu())
        return
    bal = await wallet_service.get_balance(message.from_user.id)
    if amount > int(bal.available if bal else 0):
        await message.answer("❌ رصيد المحفظة غير كافٍ.", reply_markup=cancel_menu())
        return
    await state.update_data(
        amount=amount,
        fee=str(pct),
        fee_wallet=fee,
        net=net,
        payout=str(payout),
        payout_currency=currency,
        rate=str(rate) if rate is not None else None,
    )

    if method == "usdt":
        await state.set_state(WithdrawStates.waiting_network)
        await message.answer(
            f"🪙 الصافي: <b>{_fmt_decimal(payout)} USDT</b>\n\nاختر الشبكة:",
            reply_markup=usdt_networks(withdraw_service),
        )
        return
    if method == "hawala":
        await state.set_state(WithdrawStates.waiting_hawala_name)
        await message.answer("👤 أرسل الاسم الكامل للمستلم (كلمتان على الأقل).", reply_markup=cancel_menu())
        return
    if method == "shamcash" and data.get("receiver"):
        await _show_confirmation(message, state)
        return

    await state.set_state(WithdrawStates.waiting_receiver)
    await message.answer("📱 أرسل رقم سيرياتيل المستلم.", reply_markup=cancel_menu())


@router.callback_query(WithdrawStates.waiting_network, F.data.startswith("withdraw:network:"))
async def network_cb(callback: CallbackQuery, state: FSMContext, withdraw_service: WithdrawService) -> None:
    network = str(callback.data or "").rsplit(":", 1)[-1].upper()
    if network not in {"TRC20", "BEP20"}:
        return
    if not withdraw_service.network_enabled(network):
        await safe_edit(callback, f"❌ شبكة {network} متوقفة حالياً.", reply_markup=usdt_networks(withdraw_service))
        return
    await state.update_data(network=network)
    await state.set_state(WithdrawStates.waiting_receiver)
    await safe_edit(callback, f"🪙 الشبكة: <b>{network}</b>\n\nأرسل عنوان المحفظة.", reply_markup=cancel_menu())


@router.message(WithdrawStates.waiting_receiver, F.text)
async def receiver_msg(message: Message, state: FSMContext, withdraw_service: WithdrawService) -> None:
    data = await state.get_data()
    method = str(data.get("method") or "")
    network = data.get("network")
    try:
        receiver = withdraw_service.normalize_receiver(method, message.text or "", str(network or "") or None)
    except WithdrawValidationError as exc:
        await message.answer(f"❌ {html.escape(str(exc))}\nأرسل البيانات من جديد.", reply_markup=cancel_menu())
        return

    if method == "shamcash":
        receiver_name = await withdraw_service.resolve_shamcash_name(receiver)
        await state.update_data(receiver=receiver, receiver_name=receiver_name)
        # Address is intentionally accepted even if it is new and no name exists
        # in API Syria history; preserve the hardened read-before-execute behavior.
        if data.get("amount") is None:
            await state.set_state(WithdrawStates.waiting_amount)
            details = f"👤 اسم الحساب: <b>{html.escape(receiver_name)}</b>\n" if receiver_name else ""
            await message.answer(
                "💵 <b>تم التحقق من عنوان شام كاش</b>\n\n"
                + details
                + f"📍 العنوان: <code>{html.escape(receiver)}</code>\n"
                f"الحد الأدنى: <b>{withdraw_service.minimum('shamcash'):,}</b>\n\n"
                "👇 أرسل مبلغ السحب الآن.",
                reply_markup=cancel_menu(),
            )
            return
    else:
        await state.update_data(receiver=receiver)

    await _show_confirmation(message, state)


@router.message(WithdrawStates.waiting_hawala_name, F.text)
async def hawala_name_msg(message: Message, state: FSMContext) -> None:
    name = " ".join((message.text or "").strip().split())
    if len(name) < 5 or len(name.split()) < 2:
        await message.answer("❌ الاسم غير كافٍ. أرسل الاسم الكامل من كلمتين على الأقل.", reply_markup=cancel_menu())
        return
    await state.update_data(hawala_name=name)
    await state.set_state(WithdrawStates.waiting_hawala_phone)
    await message.answer("📱 أرسل رقم موبايل المستلم.", reply_markup=cancel_menu())


@router.message(WithdrawStates.waiting_hawala_phone, F.text)
async def hawala_phone_msg(message: Message, state: FSMContext) -> None:
    phone = _normalize_phone(message.text or "")
    if not phone.isdigit() or len(phone) < 8 or len(phone) > 15:
        await message.answer("❌ رقم الموبايل غير صالح. أعد إرساله.", reply_markup=cancel_menu())
        return
    data = await state.get_data()
    name = str(data.get("hawala_name") or "")
    company = str(data.get("hawala_company") or "harm")
    company_label = "هرم" if company == "harm" else "الفؤاد"
    receiver = f"الشركة: {company_label}\nالاسم الكامل: {name}\nرقم الموبايل: {phone}"
    await state.update_data(receiver=receiver)
    await _show_confirmation(message, state)


@router.callback_query(WithdrawStates.waiting_confirm, F.data == "withdraw:confirm")
async def confirm_cb(callback: CallbackQuery, state: FSMContext, withdraw_service: WithdrawService) -> None:
    data = await state.get_data()
    await safe_edit(callback, f"{PROCESSING} <b>جاري تثبيت طلب السحب وحجز الرصيد...</b>")
    try:
        rec = await withdraw_service.create_request(
            callback.from_user.id,
            method=str(data.get("method") or ""),
            amount_wallet=int(data.get("amount") or 0),
            receiver=str(data.get("receiver") or ""),
            receiver_name=str(data.get("receiver_name") or "") or None,
            network=str(data.get("network") or "") or None,
        )
    except Exception as exc:
        await state.clear()
        await safe_edit(callback, f"❌ تعذر إنشاء طلب السحب: {html.escape(str(exc))}", reply_markup=methods_menu(withdraw_service))
        return
    await state.clear()
    await safe_edit(
        callback,
        f"{SUCCESS} <b>تم استلام طلب السحب</b>\n\n"
        f"💰 المبلغ: <code>{rec.amount_wallet:,}</code>\n"
        f"📤 المستحق: <code>{_fmt_decimal(rec.payout_amount)} {rec.payout_currency}</code>\n"
        f"🧾 رقم الطلب: <code>{rec.id}</code>\n\n"
        "تم حجز المبلغ بأمان إلى حين تنفيذ الطلب أو رفضه.",
        reply_markup=methods_menu(withdraw_service),
    )
