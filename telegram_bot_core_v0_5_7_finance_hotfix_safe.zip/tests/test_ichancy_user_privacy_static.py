from pathlib import Path


def test_withdraw_progress_does_not_expose_amount_or_job_id():
    text = Path("app/routers/ichancy.py").read_text(encoding="utf-8")
    marker = 'f"{PROCESSING} <b>جاري سحب رصيد حسابك...</b>"'
    assert marker in text
    assert "تم استلام عملية السحب وجاري تنفيذها بأمان" not in text


def test_provider_comment_uses_durable_reference():
    text = Path("app/services/ichancy_jobs.py").read_text(encoding="utf-8")
    assert 'comment = job.provider_reference or f"bot:{job.id}"' in text
    assert "mark_financial_post_started" in text
    assert "IchancyTransferUncertain" in text
