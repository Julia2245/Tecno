from uuid import UUID

from app.core.ichancy_reconciliation import build_provider_reference, reconciliation_confirmed


def test_provider_reference_is_deterministic_and_operation_scoped():
    job_id = UUID("12345678-1234-5678-9abc-def012345678")
    assert build_provider_reference("deposit", job_id) == "TEC-D-12345678123456789ABCDEF012345678"
    assert build_provider_reference("withdraw", job_id) == "TEC-W-12345678123456789ABCDEF012345678"
    assert build_provider_reference("retirement_withdraw", job_id) == "TEC-R-12345678123456789ABCDEF012345678"


def test_deposit_reconciliation_requires_exact_two_sided_delta():
    assert reconciliation_confirmed(
        "deposit",
        amount=20000,
        player_before=100000,
        player_after=120000,
        cashier_before=500000,
        cashier_after=480000,
    )
    assert not reconciliation_confirmed(
        "deposit",
        amount=20000,
        player_before=100000,
        player_after=121000,
        cashier_before=500000,
        cashier_after=480000,
    )
    assert not reconciliation_confirmed(
        "deposit",
        amount=20000,
        player_before=100000,
        player_after=120000,
        cashier_before=500000,
        cashier_after=479000,
    )


def test_withdraw_reconciliation_requires_exact_two_sided_delta():
    assert reconciliation_confirmed(
        "withdraw",
        amount=20000,
        player_before=100000,
        player_after=80000,
        cashier_before=500000,
        cashier_after=520000,
    )
    assert not reconciliation_confirmed(
        "withdraw",
        amount=20000,
        player_before=100000,
        player_after=79000,
        cashier_before=500000,
        cashier_after=520000,
    )
