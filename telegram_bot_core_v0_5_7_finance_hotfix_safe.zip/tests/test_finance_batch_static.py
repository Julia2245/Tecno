from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_ichancy_withdraw_has_two_stage_live_balance_protection() -> None:
    router = read("app/routers/ichancy.py")
    jobs = read("app/services/ichancy_jobs.py")
    assert "precheck_withdraw_balance" in router
    assert "جاري التحقق من رصيد حسابك" in router
    assert "جاري سحب رصيد حسابك" in router
    assert "precheck_withdraw_balance" in jobs
    # The worker still performs the authoritative pre-POST snapshot/read.
    assert "_read_balances" in jobs
    assert "mark_financial_post_started" in jobs


def test_bot_operation_channels_are_split() -> None:
    deposits = read("app/services/deposits.py")
    withdrawals = read("app/repositories/withdrawals.py")
    runtime = read("app/services/runtime_settings.py")
    assert 'target_key="notify.bot_deposits"' in deposits
    assert "'notify.bot_withdrawals'" in withdrawals
    assert '"notify.bot_deposits": None' in runtime
    assert '"notify.bot_withdrawals": None' in runtime


def test_per_method_deposit_minimums_are_runtime_editable() -> None:
    source = read("app/services/deposits.py")
    for key in (
        "deposit.syriatel.min",
        "deposit.sham_syp.min",
        "deposit.sham_usd.min",
        "deposit.whish_money.min",
        "deposit.binance_trc20.min",
        "deposit.binance_bep20.min",
    ):
        assert key in source


def test_admin_setting_flow_updates_origin_message_and_cleans_cancel_state() -> None:
    source = read("app/routers/admin_finance.py")
    assert 'origin_message_id=callback.message.message_id' in source
    assert 'await runtime_settings.set(key, value' in source
    assert 'message.bot.edit_message_text' in source
    assert 'F.data == "admin:setting:cancel"' in source
    assert 'await state.clear()' in source
    assert '_NUM_TRANSLATION' in source


def test_admin_withdraw_menu_has_method_pages_review_security_and_history() -> None:
    source = read("app/routers/admin_finance.py")
    for callback in (
        "admin:withdraws:pending",
        "admin:withdraws:review",
        "admin:withdraw:method:syriatel",
        "admin:withdraw:method:shamcash",
        "admin:withdraw:method:hawala",
        "admin:withdraw:method:usdt",
        "admin:withdraw:commission",
        "admin:withdraw:security",
        "admin:withdraws:history",
    ):
        assert callback in source


def test_custom_emoji_registry_matches_approved_ids() -> None:
    source = read("app/core/emojis.py")
    for emoji_id in (
        "5994683681220861528",
        "5996853812231413145",
        "5994366253072916034",
        "5994385322727709668",
        "5377548235709619284",
        "5321057299664480450",
        "5278560792998854087",
        "5454037226679718826",
        "5452010672130902785",
        "5454204635914981438",
        "5386367538735104399",
        "5884447890960552542",
        "5796205953913196373",
    ):
        assert emoji_id in source


def test_manual_deposit_request_uses_dedicated_deposit_channel() -> None:
    source = read("app/routers/deposits.py")
    assert 'runtime_settings.get("notify.bot_deposits")' in source
    assert 'await _send_manual_review_message(bot, chat_id, deposit)' in source
    assert '_notify_manual_admins(callback.bot, settings, runtime_settings, creation.deposit)' in source


def test_shamcash_source_is_normalized_before_provider_transfer() -> None:
    source = read("app/services/withdrawals.py")
    deposits = read("app/services/deposits.py")
    migration = read("migrations/0008_shamcash_address_cleanup.sql")
    assert "normalize_shamcash_address" in source
    assert "normalize_shamcash_address" in deposits
    assert "deposit.sham.address_syp" in migration
    assert "regexp_replace" in migration


def test_syriatel_withdraw_pin_is_runtime_editable_and_encrypted() -> None:
    admin = read("app/routers/admin_finance.py")
    service = read("app/services/withdrawals.py")
    main = read("app/main.py")
    assert 'admin:setting:withdraw.syriatel.pin' in admin
    assert 'PIN السحب:' in admin
    assert 'set_syriatel_pin' in service
    assert 'withdraw.syriatel.pin_enc' in service
    assert 'self.secret_cipher.encrypt(clean)' in service
    assert 'pin = self.syriatel_pin()' in service
    assert 'cipher,' in main
