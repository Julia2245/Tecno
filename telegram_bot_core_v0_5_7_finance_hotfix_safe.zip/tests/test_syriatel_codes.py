from app.core.syriatel import parse_syriatel_cash_codes


def test_runtime_codes_are_canonical() -> None:
    assert parse_syriatel_cash_codes('"45191900"; “٤٥١٩١٩٠١”') == ("45191900", "45191901")


def test_runtime_codes_dedupe_after_normalization() -> None:
    assert parse_syriatel_cash_codes('45191900, "45191900"') == ("45191900",)
