from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_deposit_progress_hides_internal_job_details() -> None:
    source = (ROOT / "app/routers/ichancy.py").read_text(encoding="utf-8")
    block = source[source.index("async def deposit_amount"):source.index("@router.callback_query(F.data == \"ichancy:deposit_all\")")]
    assert "جاري شحن حسابك" in block
    assert "رقم العملية" not in block
    assert "job.amount" not in block


def test_user_fallback_result_hides_uuid_and_amount() -> None:
    source = (ROOT / "app/repositories/ichancy_jobs.py").read_text(encoding="utf-8")
    failure = source[source.index("if op == \"deposit\""):source.index("return self._job(row)", source.index("if op == \"deposit\""))]
    assert "تعذر شحن حسابك" in failure
    assert "رقم العملية" not in failure
    assert "row['amount']" not in failure


def test_fast_callback_patch_files_are_not_reworked_by_this_change() -> None:
    source = (ROOT / "app/middlewares/callback_ack.py").read_text(encoding="utf-8")
    assert "callback_ack_parallel" in source
