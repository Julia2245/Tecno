from __future__ import annotations

import asyncio

import pytest

from app.middlewares.callback_ack import FastCallbackAckMiddleware


class _FakeCallback:
    def __init__(self, ack_started: asyncio.Event, release_ack: asyncio.Event) -> None:
        self.ack_started = ack_started
        self.release_ack = release_ack
        self.answer_calls = 0

    async def answer(self, *, cache_time: int = 0) -> None:
        self.answer_calls += 1
        self.ack_started.set()
        await self.release_ack.wait()


@pytest.mark.asyncio
async def test_callback_handler_does_not_wait_for_ack_roundtrip() -> None:
    middleware = FastCallbackAckMiddleware()
    ack_started = asyncio.Event()
    release_ack = asyncio.Event()
    handler_started = asyncio.Event()
    callback = _FakeCallback(ack_started, release_ack)

    async def handler(event, data):
        handler_started.set()
        return "ok"

    task = asyncio.create_task(middleware(handler, callback, {}))

    await asyncio.wait_for(ack_started.wait(), timeout=0.2)
    # Core guarantee of this patch: handler can start while ACK is still blocked.
    await asyncio.wait_for(handler_started.wait(), timeout=0.2)
    assert not task.done()

    release_ack.set()
    assert await asyncio.wait_for(task, timeout=0.2) == "ok"
    assert callback.answer_calls == 1


@pytest.mark.asyncio
async def test_callback_ack_is_still_completed_before_middleware_returns() -> None:
    middleware = FastCallbackAckMiddleware()
    ack_started = asyncio.Event()
    release_ack = asyncio.Event()
    callback = _FakeCallback(ack_started, release_ack)

    async def handler(event, data):
        release_ack.set()
        return "done"

    data = {}
    result = await middleware(handler, callback, data)

    assert result == "done"
    assert data["callback_acknowledged"] is True
    assert data["callback_ack_parallel"] is True
    assert data["callback_ack_ms"] >= 0
