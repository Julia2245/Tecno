from app.core.ichancy_names import build_username, normalize_person_name


def test_common_arabic_name_is_natural() -> None:
    assert normalize_person_name("أحمد") == "ahmad"


def test_common_arabic_full_name_is_tokenized() -> None:
    assert normalize_person_name("  أحـمــد محمد ❤️ ") == "ahmad_mohammad"


def test_english_and_digits_are_normalized() -> None:
    assert normalize_person_name("Ahmad ١٢") == "ahmad_12"


def test_username_uses_sequence_number() -> None:
    assert build_username("Tecno", 37, "أحمد") == "tecno37_ahmad"
