from app.core.shamcash import normalize_shamcash_address


def test_shamcash_address_strips_quotes_spaces_and_newlines() -> None:
    raw = ' "989f3ef33aaf6d773886"\n"2b5857a91bf4" '
    assert normalize_shamcash_address(raw) == "989f3ef33aaf6d7738862b5857a91bf4"


def test_shamcash_address_strips_smart_quotes() -> None:
    assert normalize_shamcash_address('“abc” ‘def’') == "abcdef"
