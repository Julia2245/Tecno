-- Split bot-wallet operation notifications into independent deposit/withdraw channels.
-- Preserve an existing legacy channel as the bootstrap value only; after this
-- migration each key is edited and used independently.
INSERT INTO bot_core.runtime_settings(key,value,updated_by)
SELECT 'notify.bot_deposits', value, updated_by
FROM bot_core.runtime_settings
WHERE key='notify.bot_operations'
ON CONFLICT(key) DO NOTHING;

INSERT INTO bot_core.runtime_settings(key,value,updated_by)
SELECT 'notify.bot_withdrawals', value, updated_by
FROM bot_core.runtime_settings
WHERE key='notify.bot_operations'
ON CONFLICT(key) DO NOTHING;
