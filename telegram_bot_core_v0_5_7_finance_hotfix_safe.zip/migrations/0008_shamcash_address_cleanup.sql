-- Canonicalize existing Sham Cash runtime addresses that were pasted with
-- quotes/newlines/spaces.  Only the two Sham Cash address keys are touched.
UPDATE bot_core.runtime_settings
SET value = to_jsonb(
        regexp_replace(
            value #>> '{}',
            '["''“”‘’[:space:]]+',
            '',
            'g'
        )
    ),
    updated_at = NOW()
WHERE key IN ('deposit.sham.address_syp', 'deposit.sham.address_usd')
  AND jsonb_typeof(value) = 'string';
