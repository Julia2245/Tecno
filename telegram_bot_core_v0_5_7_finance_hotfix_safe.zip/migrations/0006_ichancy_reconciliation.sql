ALTER TABLE bot_core.ichancy_jobs
    ADD COLUMN IF NOT EXISTS provider_reference TEXT,
    ADD COLUMN IF NOT EXISTS financial_post_started_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS reconcile_started_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS reconcile_attempt_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS reconcile_next_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS result_chat_id BIGINT,
    ADD COLUMN IF NOT EXISTS result_message_id BIGINT,
    ADD COLUMN IF NOT EXISTS result_message_status TEXT;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'ichancy_job_reconcile_attempt_nonnegative'
          AND conrelid = 'bot_core.ichancy_jobs'::regclass
    ) THEN
        ALTER TABLE bot_core.ichancy_jobs
            ADD CONSTRAINT ichancy_job_reconcile_attempt_nonnegative
            CHECK (reconcile_attempt_count >= 0);
    END IF;
END
$$;

CREATE UNIQUE INDEX IF NOT EXISTS ux_ichancy_job_provider_reference
    ON bot_core.ichancy_jobs(provider_reference)
    WHERE provider_reference IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_ichancy_jobs_reconcile_due
    ON bot_core.ichancy_jobs(reconcile_next_at, updated_at)
    WHERE status='reconciling' AND reconcile_next_at IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_ichancy_jobs_result_message
    ON bot_core.ichancy_jobs(status, updated_at)
    WHERE result_chat_id IS NOT NULL AND result_message_id IS NOT NULL;

-- Existing ambiguous jobs are safe to inspect again after upgrade.  No financial
-- POST is repeated by the reconciliation path; only read-only balance checks run.
UPDATE bot_core.ichancy_jobs
SET reconcile_started_at = COALESCE(reconcile_started_at, updated_at, created_at),
    reconcile_next_at = COALESCE(reconcile_next_at, NOW())
WHERE status='reconciling';
