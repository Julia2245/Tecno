-- Phase 5: bot-wallet withdrawal core.

CREATE TABLE IF NOT EXISTS bot_core.withdraw_requests (
    id UUID PRIMARY KEY,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    method TEXT NOT NULL,
    amount_wallet BIGINT NOT NULL,
    fee_pct NUMERIC(9,4) NOT NULL DEFAULT 0,
    fee_wallet BIGINT NOT NULL DEFAULT 0,
    net_wallet BIGINT NOT NULL,
    payout_amount NUMERIC(28,8) NOT NULL,
    payout_currency TEXT NOT NULL,
    exchange_rate NUMERIC(28,8),
    receiver TEXT NOT NULL,
    receiver_name TEXT,
    network TEXT,
    source_ref TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    wallet_hold_id UUID NOT NULL REFERENCES bot_core.wallet_holds(id) ON DELETE RESTRICT,
    wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE RESTRICT,
    provider_reference TEXT,
    provider_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    last_error TEXT,
    processing_by BIGINT,
    reviewed_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    processing_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    CONSTRAINT withdraw_method CHECK (method IN ('syriatel','shamcash','hawala','usdt')),
    CONSTRAINT withdraw_amount_positive CHECK (amount_wallet > 0 AND net_wallet > 0 AND payout_amount > 0),
    CONSTRAINT withdraw_fee_range CHECK (fee_pct BETWEEN 0 AND 100 AND fee_wallet >= 0),
    CONSTRAINT withdraw_fee_math CHECK (amount_wallet - fee_wallet = net_wallet),
    CONSTRAINT withdraw_currency CHECK (payout_currency ~ '^[A-Z0-9_]{2,12}$'),
    CONSTRAINT withdraw_status CHECK (status IN ('pending','processing','provider_success','needs_review','success','rejected','cancelled')),
    CONSTRAINT withdraw_actor CHECK ((processing_by IS NULL OR processing_by > 0) AND (reviewed_by IS NULL OR reviewed_by > 0)),
    CONSTRAINT withdraw_success_link CHECK ((status='success' AND wallet_operation_id IS NOT NULL AND finished_at IS NOT NULL) OR status<>'success')
);
CREATE INDEX IF NOT EXISTS idx_withdraw_pending ON bot_core.withdraw_requests(status,created_at)
    WHERE status IN ('pending','processing','provider_success','needs_review');
CREATE INDEX IF NOT EXISTS idx_withdraw_user ON bot_core.withdraw_requests(telegram_id,created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS ux_withdraw_one_active_per_user
    ON bot_core.withdraw_requests(telegram_id)
    WHERE status IN ('pending','processing','provider_success','needs_review');

CREATE TABLE IF NOT EXISTS bot_core.withdraw_events (
    id BIGSERIAL PRIMARY KEY,
    withdraw_id UUID NOT NULL REFERENCES bot_core.withdraw_requests(id) ON DELETE RESTRICT,
    event_type TEXT NOT NULL,
    actor_telegram_id BIGINT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT withdraw_event_type CHECK (event_type ~ '^[a-z][a-z0-9_]{1,63}$')
);
CREATE INDEX IF NOT EXISTS idx_withdraw_events ON bot_core.withdraw_events(withdraw_id,id);

CREATE OR REPLACE FUNCTION bot_core.reject_withdraw_audit_delete()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'withdraw audit rows cannot be deleted';
END;
$$;
DROP TRIGGER IF EXISTS withdraw_requests_no_delete ON bot_core.withdraw_requests;
CREATE TRIGGER withdraw_requests_no_delete BEFORE DELETE ON bot_core.withdraw_requests
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_withdraw_audit_delete();
DROP TRIGGER IF EXISTS withdraw_events_immutable ON bot_core.withdraw_events;
CREATE TRIGGER withdraw_events_immutable BEFORE UPDATE OR DELETE ON bot_core.withdraw_events
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_withdraw_audit_delete();

CREATE OR REPLACE FUNCTION bot_core.guard_withdraw_identity_update()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.id<>OLD.id OR NEW.telegram_id<>OLD.telegram_id OR NEW.method<>OLD.method
       OR NEW.amount_wallet<>OLD.amount_wallet OR NEW.fee_pct<>OLD.fee_pct OR NEW.fee_wallet<>OLD.fee_wallet
       OR NEW.net_wallet<>OLD.net_wallet OR NEW.payout_amount<>OLD.payout_amount
       OR NEW.payout_currency<>OLD.payout_currency OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate
       OR NEW.receiver<>OLD.receiver OR NEW.receiver_name IS DISTINCT FROM OLD.receiver_name
       OR NEW.network IS DISTINCT FROM OLD.network OR NEW.wallet_hold_id<>OLD.wallet_hold_id
       OR NEW.created_at<>OLD.created_at THEN
        RAISE EXCEPTION 'withdraw financial identity is immutable';
    END IF;
    IF OLD.status IN ('success','rejected','cancelled') THEN
        RAISE EXCEPTION 'terminal withdrawal cannot be changed';
    END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS withdraw_identity_guard ON bot_core.withdraw_requests;
CREATE TRIGGER withdraw_identity_guard BEFORE UPDATE ON bot_core.withdraw_requests
FOR EACH ROW EXECUTE FUNCTION bot_core.guard_withdraw_identity_update();
