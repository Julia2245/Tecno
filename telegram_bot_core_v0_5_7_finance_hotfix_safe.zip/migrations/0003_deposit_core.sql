-- Phase 3: bot-wallet deposit engine.
-- Provider claims and wallet credits are committed atomically by the application.

CREATE TABLE IF NOT EXISTS bot_core.deposit_runtime (
    singleton BOOLEAN PRIMARY KEY DEFAULT TRUE CHECK (singleton),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO bot_core.deposit_runtime(singleton)
VALUES (TRUE)
ON CONFLICT (singleton) DO NOTHING;

CREATE TABLE IF NOT EXISTS bot_core.reserved_transaction_numbers (
    provider_scope TEXT NOT NULL,
    provider_tx TEXT NOT NULL,
    note TEXT,
    created_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (provider_scope, provider_tx),
    CONSTRAINT reserved_tx_provider_format CHECK (provider_scope ~ '^[a-z][a-z0-9_]{1,31}$'),
    CONSTRAINT reserved_tx_value_length CHECK (char_length(provider_tx) BETWEEN 1 AND 160),
    CONSTRAINT reserved_tx_actor_positive CHECK (created_by IS NULL OR created_by > 0)
);

CREATE TABLE IF NOT EXISTS bot_core.deposit_requests (
    id UUID PRIMARY KEY,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    method TEXT NOT NULL,
    request_key TEXT UNIQUE,
    provider_scope TEXT,
    provider_tx TEXT,
    amount_input NUMERIC(28,8) NOT NULL,
    currency TEXT NOT NULL,
    rate NUMERIC(28,8) NOT NULL,
    bonus_pct NUMERIC(9,4) NOT NULL DEFAULT 0,
    bonus_source TEXT NOT NULL DEFAULT 'deposit_method',
    base_credit_syp BIGINT NOT NULL,
    bonus_credit_syp BIGINT NOT NULL DEFAULT 0,
    total_credit_syp BIGINT NOT NULL,
    status TEXT NOT NULL,
    target_ref TEXT,
    proof_file_id TEXT,
    provider_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE RESTRICT,
    reviewed_by BIGINT,
    review_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    settled_at TIMESTAMPTZ,
    CONSTRAINT deposit_method_format CHECK (method ~ '^[a-z][a-z0-9_]{1,31}$'),
    CONSTRAINT deposit_request_key_length CHECK (request_key IS NULL OR char_length(request_key) BETWEEN 8 AND 128),
    CONSTRAINT deposit_provider_scope_format CHECK (provider_scope IS NULL OR provider_scope ~ '^[a-z][a-z0-9_]{1,31}$'),
    CONSTRAINT deposit_provider_tx_length CHECK (provider_tx IS NULL OR char_length(provider_tx) BETWEEN 1 AND 160),
    CONSTRAINT deposit_provider_identity_pair CHECK (
        (provider_scope IS NULL AND provider_tx IS NULL)
        OR (provider_scope IS NOT NULL AND provider_tx IS NOT NULL)
    ),
    CONSTRAINT deposit_amount_positive CHECK (amount_input > 0),
    CONSTRAINT deposit_currency_format CHECK (currency ~ '^[A-Z0-9_]{2,12}$'),
    CONSTRAINT deposit_rate_positive CHECK (rate > 0),
    CONSTRAINT deposit_bonus_pct_range CHECK (bonus_pct BETWEEN 0 AND 100),
    CONSTRAINT deposit_credit_nonnegative CHECK (
        base_credit_syp > 0 AND bonus_credit_syp >= 0 AND total_credit_syp > 0
    ),
    CONSTRAINT deposit_credit_math CHECK (base_credit_syp + bonus_credit_syp = total_credit_syp),
    CONSTRAINT deposit_status_allowed CHECK (
        status IN ('verifying', 'manual_pending', 'success', 'rejected')
    ),
    CONSTRAINT deposit_reviewer_positive CHECK (reviewed_by IS NULL OR reviewed_by > 0),
    CONSTRAINT deposit_success_fields CHECK (
        (status = 'success' AND wallet_operation_id IS NOT NULL AND settled_at IS NOT NULL)
        OR
        (status <> 'success' AND wallet_operation_id IS NULL AND settled_at IS NULL)
    )
);

CREATE INDEX IF NOT EXISTS idx_deposit_requests_user_created
    ON bot_core.deposit_requests (telegram_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_deposit_requests_status_created
    ON bot_core.deposit_requests (status, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_deposit_requests_provider_tx
    ON bot_core.deposit_requests (provider_scope, provider_tx)
    WHERE provider_scope IS NOT NULL AND provider_tx IS NOT NULL;

-- One provider transaction/proof can have only one permanent financial owner.
-- For Sham Cash, both SYP and USD intentionally share provider_scope='shamcash'.
CREATE TABLE IF NOT EXISTS bot_core.deposit_tx_claims (
    provider_scope TEXT NOT NULL,
    provider_tx TEXT NOT NULL,
    deposit_id UUID NOT NULL UNIQUE REFERENCES bot_core.deposit_requests(id) ON DELETE RESTRICT,
    claimed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (provider_scope, provider_tx),
    CONSTRAINT deposit_claim_provider_format CHECK (provider_scope ~ '^[a-z][a-z0-9_]{1,31}$'),
    CONSTRAINT deposit_claim_tx_length CHECK (char_length(provider_tx) BETWEEN 1 AND 160)
);

CREATE TABLE IF NOT EXISTS bot_core.deposit_events (
    id BIGSERIAL PRIMARY KEY,
    deposit_id UUID NOT NULL REFERENCES bot_core.deposit_requests(id) ON DELETE RESTRICT,
    event_type TEXT NOT NULL,
    actor_telegram_id BIGINT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT deposit_event_type_format CHECK (event_type ~ '^[a-z][a-z0-9_]{1,47}$'),
    CONSTRAINT deposit_event_actor_positive CHECK (actor_telegram_id IS NULL OR actor_telegram_id > 0)
);
CREATE INDEX IF NOT EXISTS idx_deposit_events_deposit_id
    ON bot_core.deposit_events (deposit_id, id);

-- Deposit identity and money terms are immutable after creation. Only controlled
-- status/review/settlement fields may move forward.
CREATE OR REPLACE FUNCTION bot_core.guard_deposit_request_update()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF NEW.id <> OLD.id
       OR NEW.telegram_id <> OLD.telegram_id
       OR NEW.method <> OLD.method
       OR NEW.request_key IS DISTINCT FROM OLD.request_key
       OR NEW.provider_scope IS DISTINCT FROM OLD.provider_scope
       OR NEW.provider_tx IS DISTINCT FROM OLD.provider_tx
       OR NEW.amount_input <> OLD.amount_input
       OR NEW.currency <> OLD.currency
       OR NEW.rate <> OLD.rate
       OR NEW.bonus_pct <> OLD.bonus_pct
       OR NEW.bonus_source <> OLD.bonus_source
       OR NEW.base_credit_syp <> OLD.base_credit_syp
       OR NEW.bonus_credit_syp <> OLD.bonus_credit_syp
       OR NEW.total_credit_syp <> OLD.total_credit_syp
       OR NEW.target_ref IS DISTINCT FROM OLD.target_ref
       OR NEW.proof_file_id IS DISTINCT FROM OLD.proof_file_id
       OR NEW.provider_payload <> OLD.provider_payload
       OR NEW.created_at <> OLD.created_at THEN
        RAISE EXCEPTION 'deposit identity/financial terms are immutable';
    END IF;

    IF OLD.status IN ('success', 'rejected') THEN
        RAISE EXCEPTION 'terminal deposit cannot be changed';
    END IF;

    IF OLD.status = 'manual_pending' AND NEW.status NOT IN ('success', 'rejected') THEN
        RAISE EXCEPTION 'manual deposit can only be approved or rejected';
    END IF;

    IF OLD.status = 'verifying' AND NEW.status <> 'success' THEN
        RAISE EXCEPTION 'verified automatic deposit can only settle successfully';
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS deposit_request_update_guard ON bot_core.deposit_requests;
CREATE TRIGGER deposit_request_update_guard
BEFORE UPDATE ON bot_core.deposit_requests
FOR EACH ROW EXECUTE FUNCTION bot_core.guard_deposit_request_update();

CREATE OR REPLACE FUNCTION bot_core.reject_deposit_delete()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    RAISE EXCEPTION 'deposit audit rows cannot be deleted';
END;
$$;

DROP TRIGGER IF EXISTS deposit_requests_no_delete ON bot_core.deposit_requests;
CREATE TRIGGER deposit_requests_no_delete
BEFORE DELETE ON bot_core.deposit_requests
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_deposit_delete();

DROP TRIGGER IF EXISTS deposit_events_immutable ON bot_core.deposit_events;
CREATE TRIGGER deposit_events_immutable
BEFORE UPDATE OR DELETE ON bot_core.deposit_events
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_deposit_delete();

-- A claimed provider transaction/proof remains permanently claimed even when a
-- manual request is rejected. This is deliberately stricter than the legacy bot:
-- a rejected transfer cannot be replayed through another user or method. Historical
-- exceptions can be handled explicitly through the reserved/import tooling later.
DROP TRIGGER IF EXISTS deposit_tx_claims_immutable ON bot_core.deposit_tx_claims;
CREATE TRIGGER deposit_tx_claims_immutable
BEFORE UPDATE OR DELETE ON bot_core.deposit_tx_claims
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_deposit_delete();

-- A successful deposit must point to the exact immutable wallet credit operation.
CREATE OR REPLACE FUNCTION bot_core.assert_successful_deposit_wallet_link()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    op_key TEXT;
    op_type TEXT;
    ledger_delta BIGINT;
    ledger_telegram_id BIGINT;
    ledger_asset TEXT;
    ledger_bucket TEXT;
    claim_deposit_id UUID;
BEGIN
    IF NEW.status <> 'success' THEN
        RETURN NULL;
    END IF;

    SELECT idempotency_key, operation_type
      INTO op_key, op_type
      FROM bot_core.wallet_operations
     WHERE id = NEW.wallet_operation_id;

    IF NOT FOUND OR op_type <> 'credit' OR op_key <> ('deposit:' || NEW.id::text) THEN
        RAISE EXCEPTION 'successful deposit has invalid wallet operation link';
    END IF;

    SELECT l.available_delta, a.telegram_id, a.asset_code, a.bucket
      INTO ledger_delta, ledger_telegram_id, ledger_asset, ledger_bucket
      FROM bot_core.wallet_ledger l
      JOIN bot_core.wallet_accounts a ON a.id = l.account_id
     WHERE l.operation_id = NEW.wallet_operation_id;

    IF NOT FOUND
       OR ledger_delta <> NEW.total_credit_syp
       OR ledger_telegram_id <> NEW.telegram_id
       OR ledger_asset <> 'SYP'
       OR ledger_bucket <> 'cash' THEN
        RAISE EXCEPTION 'successful deposit wallet amount/account mismatch';
    END IF;

    IF NEW.provider_scope IS NOT NULL AND NEW.provider_tx IS NOT NULL THEN
        SELECT deposit_id
          INTO claim_deposit_id
          FROM bot_core.deposit_tx_claims
         WHERE provider_scope = NEW.provider_scope
           AND provider_tx = NEW.provider_tx;

        IF NOT FOUND OR claim_deposit_id <> NEW.id THEN
            RAISE EXCEPTION 'successful deposit does not own provider transaction claim';
        END IF;
    END IF;

    RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS deposit_wallet_link_consistency ON bot_core.deposit_requests;
CREATE CONSTRAINT TRIGGER deposit_wallet_link_consistency
AFTER INSERT OR UPDATE ON bot_core.deposit_requests
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION bot_core.assert_successful_deposit_wallet_link();
