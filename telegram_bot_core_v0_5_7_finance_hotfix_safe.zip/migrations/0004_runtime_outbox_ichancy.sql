-- Phase 4: dynamic runtime settings, durable notifications and iChancy core.

CREATE TABLE IF NOT EXISTS bot_core.runtime_settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    updated_by BIGINT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT runtime_setting_key CHECK (key ~ '^[a-z][a-z0-9_.]{1,95}$'),
    CONSTRAINT runtime_setting_actor CHECK (updated_by IS NULL OR updated_by > 0)
);

CREATE TABLE IF NOT EXISTS bot_core.notification_outbox (
    id UUID PRIMARY KEY,
    event_key TEXT NOT NULL UNIQUE,
    target_key TEXT,
    target_chat_id BIGINT,
    text TEXT NOT NULL,
    parse_mode TEXT NOT NULL DEFAULT 'HTML',
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    locked_at TIMESTAMPTZ,
    last_error TEXT,
    telegram_message_id BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sent_at TIMESTAMPTZ,
    CONSTRAINT outbox_event_key_len CHECK (char_length(event_key) BETWEEN 4 AND 180),
    CONSTRAINT outbox_target_key CHECK (target_key IS NULL OR target_key ~ '^[a-z][a-z0-9_.]{1,95}$'),
    CONSTRAINT outbox_target_one CHECK ((target_key IS NOT NULL) <> (target_chat_id IS NOT NULL)),
    CONSTRAINT outbox_parse_mode CHECK (parse_mode IN ('HTML','MarkdownV2','plain')),
    CONSTRAINT outbox_status CHECK (status IN ('pending','sending','sent','paused')),
    CONSTRAINT outbox_attempts_nonnegative CHECK (attempts >= 0),
    CONSTRAINT outbox_sent_fields CHECK (
        (status='sent' AND sent_at IS NOT NULL AND telegram_message_id IS NOT NULL)
        OR status <> 'sent'
    )
);
CREATE INDEX IF NOT EXISTS idx_notification_outbox_due
    ON bot_core.notification_outbox(status, next_attempt_at, created_at)
    WHERE status IN ('pending','sending');

CREATE SEQUENCE IF NOT EXISTS bot_core.ichancy_username_seq START WITH 1 INCREMENT BY 1 NO CYCLE;
CREATE SEQUENCE IF NOT EXISTS bot_core.ichancy_cashier_generation_seq START WITH 1 INCREMENT BY 1 NO CYCLE;

CREATE TABLE IF NOT EXISTS bot_core.ichancy_cashiers (
    id UUID PRIMARY KEY,
    generation BIGINT NOT NULL UNIQUE DEFAULT nextval('bot_core.ichancy_cashier_generation_seq'),
    label TEXT,
    api_username_cipher TEXT NOT NULL,
    api_password_cipher TEXT NOT NULL,
    parent_id TEXT,
    currency TEXT NOT NULL DEFAULT 'SYP',
    base_url TEXT NOT NULL DEFAULT 'https://agents.ichancy.com',
    gateway_url TEXT,
    gateway_secret_cipher TEXT,
    status TEXT NOT NULL DEFAULT 'staged',
    last_tested_at TIMESTAMPTZ,
    last_test_ok BOOLEAN,
    last_test_error TEXT,
    created_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    activated_at TIMESTAMPTZ,
    retired_at TIMESTAMPTZ,
    CONSTRAINT ichancy_cashier_status CHECK (status IN ('staged','active','retiring','retired')),
    CONSTRAINT ichancy_cashier_generation_positive CHECK (generation > 0),
    CONSTRAINT ichancy_cashier_actor CHECK (created_by IS NULL OR created_by > 0)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_ichancy_one_active_cashier
    ON bot_core.ichancy_cashiers((status)) WHERE status='active';

CREATE TABLE IF NOT EXISTS bot_core.ichancy_account_creations (
    id UUID PRIMARY KEY,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    cashier_id UUID NOT NULL REFERENCES bot_core.ichancy_cashiers(id) ON DELETE RESTRICT,
    sequence_no BIGINT NOT NULL UNIQUE,
    requested_name TEXT NOT NULL,
    normalized_name TEXT NOT NULL,
    final_username TEXT NOT NULL UNIQUE,
    password_cipher TEXT NOT NULL,
    email TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'creating',
    player_id TEXT,
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMPTZ,
    CONSTRAINT ichancy_creation_seq_positive CHECK (sequence_no > 0),
    CONSTRAINT ichancy_creation_status CHECK (status IN ('creating','created','failed','uncertain'))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_ichancy_creation_inflight_user
    ON bot_core.ichancy_account_creations(telegram_id)
    WHERE status IN ('creating','uncertain');

CREATE TABLE IF NOT EXISTS bot_core.ichancy_accounts (
    id UUID PRIMARY KEY,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    cashier_id UUID NOT NULL REFERENCES bot_core.ichancy_cashiers(id) ON DELETE RESTRICT,
    creation_id UUID UNIQUE REFERENCES bot_core.ichancy_account_creations(id) ON DELETE RESTRICT,
    sequence_no BIGINT NOT NULL UNIQUE,
    username TEXT NOT NULL UNIQUE,
    password_cipher TEXT NOT NULL,
    email TEXT,
    player_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    balance_at_retirement BIGINT,
    retirement_checked_at TIMESTAMPTZ,
    retirement_check_status TEXT,
    settlement_status TEXT NOT NULL DEFAULT 'none',
    compensated_amount BIGINT NOT NULL DEFAULT 0,
    compensation_wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    retired_at TIMESTAMPTZ,
    CONSTRAINT ichancy_account_status CHECK (status IN ('active','retiring','retired')),
    CONSTRAINT ichancy_retirement_check_status CHECK (
        retirement_check_status IS NULL OR retirement_check_status IN ('zero','below_minimum','withdrawable','check_failed','settling','rechecking','settled','residual_below_minimum','review')
    ),
    CONSTRAINT ichancy_settlement_status CHECK (settlement_status IN ('none','not_needed','pending','automatic','manual_compensated','review')),
    CONSTRAINT ichancy_retirement_balance_nonnegative CHECK (balance_at_retirement IS NULL OR balance_at_retirement >= 0),
    CONSTRAINT ichancy_compensation_nonnegative CHECK (compensated_amount >= 0)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_ichancy_one_active_account_per_user
    ON bot_core.ichancy_accounts(telegram_id) WHERE status='active';
CREATE INDEX IF NOT EXISTS idx_ichancy_accounts_cashier_status
    ON bot_core.ichancy_accounts(cashier_id, status, telegram_id);
CREATE INDEX IF NOT EXISTS idx_ichancy_accounts_player
    ON bot_core.ichancy_accounts(player_id);

CREATE TABLE IF NOT EXISTS bot_core.ichancy_jobs (
    id UUID PRIMARY KEY,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    account_id UUID NOT NULL REFERENCES bot_core.ichancy_accounts(id) ON DELETE RESTRICT,
    cashier_id UUID NOT NULL REFERENCES bot_core.ichancy_cashiers(id) ON DELETE RESTRICT,
    operation_type TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT 'normal',
    amount BIGINT NOT NULL,
    status TEXT NOT NULL DEFAULT 'queued',
    idempotency_key TEXT NOT NULL UNIQUE,
    wallet_hold_id UUID REFERENCES bot_core.wallet_holds(id) ON DELETE RESTRICT,
    wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE RESTRICT,
    player_balance_before BIGINT,
    player_balance_after BIGINT,
    cashier_balance_before BIGINT,
    cashier_balance_after BIGINT,
    remote_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    audit_notified BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    claimed_at TIMESTAMPTZ,
    remote_success_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT ichancy_job_op CHECK (operation_type IN ('deposit','withdraw','retirement_withdraw')),
    CONSTRAINT ichancy_job_status CHECK (status IN ('queued','executing','remote_success','reconciling','success','failed')),
    CONSTRAINT ichancy_job_amount_positive CHECK (amount > 0),
    CONSTRAINT ichancy_job_attempt_nonnegative CHECK (attempt_count >= 0),
    CONSTRAINT ichancy_job_deposit_hold CHECK (
        (operation_type='deposit' AND wallet_hold_id IS NOT NULL)
        OR operation_type <> 'deposit'
    )
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_ichancy_one_active_job_per_user
    ON bot_core.ichancy_jobs(telegram_id)
    WHERE status IN ('queued','executing','remote_success','reconciling');
CREATE INDEX IF NOT EXISTS idx_ichancy_jobs_queue
    ON bot_core.ichancy_jobs(status, created_at)
    WHERE status IN ('queued','executing','remote_success','reconciling');

CREATE TABLE IF NOT EXISTS bot_core.ichancy_job_events (
    id BIGSERIAL PRIMARY KEY,
    job_id UUID NOT NULL REFERENCES bot_core.ichancy_jobs(id) ON DELETE RESTRICT,
    event_type TEXT NOT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT ichancy_job_event_type CHECK (event_type ~ '^[a-z][a-z0-9_]{1,63}$')
);
CREATE INDEX IF NOT EXISTS idx_ichancy_job_events_job ON bot_core.ichancy_job_events(job_id,id);

CREATE TABLE IF NOT EXISTS bot_core.ichancy_cashier_replacements (
    id UUID PRIMARY KEY,
    old_cashier_id UUID NOT NULL REFERENCES bot_core.ichancy_cashiers(id) ON DELETE RESTRICT,
    new_cashier_id UUID NOT NULL REFERENCES bot_core.ichancy_cashiers(id) ON DELETE RESTRICT,
    status TEXT NOT NULL DEFAULT 'preparing',
    min_withdraw_snapshot BIGINT NOT NULL,
    total_accounts INTEGER NOT NULL DEFAULT 0,
    checked_accounts INTEGER NOT NULL DEFAULT 0,
    zero_accounts INTEGER NOT NULL DEFAULT 0,
    below_minimum_accounts INTEGER NOT NULL DEFAULT 0,
    withdrawable_accounts INTEGER NOT NULL DEFAULT 0,
    failed_checks INTEGER NOT NULL DEFAULT 0,
    settled_accounts INTEGER NOT NULL DEFAULT 0,
    review_accounts INTEGER NOT NULL DEFAULT 0,
    total_balance_snapshot BIGINT NOT NULL DEFAULT 0,
    total_withdrawn BIGINT NOT NULL DEFAULT 0,
    total_wallet_credited BIGINT NOT NULL DEFAULT 0,
    progress_chat_id BIGINT,
    progress_message_id BIGINT,
    last_progress_edit_at TIMESTAMPTZ,
    created_by BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMPTZ,
    CONSTRAINT ichancy_replacement_status CHECK (status IN ('preparing','checking','settling','ready','completed','cancelled','blocked')),
    CONSTRAINT ichancy_replacement_min_positive CHECK (min_withdraw_snapshot > 0),
    CONSTRAINT ichancy_replacement_actor_positive CHECK (created_by > 0),
    CONSTRAINT ichancy_replacement_different_cashiers CHECK (old_cashier_id <> new_cashier_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_ichancy_one_open_replacement
    ON bot_core.ichancy_cashier_replacements((TRUE))
    WHERE status IN ('preparing','checking','settling','ready','blocked');

CREATE TABLE IF NOT EXISTS bot_core.ichancy_retirement_records (
    id UUID PRIMARY KEY,
    replacement_id UUID NOT NULL REFERENCES bot_core.ichancy_cashier_replacements(id) ON DELETE RESTRICT,
    account_id UUID NOT NULL REFERENCES bot_core.ichancy_accounts(id) ON DELETE RESTRICT,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE RESTRICT,
    player_id TEXT NOT NULL,
    username TEXT NOT NULL,
    balance_snapshot BIGINT,
    final_balance_snapshot BIGINT,
    classification TEXT NOT NULL DEFAULT 'unchecked',
    check_error TEXT,
    settlement_job_id UUID REFERENCES bot_core.ichancy_jobs(id) ON DELETE RESTRICT,
    settlement_attempt INTEGER NOT NULL DEFAULT 1,
    compensated_amount BIGINT NOT NULL DEFAULT 0,
    compensation_wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE RESTRICT,
    checked_at TIMESTAMPTZ,
    settled_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT ichancy_retirement_unique_account UNIQUE(replacement_id, account_id),
    CONSTRAINT ichancy_retirement_class CHECK (classification IN ('unchecked','checking','zero','below_minimum','withdrawable','check_failed','settling','rechecking','settled','residual_below_minimum','review')),
    CONSTRAINT ichancy_retirement_balance CHECK (balance_snapshot IS NULL OR balance_snapshot >= 0),
    CONSTRAINT ichancy_retirement_final_balance CHECK (final_balance_snapshot IS NULL OR final_balance_snapshot >= 0),
    CONSTRAINT ichancy_retirement_attempt_positive CHECK (settlement_attempt > 0),
    CONSTRAINT ichancy_retirement_comp CHECK (compensated_amount >= 0)
);
CREATE INDEX IF NOT EXISTS idx_ichancy_retirement_lookup
    ON bot_core.ichancy_retirement_records(telegram_id, created_at DESC);

CREATE TABLE IF NOT EXISTS bot_core.ichancy_retirement_settlements (
    id UUID PRIMARY KEY,
    retirement_record_id UUID NOT NULL REFERENCES bot_core.ichancy_retirement_records(id) ON DELETE RESTRICT,
    attempt INTEGER NOT NULL,
    job_id UUID NOT NULL UNIQUE REFERENCES bot_core.ichancy_jobs(id) ON DELETE RESTRICT,
    planned_amount BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT ichancy_retirement_settlement_attempt_positive CHECK (attempt > 0),
    CONSTRAINT ichancy_retirement_settlement_amount_positive CHECK (planned_amount > 0),
    CONSTRAINT ichancy_retirement_settlement_unique_attempt UNIQUE(retirement_record_id, attempt)
);
CREATE INDEX IF NOT EXISTS idx_ichancy_retirement_settlements_record
    ON bot_core.ichancy_retirement_settlements(retirement_record_id, attempt);

-- Financial/audit history must not be deleted casually.
CREATE OR REPLACE FUNCTION bot_core.reject_ichancy_audit_delete()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'iChancy audit rows cannot be deleted';
END;
$$;
DROP TRIGGER IF EXISTS ichancy_jobs_no_delete ON bot_core.ichancy_jobs;
CREATE TRIGGER ichancy_jobs_no_delete BEFORE DELETE ON bot_core.ichancy_jobs
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_ichancy_audit_delete();
DROP TRIGGER IF EXISTS ichancy_job_events_immutable ON bot_core.ichancy_job_events;
CREATE TRIGGER ichancy_job_events_immutable BEFORE UPDATE OR DELETE ON bot_core.ichancy_job_events
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_ichancy_audit_delete();
DROP TRIGGER IF EXISTS ichancy_retirement_no_delete ON bot_core.ichancy_retirement_records;
CREATE TRIGGER ichancy_retirement_no_delete BEFORE DELETE ON bot_core.ichancy_retirement_records
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_ichancy_audit_delete();
DROP TRIGGER IF EXISTS ichancy_retirement_settlements_immutable ON bot_core.ichancy_retirement_settlements;
CREATE TRIGGER ichancy_retirement_settlements_immutable BEFORE UPDATE OR DELETE ON bot_core.ichancy_retirement_settlements
FOR EACH ROW EXECUTE FUNCTION bot_core.reject_ichancy_audit_delete();
