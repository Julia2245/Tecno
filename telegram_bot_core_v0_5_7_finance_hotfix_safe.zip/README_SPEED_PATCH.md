# Phase 3.1 — Fast navigation patch

This patch changes UI timing only. It does not alter wallet, ledger, deposit,
provider, migration, settlement, idempotency, or financial database logic.

The callback ACK and the screen edit are now allowed to run concurrently instead
of serialising `answerCallbackQuery` before `editMessageText`.

After applying on the server:

```bash
python -m compileall app scripts tests
python -m pytest -q
systemctl restart tecno.service
```
