from __future__ import annotations

import html
from decimal import Decimal
from uuid import UUID

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.emojis import (
    PROCESSING,
    SUCCESS,
    BOT_DEPOSIT_EMOJI_ID,
    BOT_WITHDRAW_EMOJI_ID,
    SHAM_CASH_EMOJI_ID,
    SYRIATEL_CASH_EMOJI_ID,
)
from app.core.withdrawals import WithdrawStateError, WithdrawValidationError
from app.services.runtime_settings import RuntimeSettingsService
from app.core.syriatel import parse_syriatel_cash_codes
from app.services.deposits import DepositService
from app.services.withdrawals import WithdrawService

router = Router(name="admin_finance")


class AdminFinanceStates(StatesGroup):
    waiting_setting = State()


def _admin(user_id: int, settings: Settings) -> bool:
    return user_id in settings.super_admin_ids


async def _delete_input(message: Message) -> None:
    try:
        await message.delete()
    except Exception:
        pass


def _btn(text: str, callback_data: str, icon_id: str | None = None) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data=callback_data, icon_custom_emoji_id=icon_id)


def _finance_view() -> tuple[str, InlineKeyboardMarkup]:
    return (
        "💳 <b>إدارة الشحن والسحب</b>\n\nاختر القسم:",
        InlineKeyboardMarkup(inline_keyboard=[
            [
                _btn("إدارة الشحن", "admin:finance:deposits", BOT_DEPOSIT_EMOJI_ID),
                _btn("إدارة السحب", "admin:finance:withdraws", BOT_WITHDRAW_EMOJI_ID),
            ],
            [_btn("💱 معامل العملة المحلية", "admin:setting:money.local_syp_wallet_multiplier")],
            [_btn("🚨 تنبيهات المبالغ الكبيرة", "admin:finance:alerts")],
            [_btn("📢 قنوات العمليات", "admin:finance:channels")],
            [_btn("⬅️ لوحة الإدارة", "admin:home")],
        ]),
    )


def _fmt_decimal(value: Decimal) -> str:
    return str(int(value)) if value == value.to_integral_value() else format(value.normalize(), "f")


_NUM_TRANSLATION = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")

def _normalize_numeric_input(raw: str, *, decimal: bool = False) -> str:
    value = str(raw or "").translate(_NUM_TRANSLATION).strip()
    value = value.replace("٬", "").replace(",", "")
    if decimal:
        value = value.replace("٫", ".")
    return value


def _mode_label(value: str) -> str:
    return {"auto": "آلي", "manual": "يدوي", "off": "متوقف"}.get(str(value).lower(), str(value))


def _deposits_view(runtime: RuntimeSettingsService, service: DepositService) -> tuple[str, InlineKeyboardMarkup]:
    mult = runtime.get_decimal("money.local_syp_wallet_multiplier", 100)
    sy = service.method_config("syriatel")
    sh_syp = service.method_config("sham_syp")
    sh_usd = service.method_config("sham_usd")
    whish = service.method_config("whish_money")
    trc = service.method_config("binance_trc20")
    bep = service.method_config("binance_bep20")
    api_status = "✅ جاهز" if service.api_syria.configured else "❌ غير مضبوط"
    text = (
        "💳 <b>إدارة الشحن</b>\n\n"
        f"🔌 API Syria: <b>{api_status}</b>\n"
        f"💱 العملة المحلية: <b>1 = {_fmt_decimal(mult)}</b> رصيد بالمحفظة\n\n"
        f"📱 سيرياتيل: <b>{_mode_label(sy.mode)}</b> — حد {_fmt_decimal(sy.minimum)}\n"
        f"💵 شام SYP: <b>{_mode_label(sh_syp.mode)}</b> — حد {_fmt_decimal(sh_syp.minimum)}\n"
        f"💵 شام USD: <b>{_mode_label(sh_usd.mode)}</b> — حد {_fmt_decimal(sh_usd.minimum)}\n"
        f"💸 Whish: <b>{'مفعل' if whish.enabled else 'متوقف'}</b> — حد {_fmt_decimal(whish.minimum)}\n"
        f"🪙 Binance TRC20: <b>{'مفعل' if trc.enabled else 'متوقف'}</b> — حد {_fmt_decimal(trc.minimum)}\n"
        f"🪙 Binance BEP20: <b>{'مفعل' if bep.enabled else 'متوقف'}</b> — حد {_fmt_decimal(bep.minimum)}"
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [_btn("سيرياتيل كاش", "admin:deposit:method:syriatel", SYRIATEL_CASH_EMOJI_ID)],
        [
            _btn("شام كاش SYP", "admin:deposit:method:sham_syp", SHAM_CASH_EMOJI_ID),
            _btn("شام كاش USD", "admin:deposit:method:sham_usd", SHAM_CASH_EMOJI_ID),
        ],
        [_btn("💸 Whish Money", "admin:deposit:method:whish_money")],
        [
            _btn("🪙 Binance TRC20", "admin:deposit:method:binance_trc20"),
            _btn("🪙 Binance BEP20", "admin:deposit:method:binance_bep20"),
        ],
        [_btn("📋 طلبات الشحن اليدوي", "admin:deposits:pending")],
        [_btn("💱 تعديل معامل العملة", "admin:setting:money.local_syp_wallet_multiplier")],
        [_btn("⬅️ إدارة الشحن والسحب", "admin:finance")],
    ])
    return text, kb


def _deposit_method_view(method: str, runtime: RuntimeSettingsService, service: DepositService) -> tuple[str, InlineKeyboardMarkup]:
    cfg = service.method_config(method)
    rows: list[list[InlineKeyboardButton]] = []
    state_text = "✅ متاحة" if cfg.enabled else "❌ غير متاحة"
    text = (
        f"💳 <b>إعدادات {html.escape(cfg.label)}</b>\n\n"
        f"الحالة: <b>{state_text}</b>\n"
        f"الوضع: <b>{_mode_label(cfg.mode)}</b>\n"
        f"الحد الأدنى: <b>{_fmt_decimal(cfg.minimum)} {html.escape(cfg.currency)}</b>\n"
        f"التحويل للمحفظة: <b>1 {html.escape(cfg.currency)} = {_fmt_decimal(cfg.rate)} SYP</b>\n"
        f"الحساب/العنوان: <code>{html.escape(cfg.target or 'غير مضبوط')}</code>"
    )
    min_key = {
        "syriatel": "deposit.syriatel.min",
        "sham_syp": "deposit.sham_syp.min",
        "sham_usd": "deposit.sham_usd.min",
        "whish_money": "deposit.whish_money.min",
        "binance_trc20": "deposit.binance_trc20.min",
        "binance_bep20": "deposit.binance_bep20.min",
    }[method]
    rows.append([_btn("📏 تعديل الحد الأدنى", f"admin:setting:{min_key}")])
    if method == "syriatel":
        rows.append([
            _btn("Auto", "admin:deposit:mode:syriatel:auto"),
            _btn("Manual", "admin:deposit:mode:syriatel:manual"),
            _btn("Off", "admin:deposit:mode:syriatel:off"),
        ])
        rows.append([_btn("أكواد/أرقام الاستلام", "admin:setting:deposit.syriatel.codes", SYRIATEL_CASH_EMOJI_ID)])
    elif method in {"sham_syp", "sham_usd"}:
        rows.append([
            _btn("Auto", f"admin:deposit:mode:sham:auto:{method}"),
            _btn("Manual", f"admin:deposit:mode:sham:manual:{method}"),
            _btn("Off", f"admin:deposit:mode:sham:off:{method}"),
        ])
        addr_key = "deposit.sham.address_syp" if method == "sham_syp" else "deposit.sham.address_usd"
        rows.append([_btn("تعديل عنوان الاستلام", f"admin:setting:{addr_key}", SHAM_CASH_EMOJI_ID)])
    elif method == "whish_money":
        rows.append([_btn(f"{'✅' if runtime.get_bool('deposit.whish.enabled', service.settings.whish_money_enabled) else '❌'} تفعيل/إيقاف", "admin:deposit:toggle:whish")])
    else:
        rows.append([_btn(f"{'✅' if runtime.get_bool('deposit.binance.enabled', service.settings.binance_deposit_enabled) else '❌'} تفعيل/إيقاف Binance", "admin:deposit:toggle:binance")])
    rows.append([_btn("⬅️ إدارة الشحن", "admin:finance:deposits")])
    return text, InlineKeyboardMarkup(inline_keyboard=rows)


def _withdraws_view(runtime: RuntimeSettingsService, service: WithdrawService) -> tuple[str, InlineKeyboardMarkup]:
    states = []
    for method, label in (("syriatel", "سيرياتيل"), ("shamcash", "شام كاش"), ("hawala", "حوالة"), ("usdt", "USDT")):
        states.append(f"{'✅' if service.method_enabled(method) else '❌'} {label}")
    text = (
        "💸 <b>إدارة السحب</b>\n\n"
        + " • ".join(states)
        + "\n\nكل وسيلة لها إعداداتها وحدها، وأي تعديل يُطبق فوراً على الطلبات الجديدة."
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            _btn("📋 الطلبات المعلقة", "admin:withdraws:pending"),
            _btn("⚠️ قيد المراجعة", "admin:withdraws:review"),
        ],
        [
            _btn("سيرياتيل كاش", "admin:withdraw:method:syriatel", SYRIATEL_CASH_EMOJI_ID),
            _btn("شام كاش", "admin:withdraw:method:shamcash", SHAM_CASH_EMOJI_ID),
        ],
        [
            _btn("💸 الحوالات", "admin:withdraw:method:hawala"),
            _btn("🪙 USDT", "admin:withdraw:method:usdt"),
        ],
        [_btn("💸 إدارة العمولة", "admin:withdraw:commission")],
        [_btn("🛡️ إعدادات الأمان", "admin:withdraw:security")],
        [_btn("✅ سجل السحوبات", "admin:withdraws:history")],
        [_btn("⬅️ إدارة الشحن والسحب", "admin:finance")],
    ])
    return text, kb


def _withdraw_method_view(method: str, runtime: RuntimeSettingsService, service: WithdrawService) -> tuple[str, InlineKeyboardMarkup]:
    labels = {"syriatel": "سيرياتيل كاش", "shamcash": "شام كاش", "hawala": "الحوالات", "usdt": "USDT"}
    label = labels[method]
    enabled = service.method_enabled(method)
    minimum = service.minimum(method)
    fee = service.fee_pct(method)
    rows: list[list[InlineKeyboardButton]] = [
        [_btn(f"{'✅' if enabled else '❌'} تفعيل/إيقاف", f"admin:withdraw:toggle:{method}")],
    ]
    if method == "syriatel":
        min_key = "withdraw.syriatel.min_wallet"
        extra = f"حسابات المصدر: <code>{html.escape(', '.join(service.syriatel_sources()) or 'غير مضبوطة')}</code>"
    elif method == "shamcash":
        min_key = "withdraw.shamcash.min_wallet"
        extra = f"حساب المصدر: <code>{html.escape(service.shamcash_source() or 'غير مضبوط')}</code>"
    elif method == "hawala":
        min_key = "withdraw.hawala_min_wallet"
        extra = "التنفيذ: <b>يدوي مع تأكيد الدفع</b>"
    else:
        min_key = "withdraw.usdt.min_wallet"
        extra = f"سعر USDT: <b>{_fmt_decimal(service.usdt_rate())}</b> من رصيد المحفظة"
    text = (
        f"💸 <b>إعدادات {html.escape(label)}</b>\n\n"
        f"الحالة: <b>{'✅ مفعلة' if enabled else '❌ متوقفة'}</b>\n"
        f"الحد الأدنى: <b>{minimum:,}</b>\n"
        f"العمولة: <b>{_fmt_decimal(fee)}%</b>\n"
        f"{extra}"
    )
    rows.append([_btn("📏 تعديل الحد الأدنى", f"admin:setting:{min_key}")])
    if method == "usdt":
        trc = service.network_enabled("TRC20")
        bep = service.network_enabled("BEP20")
        rows.append([
            _btn(f"{'✅' if trc else '❌'} TRC20", "admin:withdraw:network:TRC20"),
            _btn(f"{'✅' if bep else '❌'} BEP20", "admin:withdraw:network:BEP20"),
        ])
        rows.append([_btn("💵 تعديل سعر USDT", "admin:setting:withdraw.usdt.rate")])
    rows.append([_btn("⬅️ إدارة السحب", "admin:finance:withdraws")])
    return text, InlineKeyboardMarkup(inline_keyboard=rows)


def _withdraw_commission_view(runtime: RuntimeSettingsService) -> tuple[str, InlineKeyboardMarkup]:
    regular = runtime.get_decimal("withdraw.fee_pct", 0)
    hawala = runtime.get_decimal("withdraw.hawala_fee_pct", 0)
    return (
        "💸 <b>إدارة عمولة السحب</b>\n\n"
        f"العمولة العامة: <b>{_fmt_decimal(regular)}%</b>\n"
        f"عمولة الحوالات: <b>{_fmt_decimal(hawala)}%</b>",
        InlineKeyboardMarkup(inline_keyboard=[
            [_btn("💸 تعديل العمولة العامة", "admin:setting:withdraw.fee_pct")],
            [_btn("💸 تعديل عمولة الحوالات", "admin:setting:withdraw.hawala_fee_pct")],
            [_btn("⬅️ إدارة السحب", "admin:finance:withdraws")],
        ]),
    )


def _withdraw_security_view() -> tuple[str, InlineKeyboardMarkup]:
    return (
        "🛡️ <b>أمان السحب المالي</b>\n\n"
        "✅ حجز الرصيد وطلب السحب بمعاملة ذرية واحدة.\n"
        "✅ Claim ذري قبل التنفيذ يمنع ضغطتين/أدمنين من تنفيذ الطلب مرتين.\n"
        "✅ الفشل المؤكد يعيد الطلب للانتظار بدون فك الحجز.\n"
        "✅ Timeout/Network بعد POST لا يُعاد إرساله؛ يتحول لمراجعة.\n"
        "✅ نجاح المزود يُثبت محلياً بدون POST مالي ثانٍ.\n\n"
        "هذه الحمايات أساسية وغير قابلة للإيقاف من الواجهة.",
        InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ إدارة السحب", "admin:finance:withdraws")]]),
    )


def _alerts_menu(runtime: RuntimeSettingsService) -> InlineKeyboardMarkup:
    specs = [
        ("alerts.ichancy_deposit_large", "شحن iChancy"),
        ("alerts.ichancy_withdraw_large", "سحب iChancy"),
        ("alerts.bot_deposit_large", "شحن البوت"),
        ("alerts.bot_withdraw_large", "سحب البوت"),
    ]
    rows = []
    for key, label in specs:
        value = runtime.get_int(key, 0)
        shown = f"{value:,}" if value > 0 else "متوقف"
        rows.append([_btn(f"🚨 {label}: {shown}", f"admin:setting:{key}")])
    rows.append([_btn("⬅️ رجوع", "admin:finance")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _channels_view(runtime: RuntimeSettingsService) -> tuple[str, InlineKeyboardMarkup]:
    def shown(key: str) -> str:
        value = runtime.get(key)
        return "غير مضبوطة" if value in (None, "", 0, "0") else str(value)
    text = (
        "📢 <b>قنوات الإشعارات</b>\n\n"
        "عمليات محفظة البوت مفصولة بالكامل: الشحن لا يذهب لقناة السحب والعكس.\n\n"
        f"💳 قناة الشحن: <code>{html.escape(shown('notify.bot_deposits'))}</code>\n"
        f"💸 قناة السحب: <code>{html.escape(shown('notify.bot_withdrawals'))}</code>\n"
        f"🎰 عمليات iChancy: <code>{html.escape(shown('notify.ichancy_operations'))}</code>\n"
        f"👤 حسابات iChancy: <code>{html.escape(shown('notify.ichancy_accounts'))}</code>"
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [_btn("قناة عمليات الشحن", "admin:setting:notify.bot_deposits", BOT_DEPOSIT_EMOJI_ID)],
        [_btn("قناة عمليات السحب", "admin:setting:notify.bot_withdrawals", BOT_WITHDRAW_EMOJI_ID)],
        [
            _btn("🧪 اختبار الشحن", "admin:channel:test:bot_deposits"),
            _btn("🧪 اختبار السحب", "admin:channel:test:bot_withdrawals"),
        ],
        [_btn("🎰 قناة عمليات iChancy", "admin:setting:notify.ichancy_operations")],
        [_btn("👤 قناة حسابات iChancy", "admin:setting:notify.ichancy_accounts")],
        [_btn("⬅️ رجوع", "admin:finance")],
    ])
    return text, kb


_SETTING_META = {
    "money.local_syp_wallet_multiplier": ("معامل تحويل العملة المحلية إلى رصيد المحفظة", "decimal", "admin:finance"),
    "alerts.ichancy_deposit_large": ("حد تنبيه شحن iChancy الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "alerts.ichancy_withdraw_large": ("حد تنبيه سحب iChancy الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "alerts.bot_deposit_large": ("حد تنبيه شحن البوت الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "alerts.bot_withdraw_large": ("حد تنبيه سحب البوت الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "notify.ichancy_accounts": ("معرف قناة حسابات iChancy", "chat", "admin:finance:channels"),
    "notify.ichancy_operations": ("معرف قناة عمليات iChancy", "chat", "admin:finance:channels"),
    "notify.bot_deposits": ("معرف قناة عمليات الشحن", "chat", "admin:finance:channels"),
    "notify.bot_withdrawals": ("معرف قناة عمليات السحب", "chat", "admin:finance:channels"),
    "deposit.syriatel.min": ("الحد الأدنى لشحن سيرياتيل كاش", "decimal", "admin:deposit:method:syriatel"),
    "deposit.sham_syp.min": ("الحد الأدنى لشحن شام كاش SYP", "decimal", "admin:deposit:method:sham_syp"),
    "deposit.sham_usd.min": ("الحد الأدنى لشحن شام كاش USD", "decimal", "admin:deposit:method:sham_usd"),
    "deposit.whish_money.min": ("الحد الأدنى لشحن Whish Money", "decimal", "admin:deposit:method:whish_money"),
    "deposit.binance_trc20.min": ("الحد الأدنى لشحن Binance TRC20", "decimal", "admin:deposit:method:binance_trc20"),
    "deposit.binance_bep20.min": ("الحد الأدنى لشحن Binance BEP20", "decimal", "admin:deposit:method:binance_bep20"),
    "deposit.syriatel.codes": ("أكواد/أرقام سيرياتيل كاش للاستلام", "syriatel_codes", "admin:deposit:method:syriatel"),
    "deposit.sham.address_syp": ("عنوان شام كاش SYP", "sham_address", "admin:deposit:method:sham_syp"),
    "deposit.sham.address_usd": ("عنوان شام كاش USD", "sham_address", "admin:deposit:method:sham_usd"),
    "withdraw.min_wallet": ("الحد الأدنى العام القديم للسحب", "positive_int", "admin:finance:withdraws"),
    "withdraw.syriatel.min_wallet": ("الحد الأدنى لسحب سيرياتيل كاش", "positive_int", "admin:withdraw:method:syriatel"),
    "withdraw.shamcash.min_wallet": ("الحد الأدنى لسحب شام كاش", "positive_int", "admin:withdraw:method:shamcash"),
    "withdraw.hawala_min_wallet": ("الحد الأدنى لسحب الحوالة", "positive_int", "admin:withdraw:method:hawala"),
    "withdraw.usdt.min_wallet": ("الحد الأدنى لسحب USDT من رصيد المحفظة", "positive_int", "admin:withdraw:method:usdt"),
    "withdraw.fee_pct": ("عمولة السحب العامة %", "pct", "admin:withdraw:commission"),
    "withdraw.hawala_fee_pct": ("عمولة الحوالات %", "pct", "admin:withdraw:commission"),
    "withdraw.usdt.rate": ("سعر USDT للسحب مقابل رصيد المحفظة", "decimal", "admin:withdraw:method:usdt"),
}


async def _return_view(
    return_cb: str,
    runtime: RuntimeSettingsService,
    deposit_service: DepositService,
    withdraw_service: WithdrawService,
) -> tuple[str, InlineKeyboardMarkup]:
    if return_cb == "admin:finance":
        return _finance_view()
    if return_cb == "admin:finance:deposits":
        return _deposits_view(runtime, deposit_service)
    if return_cb.startswith("admin:deposit:method:"):
        return _deposit_method_view(return_cb.rsplit(":", 1)[-1], runtime, deposit_service)
    if return_cb == "admin:finance:withdraws":
        return _withdraws_view(runtime, withdraw_service)
    if return_cb.startswith("admin:withdraw:method:"):
        return _withdraw_method_view(return_cb.rsplit(":", 1)[-1], runtime, withdraw_service)
    if return_cb == "admin:withdraw:commission":
        return _withdraw_commission_view(runtime)
    if return_cb == "admin:withdraw:security":
        return _withdraw_security_view()
    if return_cb == "admin:finance:channels":
        return _channels_view(runtime)
    if return_cb == "admin:finance:alerts":
        return (
            "🚨 <b>تنبيهات المبالغ الكبيرة</b>\n\nالتنبيه يظهر داخل نفس إشعار العملية.",
            _alerts_menu(runtime),
        )
    return _finance_view()


@router.callback_query(F.data == "admin:finance")
async def finance_home(callback: CallbackQuery, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _finance_view()
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:finance:deposits")
async def deposits_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _deposits_view(runtime_settings, deposit_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.startswith("admin:deposit:method:"))
async def deposit_method_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService) -> None:
    if not _admin(callback.from_user.id, settings): return
    method = str(callback.data or "").rsplit(":", 1)[-1]
    if method not in {"syriatel", "sham_syp", "sham_usd", "whish_money", "binance_trc20", "binance_bep20"}: return
    text, kb = _deposit_method_view(method, runtime_settings, deposit_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:deposit:mode:(syriatel|sham):(auto|manual|off)(?::(sham_syp|sham_usd))?$"))
async def set_deposit_mode(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService) -> None:
    if not _admin(callback.from_user.id, settings): return
    parts = str(callback.data).split(":")
    provider = parts[3]
    mode = parts[4]
    await runtime_settings.set(f"deposit.{provider}.mode", mode, updated_by=callback.from_user.id)
    method = "syriatel" if provider == "syriatel" else (parts[5] if len(parts) > 5 else "sham_syp")
    text, kb = _deposit_method_view(method, runtime_settings, deposit_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:deposit:toggle:(whish|binance)$"))
async def toggle_deposit_method(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService) -> None:
    if not _admin(callback.from_user.id, settings): return
    name = str(callback.data).rsplit(":", 1)[-1]
    if name == "whish":
        key, fallback, method = "deposit.whish.enabled", deposit_service.settings.whish_money_enabled, "whish_money"
    else:
        key, fallback, method = "deposit.binance.enabled", deposit_service.settings.binance_deposit_enabled, "binance_trc20"
    await runtime_settings.set(key, not runtime_settings.get_bool(key, fallback), updated_by=callback.from_user.id)
    text, kb = _deposit_method_view(method, runtime_settings, deposit_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:finance:withdraws")
async def withdraws_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _withdraws_view(runtime_settings, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.startswith("admin:withdraw:method:"))
async def withdraw_method_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    method = str(callback.data or "").rsplit(":", 1)[-1]
    if method not in {"syriatel", "shamcash", "hawala", "usdt"}: return
    text, kb = _withdraw_method_view(method, runtime_settings, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:withdraw:toggle:(syriatel|shamcash|hawala|usdt)$"))
async def toggle_withdraw_method(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    method = str(callback.data).rsplit(":",1)[-1]
    key = f"withdraw.{method}.enabled"
    await runtime_settings.set(key, not runtime_settings.get_bool(key, True), updated_by=callback.from_user.id)
    text, kb = _withdraw_method_view(method, runtime_settings, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:withdraw:network:(TRC20|BEP20)$"))
async def toggle_withdraw_network(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    network = str(callback.data).rsplit(":", 1)[-1].lower()
    key = f"withdraw.usdt.{network}.enabled"
    await runtime_settings.set(key, not runtime_settings.get_bool(key, True), updated_by=callback.from_user.id)
    text, kb = _withdraw_method_view("usdt", runtime_settings, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:withdraw:commission")
async def withdraw_commission(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _withdraw_commission_view(runtime_settings)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:withdraw:security")
async def withdraw_security(callback: CallbackQuery, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _withdraw_security_view()
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:finance:alerts")
async def alerts_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await safe_edit(callback, "🚨 <b>تنبيهات المبالغ الكبيرة</b>\n\nالتنبيه يظهر داخل نفس إشعار العملية ولا يتم إرسال رسالة مستقلة.", reply_markup=_alerts_menu(runtime_settings))


@router.callback_query(F.data == "admin:finance:channels")
async def channels_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _channels_view(runtime_settings)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:channel:test:(bot_deposits|bot_withdrawals)$"))
async def test_channel(callback: CallbackQuery, bot: Bot, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    name = str(callback.data).rsplit(":", 1)[-1]
    key = f"notify.{name}"
    target = runtime_settings.get(key)
    if target in (None, "", 0, "0"):
        text, kb = _channels_view(runtime_settings)
        await safe_edit(callback, "❌ القناة غير مضبوطة بعد.\n\n" + text, reply_markup=kb)
        return
    try:
        chat_id = int(str(target).strip()) if str(target).lstrip("-").isdigit() else str(target).strip()
        title = "اختبار قناة عمليات الشحن" if name == "bot_deposits" else "اختبار قناة عمليات السحب"
        await bot.send_message(chat_id, f"✅ <b>{title}</b>\n\nتم ربط القناة بنجاح.")
        text, kb = _channels_view(runtime_settings)
        await safe_edit(callback, f"{SUCCESS} <b>تم إرسال رسالة الاختبار بنجاح.</b>\n\n" + text, reply_markup=kb)
    except Exception as exc:
        text, kb = _channels_view(runtime_settings)
        await safe_edit(callback, f"❌ فشل إرسال الاختبار: <code>{html.escape(str(exc)[:300])}</code>\n\n" + text, reply_markup=kb)


@router.callback_query(F.data == "admin:setting:cancel")
async def setting_cancel(
    callback: CallbackQuery,
    state: FSMContext,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    deposit_service: DepositService,
    withdraw_service: WithdrawService,
) -> None:
    if not _admin(callback.from_user.id, settings): return
    data = await state.get_data()
    return_cb = str(data.get("setting_return") or "admin:finance")
    await state.clear()
    text, kb = await _return_view(return_cb, runtime_settings, deposit_service, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.startswith("admin:setting:"))
async def setting_start(
    callback: CallbackQuery,
    state: FSMContext,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    deposit_service: DepositService,
    withdraw_service: WithdrawService,
) -> None:
    if not _admin(callback.from_user.id, settings): return
    key = str(callback.data or "")[len("admin:setting:"):]
    meta = _SETTING_META.get(key)
    if not meta: return
    label, kind, return_cb = meta
    current = runtime_settings.get(key)
    # Missing runtime overrides should display the effective fallback that users see now.
    if current is None:
        deposit_min_methods = {
            "deposit.syriatel.min": "syriatel",
            "deposit.sham_syp.min": "sham_syp",
            "deposit.sham_usd.min": "sham_usd",
            "deposit.whish_money.min": "whish_money",
            "deposit.binance_trc20.min": "binance_trc20",
            "deposit.binance_bep20.min": "binance_bep20",
        }
        withdraw_min_methods = {
            "withdraw.syriatel.min_wallet": "syriatel",
            "withdraw.shamcash.min_wallet": "shamcash",
            "withdraw.hawala_min_wallet": "hawala",
            "withdraw.usdt.min_wallet": "usdt",
        }
        if key in deposit_min_methods:
            current = _fmt_decimal(deposit_service.method_config(deposit_min_methods[key]).minimum)
        elif key in withdraw_min_methods:
            current = withdraw_service.minimum(withdraw_min_methods[key])
    if kind == "syriatel_codes":
        current = ",".join(parse_syriatel_cash_codes(current))
    await state.clear()
    await state.update_data(
        setting_key=key,
        setting_kind=kind,
        setting_label=label,
        setting_return=return_cb,
        origin_chat_id=callback.message.chat.id if isinstance(callback.message, Message) else None,
        origin_message_id=callback.message.message_id if isinstance(callback.message, Message) else None,
    )
    await state.set_state(AdminFinanceStates.waiting_setting)
    await safe_edit(
        callback,
        f"✏️ <b>{html.escape(label)}</b>\n\nالقيمة الحالية: <code>{html.escape(str(current))}</code>\n\nأرسل القيمة الجديدة الآن.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:setting:cancel")]]),
    )


@router.message(AdminFinanceStates.waiting_setting, F.text)
async def setting_value(
    message: Message,
    state: FSMContext,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    deposit_service: DepositService,
    withdraw_service: WithdrawService,
) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data()
    key = str(data.get("setting_key") or "")
    kind = str(data.get("setting_kind") or "")
    raw = (message.text or "").strip()
    try:
        if kind == "positive_int":
            value = int(_normalize_numeric_input(raw))
            if value <= 0: raise ValueError
        elif kind == "int0":
            value = int(_normalize_numeric_input(raw))
            if value < 0: raise ValueError
        elif kind == "decimal":
            value_d = Decimal(_normalize_numeric_input(raw, decimal=True))
            if value_d <= 0: raise ValueError
            value = format(value_d.normalize(), "f")
        elif kind == "pct":
            value_d = Decimal(_normalize_numeric_input(raw, decimal=True))
            if not (Decimal("0") <= value_d <= Decimal("100")): raise ValueError
            value = format(value_d.normalize(), "f")
        elif kind == "chat":
            if raw.lower() in {"off", "0", "تعطيل", "الغاء", "إلغاء"}:
                value = None
            else:
                normalized_chat = raw.translate(_NUM_TRANSLATION)
                value = int(normalized_chat) if normalized_chat.lstrip("-").isdigit() else raw
        elif kind == "syriatel_codes":
            parts = list(parse_syriatel_cash_codes(raw.translate(_NUM_TRANSLATION)))
            if not parts or len(parts) > 30 or any(not p.isdigit() or not (3 <= len(p) <= 30) for p in parts):
                raise ValueError
            value = ",".join(parts)
        elif kind == "sham_address":
            value = raw.strip().strip('"').strip("'").strip()
            if not (6 <= len(value) <= 160): raise ValueError
        else:
            raise ValueError
    except Exception:
        await _delete_input(message)
        chat_id, message_id = data.get("origin_chat_id"), data.get("origin_message_id")
        if chat_id and message_id:
            try:
                await message.bot.edit_message_text(
                    chat_id=int(chat_id), message_id=int(message_id),
                    text="❌ القيمة غير صالحة. أرسل قيمة صحيحة الآن.",
                    reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:setting:cancel")]]),
                    parse_mode="HTML",
                )
            except Exception:
                pass
        return

    await runtime_settings.set(key, value, updated_by=message.from_user.id)
    await _delete_input(message)
    return_cb = str(data.get("setting_return") or "admin:finance")
    text, kb = await _return_view(return_cb, runtime_settings, deposit_service, withdraw_service)
    await state.clear()
    chat_id, message_id = data.get("origin_chat_id"), data.get("origin_message_id")
    if chat_id and message_id:
        try:
            await message.bot.edit_message_text(
                chat_id=int(chat_id), message_id=int(message_id),
                text=f"{SUCCESS} <b>تم حفظ الإعداد وتطبيقه فوراً.</b>\n\n{text}",
                reply_markup=kb, parse_mode="HTML",
            )
            return
        except Exception:
            pass
    await message.answer(f"{SUCCESS} تم حفظ الإعداد وتطبيقه فوراً.\n\n{text}", reply_markup=kb)
def _deposit_method_label(method: str) -> str:
    return {
        "syriatel": "سيرياتيل كاش",
        "sham_syp": "شام كاش – ليرة",
        "sham_usd": "شام كاش – دولار",
        "whish_money": "Whish Money",
        "binance_trc20": "Binance USDT TRC20",
        "binance_bep20": "Binance USDT BEP20",
    }.get(str(method or ""), str(method or "-") or "-")


def _fmt_dt(value) -> str:
    if value is None:
        return "—"
    try:
        # Keep the stored timezone/offset visible instead of silently converting it.
        return value.isoformat(sep=" ", timespec="seconds")
    except Exception:
        return str(value)


def _withdraw_status_label(status: str) -> str:
    return {
        "pending": "بانتظار التنفيذ",
        "processing": "جاري التنفيذ",
        "provider_success": "نجح لدى المزود — بانتظار التثبيت المحلي",
        "needs_review": "يحتاج مراجعة",
        "success": "تم التقبيض",
        "rejected": "مرفوض",
        "cancelled": "ملغي",
    }.get(str(status or ""), str(status or "-"))


def _withdraw_card(rec, last_deposits=()) -> str:
    success = str(rec.status) == "success"
    title = "✅ <b>تم التقبيض</b>" if success else "💸 <b>طلب سحب</b>"
    text = (
        f"{title}\n\n"
        f"🧾 رقم الطلب: <code>{rec.id}</code>\n"
        f"👤 المستخدم: <code>{rec.telegram_id}</code>\n"
        f"💳 الطريقة: <b>{html.escape(rec.method)}</b>\n"
        f"💰 المحفظة: <code>{rec.amount_wallet:,}</code>\n"
        f"💸 العمولة: <code>{rec.fee_wallet:,}</code>\n"
        f"📤 المستحق: <code>{rec.payout_amount} {rec.payout_currency}</code>\n"
        + (f"👤 اسم الحساب: <b>{html.escape(rec.receiver_name)}</b>\n" if rec.method == "shamcash" and rec.receiver_name else "")
        + f"📍 المستلم: <code>{html.escape(rec.receiver)}</code>\n"
        + f"📌 الحالة: <b>{html.escape(_withdraw_status_label(rec.status))}</b>\n"
        + f"🕐 وقت الطلب: <code>{html.escape(_fmt_dt(rec.created_at))}</code>"
        + (f"\n✅ وقت التنفيذ: <code>{html.escape(_fmt_dt(rec.finished_at))}</code>" if rec.finished_at else "")
        + (f"\n🔢 رقم العملية: <code>{html.escape(rec.provider_reference)}</code>" if rec.provider_reference else "")
        + (f"\n⚠️ {html.escape(rec.last_error)}" if rec.last_error else "")
    )
    items = list(last_deposits or ())[:3]
    if items:
        text += "\n\n🟢 <b>آخر 3 عمليات شحن ناجحة</b>"
        for index, dep in enumerate(items, 1):
            bonus = int(dep.bonus_credit_syp or 0)
            text += (
                f"\n{index}) {_deposit_method_label(dep.method)} — "
                f"<code>{dep.total_credit_syp:,}</code>"
                f" | بونص: <code>{bonus:,}</code>"
            )
    else:
        text += "\n\n🟢 <b>آخر 3 عمليات شحن ناجحة</b>\nلا توجد عمليات ناجحة مسجلة."
    return text


def _withdraw_actions(rec) -> InlineKeyboardMarkup:
    rows = []
    if rec.status == "pending":
        if rec.method in {"syriatel","shamcash"}:
            rows.append([InlineKeyboardButton(text="⚡ تنفيذ آلي", callback_data=f"admin:withdraw:execute:{rec.id}")])
        rows.append([InlineKeyboardButton(text="✅ تأكيد تم الدفع", callback_data=f"admin:withdraw:paid:{rec.id}")])
        rows.append([InlineKeyboardButton(text="❌ رفض الطلب", callback_data=f"admin:withdraw:reject:{rec.id}")])
    elif rec.status == "provider_success":
        rows.append([InlineKeyboardButton(text="✅ تثبيت العملية محلياً", callback_data=f"admin:withdraw:paid:{rec.id}")])
    elif rec.status == "processing":
        rows.append([InlineKeyboardButton(text="⚠️ النتيجة قيد الحسم", callback_data=f"admin:withdraw:view:{rec.id}")])
    elif rec.status == "needs_review":
        rows.append([InlineKeyboardButton(text="✅ تأكيد أنها تمت", callback_data=f"admin:withdraw:paid:{rec.id}")])
        rows.append([InlineKeyboardButton(text="↩️ تأكيد أنها لم تتم", callback_data=f"admin:withdraw:notpaid:{rec.id}")])
    rows.append([InlineKeyboardButton(text="⬅️ الطلبات", callback_data="admin:withdraws:pending")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin:withdraws:pending")
async def pending_withdraws(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    items = await withdraw_service.repository.list_pending(30)
    rows = [[InlineKeyboardButton(text=f"{r.method} • {r.amount_wallet:,} • {r.status}", callback_data=f"admin:withdraw:view:{r.id}")] for r in items]
    rows.append([InlineKeyboardButton(text="⬅️ إدارة السحب", callback_data="admin:finance:withdraws")])
    await safe_edit(callback, f"📋 <b>طلبات السحب المعلقة</b>\n\nالعدد: {len(items)}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data == "admin:withdraws:review")
async def review_withdraws(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    items = await withdraw_service.repository.list_by_status("needs_review", 30)
    rows = [[_btn(f"⚠️ {r.method} • {r.amount_wallet:,}", f"admin:withdraw:view:{r.id}")] for r in items]
    rows.append([_btn("⬅️ إدارة السحب", "admin:finance:withdraws")])
    await safe_edit(
        callback,
        f"⚠️ <b>طلبات السحب قيد المراجعة</b>\n\nالعدد: <b>{len(items)}</b>\nلا يتم إعادة POST مالي تلقائياً لهذه الطلبات.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data == "admin:withdraws:history")
async def withdraw_history(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    items = await withdraw_service.repository.list_recent_terminal(30)
    rows = [[_btn(f"{_withdraw_status_label(r.status)} • {r.method} • {r.amount_wallet:,}", f"admin:withdraw:view:{r.id}")] for r in items]
    rows.append([_btn("⬅️ إدارة السحب", "admin:finance:withdraws")])
    await safe_edit(
        callback,
        f"✅ <b>سجل السحوبات الأخيرة</b>\n\nالعدد المعروض: <b>{len(items)}</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data.startswith("admin:withdraw:view:"))
async def view_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    try: wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    except Exception: return
    rec = await withdraw_service.repository.get(wid)
    if not rec:
        await safe_edit(callback, "❌ الطلب غير موجود.")
        return
    last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
    await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions(rec))


@router.callback_query(F.data.startswith("admin:withdraw:execute:"))
async def execute_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    await safe_edit(
        callback,
        f"{PROCESSING} <b>جاري تنفيذ السحب عبر المزود...</b>\n\n"
        f"🧾 رقم الطلب: <code>{wid}</code>\n"
        "يرجى عدم إعادة الضغط أو الرجوع أثناء التنفيذ. الحماية المالية تمنع إرسال POST مالي ثانٍ لنفس الطلب.",
    )
    try:
        rec = await withdraw_service.execute_auto(wid, callback.from_user.id)
        last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
        await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions(rec))
    except (WithdrawValidationError, WithdrawStateError) as exc:
        rec = await withdraw_service.repository.get(wid)
        await safe_edit(callback, f"⚠️ {html.escape(str(exc))}" + ("\n\n" + _withdraw_card(rec) if rec else ""), reply_markup=_withdraw_actions(rec) if rec else None)


@router.callback_query(F.data.startswith("admin:withdraw:paid:"))
async def paid_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    try:
        rec = await withdraw_service.confirm_paid(wid, callback.from_user.id)
        last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
        await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions(rec))
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}")


@router.callback_query(F.data.startswith("admin:withdraw:notpaid:"))
async def notpaid_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    try:
        rec = await withdraw_service.confirm_not_paid(wid, callback.from_user.id)
        await safe_edit(callback, "↩️ تم تأكيد أن التحويل لم يتم. عاد الطلب إلى الانتظار بدون تحرير الحجز.", reply_markup=_withdraw_actions(rec))
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}")


@router.callback_query(F.data.startswith("admin:withdraw:reject:"))
async def reject_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    try:
        await withdraw_service.reject_admin(wid, callback.from_user.id, "rejected by admin")
        await safe_edit(callback, "❌ تم رفض الطلب وإعادة المبلغ المحجوز إلى المستخدم.")
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}")
