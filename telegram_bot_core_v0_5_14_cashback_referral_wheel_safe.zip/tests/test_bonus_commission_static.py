from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_bonus_commission_migration_contract():
    sql = (ROOT / "migrations/0011_bonus_commission_rules.sql").read_text(encoding="utf-8")
    for token in (
        "deposit_bonus_tiers",
        "withdraw_fee_tiers",
        "user_special_deposit_bonuses",
        "welcome_bonus_claims",
        "method_scope IN ('all','syriatel','sham_syp','sham_usd','binance','whish')",
        "manual_bonus_refresh",
    ):
        assert token in sql


def test_deposit_priority_and_manual_refresh_wired():
    svc = (ROOT / "app/services/deposits.py").read_text(encoding="utf-8")
    rules = (ROOT / "app/services/finance_rules.py").read_text(encoding="utf-8")
    repo = (ROOT / "app/repositories/deposits.py").read_text(encoding="utf-8")
    assert "special_user" in rules
    assert "deposit_tier" in rules
    assert rules.index('source="special_user"') < rules.index('"deposit_tier"')
    assert "update_bonus_terms" in svc
    assert "consume_deposit_bonus" in svc
    assert "WHERE id=$1 AND status='manual_pending'" in repo


def test_commission_tier_precedes_ordinary_fee():
    rules = (ROOT / "app/services/finance_rules.py").read_text(encoding="utf-8")
    block = rules[rules.index("async def effective_withdraw_fee_pct"):]
    assert block.index("active_withdraw_tier") < block.index("withdraw.hawala_fee_pct")


def test_admin_hubs_are_present():
    finance = (ROOT / "app/routers/admin_finance.py").read_text(encoding="utf-8")
    admin_bonus = (ROOT / "app/routers/admin_bonus.py").read_text(encoding="utf-8")
    assert '"🎁 إدارة البونص", "admin:bonus_manage"' in finance
    assert '"💰 إدارة العمولة", "admin:commission_manage"' in finance
    for token in ("admin:deposit_bonus_tiers", "admin:withdraw_fee_tiers", "admin:special_bonus"):
        assert token in admin_bonus


def test_welcome_bonus_priority_and_atomic_grant_are_wired():
    rules = (ROOT / "app/services/finance_rules.py").read_text(encoding="utf-8")
    repo = (ROOT / "app/repositories/finance_rules.py").read_text(encoding="utf-8")
    start = (ROOT / "app/routers/start.py").read_text(encoding="utf-8")
    admin = (ROOT / "app/routers/admin_bonus.py").read_text(encoding="utf-8")
    block = rules[rules.index("async def resolve_deposit_bonus"):rules.index("async def preview_deposit_bonus")]
    assert block.index("pending_welcome_for_update") < block.index("active_special_for_update") < block.index("active_deposit_tier")
    assert "welcome-bonus:" in rules and "credit_in_transaction" in rules
    assert "consume_welcome_first_deposit" in rules and "consume_welcome_first_deposit" in repo
    assert "grant_welcome_if_eligible" in start
    assert '"admin:welcome_bonus"' in admin
