from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_admin_wallet_is_wired_from_admin_home():
    common = (ROOT / "app/keyboards/common.py").read_text(encoding="utf-8")
    routers = (ROOT / "app/routers/__init__.py").read_text(encoding="utf-8")
    wallet = (ROOT / "app/routers/admin_wallet.py").read_text(encoding="utf-8")
    assert 'text="👛 محفظة الأدمن"' in common
    assert 'callback_data="admin:wallet"' in common
    assert "admin_wallet.router" in routers
    for callback in (
        'F.data == "admin:wallet"',
        'F.data == "admin:wallet:syriatel"',
        'F.data == "admin:wallet:sham"',
        'F.data == "admin:wallet:binance"',
        'F.data == "admin:wallet:ichancy_agent"',
    ):
        assert callback in wallet


def test_local_wallet_uses_runtime_active_provider_not_hardcoded_api_syria():
    wallet = (ROOT / "app/routers/admin_wallet.py").read_text(encoding="utf-8")
    assert "payment_providers.active()" in wallet
    assert "provider.syriatel_balance" in wallet
    assert "provider.shamcash_balances" in wallet
    assert "_api_syria_get" not in wallet


def test_admin_wallet_reads_are_read_only_surfaces():
    wallet = (ROOT / "app/routers/admin_wallet.py").read_text(encoding="utf-8")
    forbidden = ("transfer_syriatel(", "transfer_shamcash(", "deposit_to_player(", "withdraw_from_player(")
    for token in forbidden:
        assert token not in wallet
    assert 'get_coin_info("USDT")' in wallet
    assert "active_cashier_wallets()" in wallet


def test_binance_and_sham_read_helpers_are_present():
    binance = (ROOT / "app/providers/binance.py").read_text(encoding="utf-8")
    api = (ROOT / "app/providers/api_syria.py").read_text(encoding="utf-8")
    assert '"/sapi/v1/capital/config/getall"' in binance
    assert "async def shamcash_balances" in api


def test_manual_transfers_button_is_moved_to_admin_wallet_only():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    finance = (root / 'app/routers/admin_finance.py').read_text()
    wallet = (root / 'app/routers/admin_wallet.py').read_text()
    finance_menu = finance[finance.index('def _finance_view'):finance.index('def _fmt_decimal')]
    wallet_menu = wallet[wallet.index('def _kb'):wallet.index('def _detail_kb')]
    manual_menu = finance[finance.index('def _manual_transfers_menu'):finance.index('def _manual_transfer_methods_menu')]
    assert 'admin:manual_transfers' not in finance_menu
    assert '💸 حوالات يدوية' not in finance_menu
    assert 'admin:manual_transfers' in wallet_menu
    assert '💸 حوالات يدوية' in wallet_menu
    assert '"admin:wallet"' in manual_menu
    assert '⬅️ محفظة الأدمن' in manual_menu
