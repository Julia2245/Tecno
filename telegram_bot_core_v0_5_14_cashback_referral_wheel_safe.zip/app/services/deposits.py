from __future__ import annotations

import asyncio
import re

import asyncpg
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, TYPE_CHECKING
from uuid import UUID

from app.config import Settings
from app.core.deposits import (
    DepositAlreadyProcessed,
    DepositAlreadyUsed,
    DepositProviderUnavailable,
    DepositOutcomeUncertain,
    DepositRecord,
    DepositSettlement,
    ManualDepositCreation,
    DepositValidationError,
    DepositVerificationFailed,
    ProviderTransaction,
)
from app.core.money import parse_decimal, percent_amount, wallet_syp_amount
from app.core.syriatel import parse_syriatel_cash_codes
from app.core.shamcash import normalize_shamcash_address
from app.providers.api_syria import ApiSyriaClient
from app.providers.payment import PaymentProviderManager
from app.providers.binance import BinanceDepositClient, normalize_binance_txid
from app.repositories.deposits import DepositRepository
from app.repositories.outbox import OutboxRepository
from app.services.wallet import WalletService
from app.services.runtime_settings import RuntimeSettingsService
from app.services.finance_rules import FinanceRulesService
from app.services.outbox import NotificationOutboxWorker

if TYPE_CHECKING:
    from app.services.rewards import CashbackPrincipalTracker, ReferralService

_NUMERIC_TRANSLATION = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_NUMERIC_TX_RE = re.compile(r"^\d{3,30}$")
_BINANCE_TX_RE = re.compile(r"^[A-Za-z0-9:_\-. ]{6,160}$")
_PROOF_UNIQUE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,160}$")
_MAX_WALLET_SYP = 9_000_000_000_000_000_000
_MAX_INPUT_AMOUNT = Decimal("99999999999999999999.99999999")


@dataclass(slots=True, frozen=True)
class DepositMethodConfig:
    method: str
    label: str
    enabled: bool
    mode: str
    currency: str
    rate: Decimal
    minimum: Decimal
    bonus_pct: Decimal
    target: str | None
    provider_scope: str | None
    network: str | None = None


class DepositService:
    """Financially safe bot-wallet deposits modeled after the reference bot.

    Provider verification never changes money. Settlement is one PostgreSQL
    transaction containing provider-tx claim + deposit row + wallet credit +
    immutable ledger link. Provider outages therefore cannot create partial money.
    """

    def __init__(
        self,
        repository: DepositRepository,
        wallet_service: WalletService,
        settings: Settings,
        api_syria: ApiSyriaClient,
        binance: BinanceDepositClient,
        runtime_settings: RuntimeSettingsService | None = None,
        outbox_repository: OutboxRepository | None = None,
        outbox_worker: NotificationOutboxWorker | None = None,
        payment_providers: PaymentProviderManager | None = None,
        finance_rules: FinanceRulesService | None = None,
        cashback_tracker: "CashbackPrincipalTracker | None" = None,
        referral_service: "ReferralService | None" = None,
    ) -> None:
        self.repository = repository
        self.wallet_service = wallet_service
        self.settings = settings
        self.api_syria = api_syria
        self.binance = binance
        self.runtime_settings = runtime_settings
        self.outbox_repository = outbox_repository
        self.outbox_worker = outbox_worker
        self.payment_providers = payment_providers
        self.finance_rules = finance_rules
        self.cashback_tracker = cashback_tracker
        self.referral_service = referral_service
        self._system_started_at = None
        # UX-only in-flight guard.  Financial idempotency remains in PostgreSQL;
        # this set only prevents one user from starting a second provider lookup
        # while the first short verification request is still running.
        self._active_verifications: set[int] = set()

    def active_provider(self):
        """Freeze the configured payment provider at the start of each operation."""
        return self.payment_providers.active() if self.payment_providers is not None else self.api_syria

    def active_provider_label(self) -> str:
        provider = self.active_provider()
        return str(getattr(provider, "provider_label", "API SYRIA"))

    def verification_in_progress(self, telegram_id: int) -> bool:
        return int(telegram_id) in self._active_verifications

    def begin_verification(self, telegram_id: int) -> bool:
        user_id = int(telegram_id)
        if user_id in self._active_verifications:
            return False
        self._active_verifications.add(user_id)
        return True

    def end_verification(self, telegram_id: int) -> None:
        self._active_verifications.discard(int(telegram_id))

    def syriatel_codes(self) -> tuple[str, ...]:
        fallback = ",".join(self.settings.syriatel_codes)
        raw = fallback
        if self.runtime_settings is not None:
            raw = str(self.runtime_settings.get("deposit.syriatel.codes", fallback) or "")
        return parse_syriatel_cash_codes(raw)

    def shamcash_address(self, currency: str = "SYP") -> str:
        is_usd = str(currency or "SYP").upper() == "USD"
        fallback = self.settings.shamcash_address_usd if is_usd else self.settings.shamcash_address_syp
        key = "deposit.sham.address_usd" if is_usd else "deposit.sham.address_syp"
        if self.runtime_settings is None:
            return normalize_shamcash_address(fallback)
        return normalize_shamcash_address(self.runtime_settings.get(key, fallback))

    def _runtime_mode(self, key: str, fallback: str) -> str:
        if self.runtime_settings is None:
            return fallback
        value = str(self.runtime_settings.get(key, fallback) or fallback).strip().lower()
        return value if value in {"auto", "manual", "off"} else fallback

    def _runtime_enabled(self, key: str, fallback: bool) -> bool:
        return self.runtime_settings.get_bool(key, fallback) if self.runtime_settings else fallback

    def method_config(self, method: str) -> DepositMethodConfig:
        s = self.settings
        if method == "syriatel":
            mode = self._runtime_mode("deposit.syriatel.mode", s.syriatel_charge_mode)
            codes = self.syriatel_codes()
            return DepositMethodConfig(
                method=method,
                label="سيرياتيل كاش",
                enabled=(mode != "off" and bool(codes) and (mode != "auto" or self.active_provider().configured)),
                mode=mode,
                currency="SYP",
                rate=(self.runtime_settings.get_decimal("money.local_syp_wallet_multiplier", s.rate_syriatel_syp_to_wallet) if self.runtime_settings else s.rate_syriatel_syp_to_wallet),
                minimum=(self.runtime_settings.get_decimal("deposit.syriatel.min", s.min_deposit_syp) if self.runtime_settings else s.min_deposit_syp),
                bonus_pct=(self.finance_rules.ordinary_bonus_pct(method) if self.finance_rules else s.bonus_syriatel_pct),
                target=", ".join(codes) or None,
                provider_scope="syriatel",
            )
        if method == "sham_syp":
            mode = self._runtime_mode("deposit.sham.mode", s.sham_charge_mode)
            address = self.shamcash_address("SYP")
            return DepositMethodConfig(
                method=method,
                label="شام كاش – ليرة",
                enabled=(mode != "off" and bool(address) and (mode != "auto" or self.active_provider().configured)),
                mode=mode,
                currency="SYP",
                rate=(self.runtime_settings.get_decimal("money.local_syp_wallet_multiplier", s.rate_sham_syp_to_wallet) if self.runtime_settings else s.rate_sham_syp_to_wallet),
                minimum=(self.runtime_settings.get_decimal("deposit.sham_syp.min", s.min_deposit_syp) if self.runtime_settings else s.min_deposit_syp),
                bonus_pct=(self.finance_rules.ordinary_bonus_pct(method) if self.finance_rules else s.bonus_sham_syp_pct),
                target=address or None,
                provider_scope="shamcash",
            )
        if method == "sham_usd":
            mode = self._runtime_mode("deposit.sham.mode", s.sham_charge_mode)
            address = self.shamcash_address("USD")
            return DepositMethodConfig(
                method=method,
                label="شام كاش – دولار",
                enabled=(mode != "off" and bool(address) and (mode != "auto" or self.active_provider().configured)),
                mode=mode,
                currency="USD",
                rate=(self.runtime_settings.get_decimal("deposit.sham_usd.rate", s.rate_sham_usd_to_wallet) if self.runtime_settings else s.rate_sham_usd_to_wallet),
                minimum=(self.runtime_settings.get_decimal("deposit.sham_usd.min", s.min_sham_usd_deposit) if self.runtime_settings else s.min_sham_usd_deposit),
                bonus_pct=(self.finance_rules.ordinary_bonus_pct(method) if self.finance_rules else s.bonus_sham_usd_pct),
                target=address or None,
                provider_scope="shamcash",
            )
        if method == "whish_money":
            return DepositMethodConfig(
                method=method,
                label="Whish Money",
                enabled=self._runtime_enabled("deposit.whish.enabled", s.whish_money_enabled) and bool(s.whish_money_number.strip()),
                mode="manual",
                currency="USD",
                rate=(self.runtime_settings.get_decimal("deposit.whish_money.rate", s.rate_whish_usd_to_wallet) if self.runtime_settings else s.rate_whish_usd_to_wallet),
                minimum=(self.runtime_settings.get_decimal("deposit.whish_money.min", s.min_whish_usd_deposit) if self.runtime_settings else s.min_whish_usd_deposit),
                bonus_pct=(self.finance_rules.ordinary_bonus_pct(method) if self.finance_rules else s.bonus_whish_money_pct),
                target=s.whish_money_number.strip() or None,
                provider_scope="whish_proof",
            )
        if method in {"binance_trc20", "binance_bep20"}:
            trc = method == "binance_trc20"
            address = s.binance_trc20_address.strip() if trc else s.binance_bep20_address.strip()
            network = s.binance_trc20_network.strip().upper() if trc else s.binance_bep20_network.strip().upper()
            label_network = "TRC20" if trc else "BEP20"
            return DepositMethodConfig(
                method=method,
                label=f"Binance USDT {label_network}",
                enabled=self._runtime_enabled("deposit.binance.enabled", s.binance_deposit_enabled) and bool(address) and self.binance.configured,
                mode="auto",
                currency="USDT",
                rate=(self.runtime_settings.get_decimal("deposit.binance_trc20.rate" if trc else "deposit.binance_bep20.rate", s.rate_binance_usdt_to_wallet) if self.runtime_settings else s.rate_binance_usdt_to_wallet),
                minimum=(
                    self.runtime_settings.get_decimal(
                        "deposit.binance_trc20.min" if trc else "deposit.binance_bep20.min",
                        s.min_binance_usdt_deposit,
                    )
                    if self.runtime_settings else s.min_binance_usdt_deposit
                ),
                bonus_pct=(self.finance_rules.ordinary_bonus_pct(method) if self.finance_rules else s.bonus_binance_usdt_pct),
                target=address or None,
                provider_scope="binance_usdt",
                network=network,
            )
        raise DepositValidationError("unknown deposit method")

    def all_methods(self) -> tuple[DepositMethodConfig, ...]:
        return tuple(
            self.method_config(name)
            for name in (
                "syriatel",
                "sham_syp",
                "sham_usd",
                "whish_money",
                "binance_trc20",
                "binance_bep20",
            )
        )

    @staticmethod
    def normalize_numeric_tx(raw: str) -> str:
        value = str(raw or "").translate(_NUMERIC_TRANSLATION).replace(" ", "").strip()
        if not _NUMERIC_TX_RE.fullmatch(value):
            raise DepositValidationError("رقم العملية يجب أن يكون أرقام فقط من 3 إلى 30 خانة.")
        return value

    @staticmethod
    def normalize_amount(raw: str) -> Decimal:
        value = (
            str(raw or "")
            .translate(_NUMERIC_TRANSLATION)
            .replace(" ", "")
            .replace("٬", "")
            .replace("٫", ".")
        )

        # Do not silently turn a displayed amount such as 25,000 into 25.
        # ASCII comma is accepted as a thousands separator when grouping is
        # unambiguous; otherwise a one/two-digit tail is treated as decimal.
        if "," in value:
            if "." in value:
                if not re.fullmatch(r"[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?", value):
                    raise DepositValidationError("تنسيق المبلغ غير واضح. استخدم النقطة للفاصلة العشرية.")
                value = value.replace(",", "")
            elif re.fullmatch(r"[+-]?\d{1,3}(?:,\d{3})+", value):
                value = value.replace(",", "")
            elif re.fullmatch(r"[+-]?\d+,\d{1,2}", value):
                value = value.replace(",", ".")
            else:
                raise DepositValidationError("تنسيق المبلغ غير واضح. استخدم النقطة للفاصلة العشرية.")

        try:
            amount = parse_decimal(value)
        except ValueError as exc:
            raise DepositValidationError("المبلغ غير صحيح.") from exc
        if amount <= 0:
            raise DepositValidationError("المبلغ يجب أن يكون أكبر من صفر.")
        DepositService._assert_amount_shape(amount)
        return amount

    @staticmethod
    def normalize_binance_tx(raw: str) -> str:
        value = " ".join(str(raw or "").strip().split())
        if not _BINANCE_TX_RE.fullmatch(value):
            raise DepositValidationError("رمز العملية TxID غير صحيح.")
        normalized = normalize_binance_txid(value)
        if not normalized:
            raise DepositValidationError("رمز العملية TxID غير صحيح.")
        return normalized

    def credit_preview(self, method: str, amount: Decimal) -> tuple[int, int, int]:
        cfg = self.method_config(method)
        self._assert_minimum(amount, cfg.minimum)
        return self._credit_terms(amount, cfg)

    async def credit_preview_for_user(self, telegram_id: int, method: str, amount: Decimal) -> tuple[int, int, int]:
        cfg = self.method_config(method)
        self._assert_minimum(amount, cfg.minimum)
        base, ordinary_bonus, ordinary_total = self._credit_terms(amount, cfg)
        if self.finance_rules is None:
            return base, ordinary_bonus, ordinary_total
        decision = await self.finance_rules.preview_deposit_bonus(
            int(telegram_id), method=method, amount_input=amount, ordinary_pct=cfg.bonus_pct
        )
        try:
            bonus = percent_amount(base, decision.pct)
        except (ValueError, ArithmeticError) as exc:
            raise DepositValidationError("تعذر حساب قيمة الشحن بأمان.") from exc
        total = base + bonus
        if total <= 0 or total > _MAX_WALLET_SYP:
            raise DepositValidationError("قيمة الشحن بعد التحويل خارج النطاق المسموح.")
        return base, bonus, total

    async def auto_syriatel(self, telegram_id: int, tx_raw: str) -> DepositSettlement:
        cfg = self._available("syriatel", require_auto=True)
        tx = self.normalize_numeric_tx(tx_raw)
        duplicate = await self._preflight_duplicate(telegram_id, cfg.provider_scope, tx)
        if duplicate:
            return duplicate
        codes = self.syriatel_codes()
        if not codes:
            raise DepositValidationError("لا توجد أرقام سيرياتيل كاش مضبوطة حالياً.")
        provider = self.active_provider()
        if not provider.configured:
            raise DepositProviderUnavailable(f"{getattr(provider, 'provider_label', 'API')} is not configured")

        results = await asyncio.gather(
            *(provider.find_syriatel(tx, code) for code in codes),
            return_exceptions=True,
        )
        matches: list[ProviderTransaction] = []
        provider_errors = 0
        for result in results:
            if isinstance(result, DepositProviderUnavailable):
                provider_errors += 1
            elif isinstance(result, Exception):
                provider_errors += 1
            elif result is not None:
                matches.append(result)

        if not matches:
            # Search must be conclusive across every configured receiving number.
            # If even one lookup failed, saying "not found" could be a false negative
            # for a real transfer sent to that number.
            if provider_errors:
                raise DepositProviderUnavailable("تعذر إكمال التحقق عبر جميع أرقام الاستلام حالياً.")
            raise DepositVerificationFailed("لم يتم العثور على العملية.")

        signatures = {(m.amount, m.occurred_at, m.currency, m.destination) for m in matches}
        if len(signatures) > 1:
            raise DepositVerificationFailed("ظهرت بيانات متعارضة للعملية عبر أرقام الاستلام.")
        verified = matches[0]
        await self._assert_fresh_provider_tx(verified)
        self._assert_minimum(verified.amount, cfg.minimum)
        return await self._settle_verified(
            telegram_id=telegram_id,
            cfg=cfg,
            tx=tx,
            amount=verified.amount,
            target_ref=verified.destination,
            provider_payload={**(verified.raw or {}), "_api_provider": getattr(provider, "provider_id", "api_syria")},
        )

    async def auto_sham(self, telegram_id: int, method: str, tx_raw: str) -> DepositSettlement:
        if method not in {"sham_syp", "sham_usd"}:
            raise DepositValidationError("طريقة شام كاش غير صحيحة.")
        cfg = self._available(method, require_auto=True)
        tx = self.normalize_numeric_tx(tx_raw)
        duplicate = await self._preflight_duplicate(telegram_id, cfg.provider_scope, tx)
        if duplicate:
            return duplicate
        if not cfg.target:
            raise DepositValidationError("حساب شام كاش غير مضبوط حالياً.")
        provider = self.active_provider()
        if not provider.configured:
            raise DepositProviderUnavailable(f"{getattr(provider, 'provider_label', 'API')} is not configured")
        verified = await provider.find_shamcash(tx, cfg.target)
        if verified is None:
            raise DepositVerificationFailed("لم يتم العثور على العملية.")
        await self._assert_fresh_provider_tx(verified)
        if verified.currency.upper() != cfg.currency:
            raise DepositVerificationFailed("عملة العملية لا تطابق طريقة الشحن المختارة.")
        self._assert_minimum(verified.amount, cfg.minimum)
        return await self._settle_verified(
            telegram_id=telegram_id,
            cfg=cfg,
            tx=tx,
            amount=verified.amount,
            target_ref=cfg.target,
            provider_payload={**(verified.raw or {}), "_api_provider": getattr(provider, "provider_id", "api_syria")},
        )

    async def auto_binance(
        self,
        telegram_id: int,
        method: str,
        *,
        amount: Decimal,
        tx_raw: str,
    ) -> DepositSettlement:
        cfg = self._available(method, require_auto=True)
        if method not in {"binance_trc20", "binance_bep20"}:
            raise DepositValidationError("طريقة Binance غير صحيحة.")
        self._assert_minimum(amount, cfg.minimum)
        tx = self.normalize_binance_tx(tx_raw)
        duplicate = await self._preflight_duplicate(telegram_id, cfg.provider_scope, tx)
        if duplicate:
            return duplicate
        if not cfg.network or not cfg.target:
            raise DepositValidationError("بيانات Binance غير مكتملة.")
        try:
            verified = await self.binance.verify_usdt_deposit(
                txid=tx,
                expected_network=cfg.network,
                expected_address=cfg.target,
                expected_amount=amount,
            )
        except LookupError as exc:
            raise DepositVerificationFailed("لم يتم العثور على عملية Binance مطابقة.") from exc
        except ValueError as exc:
            raise DepositVerificationFailed("مبلغ العملية لا يطابق المبلغ المدخل.") from exc
        await self._assert_fresh_provider_tx(verified)
        return await self._settle_verified(
            telegram_id=telegram_id,
            cfg=cfg,
            tx=tx,
            amount=amount,
            target_ref=cfg.target,
            provider_payload=verified.raw or {},
        )

    async def create_manual_request(
        self,
        telegram_id: int,
        method: str,
        *,
        amount: Decimal,
        tx_raw: str | None = None,
        target_ref: str | None = None,
        proof_file_id: str | None = None,
        proof_unique_id: str | None = None,
        request_key: str | None = None,
    ) -> ManualDepositCreation:
        cfg = self._available(method, require_auto=False)
        if cfg.mode != "manual":
            raise DepositValidationError("طريقة الشحن ليست في الوضع اليدوي.")
        self._assert_minimum(amount, cfg.minimum)

        tx: str | None = None
        scope = cfg.provider_scope
        if method in {"syriatel", "sham_syp", "sham_usd"}:
            tx = self.normalize_numeric_tx(tx_raw or "")
        elif method == "whish_money":
            if not proof_file_id:
                raise DepositValidationError("صورة إشعار التحويل مطلوبة.")
            proof_key = str(proof_unique_id or "").strip()
            if not _PROOF_UNIQUE_ID_RE.fullmatch(proof_key):
                raise DepositValidationError("تعذر إنشاء بصمة آمنة لصورة التحويل. أرسل الصورة من جديد.")
            # Telegram file_unique_id gives us a second anti-duplicate barrier for
            # Whish proof-only deposits without changing the user flow.
            tx = proof_key
        else:
            raise DepositValidationError("هذه الطريقة لا تدعم المراجعة اليدوية.")

        if method == "syriatel":
            target_ref = str(target_ref or "").strip()
            if target_ref not in self.syriatel_codes():
                raise DepositValidationError("رقم سيرياتيل المحول إليه غير صحيح.")
        elif method in {"sham_syp", "sham_usd"}:
            target_ref = cfg.target
        elif method == "whish_money":
            target_ref = cfg.target

        base, bonus, total = self._credit_terms(amount, cfg)
        preview_pct = cfg.bonus_pct
        preview_source = "deposit_method"
        if self.finance_rules is not None:
            decision = await self.finance_rules.preview_deposit_bonus(
                int(telegram_id), method=method, amount_input=amount, ordinary_pct=cfg.bonus_pct
            )
            preview_pct = decision.pct
            preview_source = decision.source
            bonus = percent_amount(base, preview_pct)
            total = base + bonus
        clean_request_key = str(request_key or "").strip() or None
        if clean_request_key is not None and not re.fullmatch(r"[A-Za-z0-9:._-]{8,128}", clean_request_key):
            raise DepositValidationError("مفتاح طلب الشحن غير صالح.")

        pool = self.repository.db.require_pool()
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    deposit = await self.repository.insert_request(
                        conn,
                        telegram_id=telegram_id,
                        method=method,
                        request_key=clean_request_key,
                        provider_scope=scope,
                        provider_tx=tx,
                        amount_input=amount,
                        currency=cfg.currency,
                        rate=cfg.rate,
                        bonus_pct=preview_pct,
                        bonus_source=preview_source,
                        base_credit_syp=base,
                        bonus_credit_syp=bonus,
                        total_credit_syp=total,
                        status="manual_pending",
                        target_ref=target_ref,
                        proof_file_id=proof_file_id,
                        provider_payload={"proof_unique_id": tx} if method == "whish_money" else {},
                    )
                    await self.repository.claim_provider_tx(conn, deposit=deposit)
            return ManualDepositCreation(deposit=deposit, duplicate=False)
        except asyncpg.UniqueViolationError:
            if clean_request_key:
                existing = await self.repository.get_by_request_key(clean_request_key)
                if existing is not None and existing.telegram_id == telegram_id:
                    return ManualDepositCreation(deposit=existing, duplicate=True)
            raise DepositAlreadyUsed()
        except asyncpg.PostgresError as exc:
            # A connection/commit error may happen after PostgreSQL committed. Re-read
            # by the stable request key before telling the user anything.
            if clean_request_key:
                try:
                    existing = await self.repository.get_by_request_key(clean_request_key)
                except Exception:
                    existing = None
                if existing is not None and existing.telegram_id == telegram_id:
                    return ManualDepositCreation(deposit=existing, duplicate=True)
            raise DepositOutcomeUncertain("manual_request_outcome_uncertain") from exc

    async def approve_manual(self, deposit_id: UUID | str, admin_id: int) -> DepositSettlement:
        deposit_uuid = UUID(str(deposit_id))
        pool = self.repository.db.require_pool()
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    deposit = await self.repository.lock(conn, deposit_uuid)
                    if deposit.status == "success":
                        balance = await conn.fetchval(
                            "SELECT available FROM bot_core.wallet_accounts WHERE telegram_id=$1 AND asset_code='SYP' AND bucket='cash'",
                            deposit.telegram_id,
                        )
                        return DepositSettlement(deposit, True, int(balance or 0))
                    if deposit.status != "manual_pending":
                        raise DepositAlreadyProcessed(status=deposit.status)
                    decision = None
                    if self.finance_rules is not None:
                        cfg = self.method_config(deposit.method)
                        decision = await self.finance_rules.resolve_deposit_bonus(
                            conn, telegram_id=deposit.telegram_id, method=deposit.method,
                            amount_input=deposit.amount_input, ordinary_pct=cfg.bonus_pct, lock_special=True,
                        )
                        refreshed_bonus = percent_amount(deposit.base_credit_syp, decision.pct)
                        deposit = await self.repository.update_bonus_terms(
                            conn, deposit_id=deposit.id, bonus_pct=decision.pct,
                            bonus_source=decision.source, bonus_credit_syp=refreshed_bonus,
                        )
                    mutation = await self.wallet_service.credit_in_transaction(
                        conn,
                        deposit.telegram_id,
                        deposit.total_credit_syp,
                        idempotency_key=f"deposit:{deposit.id}",
                        reason=f"bot_wallet_deposit:{deposit.method}",
                        actor_telegram_id=admin_id,
                        metadata=self._wallet_metadata(deposit),
                    )
                    done = await self.repository.mark_success(
                        conn,
                        deposit_id=deposit.id,
                        wallet_operation_id=mutation.operation_id,
                        reviewed_by=admin_id,
                    )
                    if self.cashback_tracker is not None:
                        await self.cashback_tracker.add_real_deposit(conn, done.telegram_id, done.base_credit_syp)
                    if self.referral_service is not None:
                        await self.referral_service.on_successful_deposit(conn, done.telegram_id, done.id)
                    if decision is not None:
                        await self.finance_rules.consume_deposit_bonus(conn, decision, done.id)
                    await self._enqueue_success_notification(conn, done, reviewed_by=admin_id)
                    result = DepositSettlement(done, mutation.duplicate, mutation.balance_after.available)
            if self.outbox_worker:
                self.outbox_worker.wake()
            return result
        except (DepositAlreadyProcessed, DepositAlreadyUsed):
            raise
        except asyncpg.PostgresError as exc:
            # Never retry a credit blindly after an uncertain COMMIT. First inspect the
            # immutable deposit row; if it is success, return that proven outcome.
            try:
                existing = await self.repository.get(deposit_uuid)
            except Exception:
                existing = None
            if existing is not None and existing.status == "success":
                return DepositSettlement(existing, True, await self._balance_value(existing.telegram_id))
            raise DepositOutcomeUncertain("manual_approval_outcome_uncertain") from exc

    async def reject_manual(self, deposit_id: UUID | str, admin_id: int, note: str = "رفض من الإدارة") -> DepositRecord:
        deposit_uuid = UUID(str(deposit_id))
        pool = self.repository.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                return await self.repository.reject_manual(
                    conn, deposit_id=deposit_uuid, admin_id=admin_id, note=note
                )

    async def pending_manual(self, limit: int = 50) -> list[DepositRecord]:
        return await self.repository.list_manual_pending(limit=limit)

    async def _settle_verified(
        self,
        *,
        telegram_id: int,
        cfg: DepositMethodConfig,
        tx: str,
        amount: Decimal,
        target_ref: str | None,
        provider_payload: dict[str, Any],
    ) -> DepositSettlement:
        base, ordinary_bonus, ordinary_total = self._credit_terms(amount, cfg)
        pool = self.repository.db.require_pool()
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    decision = None
                    bonus_pct = cfg.bonus_pct
                    bonus_source = "deposit_method"
                    bonus = ordinary_bonus
                    total = ordinary_total
                    if self.finance_rules is not None:
                        decision = await self.finance_rules.resolve_deposit_bonus(
                            conn, telegram_id=telegram_id, method=cfg.method,
                            amount_input=amount, ordinary_pct=cfg.bonus_pct, lock_special=True,
                        )
                        bonus_pct = decision.pct
                        bonus_source = decision.source
                        bonus = percent_amount(base, bonus_pct)
                        total = base + bonus
                    deposit = await self.repository.insert_request(
                        conn,
                        telegram_id=telegram_id,
                        method=cfg.method,
                        request_key=None,
                        provider_scope=cfg.provider_scope,
                        provider_tx=tx,
                        amount_input=amount,
                        currency=cfg.currency,
                        rate=cfg.rate,
                        bonus_pct=bonus_pct,
                        bonus_source=bonus_source,
                        base_credit_syp=base,
                        bonus_credit_syp=bonus,
                        total_credit_syp=total,
                        status="verifying",
                        target_ref=target_ref,
                        proof_file_id=None,
                        provider_payload=provider_payload,
                    )
                    await self.repository.claim_provider_tx(conn, deposit=deposit)
                    mutation = await self.wallet_service.credit_in_transaction(
                        conn,
                        telegram_id,
                        total,
                        idempotency_key=f"deposit:{deposit.id}",
                        reason=f"bot_wallet_deposit:{cfg.method}",
                        actor_telegram_id=telegram_id,
                        metadata=self._wallet_metadata(deposit),
                    )
                    done = await self.repository.mark_success(
                        conn,
                        deposit_id=deposit.id,
                        wallet_operation_id=mutation.operation_id,
                        reviewed_by=None,
                    )
                    if self.cashback_tracker is not None:
                        await self.cashback_tracker.add_real_deposit(conn, done.telegram_id, done.base_credit_syp)
                    if self.referral_service is not None:
                        await self.referral_service.on_successful_deposit(conn, done.telegram_id, done.id)
                    if decision is not None:
                        await self.finance_rules.consume_deposit_bonus(conn, decision, done.id)
                    await self._enqueue_success_notification(conn, done, reviewed_by=None)
                    result = DepositSettlement(done, mutation.duplicate, mutation.balance_after.available)
            if self.outbox_worker:
                self.outbox_worker.wake()
            return result
        except DepositAlreadyUsed as exc:
            if exc.telegram_id == telegram_id and exc.status == "success" and exc.deposit_id:
                existing = await self.repository.get(exc.deposit_id)
                if existing is not None:
                    return DepositSettlement(existing, True, await self._balance_value(telegram_id))
            raise
        except asyncpg.PostgresError as exc:
            # The provider verification already succeeded, but the local transaction
            # outcome is uncertain. Reconcile by provider claim before returning.
            try:
                existing = (
                    await self.repository.get_claimed(cfg.provider_scope, tx)
                    if cfg.provider_scope
                    else None
                )
            except Exception:
                existing = None
            if existing is not None and existing.telegram_id == telegram_id and existing.status == "success":
                return DepositSettlement(existing, True, await self._balance_value(telegram_id))
            raise DepositOutcomeUncertain("automatic_settlement_outcome_uncertain") from exc

    async def _enqueue_success_notification(
        self,
        conn: asyncpg.Connection,
        deposit: DepositRecord,
        *,
        reviewed_by: int | None,
    ) -> None:
        if self.outbox_repository is None:
            return
        await self.outbox_repository.enqueue(
            event_key=f"bot-deposit-success:{deposit.id}",
            target_key="notify.bot_deposits",
            text=self._channel_notification(deposit, reviewed_by=reviewed_by),
            parse_mode="HTML",
            conn=conn,
        )

    def _channel_notification(self, deposit: DepositRecord, *, reviewed_by: int | None) -> str:
        threshold = self.runtime_settings.get_int("alerts.bot_deposit_large", 0) if self.runtime_settings else 0
        title = "💳 <b>شحن رصيد البوت ناجح</b>"
        # The alert compares the converted provider value before bonus; this keeps
        # every deposit method on the same wallet-value scale.
        if threshold > 0 and deposit.base_credit_syp >= threshold:
            title = "💳 <b>شحن رصيد البوت ناجح — 🚨 مبلغ كبير</b>"
        labels = {
            "syriatel": "سيرياتيل كاش",
            "sham_syp": "شام كاش – ليرة",
            "sham_usd": "شام كاش – دولار",
            "whish_money": "Whish Money",
            "binance_trc20": "Binance USDT TRC20",
            "binance_bep20": "Binance USDT BEP20",
        }
        tx = deposit.provider_tx or "-"
        lines = [
            title,
            "",
            f"🆔 Telegram ID: <code>{deposit.telegram_id}</code>",
            f"💳 الطريقة: <b>{labels.get(deposit.method, deposit.method)}</b>",
            f"💰 مبلغ المزود: <code>{deposit.amount_input} {deposit.currency}</code>",
            f"💱 معامل التحويل: <code>{deposit.rate}</code>",
            f"➕ المبلغ الأساسي: <code>{deposit.base_credit_syp:,}</code>",
        ]
        if deposit.bonus_credit_syp:
            lines.append(f"🎁 البونص: <code>{deposit.bonus_credit_syp:,}</code>")
        lines.extend([
            f"✅ الإجمالي المضاف: <code>{deposit.total_credit_syp:,}</code>",
            f"🧾 رقم العملية: <code>{tx}</code>",
            f"🔖 رقم الطلب: <code>{deposit.id}</code>",
        ])
        if reviewed_by is not None:
            lines.append(f"👮 اعتماد يدوي بواسطة: <code>{reviewed_by}</code>")
        return "\n".join(lines)

    async def _preflight_duplicate(
        self, telegram_id: int, scope: str | None, tx: str
    ) -> DepositSettlement | None:
        if not scope:
            return None
        if await self.repository.is_reserved(scope, tx):
            raise DepositAlreadyUsed("provider transaction is reserved")
        existing = await self.repository.get_claimed(scope, tx)
        if existing is None:
            return None
        if existing.telegram_id == telegram_id and existing.status == "success":
            return DepositSettlement(existing, True, await self._balance_value(telegram_id))
        raise DepositAlreadyUsed(
            deposit_id=existing.id,
            telegram_id=existing.telegram_id,
            status=existing.status,
        )

    async def _assert_fresh_provider_tx(self, tx: ProviderTransaction) -> None:
        # A brand-new deployment must not accept an old provider transaction simply
        # because its local DB has never seen that transaction number before.
        if tx.occurred_at is None:
            raise DepositVerificationFailed("تعذر التحقق من وقت العملية، لذلك لم يتم اعتمادها تلقائياً.")
        if tx.occurred_at.tzinfo is None:
            raise DepositVerificationFailed("وقت العملية غير موثوق، لذلك لم يتم اعتمادها تلقائياً.")
        if self._system_started_at is None:
            self._system_started_at = await self.repository.system_started_at()
        if self._system_started_at is None:
            raise DepositVerificationFailed("تعذر تحديد بداية سجل العمليات الآمن.")
        now = datetime.now(timezone.utc)
        if tx.occurred_at.astimezone(timezone.utc) > now + timedelta(minutes=10):
            raise DepositVerificationFailed("وقت العملية المستلم من المزود غير منطقي.")
        tx_utc = tx.occurred_at.astimezone(timezone.utc)
        if tx_utc < self._system_started_at.astimezone(timezone.utc) - timedelta(minutes=15):
            raise DepositAlreadyUsed("العملية أقدم من بداية سجل هذا البوت.")
        if tx_utc < now - timedelta(hours=self.settings.auto_deposit_max_age_hours):
            raise DepositAlreadyUsed("العملية أقدم من المدة المسموح بها للشحن الآلي.")

    def _available(self, method: str, *, require_auto: bool) -> DepositMethodConfig:
        cfg = self.method_config(method)
        if not cfg.enabled:
            raise DepositValidationError(f"الشحن عبر {cfg.label} غير متاح حالياً.")
        if require_auto and cfg.mode != "auto":
            raise DepositValidationError(f"{cfg.label} ليس في وضع التحقق الآلي حالياً.")
        return cfg

    @staticmethod
    def _assert_minimum(amount: Decimal, minimum: Decimal) -> None:
        if amount < minimum:
            raise DepositValidationError(f"المبلغ أقل من الحد الأدنى ({minimum:g}).")

    @staticmethod
    def _assert_amount_shape(amount: Decimal) -> None:
        if not amount.is_finite() or amount <= 0 or amount > _MAX_INPUT_AMOUNT:
            raise DepositValidationError("قيمة المبلغ خارج النطاق المسموح.")
        # The DB stores provider amounts as NUMERIC(28,8). Do not let PostgreSQL
        # silently round a value that was verified against a provider.
        quantum = Decimal("0.00000001")
        if amount != amount.quantize(quantum):
            raise DepositValidationError("المبلغ يحتوي على أكثر من 8 خانات عشرية.")

    @staticmethod
    def _credit_terms(amount: Decimal, cfg: DepositMethodConfig) -> tuple[int, int, int]:
        DepositService._assert_amount_shape(amount)
        try:
            base = wallet_syp_amount(amount, cfg.rate)
            bonus = percent_amount(base, cfg.bonus_pct)
        except (ValueError, ArithmeticError) as exc:
            raise DepositValidationError("تعذر حساب قيمة الشحن بأمان.") from exc
        total = base + bonus
        if total <= 0 or total > _MAX_WALLET_SYP:
            raise DepositValidationError("قيمة الشحن بعد التحويل خارج النطاق المسموح.")
        return base, bonus, total

    async def _balance_value(self, telegram_id: int) -> int:
        balance = await self.wallet_service.get_balance(telegram_id)
        return balance.available if balance else 0

    @staticmethod
    def _wallet_metadata(deposit: DepositRecord) -> dict[str, Any]:
        return {
            "deposit_id": str(deposit.id),
            "method": deposit.method,
            "provider_scope": deposit.provider_scope,
            "provider_tx": deposit.provider_tx,
            "amount_input": str(deposit.amount_input),
            "currency": deposit.currency,
            "rate": str(deposit.rate),
            "base_credit_syp": deposit.base_credit_syp,
            "bonus_credit_syp": deposit.bonus_credit_syp,
            "bonus_source": deposit.bonus_source,
        }
