from __future__ import annotations

import asyncio
import html
import secrets
from dataclasses import dataclass
from uuid import UUID

import aiohttp

from app.config import Settings
from app.core.crypto import CredentialCipher
from app.core.ichancy_names import build_username, generate_password, normalize_person_name
from app.providers.ichancy import (
    IchancyClient,
    IchancyCredentials,
    IchancyDefiniteError,
    IchancyError,
    IchancyTemporaryError,
    extract_cashier_balance,
)
from app.providers.ichancy_ws import fetch_ichancy_auth_token
from app.repositories.ichancy import AccountRecord, CashierRecord, CreationRecord, IchancyRepository
from app.services.runtime_settings import RuntimeSettingsService


@dataclass(frozen=True, slots=True)
class CreatedAccount:
    account: AccountRecord
    password: str
    recovered: bool


class IchancyAccountsService:
    def __init__(
        self,
        repository: IchancyRepository,
        runtime: RuntimeSettingsService,
        settings: Settings,
        session: aiohttp.ClientSession,
        cipher: CredentialCipher | None,
    ) -> None:
        self.repository = repository
        self.runtime = runtime
        self.settings = settings
        self.session = session
        self.cipher = cipher

    @property
    def credentials_ready(self) -> bool:
        return self.cipher is not None

    async def bootstrap_from_env(self) -> CashierRecord | None:
        if not (self.settings.ichancy_api_username and self.settings.ichancy_api_password):
            return await self.repository.get_active_cashier()
        if self.cipher is None:
            raise ValueError("ICHANCY_CREDENTIALS_KEY must be set before storing iChancy credentials")
        return await self.repository.bootstrap_cashier(
            username_cipher=self.cipher.encrypt(self.settings.ichancy_api_username),
            password_cipher=self.cipher.encrypt(self.settings.ichancy_api_password),
            parent_id=self.settings.ichancy_parent_id,
            currency=self.settings.ichancy_currency,
            base_url=self.settings.ichancy_base_url,
            gateway_url=self.settings.ichancy_gateway_url,
            gateway_secret_cipher=(self.cipher.encrypt(self.settings.ichancy_gateway_secret) if self.settings.ichancy_gateway_secret else None),
        )


    async def stage_cashier(
        self,
        *,
        username: str,
        password: str,
        created_by: int,
        parent_id: str | None = None,
        label: str | None = None,
    ) -> CashierRecord:
        if self.cipher is None:
            raise IchancyDefiniteError("مفتاح تشفير بيانات iChancy غير مضبوط")
        old = await self.repository.get_active_cashier()
        if old is None:
            base_url = self.settings.ichancy_base_url
            currency = self.settings.ichancy_currency
            gateway_url = self.settings.ichancy_gateway_url
            gateway_secret = self.settings.ichancy_gateway_secret
            inherited_parent = self.settings.ichancy_parent_id
        else:
            base_url = old.base_url
            currency = old.currency
            gateway_url = old.gateway_url
            gateway_secret = self.cipher.decrypt(old.gateway_secret_cipher) if old.gateway_secret_cipher else ""
            inherited_parent = old.parent_id
        return await self.repository.create_staged_cashier(
            label=(label or username)[:120],
            username_cipher=self.cipher.encrypt(username.strip()),
            password_cipher=self.cipher.encrypt(password),
            parent_id=(parent_id.strip() if parent_id is not None and parent_id.strip() else inherited_parent),
            currency=currency,
            base_url=base_url,
            gateway_url=gateway_url,
            gateway_secret_cipher=(self.cipher.encrypt(gateway_secret) if gateway_secret else None),
            created_by=created_by,
        )

    async def active_cashier(self) -> CashierRecord | None:
        return await self.repository.get_active_cashier()

    async def active_cashier_wallets(self) -> tuple[CashierRecord | None, dict | None]:
        """Read all wallets for the active iChancy cashier without mutating any state."""
        cashier = await self.repository.get_active_cashier()
        if cashier is None:
            return None, None
        client = self._client(cashier)
        return cashier, await client.get_agent_all_wallets()

    async def test_cashier(self, cashier: CashierRecord) -> int | None:
        try:
            client = self._client(cashier)
            balance, _ = await client.test_cashier()
            await self.repository.update_cashier_test(cashier.id, ok=True, error=None)
            return balance
        except Exception as exc:
            await self.repository.update_cashier_test(cashier.id, ok=False, error=f"{type(exc).__name__}: {exc}")
            raise

    def _client(self, cashier: CashierRecord) -> IchancyClient:
        if self.cipher is None:
            raise IchancyDefiniteError("مفتاح تشفير بيانات iChancy غير مضبوط")
        creds = IchancyCredentials(
            username=self.cipher.decrypt(cashier.api_username_cipher),
            password=self.cipher.decrypt(cashier.api_password_cipher),
            parent_id=cashier.parent_id,
            currency=cashier.currency,
            base_url=cashier.base_url,
            gateway_url=cashier.gateway_url,
            gateway_secret=(self.cipher.decrypt(cashier.gateway_secret_cipher) if cashier.gateway_secret_cipher else ""),
        )
        return IchancyClient(self.session, creds)

    async def active_account(self, telegram_id: int) -> AccountRecord | None:
        return await self.repository.get_active_account(telegram_id)

    async def cashier_username(self, cashier: CashierRecord) -> str:
        if self.cipher is None:
            raise IchancyDefiniteError("مفتاح تشفير iChancy غير مضبوط")
        return self.cipher.decrypt(cashier.api_username_cipher)

    async def account_password(self, account: AccountRecord) -> str:
        if self.cipher is None:
            raise IchancyDefiniteError("مفتاح تشفير iChancy غير مضبوط")
        return self.cipher.decrypt(account.password_cipher)

    async def create_account(self, telegram_id: int, requested_name: str, *, user_label: str = "-") -> CreatedAccount:
        existing = await self.repository.get_active_account(telegram_id)
        if existing:
            return CreatedAccount(existing, await self.account_password(existing), True)
        cashier = await self.repository.get_active_cashier()
        if cashier is None:
            raise IchancyDefiniteError("لا توجد كاشيرة iChancy نشطة حالياً")
        if self.cipher is None:
            raise IchancyDefiniteError("نظام iChancy غير جاهز بعد")

        normalized = normalize_person_name(requested_name)
        inflight = await self.repository.get_inflight_creation(telegram_id)
        if inflight is None:
            password = generate_password()
            prefix = str(self.runtime.get("ichancy.username_prefix", "bot"))
            inflight = await self.repository.begin_creation(
                telegram_id=telegram_id,
                cashier_id=cashier.id,
                requested_name=requested_name[:120],
                normalized_name=normalized,
                prefix=prefix,
                password_cipher=self.cipher.encrypt(password),
                username_factory=build_username,
                email_factory=lambda username, tg_id, seq: f"{username}_{tg_id}_{seq}_{secrets.token_hex(3)}@example.com",
            )
        password = self.cipher.decrypt(inflight.password_cipher)
        cashier = await self.repository.get_cashier(inflight.cashier_id)
        if cashier is None or cashier.status != "active":
            await self.repository.mark_creation_failed(inflight.id, "cashier no longer active")
            raise IchancyDefiniteError("تم بدء تحديث كاشيرة iChancy أثناء إنشاء الحساب. حاول من جديد بعد اكتمال التحديث.")
        client = self._client(cashier)

        # Reconciliation-first: a previous request may have created the player
        # remotely but failed before local COMMIT. Search the fixed generated name
        # before ever sending registerPlayer again.
        try:
            existing_pid = await client.get_player_id_by_username(inflight.final_username)
        except IchancyTemporaryError:
            existing_pid = None
        if existing_pid:
            account = await self._finalize(inflight, existing_pid, user_label=user_label)
            return CreatedAccount(account, password, True)

        try:
            response = await client.create_player(
                email=inflight.email,
                login=inflight.final_username,
                password=password,
            )
            raw_pid = response.get("result") if isinstance(response, dict) else None
            player_id = None
            if raw_pid not in (None, "", 0, False, 1, "1", True, "True") and not isinstance(raw_pid, (dict, list)):
                player_id = str(raw_pid)
            if not player_id:
                player_id = await client.get_player_id_by_username(inflight.final_username)
            if not player_id:
                await self.repository.mark_creation_uncertain(inflight.id, "player id unavailable after registration")
                raise IchancyTemporaryError("تم إرسال طلب الإنشاء لكن تعذر تأكيد Player ID. أعد المحاولة بعد قليل.")
            account = await self._finalize(inflight, player_id, user_label=user_label)
            return CreatedAccount(account, password, False)
        except IchancyDefiniteError as exc:
            # A duplicate-style rejection can be the delayed evidence of an earlier
            # successful but unconfirmed request. Reconcile the deterministic username
            # before declaring the creation failed.
            try:
                existing_pid = await client.get_player_id_by_username(inflight.final_username)
            except Exception:
                existing_pid = None
            if existing_pid:
                account = await self._finalize(inflight, existing_pid, user_label=user_label)
                return CreatedAccount(account, password, True)
            await self.repository.mark_creation_failed(inflight.id, str(exc))
            raise
        except (IchancyTemporaryError, asyncio.TimeoutError, aiohttp.ClientError) as exc:
            await self.repository.mark_creation_uncertain(inflight.id, str(exc))
            raise IchancyTemporaryError("تعذر تأكيد نتيجة إنشاء الحساب. أعد المحاولة بنفس الاسم بعد قليل.") from exc
        except IchancyError:
            raise
        except Exception as exc:
            await self.repository.mark_creation_uncertain(inflight.id, f"{type(exc).__name__}: {exc}")
            raise IchancyTemporaryError("تعذر تأكيد نتيجة إنشاء الحساب حالياً.") from exc

    async def _finalize(self, creation: CreationRecord, player_id: str, *, user_label: str) -> AccountRecord:
        text = (
            "🆕 <b>تم إنشاء حساب iChancy جديد</b>\n\n"
            f"👤 المستخدم: <b>{html.escape(user_label)}</b>\n"
            f"🆔 Telegram ID: <code>{creation.telegram_id}</code>\n"
            f"🎰 الحساب: <code>{html.escape(creation.final_username)}</code>\n"
            f"🎮 Player ID: <code>{html.escape(str(player_id))}</code>"
        )
        return await self.repository.finalize_creation(
            creation_id=creation.id,
            player_id=str(player_id),
            notification_text=text,
        )

    async def website_token(self, telegram_id: int) -> str | None:
        account = await self.repository.get_active_account(telegram_id)
        if account is None:
            raise IchancyDefiniteError("لا يوجد حساب iChancy نشط")
        password = await self.account_password(account)
        return await fetch_ichancy_auth_token(
            account.username,
            password,
            ws_url=self.settings.ichancy_ws_url,
            origin=self.settings.ichancy_ws_origin,
            site_id=self.settings.ichancy_ws_site_id,
            source=self.settings.ichancy_ws_source,
        )

    async def player_balance(self, telegram_id: int) -> int | None:
        account = await self.repository.get_active_account(telegram_id)
        if account is None:
            return None
        cashier = await self.repository.get_cashier(account.cashier_id)
        if cashier is None:
            return None
        from app.providers.ichancy import extract_player_balance_value
        response = await self._client(cashier).get_player_balance(account.player_id)
        return extract_player_balance_value(response)
