from __future__ import annotations

import html
import re
from decimal import Decimal, ROUND_HALF_UP
from uuid import UUID, uuid4
from typing import TYPE_CHECKING

from app.config import Settings
from app.core.money import percent_amount
from app.core.withdrawals import WithdrawRecord, WithdrawValidationError, WithdrawStateError
from app.providers.api_syria import ApiSyriaClient
from app.providers.payment import (
    PaymentProviderManager,
    ProviderFinancialDefiniteError,
    ProviderFinancialUncertain,
)
from app.repositories.withdrawals import WithdrawRepository
from app.repositories.deposits import DepositRepository
from app.services.outbox import NotificationOutboxWorker
from app.services.runtime_settings import RuntimeSettingsService
from app.core.syriatel import parse_syriatel_cash_codes
from app.core.shamcash import normalize_shamcash_address
from app.core.crypto import CredentialCipher
from app.services.wallet import WalletService
from app.services.finance_rules import FinanceRulesService

if TYPE_CHECKING:
    from app.services.rewards import CashbackPrincipalTracker


_PHONE_RE = re.compile(r"^\+?\d{8,15}$")
_TRON_RE = re.compile(r"^T[1-9A-HJ-NP-Za-km-z]{33}$")
_EVM_RE = re.compile(r"^0x[a-fA-F0-9]{40}$")


class WithdrawService:
    def __init__(
        self,
        repository: WithdrawRepository,
        wallet: WalletService,
        runtime: RuntimeSettingsService,
        settings: Settings,
        api_syria: ApiSyriaClient,
        outbox_worker: NotificationOutboxWorker | None = None,
        deposits: DepositRepository | None = None,
        secret_cipher: CredentialCipher | None = None,
        payment_providers: PaymentProviderManager | None = None,
        finance_rules: FinanceRulesService | None = None,
        cashback_tracker: "CashbackPrincipalTracker | None" = None,
    ) -> None:
        self.repository = repository
        self.wallet = wallet
        self.runtime = runtime
        self.settings = settings
        self.api_syria = api_syria
        self.outbox_worker = outbox_worker
        self.deposits = deposits
        self.secret_cipher = secret_cipher
        self.payment_providers = payment_providers
        self.finance_rules = finance_rules
        self.cashback_tracker = cashback_tracker

    def active_provider(self):
        return self.payment_providers.active() if self.payment_providers is not None else self.api_syria

    def active_provider_label(self) -> str:
        return str(getattr(self.active_provider(), "provider_label", "API SYRIA"))

    def method_enabled(self, method: str) -> bool:
        return self.runtime.get_bool(f"withdraw.{method}.enabled", True)

    def minimum(self, method: str) -> int:
        if method == "usdt":
            return max(1, self.runtime.get_int("withdraw.usdt.min_wallet", self.runtime.get_int("withdraw.min_wallet", 50000)))
        if method == "hawala":
            return max(1, self.runtime.get_int("withdraw.hawala_min_wallet", 1000000))
        if method == "syriatel":
            return max(1, self.runtime.get_int("withdraw.syriatel.min_wallet", self.runtime.get_int("withdraw.min_wallet", 50000)))
        if method == "shamcash":
            return max(1, self.runtime.get_int("withdraw.shamcash.min_wallet", self.runtime.get_int("withdraw.min_wallet", 50000)))
        return max(1, self.runtime.get_int("withdraw.min_wallet", 50000))

    def network_enabled(self, network: str) -> bool:
        network = str(network or "").upper()
        if network not in {"TRC20", "BEP20"}:
            return False
        return self.runtime.get_bool(f"withdraw.usdt.{network.lower()}.enabled", True)

    def fee_pct(self, method: str) -> Decimal:
        key = "withdraw.hawala_fee_pct" if method == "hawala" else "withdraw.fee_pct"
        pct = self.runtime.get_decimal(key, 0)
        return max(Decimal("0"), min(Decimal("100"), pct))

    def usdt_rate(self) -> Decimal:
        return max(Decimal("0.00000001"), self.runtime.get_decimal("withdraw.usdt.rate", 11500))

    def local_multiplier(self) -> Decimal:
        return max(Decimal("0.00000001"), self.runtime.get_decimal("money.local_syp_wallet_multiplier", 100))

    def syriatel_sources(self) -> tuple[str, ...]:
        fallback = ",".join(self.settings.syriatel_codes)
        raw = str(self.runtime.get("deposit.syriatel.codes", fallback) or "")
        return parse_syriatel_cash_codes(raw)

    def shamcash_source(self) -> str:
        return normalize_shamcash_address(
            self.runtime.get("deposit.sham.address_syp", self.settings.shamcash_address_syp)
        )

    def syriatel_pin_configured(self) -> bool:
        encrypted = str(self.runtime.get("withdraw.syriatel.pin_enc", "") or "").strip()
        return bool(encrypted or self.settings.syriatel_cash_pin_code.strip())

    def syriatel_pin(self) -> str:
        encrypted = str(self.runtime.get("withdraw.syriatel.pin_enc", "") or "").strip()
        if encrypted:
            if self.secret_cipher is None:
                raise WithdrawValidationError("تعذر قراءة PIN السحب لأن مفتاح التشفير غير مضبوط")
            try:
                return self.secret_cipher.decrypt(encrypted).strip()
            except Exception as exc:
                raise WithdrawValidationError("تعذر قراءة PIN السحب المحفوظ") from exc
        return self.settings.syriatel_cash_pin_code.strip()

    async def set_syriatel_pin(self, pin: str, *, updated_by: int) -> None:
        clean = str(pin or "").strip()
        if not clean.isdigit() or not (4 <= len(clean) <= 20):
            raise WithdrawValidationError("PIN سيرياتيل كاش يجب أن يكون أرقاماً فقط")
        if self.secret_cipher is None:
            raise WithdrawValidationError("لا يمكن حفظ PIN بأمان لأن مفتاح التشفير غير مضبوط")
        await self.runtime.set(
            "withdraw.syriatel.pin_enc",
            self.secret_cipher.encrypt(clean),
            updated_by=updated_by,
        )

    def shamcash_pin_configured(self) -> bool:
        encrypted = str(self.runtime.get("withdraw.shamcash.pin_enc", "") or "").strip()
        return bool(encrypted)

    def shamcash_pin(self) -> str:
        encrypted = str(self.runtime.get("withdraw.shamcash.pin_enc", "") or "").strip()
        if not encrypted:
            return ""
        if self.secret_cipher is None:
            raise WithdrawValidationError("تعذر قراءة PIN شام كاش لأن مفتاح التشفير غير مضبوط")
        try:
            return self.secret_cipher.decrypt(encrypted).strip()
        except Exception as exc:
            raise WithdrawValidationError("تعذر قراءة PIN شام كاش المحفوظ") from exc

    async def set_shamcash_pin(self, pin: str, *, updated_by: int) -> None:
        clean = str(pin or "").strip()
        if not clean.isdigit() or not (4 <= len(clean) <= 20):
            raise WithdrawValidationError("PIN شام كاش يجب أن يكون أرقاماً فقط")
        if self.secret_cipher is None:
            raise WithdrawValidationError("لا يمكن حفظ PIN بأمان لأن مفتاح التشفير غير مضبوط")
        await self.runtime.set(
            "withdraw.shamcash.pin_enc",
            self.secret_cipher.encrypt(clean),
            updated_by=updated_by,
        )

    @staticmethod
    def normalize_receiver(method: str, raw: str, network: str | None = None) -> str:
        value = str(raw or "").strip().replace(" ", "")
        if method == "syriatel":
            if not _PHONE_RE.fullmatch(value):
                raise WithdrawValidationError("رقم سيرياتيل غير صالح")
            return value
        if method == "shamcash":
            value = normalize_shamcash_address(raw)
            if len(value) < 6 or len(value) > 160:
                raise WithdrawValidationError("عنوان شام كاش غير صالح")
            return value
        if method == "usdt":
            net = str(network or "").upper()
            if net == "TRC20" and not _TRON_RE.fullmatch(value):
                raise WithdrawValidationError("عنوان TRC20 غير صالح")
            if net == "BEP20" and not _EVM_RE.fullmatch(value):
                raise WithdrawValidationError("عنوان BEP20 غير صالح")
            if net not in {"TRC20", "BEP20"}:
                raise WithdrawValidationError("شبكة USDT غير صالحة")
            return value
        if method == "hawala":
            if len(value) < 3:
                raise WithdrawValidationError("بيانات المستلم غير كافية")
            return str(raw or "").strip()
        raise WithdrawValidationError("طريقة السحب غير معروفة")

    async def preview(self, method: str, amount_wallet: int) -> tuple[Decimal, int, int, Decimal, str, Decimal | None]:
        if not self.method_enabled(method):
            raise WithdrawValidationError("طريقة السحب متوقفة حالياً")
        amount = int(amount_wallet)
        if amount < self.minimum(method):
            raise WithdrawValidationError(f"الحد الأدنى للسحب هو {self.minimum(method):,}")
        pct = (await self.finance_rules.effective_withdraw_fee_pct(method, amount) if self.finance_rules else self.fee_pct(method))
        fee = percent_amount(amount, pct)
        net = amount - fee
        if net <= 0:
            raise WithdrawValidationError("صافي السحب غير صالح")
        if method in {"syriatel", "shamcash", "hawala"}:
            rate = self.local_multiplier()
            exact = Decimal(net) / rate
            if method in {"syriatel", "shamcash"}:
                # Automated local providers accept whole provider-currency units.
                # Reject before holding money rather than silently altering the amount.
                if exact != exact.to_integral_value():
                    raise WithdrawValidationError(
                        f"المبلغ بعد العمولة يجب أن يكون متوافقاً مع معامل التحويل الحالي (1 = {rate})."
                    )
                payout = exact.to_integral_value()
            else:
                # Hawala is manual and keeps two decimal
                # places, so preserve the exact local-currency conversion to cents.
                payout = exact.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            return pct, fee, net, payout, "SYP", rate
        if method == "usdt":
            if not (self.network_enabled("TRC20") or self.network_enabled("BEP20")):
                raise WithdrawValidationError("جميع شبكات سحب USDT متوقفة حالياً")
            rate = self.usdt_rate()
            payout = (Decimal(net) / rate).quantize(Decimal("0.00000001"), rounding=ROUND_HALF_UP)
            return pct, fee, net, payout, "USDT", rate
        return pct, fee, net, Decimal(net), "SYP", Decimal("1")

    async def resolve_shamcash_name(self, receiver: str) -> str:
        source = self.shamcash_source()
        provider = self.active_provider()
        if not source or not provider.configured:
            return ""
        strict = str(getattr(provider, "provider_id", "")) == "tsa"
        try:
            name = await provider.resolve_shamcash_recipient_name(source=source, receiver=receiver)
        except Exception as exc:
            if strict:
                raise WithdrawValidationError(
                    "تعذر التحقق من حساب شام كاش عبر TSA حالياً. تحقق من العنوان أو حاول بعد قليل."
                ) from exc
            return ""
        if strict and not name:
            raise WithdrawValidationError("لم يتم العثور على حساب شام كاش بهذا العنوان عبر TSA.")
        return name

    async def create_request(
        self,
        telegram_id: int,
        *,
        method: str,
        amount_wallet: int,
        receiver: str,
        receiver_name: str | None = None,
        network: str | None = None,
    ) -> WithdrawRecord:
        if await self.repository.active_for_user(telegram_id):
            raise WithdrawValidationError("لديك طلب سحب غير محسوم حالياً")
        if method == "usdt" and not self.network_enabled(str(network or "")):
            raise WithdrawValidationError("شبكة USDT المختارة متوقفة حالياً")
        clean_receiver = self.normalize_receiver(method, receiver, network)
        pct, fee, net, payout, currency, rate = await self.preview(method, int(amount_wallet))
        request_id = uuid4()
        pool = self.repository.db.require_pool()
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    # Hold + request are one atomic financial transaction. A crash
                    # cannot leave money held without a durable withdrawal row.
                    _, hold = await self.wallet.create_hold_in_transaction(
                        conn, telegram_id, int(amount_wallet),
                        idempotency_key=f"withdraw-hold:{request_id}",
                        reason=f"bot_withdraw_reserve:{method}",
                        actor_telegram_id=telegram_id,
                        metadata={"withdraw_id": str(request_id), "method": method},
                    )
                    if self.cashback_tracker is not None:
                        await self.cashback_tracker.reserve_wallet_spend(
                            conn, source_type="bot_withdraw", source_id=request_id,
                            telegram_id=telegram_id, amount=int(amount_wallet),
                        )
                    rec = await self.repository.create_in_transaction(
                        conn, withdraw_id=request_id, telegram_id=telegram_id, method=method,
                        amount_wallet=int(amount_wallet), fee_pct=pct, fee_wallet=fee, net_wallet=net,
                        payout_amount=payout, payout_currency=currency, exchange_rate=rate,
                        receiver=clean_receiver, receiver_name=(receiver_name.strip() if receiver_name else None),
                        network=(network.upper() if network else None), wallet_hold_id=hold.id,
                    )
        except Exception as exc:
            if "ux_withdraw_one_active_per_user" in str(exc):
                raise WithdrawValidationError("لديك طلب سحب غير محسوم حالياً") from exc
            raise
        return rec

    async def cancel_user(self, withdraw_id: UUID, telegram_id: int) -> WithdrawRecord:
        pool = self.repository.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT * FROM bot_core.withdraw_requests WHERE id=$1 AND telegram_id=$2 FOR UPDATE",
                    withdraw_id, telegram_id,
                )
                if not row or str(row["status"]) != "pending":
                    raise WithdrawStateError("request is no longer cancellable")
                rec = self.repository._record(row)
                await self.wallet.release_hold_in_transaction(
                    conn, rec.wallet_hold_id,
                    idempotency_key=f"withdraw-cancel-release:{rec.id}",
                    reason="bot_withdraw_cancelled", actor_telegram_id=telegram_id,
                )
                if self.cashback_tracker is not None:
                    await self.cashback_tracker.release_wallet_spend(conn, source_type="bot_withdraw", source_id=rec.id)
                updated = await conn.fetchrow(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='cancelled',last_error='cancelled by user',finished_at=NOW(),updated_at=NOW()
                    WHERE id=$1 AND status='pending' RETURNING *
                    """,
                    withdraw_id,
                )
                if not updated:
                    raise WithdrawStateError("request is no longer cancellable")
                await self.repository.add_event(conn, withdraw_id, "cancelled", telegram_id, {})
        return self.repository._record(updated)

    async def reject_admin(self, withdraw_id: UUID, admin_id: int, note: str) -> WithdrawRecord:
        pool = self.repository.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT * FROM bot_core.withdraw_requests WHERE id=$1 FOR UPDATE", withdraw_id
                )
                if not row:
                    raise WithdrawValidationError("طلب السحب غير موجود")
                # Never release funds from an uncertain provider outcome. The
                # admin must first explicitly confirm_not_paid, which returns it
                # to pending without touching the hold.
                if str(row["status"]) != "pending":
                    if str(row["status"]) == "needs_review":
                        raise WithdrawStateError("الطلب يحتاج مراجعة نتيجة التحويل؛ أكد أولاً أنه لم يُدفع أو أنه دُفع.")
                    raise WithdrawStateError(f"لا يمكن رفض الطلب بحالته الحالية: {row['status']}")
                rec = self.repository._record(row)
                await self.wallet.release_hold_in_transaction(
                    conn, rec.wallet_hold_id,
                    idempotency_key=f"withdraw-reject-release:{rec.id}",
                    reason="bot_withdraw_rejected", actor_telegram_id=admin_id,
                    metadata={"note": note[:300]},
                )
                if self.cashback_tracker is not None:
                    await self.cashback_tracker.release_wallet_spend(conn, source_type="bot_withdraw", source_id=rec.id)
                updated = await conn.fetchrow(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='rejected',reviewed_by=$2,last_error=$3,finished_at=NOW(),updated_at=NOW()
                    WHERE id=$1 AND status='pending' RETURNING *
                    """,
                    withdraw_id, admin_id, note[:1200],
                )
                if not updated:
                    raise WithdrawStateError("تعذر رفض الطلب")
                await self.repository.add_event(conn, withdraw_id, "rejected", admin_id, {"error": note[:500]})
                user_text = (
                    "❌ <b>تم رفض طلب السحب</b>\n\n"
                    f"💳 الطريقة: <b>{html.escape(self._method_label(rec.method, rec.network))}</b>\n"
                    f"💰 المبلغ: <code>{rec.amount_wallet:,}</code>\n"
                    "تم إعادة المبلغ المحجوز إلى محفظتك."
                )
                await conn.execute(
                    """
                    INSERT INTO bot_core.notification_outbox(id,event_key,target_chat_id,text,parse_mode)
                    VALUES($1,$2,$3,$4,'HTML') ON CONFLICT(event_key) DO NOTHING
                    """,
                    uuid4(), f"bot-withdraw-user-rejected:{rec.id}", rec.telegram_id, user_text,
                )
        if self.outbox_worker:
            self.outbox_worker.wake()
        return self.repository._record(updated)

    def withdraw_sources(self, method: str) -> list[tuple[str, str, str]]:
        """Return the configured provider sources in the same order shown to admins."""
        method = str(method or "")
        if method == "syriatel":
            return [("syriatel", code, f"الكود {code}") for code in self.syriatel_sources()]
        if method == "shamcash":
            source = self.shamcash_source()
            return [("shamcash", source, "محفظة شام كاش SYP")] if source else []
        return []

    async def withdraw_source_balance(self, kind: str, source: str) -> Decimal:
        provider = self.active_provider()
        if not provider.configured:
            raise WithdrawValidationError(f"{getattr(provider, 'provider_label', 'API')} غير مضبوط")
        if kind == "syriatel":
            _actual, balance = await provider.syriatel_balance(source)
            return balance
        if kind == "shamcash":
            return await provider.shamcash_balance(source, "SYP")
        raise WithdrawValidationError("نوع حساب المصدر غير معروف")

    async def execute_auto(self, withdraw_id: UUID, admin_id: int, *, source: str | None = None) -> WithdrawRecord:
        current = await self.repository.get(withdraw_id)
        if current is None:
            raise WithdrawValidationError("طلب السحب غير موجود")
        if current.method not in {"syriatel", "shamcash"}:
            raise WithdrawStateError("هذه الطريقة تحتاج تنفيذ يدوي ثم تأكيد الدفع")
        configured_sources = self.withdraw_sources(current.method)
        requested_source = str(source or current.source_ref or "").strip()
        if requested_source:
            selected = next((item for item in configured_sources if item[1] == requested_source), None)
            if selected is None:
                raise WithdrawValidationError("حساب التنفيذ المختار لم يعد ضمن الحسابات المضبوطة")
            selected_source = selected[1]
        else:
            # Compatibility fallback for service callers outside the channel/admin UI.
            # The UI itself always forces explicit source selection before confirmation.
            selected_source = ""

        # Freeze the active provider before claiming/executing this financial request.
        provider = self.active_provider()
        if not provider.configured:
            raise WithdrawValidationError(f"{getattr(provider, 'provider_label', 'API')} غير مضبوط")
        provider_id = str(getattr(provider, "provider_id", "api_syria"))
        provider_label = str(getattr(provider, "provider_label", "API SYRIA"))

        rec = await self.repository.claim_for_processing(
            withdraw_id, admin_id, provider_id=provider_id
        )
        if rec.method not in {"syriatel", "shamcash"}:
            # Manual payout methods are finalized only after the admin confirms payment.
            await self.repository.mark_needs_review(rec.id, admin_id, "manual payout requires confirmation")
            raise WithdrawStateError("هذه الطريقة تحتاج تنفيذ يدوي ثم تأكيد الدفع")
        before_tx_ids: set[str] = set()
        snapshot_reliable = False
        try:
            if rec.method == "syriatel":
                source = selected_source or await self._pick_syriatel_source(rec.payout_amount, provider)
                rec = await self.repository.set_processing_source(rec.id, admin_id, source)
                linked = await provider.source_is_linked("syriatel", source)
                if linked is False:
                    raise ProviderFinancialDefiniteError(
                        f"حساب سيرياتيل المصدر غير ظاهر ضمن الحسابات الفعالة في {provider_label}: {source}"
                    )
                before_tx_ids, snapshot_reliable = await provider.syriatel_outgoing_snapshot(source)
                try:
                    pin = self.syriatel_pin()
                except WithdrawValidationError as exc:
                    raise ProviderFinancialDefiniteError(str(exc)) from exc
                if not pin:
                    raise ProviderFinancialDefiniteError("PIN سيرياتيل كاش غير مضبوط")
                payload = await provider.transfer_syriatel(
                    source=source, receiver=rec.receiver, amount=rec.payout_amount, pin_code=pin
                )
            else:
                source = selected_source or self.shamcash_source()
                if not source:
                    raise ProviderFinancialDefiniteError("حساب شام كاش المصدر غير مضبوط")
                rec = await self.repository.set_processing_source(rec.id, admin_id, source)
                linked = await provider.source_is_linked("shamcash", source)
                if linked is False:
                    raise ProviderFinancialDefiniteError(
                        f"حساب شام كاش المصدر غير ظاهر ضمن الحسابات الفعالة في {provider_label}: {source}"
                    )
                before_tx_ids, snapshot_reliable = await provider.shamcash_outgoing_snapshot(source)
                try:
                    sham_pin = self.shamcash_pin()
                except WithdrawValidationError as exc:
                    raise ProviderFinancialDefiniteError(str(exc)) from exc
                payload = await provider.transfer_shamcash(
                    source=source, receiver=rec.receiver, amount=rec.payout_amount, currency="SYP",
                    note="مبروك", pin=sham_pin or None,
                )
        except ProviderFinancialDefiniteError as exc:
            await self.repository.revert_pending(rec.id, admin_id, str(exc))
            raise WithdrawValidationError(str(exc)) from exc
        except ProviderFinancialUncertain as exc:
            await self.repository.mark_needs_review(
                rec.id, admin_id, str(exc), {"_api_provider": provider_id}
            )
            raise WithdrawStateError("نتيجة التحويل غير مؤكدة. الطلب يحتاج تدخل الأدمن قبل أي محاولة جديدة.") from exc
        except Exception as exc:
            await self.repository.mark_needs_review(
                rec.id, admin_id, f"{type(exc).__name__}: {exc}", {"_api_provider": provider_id}
            )
            raise WithdrawStateError("تعذر حسم نتيجة التحويل. الطلب يحتاج تدخل الأدمن بدون إعادة POST.") from exc

        provider_ref = provider.provider_reference(payload)
        if rec.method == "shamcash" and snapshot_reliable:
            resolved_tx, _resolved_name = await provider.resolve_shamcash_outgoing_transfer(
                source=source, receiver=rec.receiver, amount=rec.payout_amount, currency="SYP",
                note="مبروك", api_data=payload, exclude_tx_ids=before_tx_ids,
            )
            provider_ref = resolved_tx or provider_ref
        elif rec.method == "syriatel" and not provider_ref and snapshot_reliable:
            provider_ref = await provider.resolve_syriatel_outgoing_transfer(
                source=source, receiver=rec.receiver, amount=rec.payout_amount, exclude_tx_ids=before_tx_ids,
            )
        provider_payload = dict(payload or {})
        provider_payload["_api_provider"] = provider_id
        rec = await self.repository.set_provider_success(
            rec.id, admin_id, source_ref=source, provider_reference=provider_ref or None, payload=provider_payload
        )
        return await self.confirm_paid(rec.id, admin_id)

    async def confirm_paid(self, withdraw_id: UUID, admin_id: int) -> WithdrawRecord:
        # Explicit admin confirmation is allowed for a fresh manual request and for
        # an uncertain provider result. Lock the request before touching the hold so
        # two admins cannot finalize the same payout concurrently.
        pool = self.repository.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT * FROM bot_core.withdraw_requests WHERE id=$1 FOR UPDATE",
                    withdraw_id,
                )
                if row is None:
                    raise WithdrawValidationError("طلب السحب غير موجود")
                rec = self.repository._record(row)
                if rec.status == "success":
                    return rec
                if rec.status not in {"pending", "processing", "provider_success", "needs_review"}:
                    raise WithdrawStateError(f"لا يمكن اعتماد الطلب بحالته الحالية: {rec.status}")
                if rec.status == "processing":
                    raise WithdrawStateError("نتيجة التنفيذ الآلي غير محسومة بعد. لا يمكن اعتماد الدفع قبل مراجعة النتيجة.")
                if rec.status == "pending":
                    row = await conn.fetchrow(
                        """
                        UPDATE bot_core.withdraw_requests
                        SET status='processing',processing_by=$2,processing_at=NOW(),updated_at=NOW(),
                            last_error=COALESCE(last_error,'manual payment confirmed by admin')
                        WHERE id=$1 AND status='pending'
                        RETURNING *
                        """,
                        withdraw_id, admin_id,
                    )
                    if row is None:
                        raise WithdrawStateError("تعذر حجز طلب السحب للاعتماد")
                    rec = self.repository._record(row)
                    await self.repository.add_event(conn, withdraw_id, "manual_payment_confirmed", admin_id, {})

                mutation, _ = await self.wallet.capture_hold_in_transaction(
                    conn,
                    rec.wallet_hold_id,
                    idempotency_key=f"withdraw-capture:{rec.id}",
                    reason=f"bot_withdraw_success:{rec.method}",
                    actor_telegram_id=admin_id,
                    metadata={"withdraw_id": str(rec.id), "method": rec.method},
                )
                if self.cashback_tracker is not None:
                    await self.cashback_tracker.consume_wallet_spend(conn, source_type="bot_withdraw", source_id=rec.id)
                notification = self._channel_notification(rec)
                user_lines = [
                    "✅ <b>تم تنفيذ طلب السحب بنجاح</b>",
                    "",
                    f"💳 الطريقة: <b>{html.escape(self._method_label(rec.method, rec.network))}</b>",
                    f"💰 المبلغ: <code>{rec.amount_wallet:,}</code>",
                    f"📤 المبلغ المرسل: <code>{self._fmt_decimal(rec.payout_amount)} {rec.payout_currency}</code>",
                ]
                if rec.method == "shamcash" and rec.receiver_name:
                    user_lines.append(f"👤 اسم حساب شام كاش: <b>{html.escape(rec.receiver_name)}</b>")
                user_lines.append(f"📍 المستلم: <code>{html.escape(rec.receiver)}</code>")
                if rec.provider_reference:
                    provider_label = "رقم عملية شام كاش" if rec.method == "shamcash" else "رقم عملية المزود"
                    user_lines.append(f"🔢 {provider_label}: <code>{html.escape(rec.provider_reference)}</code>")
                user_text = "\n".join(user_lines)
                done = await self.repository.finalize_success(
                    conn,
                    withdraw_id=rec.id,
                    admin_id=admin_id,
                    wallet_operation_id=mutation.operation_id,
                    notification_text=notification,
                    user_text=user_text,
                )
        if self.outbox_worker:
            self.outbox_worker.wake()
        return done

    async def confirm_not_paid(self, withdraw_id: UUID, admin_id: int, note: str = "confirmed not paid") -> WithdrawRecord:
        rec = await self.repository.get(withdraw_id)
        if rec is None or rec.status != "needs_review":
            raise WithdrawStateError("الطلب ليس بحالة مراجعة")
        # Admin explicitly confirms no provider payout happened: keep the hold and
        # return request to pending for a fresh deliberate execution.
        pool = self.repository.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    UPDATE bot_core.withdraw_requests
                    SET status='pending',processing_by=NULL,processing_at=NULL,last_error=$2,updated_at=NOW()
                    WHERE id=$1 AND status='needs_review'
                    RETURNING *
                    """,
                    withdraw_id, note[:1200],
                )
                if not row:
                    raise WithdrawStateError("تعذر إعادة الطلب إلى الانتظار")
                await self.repository.add_event(conn, withdraw_id, "confirmed_not_paid", admin_id, {"note": note[:300]})
        return self.repository._record(row)

    async def last_successful_deposits(self, telegram_id: int, limit: int = 3):
        if self.deposits is None:
            return []
        return await self.deposits.list_successful_for_user(telegram_id, limit)

    async def _pick_syriatel_source(self, payout_amount: Decimal, provider=None) -> str:
        provider = provider or self.active_provider()
        codes = self.syriatel_sources()
        if not codes:
            raise ProviderFinancialDefiniteError("لا توجد حسابات سيرياتيل كاش مضبوطة")
        last_error: Exception | None = None
        for code in codes:
            try:
                source, balance = await provider.syriatel_balance(code)
                if balance >= payout_amount:
                    return source
            except Exception as exc:
                last_error = exc
        if last_error:
            raise ProviderFinancialDefiniteError(f"تعذر إيجاد مصدر سيرياتيل مناسب: {last_error}")
        raise ProviderFinancialDefiniteError("رصيد حسابات سيرياتيل كاش غير كافٍ")

    @staticmethod
    def _method_label(method: str, network: str | None = None) -> str:
        return {
            "syriatel": "سيرياتيل كاش",
            "shamcash": "شام كاش",
            "hawala": "حوالة",
            "usdt": f"USDT {network or ''}".strip(),
        }.get(str(method or ""), str(method or "-") or "-")

    def _channel_notification(self, rec: WithdrawRecord) -> str:
        threshold = self.runtime.get_int("alerts.bot_withdraw_large", 0)
        title = "💸 <b>سحب رصيد البوت ناجح</b>"
        if threshold > 0 and rec.amount_wallet >= threshold:
            title = "💸 <b>سحب رصيد البوت ناجح — 🚨 مبلغ كبير</b>"
        method_label = {
            "syriatel": "سيرياتيل كاش",
            "shamcash": "شام كاش",
            "hawala": "حوالة",
            "usdt": f"USDT {rec.network or ''}".strip(),
        }.get(rec.method, rec.method)
        return (
            f"{title}\n\n"
            f"🆔 Telegram ID: <code>{rec.telegram_id}</code>\n"
            f"💳 الطريقة: <b>{html.escape(method_label)}</b>\n"
            f"💰 مبلغ المحفظة: <code>{rec.amount_wallet:,}</code>\n"
            f"💸 العمولة: <code>{rec.fee_wallet:,}</code>\n"
            f"📤 المرسل: <code>{self._fmt_decimal(rec.payout_amount)} {rec.payout_currency}</code>\n"
            + (f"👤 اسم حساب شام كاش: <b>{html.escape(rec.receiver_name)}</b>\n" if rec.method == "shamcash" and rec.receiver_name else "")
            + f"📍 المستلم: <code>{html.escape(rec.receiver)}</code>\n"
            + f"🧾 رقم الطلب: <code>{rec.id}</code>"
            + (f"\n🔢 رقم العملية: <code>{html.escape(rec.provider_reference)}</code>" if rec.provider_reference else "")
        )

    @staticmethod
    def _provider_reference(payload: dict) -> str | None:
        if not isinstance(payload, dict):
            return None
        candidates = [payload]
        for key in ("data", "result", "transaction"):
            value = payload.get(key)
            if isinstance(value, dict):
                candidates.append(value)
        keys = (
            "billcode", "transaction_no", "transaction_number", "tran_id",
            "transaction_id", "reference", "reference_id", "id",
        )
        for obj in candidates:
            for key in keys:
                value = obj.get(key)
                if value not in (None, ""):
                    return str(value)
        return None

    @staticmethod
    def _fmt_decimal(value: Decimal) -> str:
        return str(int(value)) if value == value.to_integral_value() else format(value.normalize(), "f")
