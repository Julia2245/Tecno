from __future__ import annotations

from aiogram.types import User as TelegramUser

from app.repositories.users import UserRecord, UserRepository


class UserService:
    def __init__(self, repository: UserRepository) -> None:
        self.repository = repository

    async def sync_profile(self, telegram_user: TelegramUser) -> UserRecord:
        return await self.repository.upsert_from_telegram(telegram_user)

    async def sync_profile_with_created(self, telegram_user: TelegramUser) -> tuple[UserRecord, bool]:
        return await self.repository.upsert_from_telegram_with_created(telegram_user)
