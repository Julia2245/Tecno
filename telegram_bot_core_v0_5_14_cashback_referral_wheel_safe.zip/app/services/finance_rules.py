from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, TYPE_CHECKING
from uuid import UUID

import asyncpg

from app.core.finance_rules import DepositBonusDecision
from app.repositories.finance_rules import FinanceRulesRepository
from app.services.runtime_settings import RuntimeSettingsService

if TYPE_CHECKING:
    from app.services.wallet import WalletService


class FinanceRulesService:
    def __init__(
        self,
        repository: FinanceRulesRepository,
        runtime: RuntimeSettingsService,
        wallet: "WalletService | None" = None,
    ) -> None:
        self.repository = repository
        self.runtime = runtime
        self.wallet = wallet

    @staticmethod
    def _clamp_pct(value: Decimal | int | str) -> Decimal:
        pct = Decimal(str(value))
        return max(Decimal("0"), min(Decimal("100"), pct))

    @staticmethod
    def _as_utc_datetime(value: Any) -> datetime | None:
        if isinstance(value, datetime):
            dt = value
        else:
            raw = str(value or "").strip()
            if not raw:
                return None
            try:
                dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
            except ValueError:
                return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)

    async def grant_welcome_if_eligible(self, telegram_id: int) -> dict[str, Any]:
        if not self.runtime.get_bool("bonus.welcome_enabled", False):
            return {"granted": False, "reason": "disabled"}
        enabled_since = self._as_utc_datetime(self.runtime.get("bonus.welcome_enabled_since"))
        if enabled_since is None:
            return {"granted": False, "reason": "disabled"}
        mode = str(self.runtime.get("bonus.welcome_mode", "instant") or "instant").strip().lower()
        if mode not in {"instant", "first_deposit"}:
            mode = "instant"
        amount = max(0, self.runtime.get_int("bonus.welcome_amount", 0))
        first_pct = self._clamp_pct(self.runtime.get_decimal("bonus.welcome_first_deposit_pct", 0))
        if (mode == "instant" and amount <= 0) or (mode == "first_deposit" and first_pct <= 0):
            return {"granted": False, "reason": "disabled"}
        if mode == "instant" and self.wallet is None:
            return {"granted": False, "reason": "wallet_unavailable"}

        pool = self.repository.db.require_pool()
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    user = await conn.fetchrow(
                        "SELECT telegram_id,created_at FROM bot_core.users WHERE telegram_id=$1 FOR UPDATE",
                        int(telegram_id),
                    )
                    if user is None:
                        return {"granted": False, "reason": "user_not_found"}
                    joined = user["created_at"]
                    if joined.tzinfo is None:
                        joined = joined.replace(tzinfo=timezone.utc)
                    if joined.astimezone(timezone.utc) < enabled_since:
                        return {"granted": False, "reason": "before_activation"}
                    if await self.repository.existing_welcome_claim_for_update(conn, int(telegram_id)):
                        return {"granted": False, "reason": "already_claimed"}

                    if mode == "first_deposit":
                        claim = await self.repository.create_welcome_claim(
                            conn, telegram_id=int(telegram_id), claim_type="first_deposit",
                            amount_syp=0, bonus_pct=first_pct, enabled_since=enabled_since,
                        )
                        return {
                            "granted": True, "mode": "first_deposit",
                            "bonus_pct": first_pct, "claim_id": int(claim["id"]),
                        }

                    claim = await self.repository.create_welcome_claim(
                        conn, telegram_id=int(telegram_id), claim_type="instant",
                        amount_syp=int(amount), bonus_pct=Decimal("0"), enabled_since=enabled_since,
                    )
                    mutation = await self.wallet.credit_in_transaction(
                        conn, int(telegram_id), int(amount),
                        idempotency_key=f"welcome-bonus:{int(claim['id'])}",
                        reason="welcome_bonus",
                        actor_telegram_id=None,
                        metadata={"welcome_bonus_claim_id": int(claim["id"]), "mode": "instant"},
                    )
                    return {
                        "granted": True, "mode": "instant", "amount": int(amount),
                        "balance": int(mutation.balance_after.available),
                        "claim_id": int(claim["id"]),
                    }
        except asyncpg.UniqueViolationError:
            return {"granted": False, "reason": "already_claimed"}

    def ordinary_bonus_pct(self, method: str) -> Decimal:
        key = {
            "syriatel": "bonus.syriatel_pct",
            "sham_syp": "bonus.sham_syp_pct",
            "sham_usd": "bonus.sham_usd_pct",
            "whish_money": "bonus.whish_money_pct",
            "binance_trc20": "bonus.binance_usdt_pct",
            "binance_bep20": "bonus.binance_usdt_pct",
        }.get(str(method or ""), "")
        return self._clamp_pct(self.runtime.get_decimal(key, 0)) if key else Decimal("0")

    async def resolve_deposit_bonus(
        self,
        conn: asyncpg.Connection,
        *,
        telegram_id: int,
        method: str,
        amount_input: Decimal,
        ordinary_pct: Decimal,
        lock_special: bool = True,
    ) -> DepositBonusDecision:
        welcome = await self.repository.pending_welcome_for_update(conn, telegram_id)
        if welcome is not None:
            return DepositBonusDecision(
                pct=self._clamp_pct(welcome["bonus_pct"]),
                source="welcome_first_deposit",
                welcome_claim_id=int(welcome["id"]),
            )
        special = (
            await self.repository.active_special_for_update(conn, telegram_id)
            if lock_special
            else None
        )
        if special is not None:
            return DepositBonusDecision(
                pct=self._clamp_pct(special["pct"]),
                source="special_user",
                special_bonus_id=int(special["id"]),
                special_mode=str(special["mode"]),
            )
        if self.runtime.get_bool("bonus.deposit_tiers_enabled", True):
            tier = await self.repository.active_deposit_tier(conn, amount_input, method)
            if tier is not None:
                return DepositBonusDecision(self._clamp_pct(tier["pct"]), "deposit_tier")
        return DepositBonusDecision(self._clamp_pct(ordinary_pct), "deposit_method")

    async def preview_deposit_bonus(
        self,
        telegram_id: int,
        *,
        method: str,
        amount_input: Decimal,
        ordinary_pct: Decimal,
    ) -> DepositBonusDecision:
        pool = self.repository.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                welcome = await self.repository.pending_welcome_for_update(conn, telegram_id)
                if welcome is not None:
                    return DepositBonusDecision(
                        self._clamp_pct(welcome["bonus_pct"]), "welcome_first_deposit",
                        welcome_claim_id=int(welcome["id"]),
                    )
                special = await self.repository.active_special_for_update(conn, telegram_id)
                if special is not None:
                    return DepositBonusDecision(
                        self._clamp_pct(special["pct"]), "special_user",
                        int(special["id"]), str(special["mode"]),
                    )
                if self.runtime.get_bool("bonus.deposit_tiers_enabled", True):
                    tier = await self.repository.active_deposit_tier(conn, amount_input, method)
                    if tier is not None:
                        return DepositBonusDecision(self._clamp_pct(tier["pct"]), "deposit_tier")
        return DepositBonusDecision(self._clamp_pct(ordinary_pct), "deposit_method")

    async def consume_deposit_bonus(
        self, conn: asyncpg.Connection, decision: DepositBonusDecision, deposit_id: UUID
    ) -> None:
        if decision.source == "welcome_first_deposit" and decision.welcome_claim_id is not None:
            deposit_bonus = await conn.fetchval(
                "SELECT bonus_credit_syp FROM bot_core.deposit_requests WHERE id=$1", deposit_id
            )
            await self.repository.consume_welcome_first_deposit(
                conn, claim_id=decision.welcome_claim_id, deposit_id=deposit_id,
                amount_syp=int(deposit_bonus or 0),
            )
            return
        if decision.source == "special_user" and decision.special_bonus_id is not None:
            await self.repository.consume_special(
                conn,
                bonus_id=decision.special_bonus_id,
                mode=str(decision.special_mode or "once"),
                deposit_id=deposit_id,
            )

    async def effective_withdraw_fee_pct(self, method: str, amount_wallet: int) -> Decimal:
        if self.runtime.get_bool("commission.withdraw_tiers_enabled", True):
            tier = await self.repository.active_withdraw_tier(int(amount_wallet))
            if tier is not None:
                return self._clamp_pct(tier["pct"])
        key = "withdraw.hawala_fee_pct" if method == "hawala" else "withdraw.fee_pct"
        return self._clamp_pct(self.runtime.get_decimal(key, 0))

    async def list_deposit_tiers(self):
        return await self.repository.list_deposit_tiers()

    async def list_withdraw_tiers(self):
        return await self.repository.list_withdraw_tiers()

    async def get_tier(self, kind: str, tier_id: int):
        return await self.repository.get_tier(kind, tier_id)

    async def save_tier(self, kind: str, minimum, pct, *, created_by: int, tier_id: int | None = None, method_scope: str = "all"):
        return await self.repository.save_tier(kind, minimum, Decimal(str(pct)), created_by=created_by, tier_id=tier_id, method_scope=method_scope)

    async def delete_tier(self, kind: str, tier_id: int):
        await self.repository.delete_tier(kind, tier_id)

    async def set_special(self, telegram_id: int, pct, mode: str, *, created_by: int, expires_at: datetime | None = None):
        return await self.repository.set_special(telegram_id, Decimal(str(pct)), mode, created_by=created_by, expires_at=expires_at)

    async def list_active_specials(self, limit: int = 50):
        return await self.repository.list_active_specials(limit)

    async def get_special(self, bonus_id: int):
        return await self.repository.get_special(bonus_id)

    async def cancel_special(self, bonus_id: int, cancelled_by: int) -> bool:
        return await self.repository.cancel_special(bonus_id, cancelled_by)
