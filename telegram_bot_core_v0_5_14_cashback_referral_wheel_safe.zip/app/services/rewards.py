from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID
from zoneinfo import ZoneInfo

import asyncpg
from aiogram import Bot

from app.core.db import Database
from app.providers.ichancy import extract_player_balance_value
from app.services.wallet import WalletService
from app.services.runtime_settings import RuntimeSettingsService
from app.services.ichancy_accounts import IchancyAccountsService
from app.repositories.outbox import OutboxRepository

logger = logging.getLogger(__name__)
DAMASCUS = ZoneInfo("Asia/Damascus")
UTC = timezone.utc


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _damascus_day_bounds(day=None) -> tuple[datetime, datetime]:
    if day is None:
        day = _utcnow().astimezone(DAMASCUS).date()
    start_local = datetime.combine(day, datetime.min.time(), tzinfo=DAMASCUS)
    return start_local.astimezone(UTC), (start_local + timedelta(days=1)).astimezone(UTC)


def _fmt_local(dt: datetime | None) -> str:
    if not dt:
        return "-"
    return dt.astimezone(DAMASCUS).strftime("%Y-%m-%d %H:%M")


def _cashback_aligned_start(now_utc: datetime, cycle_days: int) -> datetime:
    """Return the Damascus-local cycle boundary that contains *now_utc*."""
    local = now_utc.astimezone(DAMASCUS)
    days = 1 if int(cycle_days or 7) <= 1 else 7
    if days == 1:
        boundary = datetime(local.year, local.month, local.day, 0, 0, 0, tzinfo=DAMASCUS)
    else:
        monday = local.date() - timedelta(days=local.weekday())
        boundary = datetime(monday.year, monday.month, monday.day, 0, 0, 0, tzinfo=DAMASCUS)
    return boundary.astimezone(UTC)


def _cashback_cycle_end_for(start_utc: datetime, cycle_days: int) -> datetime:
    """Return the next exact daily/weekly Damascus boundary after *start_utc*."""
    local = start_utc.astimezone(DAMASCUS)
    days = 1 if int(cycle_days or 7) <= 1 else 7
    if days == 1:
        boundary = datetime(local.year, local.month, local.day, 0, 0, 0, tzinfo=DAMASCUS)
        if local >= boundary:
            boundary += timedelta(days=1)
    else:
        monday = local.date() - timedelta(days=local.weekday())
        boundary = datetime(monday.year, monday.month, monday.day, 0, 0, 0, tzinfo=DAMASCUS)
        if local >= boundary:
            boundary += timedelta(days=7)
    return boundary.astimezone(UTC)


class CashbackPrincipalTracker:
    """Tracks the reference-style real-deposit principal separately from wallet cash.

    Wallet cash remains the authoritative spendable balance. This ledger only marks
    which part originated from real successful deposits and may therefore participate
    in cashback after it reaches iChancy. Every reservation is made under the same
    PostgreSQL transaction as the financial hold that consumes it.
    """

    def __init__(self, db: Database) -> None:
        self.db = db

    async def add_real_deposit(self, conn: asyncpg.Connection, telegram_id: int, amount: int) -> None:
        amount = max(0, int(amount))
        if amount <= 0:
            return
        await conn.execute(
            """
            INSERT INTO bot_core.cashback_wallet_principal(telegram_id,eligible_syp)
            VALUES($1,$2)
            ON CONFLICT(telegram_id) DO UPDATE
            SET eligible_syp=bot_core.cashback_wallet_principal.eligible_syp+EXCLUDED.eligible_syp,
                updated_at=NOW()
            """,
            telegram_id, amount,
        )

    async def eligible_wallet_principal(self, conn: asyncpg.Connection, telegram_id: int, *, lock: bool = False) -> int:
        sql = "SELECT eligible_syp FROM bot_core.cashback_wallet_principal WHERE telegram_id=$1"
        if lock:
            sql += " FOR UPDATE"
        value = await conn.fetchval(sql, telegram_id)
        return max(0, int(value or 0))

    async def reserve_wallet_spend(
        self,
        conn: asyncpg.Connection,
        *,
        source_type: str,
        source_id: UUID,
        telegram_id: int,
        amount: int,
    ) -> int:
        amount = max(0, int(amount))
        existing = await conn.fetchrow(
            "SELECT amount_syp,status FROM bot_core.cashback_wallet_holds WHERE source_type=$1 AND source_id=$2 FOR UPDATE",
            source_type, source_id,
        )
        if existing:
            return int(existing["amount_syp"] or 0)
        eligible = await self.eligible_wallet_principal(conn, telegram_id, lock=True)
        wallet = await conn.fetchrow(
            """
            SELECT available,held FROM bot_core.wallet_accounts
            WHERE telegram_id=$1 AND asset_code='SYP' AND bucket='cash' FOR UPDATE
            """,
            telegram_id,
        )
        # The financial hold is created immediately before this source reservation.
        # Existing holds already had their eligible source removed from this ledger,
        # so they must not inflate the ineligible amount available to the new spend.
        # Reconstruct only the unreserved balance that existed just before THIS hold.
        available_after_hold = int((wallet["available"] if wallet else 0) or 0)
        unreserved_before_this_hold = max(0, available_after_hold + amount)
        eligible = min(eligible, unreserved_before_this_hold)
        ineligible = max(0, unreserved_before_this_hold - eligible)
        eligible_used = min(eligible, max(0, amount - ineligible))
        if eligible_used:
            await conn.execute(
                "UPDATE bot_core.cashback_wallet_principal SET eligible_syp=eligible_syp-$2,updated_at=NOW() WHERE telegram_id=$1",
                telegram_id, eligible_used,
            )
        await conn.execute(
            """
            INSERT INTO bot_core.cashback_wallet_holds(source_type,source_id,telegram_id,amount_syp,status)
            VALUES($1,$2,$3,$4,'active')
            """,
            source_type, source_id, telegram_id, eligible_used,
        )
        return eligible_used

    async def release_wallet_spend(self, conn: asyncpg.Connection, *, source_type: str, source_id: UUID) -> int:
        row = await conn.fetchrow(
            "SELECT * FROM bot_core.cashback_wallet_holds WHERE source_type=$1 AND source_id=$2 FOR UPDATE",
            source_type, source_id,
        )
        if not row or str(row["status"]) != "active":
            return int(row["amount_syp"] or 0) if row else 0
        amount = int(row["amount_syp"] or 0)
        if amount:
            await conn.execute(
                """
                INSERT INTO bot_core.cashback_wallet_principal(telegram_id,eligible_syp)
                VALUES($1,$2)
                ON CONFLICT(telegram_id) DO UPDATE
                SET eligible_syp=bot_core.cashback_wallet_principal.eligible_syp+EXCLUDED.eligible_syp,
                    updated_at=NOW()
                """,
                int(row["telegram_id"]), amount,
            )
        await conn.execute(
            "UPDATE bot_core.cashback_wallet_holds SET status='released',closed_at=NOW() WHERE source_type=$1 AND source_id=$2 AND status='active'",
            source_type, source_id,
        )
        return amount

    async def consume_wallet_spend(self, conn: asyncpg.Connection, *, source_type: str, source_id: UUID) -> int:
        row = await conn.fetchrow(
            "SELECT * FROM bot_core.cashback_wallet_holds WHERE source_type=$1 AND source_id=$2 FOR UPDATE",
            source_type, source_id,
        )
        if not row:
            return 0
        if str(row["status"]) == "active":
            await conn.execute(
                "UPDATE bot_core.cashback_wallet_holds SET status='consumed',closed_at=NOW() WHERE source_type=$1 AND source_id=$2",
                source_type, source_id,
            )
        return int(row["amount_syp"] or 0)

    async def create_ichancy_deposit_allocation(
        self, conn: asyncpg.Connection, *, job_id: UUID, telegram_id: int, account_id: UUID, amount: int
    ) -> int:
        eligible = await self.reserve_wallet_spend(
            conn, source_type="ichancy_deposit", source_id=job_id, telegram_id=telegram_id, amount=amount
        )
        await conn.execute(
            """
            INSERT INTO bot_core.ichancy_cashback_allocations(
                job_id,telegram_id,account_id,operation_type,amount_syp,eligible_amount_syp,status
            ) VALUES($1,$2,$3,'deposit',$4,$5,'pending')
            ON CONFLICT(job_id) DO NOTHING
            """,
            job_id, telegram_id, account_id, int(amount), int(eligible),
        )
        return eligible

    async def release_ichancy_deposit(self, conn: asyncpg.Connection, job_id: UUID) -> None:
        await self.release_wallet_spend(conn, source_type="ichancy_deposit", source_id=job_id)
        await conn.execute(
            "UPDATE bot_core.ichancy_cashback_allocations SET status='released',settled_at=NOW() WHERE job_id=$1 AND status='pending'",
            job_id,
        )

    async def finalize_ichancy_deposit(self, conn: asyncpg.Connection, job_id: UUID) -> None:
        await self.consume_wallet_spend(conn, source_type="ichancy_deposit", source_id=job_id)
        await conn.execute(
            "UPDATE bot_core.ichancy_cashback_allocations SET status='success',settled_at=NOW() WHERE job_id=$1 AND status='pending'",
            job_id,
        )

    async def _outstanding_account_principal(self, conn: asyncpg.Connection, account_id: UUID) -> int:
        dep = int(await conn.fetchval(
            "SELECT COALESCE(SUM(eligible_amount_syp),0) FROM bot_core.ichancy_cashback_allocations WHERE account_id=$1 AND status='success' AND operation_type='deposit'",
            account_id,
        ) or 0)
        wd = int(await conn.fetchval(
            "SELECT COALESCE(SUM(eligible_amount_syp),0) FROM bot_core.ichancy_cashback_allocations WHERE account_id=$1 AND status='success' AND operation_type IN ('withdraw','retirement_withdraw')",
            account_id,
        ) or 0)
        settled = int(await conn.fetchval(
            "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.cashback_principal_settlements WHERE account_id=$1",
            account_id,
        ) or 0)
        held = int(await conn.fetchval(
            "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.cashback_principal_holds WHERE account_id=$1 AND status='active'",
            account_id,
        ) or 0)
        return max(0, dep - wd - settled - held)

    async def finalize_ichancy_withdraw(
        self,
        conn: asyncpg.Connection,
        *,
        job_id: UUID,
        telegram_id: int,
        account_id: UUID,
        operation_type: str,
        amount: int,
    ) -> int:
        existing = await conn.fetchrow("SELECT * FROM bot_core.ichancy_cashback_allocations WHERE job_id=$1 FOR UPDATE", job_id)
        if existing:
            return int(existing["eligible_amount_syp"] or 0)
        outstanding = await self._outstanding_account_principal(conn, account_id)
        eligible_return = min(max(0, int(amount)), outstanding)
        await conn.execute(
            """
            INSERT INTO bot_core.ichancy_cashback_allocations(
                job_id,telegram_id,account_id,operation_type,amount_syp,eligible_amount_syp,status,settled_at
            ) VALUES($1,$2,$3,$4,$5,$6,'success',NOW())
            """,
            job_id, telegram_id, account_id, operation_type, int(amount), eligible_return,
        )
        if eligible_return:
            await conn.execute(
                """
                INSERT INTO bot_core.cashback_wallet_principal(telegram_id,eligible_syp)
                VALUES($1,$2)
                ON CONFLICT(telegram_id) DO UPDATE
                SET eligible_syp=bot_core.cashback_wallet_principal.eligible_syp+EXCLUDED.eligible_syp,
                    updated_at=NOW()
                """,
                telegram_id, eligible_return,
            )
        return eligible_return


@dataclass(frozen=True, slots=True)
class WheelClaimResult:
    ok: bool
    message: str
    prize: int = 0
    balance: int = 0
    free: bool = False


class WheelService:
    def __init__(self, db: Database, runtime: RuntimeSettingsService, wallet: WalletService) -> None:
        self.db = db
        self.runtime = runtime
        self.wallet = wallet

    def settings(self) -> tuple[int, int]:
        return max(0, self.runtime.get_int("wheel.min_deposit", 50_000)), max(0, self.runtime.get_int("wheel.fixed_prize", 1_000))

    def free_settings(self) -> tuple[bool, int]:
        return self.runtime.get_bool("wheel.free_spin_enabled", False), max(0, self.runtime.get_int("wheel.free_prize", 0))

    async def grant_new_user_free_entitlement(self, conn: asyncpg.Connection, telegram_id: int) -> None:
        enabled, _ = self.free_settings()
        if not enabled:
            return
        await conn.execute(
            "INSERT INTO bot_core.wheel_free_entitlements(telegram_id) VALUES($1) ON CONFLICT(telegram_id) DO NOTHING",
            telegram_id,
        )

    async def free_eligible(self, telegram_id: int) -> bool:
        enabled, _ = self.free_settings()
        if not enabled:
            return False
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return bool(await conn.fetchval(
                "SELECT 1 FROM bot_core.wheel_free_entitlements WHERE telegram_id=$1 AND claimed_at IS NULL",
                telegram_id,
            ))

    async def _daily_total(self, conn: asyncpg.Connection, telegram_id: int, start: datetime, end: datetime) -> int:
        value = await conn.fetchval(
            """
            SELECT COALESCE(SUM(CASE
                WHEN COALESCE(bonus_source,'')='special_user' THEN base_credit_syp
                ELSE total_credit_syp END),0)
            FROM bot_core.deposit_requests
            WHERE telegram_id=$1 AND status='success' AND created_at >= $2 AND created_at < $3
            """,
            telegram_id, start, end,
        )
        return int(value or 0)

    async def eligibility(self, telegram_id: int) -> tuple[bool, str, int]:
        min_dep, prize = self.settings()
        today = _utcnow().astimezone(DAMASCUS).date()
        start, end = _damascus_day_bounds(today)
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            if await conn.fetchval("SELECT 1 FROM bot_core.wheel_claims WHERE telegram_id=$1 AND claim_day=$2", telegram_id, today):
                return False, "❌ لقد قمت بتدوير العجلة واستلام جائزتك اليوم بالفعل!\nانتظر للغد لتدويرة جديدة.", prize
            total = await self._daily_total(conn, telegram_id, start, end)
        if total < min_dep:
            return False, (
                f"⚠️ يجب أن تشحن حسابك اليوم بمبلغ {min_dep:,} ل.س على الأقل للحصول على تدويرة مجانية.\n\n"
                f"💰 مجموع شحناتك لليوم: {total:,} ل.س"
            ), prize
        return True, "", prize

    async def claim(self, telegram_id: int) -> WheelClaimResult:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute("SELECT pg_advisory_xact_lock($1)", int(telegram_id))
                free_enabled, free_prize = self.free_settings()
                ent = None
                if free_enabled:
                    ent = await conn.fetchrow(
                        "SELECT * FROM bot_core.wheel_free_entitlements WHERE telegram_id=$1 FOR UPDATE", telegram_id
                    )
                if ent and ent["claimed_at"] is None:
                    prize = free_prize
                    mutation = None
                    if prize > 0:
                        mutation = await self.wallet.credit_in_transaction(
                            conn, telegram_id, prize,
                            idempotency_key=f"wheel-free:{telegram_id}",
                            reason="wheel_free_claim", actor_telegram_id=telegram_id,
                            metadata={"reward_source": "wheel_free", "cashback_eligible": False},
                        )
                    await conn.execute(
                        "UPDATE bot_core.wheel_free_entitlements SET claimed_at=NOW(),prize_syp=$2,wallet_operation_id=$3 WHERE telegram_id=$1 AND claimed_at IS NULL",
                        telegram_id, prize, mutation.operation_id if mutation else None,
                    )
                    bal = mutation.balance_after.available if mutation else int(await conn.fetchval(
                        "SELECT COALESCE(available,0) FROM bot_core.wallet_accounts WHERE telegram_id=$1 AND asset_code='SYP' AND bucket='cash'", telegram_id
                    ) or 0)
                    return WheelClaimResult(True, "", prize, bal, True)

                min_dep, prize = self.settings()
                today = _utcnow().astimezone(DAMASCUS).date()
                start, end = _damascus_day_bounds(today)
                if await conn.fetchval("SELECT 1 FROM bot_core.wheel_claims WHERE telegram_id=$1 AND claim_day=$2", telegram_id, today):
                    return WheelClaimResult(False, "❌ لقد قمت بتدوير العجلة واستلام جائزتك اليوم بالفعل!\nانتظر للغد لتدويرة جديدة.")
                total = await self._daily_total(conn, telegram_id, start, end)
                if total < min_dep:
                    return WheelClaimResult(False, f"⚠️ يجب أن تشحن حسابك اليوم بمبلغ {min_dep:,} ل.س على الأقل للحصول على تدويرة مجانية.\n\n💰 مجموع شحناتك لليوم: {total:,} ل.س")
                mutation = None
                if prize > 0:
                    mutation = await self.wallet.credit_in_transaction(
                        conn, telegram_id, prize,
                        idempotency_key=f"wheel:{telegram_id}:{today.isoformat()}",
                        reason="wheel_claim", actor_telegram_id=telegram_id,
                        metadata={"reward_source": "wheel", "cashback_eligible": False},
                    )
                await conn.execute(
                    "INSERT INTO bot_core.wheel_claims(telegram_id,claim_day,prize_syp,wallet_operation_id) VALUES($1,$2,$3,$4)",
                    telegram_id, today, prize, mutation.operation_id if mutation else None,
                )
                bal = mutation.balance_after.available if mutation else int(await conn.fetchval(
                    "SELECT COALESCE(available,0) FROM bot_core.wallet_accounts WHERE telegram_id=$1 AND asset_code='SYP' AND bucket='cash'", telegram_id
                ) or 0)
                return WheelClaimResult(True, "", prize, bal, False)


class ReferralService:
    def __init__(
        self, db: Database, runtime: RuntimeSettingsService, wallet: WalletService, ichancy_accounts: IchancyAccountsService,
        outbox: OutboxRepository | None = None,
    ) -> None:
        self.db = db
        self.runtime = runtime
        self.wallet = wallet
        self.ichancy_accounts = ichancy_accounts
        self.outbox = outbox

    def fixed_settings(self) -> dict[str, Any]:
        return {
            "enabled": self.runtime.get_bool("referral.fixed_enabled", False),
            "amount": max(0, self.runtime.get_int("referral.fixed_amount", 500)),
            "trigger": "first_deposit" if str(self.runtime.get("referral.fixed_trigger", "verify")) == "first_deposit" else "verify",
        }

    async def attach_first_touch(self, conn: asyncpg.Connection, telegram_id: int, referrer_id: int | None) -> bool:
        if not referrer_id or int(referrer_id) == int(telegram_id):
            return False
        user = await conn.fetchrow("SELECT telegram_id,referrer_telegram_id,referral_status FROM bot_core.users WHERE telegram_id=$1 FOR UPDATE", telegram_id)
        ref = await conn.fetchrow("SELECT telegram_id,is_blocked,is_bot FROM bot_core.users WHERE telegram_id=$1", int(referrer_id))
        if not user or user["referrer_telegram_id"] is not None or str(user["referral_status"]) != "none":
            return False
        if not ref or bool(ref["is_blocked"]) or bool(ref["is_bot"]):
            return False
        await conn.execute(
            """
            UPDATE bot_core.users SET referrer_telegram_id=$2,referral_status='confirmed',
                referral_first_seen_at=NOW(),referral_confirmed_at=NOW(),updated_at=NOW()
            WHERE telegram_id=$1 AND referrer_telegram_id IS NULL AND referral_status='none'
            """,
            telegram_id, int(referrer_id),
        )
        cfg = self.fixed_settings()
        fixed_paid_now = False
        if cfg["enabled"] and cfg["amount"] > 0:
            await conn.execute(
                """
                INSERT INTO bot_core.referral_fixed_entitlements(
                    referred_telegram_id,referrer_telegram_id,amount_syp,trigger_type,status
                ) VALUES($1,$2,$3,$4,'pending') ON CONFLICT(referred_telegram_id) DO NOTHING
                """,
                telegram_id, int(referrer_id), int(cfg["amount"]), str(cfg["trigger"]),
            )
            if cfg["trigger"] == "verify":
                fixed_paid_now = bool(await self._grant_fixed_locked(conn, telegram_id, "verify", None))
        if self.outbox is not None and not fixed_paid_now:
            referred = await conn.fetchrow("SELECT first_name,username FROM bot_core.users WHERE telegram_id=$1", telegram_id)
            name = (str(referred['first_name'] or '').strip() if referred else '') or 'مستخدم جديد'
            username = (str(referred['username'] or '').strip() if referred and referred['username'] else '')
            user_line = f"👤 المستخدم: {name}" + (f" (@{username})" if username else "")
            await self.outbox.enqueue(
                event_key=f"referral-join:{telegram_id}", target_chat_id=int(referrer_id), conn=conn,
                text=(
                    "🎉 <b>إحالة جديدة!</b>\n\n"
                    "تم تأكيد إحالة جديدة عن طريق رابطك بنجاح.\n\n"
                    f"{user_line}\n🆔 ID: <code>{telegram_id}</code>"
                ),
            )
        return True

    async def _grant_fixed_locked(
        self, conn: asyncpg.Connection, referred_id: int, trigger: str, deposit_id: UUID | None
    ) -> dict[str, Any] | None:
        ent = await conn.fetchrow(
            "SELECT * FROM bot_core.referral_fixed_entitlements WHERE referred_telegram_id=$1 FOR UPDATE",
            referred_id,
        )
        if not ent or str(ent["status"]) != "pending" or str(ent["trigger_type"]) != str(trigger):
            return None
        amount = int(ent["amount_syp"] or 0)
        referrer = int(ent["referrer_telegram_id"])
        valid = await conn.fetchval(
            """
            SELECT 1 FROM bot_core.users u JOIN bot_core.users r ON r.telegram_id=$2
            WHERE u.telegram_id=$1 AND u.referral_status='confirmed' AND u.referrer_telegram_id=$2
              AND NOT u.is_blocked AND NOT r.is_blocked AND NOT u.is_bot AND NOT r.is_bot
            """,
            referred_id, referrer,
        )
        if amount <= 0 or not valid:
            await conn.execute(
                "UPDATE bot_core.referral_fixed_entitlements SET status='cancelled',cancelled_at=NOW(),cancel_reason='ineligible' WHERE referred_telegram_id=$1",
                referred_id,
            )
            return None
        if trigger == "first_deposit":
            first_id = await conn.fetchval(
                "SELECT id FROM bot_core.deposit_requests WHERE telegram_id=$1 AND status='success' ORDER BY settled_at,id LIMIT 1",
                referred_id,
            )
            if first_id is None or (deposit_id is not None and UUID(str(first_id)) != UUID(str(deposit_id))):
                return None
        mutation = await self.wallet.credit_in_transaction(
            conn, referrer, amount,
            idempotency_key=f"referral-fixed:{referred_id}",
            reason="referral_fixed_reward", actor_telegram_id=None,
            metadata={"referred_telegram_id": referred_id, "trigger": trigger, "cashback_eligible": False},
        )
        await conn.execute(
            """
            INSERT INTO bot_core.referral_fixed_rewards(
                referred_telegram_id,referrer_telegram_id,amount_syp,trigger_type,deposit_id,wallet_operation_id
            ) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(referred_telegram_id) DO NOTHING
            """,
            referred_id, referrer, amount, trigger, deposit_id, mutation.operation_id,
        )
        await conn.execute(
            "UPDATE bot_core.referral_fixed_entitlements SET status='paid',eligible_at=COALESCE(eligible_at,NOW()),paid_at=NOW(),deposit_id=COALESCE(deposit_id,$2) WHERE referred_telegram_id=$1",
            referred_id, deposit_id,
        )
        if self.outbox is not None:
            referred = await conn.fetchrow("SELECT first_name,username FROM bot_core.users WHERE telegram_id=$1", referred_id)
            name = (str(referred['first_name'] or '').strip() if referred else '') or 'مستخدم جديد'
            username = (str(referred['username'] or '').strip() if referred and referred['username'] else '')
            user_line = f"👤 المستخدم: {name}" + (f" (@{username})" if username else "")
            if trigger == "verify":
                text = (
                    "🎉 <b>إحالة جديدة!</b>\n\n"
                    "تم تأكيد إحالة جديدة عن طريق رابطك بنجاح.\n\n"
                    f"{user_line}\n🆔 ID: <code>{referred_id}</code>\n\n"
                    f"🎁 حصلت على مكافأة: <code>{amount:,}</code> ل.س\n"
                    f"💰 رصيدك الحالي: <code>{mutation.balance_after.available:,}</code> ل.س"
                )
            else:
                text = (
                    "🎁 <b>مكافأة إحالة</b>\n\n"
                    "أكملت إحالتك أول عملية شحن ناجحة.\n\n"
                    f"{user_line}\n🆔 ID: <code>{referred_id}</code>\n\n"
                    f"🎁 تمت إضافة: <code>{amount:,}</code> ل.س\n"
                    f"💰 رصيدك الحالي: <code>{mutation.balance_after.available:,}</code> ل.س"
                )
            await self.outbox.enqueue(
                event_key=f"referral-fixed-user:{referred_id}", target_chat_id=referrer, conn=conn, text=text
            )
        return {"referrer": referrer, "amount": amount, "balance": mutation.balance_after.available}

    async def on_successful_deposit(self, conn: asyncpg.Connection, telegram_id: int, deposit_id: UUID) -> None:
        await self._grant_fixed_locked(conn, telegram_id, "first_deposit", deposit_id)

    async def current_cycle(self) -> asyncpg.Record | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetchrow(
                "SELECT * FROM bot_core.referral_cycles WHERE status IN ('active','preparing','ready','distributing') ORDER BY id DESC LIMIT 1"
            )

    async def start_cycle(self, *, mode: str, admin_id: int | None = None) -> asyncpg.Record:
        mode = "hierarchical" if mode == "hierarchical" else "direct"
        days = max(1, self.runtime.get_int("referral.cycle_days", 10))
        direct = self.runtime.get_decimal("referral.direct_pct", Decimal("4"))
        p1 = self.runtime.get_decimal("referral.level1_pct", direct)
        p2 = self.runtime.get_decimal("referral.level2_pct", Decimal("2"))
        p3 = self.runtime.get_decimal("referral.level3_pct", Decimal("1"))
        min_refs = max(0, self.runtime.get_int("referral.min_active_refs", 3))
        active_min = max(0, self.runtime.get_int("referral.active_min_deposit", 0))
        now = _utcnow()
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                existing = await conn.fetchrow(
                    "SELECT id FROM bot_core.referral_cycles WHERE status IN ('active','preparing','ready','distributing') FOR UPDATE"
                )
                if existing:
                    raise ValueError("REFERRAL_CYCLE_ALREADY_OPEN")
                return await conn.fetchrow(
                    """
                    INSERT INTO bot_core.referral_cycles(
                        mode,status,duration_days,cycle_start,cycle_end,direct_pct,level1_pct,level2_pct,level3_pct,
                        min_active_refs,active_min_deposit
                    ) VALUES($1,'active',$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *
                    """,
                    mode, days, now, now + timedelta(days=days), direct, p1, p2, p3, min_refs, active_min,
                )

    async def active_direct_count(self, conn: asyncpg.Connection, referrer_id: int, cycle: asyncpg.Record, cutoff: datetime | None = None) -> int:
        cutoff = cutoff or min(_utcnow(), cycle["cycle_end"])
        active_min = max(1, int(cycle["active_min_deposit"] or 0))
        return int(await conn.fetchval(
            """
            SELECT COUNT(*) FROM bot_core.users u
            WHERE u.referrer_telegram_id=$1 AND u.referral_status='confirmed' AND NOT u.is_blocked AND NOT u.is_bot
              AND u.referral_confirmed_at < $3
              AND EXISTS (
                SELECT 1 FROM bot_core.deposit_requests d
                WHERE d.telegram_id=u.telegram_id AND d.status='success'
                  AND d.settled_at >= $2 AND d.settled_at < $3
                  AND d.settled_at >= u.referral_confirmed_at
                  AND d.base_credit_syp >= $4
              )
            """,
            referrer_id, cycle["cycle_start"], cutoff, active_min,
        ) or 0)

    async def dashboard(self, telegram_id: int) -> dict[str, Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            total = int(await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.users WHERE referrer_telegram_id=$1 AND referral_status='confirmed'", telegram_id
            ) or 0)
            cycle = await conn.fetchrow(
                "SELECT * FROM bot_core.referral_cycles WHERE status IN ('active','preparing','ready','distributing') ORDER BY id DESC LIMIT 1"
            )
            active = await self.active_direct_count(conn, telegram_id, cycle) if cycle else 0
            fixed_paid = int(await conn.fetchval(
                "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_fixed_rewards WHERE referrer_telegram_id=$1", telegram_id
            ) or 0)
            pending = int(await conn.fetchval(
                "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 AND status='pending'", telegram_id
            ) or 0)
            distributed = int(await conn.fetchval(
                "SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 AND status='paid'", telegram_id
            ) or 0)
        cfg = self.fixed_settings()
        out: dict[str, Any] = {
            "total": total, "active": active, "fixed": fixed_paid, "pending": pending, "distributed": distributed,
            "fixed_enabled": cfg["enabled"], "fixed_amount": cfg["amount"], "fixed_trigger": cfg["trigger"],
            "status": "none", "mode": str(self.runtime.get("referral.mode", "direct")),
        }
        if cycle:
            now = _utcnow()
            out.update(dict(cycle))
            out["remaining_seconds"] = max(0, int((cycle["cycle_end"] - now).total_seconds()))
            out["remaining_days"] = max(0, int((cycle["cycle_end"] - now).total_seconds() // 86400))
            out["cycle_days"] = int(cycle["duration_days"])
        return out

    async def my_referrals(self, telegram_id: int, limit: int = 20) -> tuple[list[dict[str, Any]], int]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow(
                "SELECT * FROM bot_core.referral_cycles WHERE status IN ('active','preparing','ready','distributing') ORDER BY id DESC LIMIT 1"
            )
            rows = await conn.fetch(
                """
                SELECT telegram_id,first_name,username,referral_confirmed_at
                FROM bot_core.users WHERE referrer_telegram_id=$1 AND referral_status='confirmed'
                ORDER BY referral_confirmed_at DESC,telegram_id DESC LIMIT $2
                """,
                telegram_id, limit,
            )
            total = int(await conn.fetchval(
                "SELECT COUNT(*) FROM bot_core.users WHERE referrer_telegram_id=$1 AND referral_status='confirmed'", telegram_id
            ) or 0)
            output = []
            for r in rows:
                active = bool(cycle and await self._is_direct_active(conn, int(r["telegram_id"]), cycle))
                output.append({**dict(r), "is_active": active})
        return output, total

    async def _is_direct_active(self, conn: asyncpg.Connection, referred_id: int, cycle: asyncpg.Record) -> bool:
        active_min = max(1, int(cycle["active_min_deposit"] or 0))
        return bool(await conn.fetchval(
            """
            SELECT 1 FROM bot_core.users u WHERE u.telegram_id=$1 AND u.referral_status='confirmed' AND NOT u.is_blocked AND NOT u.is_bot
              AND u.referral_confirmed_at < $3
              AND EXISTS(SELECT 1 FROM bot_core.deposit_requests d WHERE d.telegram_id=u.telegram_id AND d.status='success'
                  AND d.settled_at >= $2 AND d.settled_at < $3 AND d.settled_at >= u.referral_confirmed_at AND d.base_credit_syp >= $4)
            """,
            referred_id, cycle["cycle_start"], min(_utcnow(), cycle["cycle_end"]), active_min,
        ))

    async def earnings_report(self, telegram_id: int) -> dict[str, Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            fixed = int(await conn.fetchval("SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_fixed_rewards WHERE referrer_telegram_id=$1", telegram_id) or 0)
            distributed = int(await conn.fetchval("SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 AND status='paid'", telegram_id) or 0)
            pending = int(await conn.fetchval("SELECT COALESCE(SUM(amount_syp),0) FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 AND status='pending'", telegram_id) or 0)
            latest = await conn.fetch(
                "SELECT level,amount_syp,status,created_at FROM bot_core.referral_earnings WHERE referrer_telegram_id=$1 ORDER BY id DESC LIMIT 10",
                telegram_id,
            )
        return {"fixed": fixed, "distributed": distributed, "pending": pending, "latest": [dict(x) for x in latest]}

    async def _balance_for_account(self, account_id: UUID) -> tuple[int, datetime]:
        account = await self.ichancy_accounts.repository.get_account(account_id)
        if not account:
            raise RuntimeError("iChancy account missing")
        cashier = await self.ichancy_accounts.repository.get_cashier(account.cashier_id)
        if not cashier:
            raise RuntimeError("iChancy cashier missing")
        last: Exception | None = None
        for attempt in range(3):
            try:
                resp = await self.ichancy_accounts._client(cashier).get_player_balance(account.player_id)
                value = extract_player_balance_value(resp)
                if value is None:
                    raise RuntimeError("empty player balance")
                return max(0, int(value)), _utcnow()
            except Exception as exc:
                last = exc
                if attempt < 2:
                    await asyncio.sleep(0.7 * (attempt + 1))
        raise RuntimeError(str(last or "balance lookup failed"))

    async def _signed_result_for_user(self, telegram_id: int, start: datetime, end: datetime) -> tuple[int, dict[str, Any]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            accounts = await conn.fetch(
                """
                SELECT DISTINCT account_id FROM bot_core.ichancy_jobs
                WHERE telegram_id=$1 AND status='success' AND operation_type IN ('deposit','withdraw','retirement_withdraw')
                  AND finished_at >= $2 AND finished_at < $3
                """,
                telegram_id, start, end,
            )
        total = 0
        details = []
        for ar in accounts:
            account_id = ar["account_id"]
            async with pool.acquire() as conn:
                sums = await conn.fetchrow(
                    """
                    SELECT COALESCE(SUM(CASE WHEN operation_type='deposit' THEN amount ELSE 0 END),0) dep,
                           COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN amount ELSE 0 END),0) wd
                    FROM bot_core.ichancy_jobs
                    WHERE telegram_id=$1 AND account_id=$2 AND status='success' AND finished_at >= $3 AND finished_at < $4
                    """,
                    telegram_id, account_id, start, end,
                )
            dep, wd = int(sums["dep"] or 0), int(sums["wd"] or 0)
            if dep == 0 and wd == 0:
                continue
            observed, captured_at = await self._balance_for_account(account_id)
            async with pool.acquire() as conn:
                post = await conn.fetchrow(
                    """
                    SELECT COALESCE(SUM(CASE WHEN operation_type='deposit' THEN amount ELSE 0 END),0) dep,
                           COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN amount ELSE 0 END),0) wd
                    FROM bot_core.ichancy_jobs
                    WHERE account_id=$1 AND status='success' AND finished_at >= $2 AND finished_at <= $3
                    """,
                    account_id, end, captured_at,
                )
            adjusted = max(0, observed - int(post["dep"] or 0) + int(post["wd"] or 0))
            cash_net = dep - wd
            signed = cash_net if cash_net < 0 else max(0, cash_net - adjusted)
            total += signed
            details.append({
                "account_id": str(account_id), "deposits": dep, "withdrawals": wd,
                "observed_balance": observed, "adjusted_end_balance": adjusted, "signed_result": signed,
            })
        return int(total), {"accounts": details}

    async def _network_chain(self, conn: asyncpg.Connection, referred_id: int, cycle: asyncpg.Record) -> list[dict[str, Any]]:
        mode = str(cycle["mode"])
        max_level = 1 if mode == "direct" else 3
        pcts = [Decimal(str(cycle["direct_pct"] if mode == "direct" else cycle["level1_pct"])), Decimal(str(cycle["level2_pct"])), Decimal(str(cycle["level3_pct"]))]
        chain: list[dict[str, Any]] = []
        current = referred_id
        seen = {int(referred_id)}
        effective = cycle["cycle_start"]
        for level in range(1, max_level + 1):
            u = await conn.fetchrow(
                "SELECT referrer_telegram_id,referral_status,referral_confirmed_at FROM bot_core.users WHERE telegram_id=$1", current
            )
            if not u or str(u["referral_status"]) != "confirmed" or not u["referrer_telegram_id"]:
                break
            referrer = int(u["referrer_telegram_id"])
            if referrer in seen:
                break
            seen.add(referrer)
            owner = await conn.fetchrow(
                "SELECT is_blocked,is_bot FROM bot_core.users WHERE telegram_id=$1", referrer
            )
            if not owner or bool(owner["is_blocked"]) or bool(owner["is_bot"]):
                break
            if u["referral_confirmed_at"]:
                effective = max(effective, u["referral_confirmed_at"])
            active_count = await self.active_direct_count(conn, referrer, cycle, cutoff=cycle["cycle_end"])
            qualifies = active_count >= int(cycle["min_active_refs"] or 0) and pcts[level-1] > 0
            chain.append({"referrer": referrer, "level": level, "pct": pcts[level-1], "window_start": effective, "qualifies": qualifies})
            current = referrer
        return chain

    async def prepare_ended_cycle(self, cycle_id: int) -> dict[str, Any]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1 FOR UPDATE", cycle_id)
                if not cycle or str(cycle["status"]) not in {"active", "preparing"}:
                    return {"done": False}
                if cycle["cycle_end"] > _utcnow():
                    return {"done": False}
                await conn.execute("UPDATE bot_core.referral_cycles SET status='preparing',updated_at=NOW() WHERE id=$1", cycle_id)
                await conn.execute("DELETE FROM bot_core.referral_earnings WHERE cycle_id=$1 AND status='pending'", cycle_id)
                await conn.execute("DELETE FROM bot_core.referral_cycle_payouts WHERE cycle_id=$1 AND status='pending'", cycle_id)
                cycle = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1", cycle_id)
                referred_rows = await conn.fetch(
                    "SELECT telegram_id FROM bot_core.users WHERE referral_status='confirmed' AND referral_confirmed_at < $1 AND NOT is_blocked AND NOT is_bot ORDER BY telegram_id",
                    cycle["cycle_end"],
                )
        aggregated: dict[tuple[int,int,Decimal], int] = {}
        snapshot_rows: list[tuple[int, datetime, int, dict[str, Any]]] = []
        for rr in referred_rows:
            referred = int(rr["telegram_id"])
            async with pool.acquire() as conn:
                chain = await self._network_chain(conn, referred, cycle)
            if not chain:
                continue
            level_results = []
            base_signed = 0
            base_details: dict[str, Any] = {}
            for idx, item in enumerate(chain):
                if not item["qualifies"]:
                    continue
                signed, details = await self._signed_result_for_user(referred, item["window_start"], cycle["cycle_end"])
                if idx == 0:
                    base_signed, base_details = signed, details
                key = (int(item["referrer"]), int(item["level"]), Decimal(item["pct"]))
                aggregated[key] = aggregated.get(key, 0) + int(signed)
                level_results.append({"referrer_tg": key[0], "level": key[1], "pct": str(key[2]), "window_start": item["window_start"].isoformat(), "net_loss": int(signed)})
            snapshot_rows.append((referred, chain[0]["window_start"], base_signed, {**base_details, "levels": level_results}))
        async with pool.acquire() as conn:
            async with conn.transaction():
                own = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1 FOR UPDATE", cycle_id)
                if not own or str(own["status"]) != "preparing":
                    return {"done": False}
                for referred, window_start, signed, details in snapshot_rows:
                    await conn.execute(
                        """
                        INSERT INTO bot_core.referral_loss_snapshots(cycle_id,referred_telegram_id,window_start,window_end,net_result_syp,details,status)
                        VALUES($1,$2,$3,$4,$5,$6::jsonb,'ready')
                        ON CONFLICT(cycle_id,referred_telegram_id) DO UPDATE SET window_start=EXCLUDED.window_start,window_end=EXCLUDED.window_end,
                            net_result_syp=EXCLUDED.net_result_syp,details=EXCLUDED.details,status='ready',prepared_at=NOW()
                        """,
                        cycle_id, referred, window_start, own["cycle_end"], signed, json.dumps(details, ensure_ascii=False),
                    )
                for (referrer, level, pct), network_result in aggregated.items():
                    if network_result <= 0:
                        continue
                    amount = int((Decimal(network_result) * pct / Decimal(100)).quantize(Decimal("1")))
                    if amount <= 0:
                        continue
                    await conn.execute(
                        """
                        INSERT INTO bot_core.referral_earnings(cycle_id,referrer_telegram_id,level,pct,base_net_loss_syp,amount_syp,status)
                        VALUES($1,$2,$3,$4,$5,$6,'pending')
                        ON CONFLICT(cycle_id,referrer_telegram_id,level) DO UPDATE SET pct=EXCLUDED.pct,base_net_loss_syp=EXCLUDED.base_net_loss_syp,amount_syp=EXCLUDED.amount_syp
                        """,
                        cycle_id, referrer, level, pct, network_result, amount,
                    )
                due = await conn.fetch(
                    """
                    SELECT referrer_telegram_id,COALESCE(SUM(amount_syp),0) amount
                    FROM bot_core.referral_earnings WHERE cycle_id=$1 AND status='pending'
                    GROUP BY referrer_telegram_id HAVING COALESCE(SUM(amount_syp),0)>0
                    """,
                    cycle_id,
                )
                total = 0
                for d in due:
                    referrer, amount = int(d["referrer_telegram_id"]), int(d["amount"] or 0)
                    total += amount
                    active = await self.active_direct_count(conn, referrer, own, cutoff=own["cycle_end"])
                    await conn.execute(
                        """
                        INSERT INTO bot_core.referral_cycle_payouts(cycle_id,referrer_telegram_id,amount_syp,active_referrals,status)
                        VALUES($1,$2,$3,$4,'pending') ON CONFLICT(cycle_id,referrer_telegram_id) DO NOTHING
                        """,
                        cycle_id, referrer, amount, active,
                    )
                status = "ready" if due else "empty"
                await conn.execute(
                    "UPDATE bot_core.referral_cycles SET status=$2,prepared_at=NOW(),eligible_count=$3,total_amount_syp=$4,updated_at=NOW() WHERE id=$1",
                    cycle_id, status, len(due), total,
                )
        return {"done": True, "status": status, "count": len(due), "total": total}

    async def distribute(self, cycle_id: int, admin_id: int) -> dict[str, Any]:
        pool = self.db.require_pool()
        paid = total = skipped = 0
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1 FOR UPDATE", cycle_id)
                if not cycle or str(cycle["status"]) not in {"ready", "distributing"}:
                    raise ValueError("REFERRAL_CYCLE_NOT_READY")
                await conn.execute("UPDATE bot_core.referral_cycles SET status='distributing',updated_at=NOW() WHERE id=$1", cycle_id)
                rows = await conn.fetch("SELECT * FROM bot_core.referral_cycle_payouts WHERE cycle_id=$1 AND status='pending' ORDER BY referrer_telegram_id FOR UPDATE", cycle_id)
                for row in rows:
                    amount = int(row["amount_syp"] or 0)
                    tg = int(row["referrer_telegram_id"])
                    valid = bool(await conn.fetchval(
                        "SELECT 1 FROM bot_core.users WHERE telegram_id=$1 AND NOT is_blocked AND NOT is_bot", tg
                    ))
                    if amount <= 0 or not valid:
                        await conn.execute(
                            "UPDATE bot_core.referral_cycle_payouts SET status='skipped',paid_at=NOW() WHERE cycle_id=$1 AND referrer_telegram_id=$2 AND status='pending'",
                            cycle_id, tg,
                        )
                        await conn.execute(
                            "UPDATE bot_core.referral_earnings SET status='skipped',distributed_at=NOW() WHERE cycle_id=$1 AND referrer_telegram_id=$2 AND status='pending'",
                            cycle_id, tg,
                        )
                        skipped += 1
                        continue
                    mutation = await self.wallet.credit_in_transaction(
                        conn, tg, amount,
                        idempotency_key=f"referral-cycle:{cycle_id}:{tg}", reason="referral_distribution",
                        actor_telegram_id=admin_id, metadata={"cycle_id": cycle_id, "cashback_eligible": False},
                    )
                    await conn.execute(
                        "UPDATE bot_core.referral_cycle_payouts SET status='paid',paid_at=NOW(),wallet_operation_id=$3 WHERE cycle_id=$1 AND referrer_telegram_id=$2",
                        cycle_id, tg, mutation.operation_id,
                    )
                    await conn.execute(
                        "UPDATE bot_core.referral_earnings SET status='paid',distributed_at=NOW() WHERE cycle_id=$1 AND referrer_telegram_id=$2 AND status='pending'",
                        cycle_id, tg,
                    )
                    if self.outbox is not None:
                        await self.outbox.enqueue(
                            event_key=f"referral-cycle-user:{cycle_id}:{tg}", target_chat_id=tg, conn=conn,
                            text=(
                                "🎉 <b>تم توزيع أرباح الإحالات</b>\n\n"
                                f"💰 أرباح هذه الدورة: <code>{amount:,}</code> ل.س\n"
                                f"👛 رصيدك الحالي: <code>{mutation.balance_after.available:,}</code> ل.س"
                            ),
                        )
                    paid += 1; total += amount
                await conn.execute(
                    "UPDATE bot_core.referral_cycles SET status='distributed',distributed_at=NOW(),distributed_by=$2,paid_count=$3,total_paid_syp=$4,skipped_count=$5,updated_at=NOW() WHERE id=$1",
                    cycle_id, admin_id, paid, total, skipped,
                )
        return {"paid_count": paid, "total": total, "skipped_count": skipped}

    async def skip(self, cycle_id: int, admin_id: int) -> None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1 FOR UPDATE", cycle_id)
                if not cycle or str(cycle["status"]) not in {"ready", "empty"}:
                    raise ValueError("REFERRAL_CYCLE_NOT_SKIPPABLE")
                stats = await conn.fetchrow(
                    "SELECT COUNT(*) cnt,COALESCE(SUM(amount_syp),0) amount FROM bot_core.referral_cycle_payouts WHERE cycle_id=$1 AND status='pending'",
                    cycle_id,
                )
                await conn.execute("UPDATE bot_core.referral_cycle_payouts SET status='skipped',paid_at=NOW() WHERE cycle_id=$1 AND status='pending'", cycle_id)
                await conn.execute("UPDATE bot_core.referral_earnings SET status='skipped',distributed_at=NOW() WHERE cycle_id=$1 AND status='pending'", cycle_id)
                await conn.execute(
                    "UPDATE bot_core.referral_cycles SET status='skipped',skipped_at=NOW(),skipped_by=$2,skipped_eligible_count=$3,skipped_amount_syp=$4,updated_at=NOW() WHERE id=$1",
                    cycle_id, admin_id, int(stats['cnt'] or 0), int(stats['amount'] or 0),
                )

    async def history(self, limit: int = 8, offset: int = 0) -> list[asyncpg.Record]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(
                "SELECT * FROM bot_core.referral_cycles ORDER BY id DESC LIMIT $1 OFFSET $2",
                max(1, min(50, int(limit))), max(0, int(offset)),
            )

    async def cycle_detail(self, cycle_id: int) -> tuple[asyncpg.Record | None, list[asyncpg.Record]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow("SELECT * FROM bot_core.referral_cycles WHERE id=$1", int(cycle_id))
            if not cycle:
                return None, []
            payouts = await conn.fetch(
                "SELECT * FROM bot_core.referral_cycle_payouts WHERE cycle_id=$1 ORDER BY amount_syp DESC,referrer_telegram_id",
                int(cycle_id),
            )
            return cycle, payouts


class CashbackService:
    def __init__(
        self, db: Database, runtime: RuntimeSettingsService, wallet: WalletService,
        ichancy_accounts: IchancyAccountsService, tracker: CashbackPrincipalTracker,
        outbox: OutboxRepository | None = None,
    ) -> None:
        self.db = db
        self.runtime = runtime
        self.wallet = wallet
        self.ichancy_accounts = ichancy_accounts
        self.tracker = tracker
        self.outbox = outbox

    def default_pct(self) -> Decimal:
        return max(Decimal(0), self.runtime.get_decimal("cashback.default_pct", Decimal(0)))

    async def ensure_cycle(self) -> asyncpg.Record:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow("SELECT * FROM bot_core.cashback_cycles WHERE status IN ('open','preparing') ORDER BY id DESC LIMIT 1 FOR UPDATE")
                if row:
                    return row
                days = self.runtime.get_int("cashback.next_cycle_days", 0) or self.runtime.get_int("cashback.cycle_days", 7)
                days = 1 if days <= 1 else 7
                if self.runtime.get_int("cashback.next_cycle_days", 0):
                    await self.runtime.set("cashback.cycle_days", days, updated_by=None)
                    await self.runtime.set("cashback.next_cycle_days", 0, updated_by=None)
                now = _utcnow()
                # Exact reference boundaries: daily cycles are Damascus 00:00→00:00
                # and weekly cycles are Monday 00:00→next Monday 00:00.  Once a
                # chain exists, every new cycle starts at the exact prior boundary.
                previous_end = await conn.fetchval(
                    "SELECT cycle_end FROM bot_core.cashback_cycles ORDER BY cycle_end DESC,id DESC LIMIT 1"
                )
                start = (
                    previous_end
                    if previous_end is not None and previous_end <= now
                    else _cashback_aligned_start(now, days)
                )
                end = _cashback_cycle_end_for(start, days)
                return await conn.fetchrow(
                    """
                    INSERT INTO bot_core.cashback_cycles(status,cycle_days,cycle_start,cycle_end,pct,min_turnover)
                    VALUES('open',$1,$2,$3,$4,$5) RETURNING *
                    """,
                    days, start, end, self.default_pct(), max(0,self.runtime.get_int("cashback.min_turnover",200_000)),
                )

    async def current_info(self) -> dict[str, Any]:
        cycle = await self.ensure_cycle()
        now = _utcnow()
        return {**dict(cycle), "start_local": _fmt_local(cycle["cycle_start"]),
                "end_local": _fmt_local(cycle["cycle_end"] - timedelta(minutes=1)),
                "remaining_seconds": max(0,int((cycle["cycle_end"]-now).total_seconds())), "is_finished": cycle["cycle_end"] <= now}

    async def set_mode(self, days: int, admin_id: int) -> dict[str, Any]:
        days = 1 if int(days) <= 1 else 7
        cycle = await self.ensure_cycle()
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            used = int(await conn.fetchval(
                """
                SELECT COUNT(*) FROM bot_core.ichancy_cashback_allocations a
                WHERE a.status='success' AND a.eligible_amount_syp>0
                  AND a.settled_at >= $1 AND a.settled_at < $2
                """, cycle["cycle_start"], cycle["cycle_end"]
            ) or 0)
            if str(cycle["status"]) == "open" and used == 0:
                new_end = _cashback_cycle_end_for(cycle["cycle_start"], days)
                # Never rewrite the current period to a boundary already in the past.
                if new_end > _utcnow():
                    await conn.execute(
                        "UPDATE bot_core.cashback_cycles SET cycle_days=$2,cycle_end=$3,updated_at=NOW() WHERE id=$1 AND status='open'",
                        cycle["id"], days, new_end,
                    )
                    await self.runtime.set("cashback.cycle_days", days, updated_by=admin_id)
                    return {"scheduled": False}
        await self.runtime.set("cashback.next_cycle_days", days, updated_by=admin_id)
        return {"scheduled": True}

    async def set_pct(self, pct: Decimal, admin_id: int) -> None:
        pct = min(Decimal(100), max(Decimal(0), Decimal(str(pct))))
        await self.runtime.set("cashback.default_pct", str(pct), updated_by=admin_id)
        cycle = await self.ensure_cycle()
        if str(cycle["status"]) == "open":
            pool = self.db.require_pool();
            async with pool.acquire() as conn:
                await conn.execute("UPDATE bot_core.cashback_cycles SET pct=$2,updated_at=NOW() WHERE id=$1 AND status='open'", cycle["id"], pct)

    async def set_min_turnover(self, amount: int, admin_id: int) -> None:
        amount = max(0,int(amount))
        await self.runtime.set("cashback.min_turnover", amount, updated_by=admin_id)
        cycle = await self.ensure_cycle()
        if str(cycle["status"]) == "open":
            pool=self.db.require_pool();
            async with pool.acquire() as conn:
                await conn.execute("UPDATE bot_core.cashback_cycles SET min_turnover=$2,updated_at=NOW() WHERE id=$1 AND status='open'", cycle["id"], amount)

    async def _account_principal(self, conn: asyncpg.Connection, account_id: UUID, start: datetime, end: datetime, tg: int) -> dict[str,int]:
        before = await conn.fetchrow(
            """
            SELECT COALESCE(SUM(CASE WHEN operation_type='deposit' THEN eligible_amount_syp ELSE 0 END),0) dep,
                   COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN eligible_amount_syp ELSE 0 END),0) wd
            FROM bot_core.ichancy_cashback_allocations WHERE account_id=$1 AND telegram_id=$2 AND status='success' AND settled_at < $3
            """, account_id,tg,start
        )
        during = await conn.fetchrow(
            """
            SELECT COALESCE(SUM(CASE WHEN operation_type='deposit' THEN eligible_amount_syp ELSE 0 END),0) dep,
                   COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN eligible_amount_syp ELSE 0 END),0) wd
            FROM bot_core.ichancy_cashback_allocations WHERE account_id=$1 AND telegram_id=$2 AND status='success' AND settled_at >= $3 AND settled_at < $4
            """, account_id,tg,start,end
        )
        settled = int(await conn.fetchval(
            """SELECT COALESCE(SUM(s.amount_syp),0) FROM bot_core.cashback_principal_settlements s
               JOIN bot_core.cashback_cycles c ON c.id=s.cycle_id
               WHERE s.account_id=$1 AND s.telegram_id=$2 AND c.cycle_end <= $3""", account_id,tg,start
        ) or 0)
        held = int(await conn.fetchval(
            """SELECT COALESCE(SUM(h.amount_syp),0) FROM bot_core.cashback_principal_holds h
               JOIN bot_core.cashback_cycles c ON c.id=h.cycle_id
               WHERE h.account_id=$1 AND h.telegram_id=$2 AND h.status='active' AND c.cycle_end <= $3""", account_id,tg,start
        ) or 0)
        start_principal=max(0,int(before['dep'] or 0)-int(before['wd'] or 0)-settled-held)
        dep=int(during['dep'] or 0); wd=int(during['wd'] or 0)
        return {'start':start_principal,'dep':dep,'wd':wd,'end_principal':max(0,start_principal+dep-wd)}

    async def _balance_account_at_end(self, account_id: UUID, end: datetime) -> tuple[int,dict[str,int]]:
        account=await self.ichancy_accounts.repository.get_account(account_id)
        if not account: raise RuntimeError('iChancy account missing')
        cashier=await self.ichancy_accounts.repository.get_cashier(account.cashier_id)
        if not cashier: raise RuntimeError('iChancy cashier missing')
        last=None
        for attempt in range(3):
            try:
                response=await self.ichancy_accounts._client(cashier).get_player_balance(account.player_id)
                observed=extract_player_balance_value(response)
                if observed is None: raise RuntimeError('empty player balance')
                captured=_utcnow()
                pool=self.db.require_pool()
                async with pool.acquire() as conn:
                    post=await conn.fetchrow(
                        """SELECT COALESCE(SUM(CASE WHEN operation_type='deposit' THEN amount ELSE 0 END),0) dep,
                                  COALESCE(SUM(CASE WHEN operation_type IN ('withdraw','retirement_withdraw') THEN amount ELSE 0 END),0) wd
                           FROM bot_core.ichancy_jobs WHERE account_id=$1 AND status='success' AND finished_at >= $2 AND finished_at <= $3""",
                        account_id,end,captured,
                    )
                adjusted=max(0,int(observed)-int(post['dep'] or 0)+int(post['wd'] or 0))
                return adjusted,{'observed':int(observed),'post_deposits':int(post['dep'] or 0),'post_withdrawals':int(post['wd'] or 0)}
            except Exception as exc:
                last=exc
                if attempt<2: await asyncio.sleep(.7*(attempt+1))
        raise RuntimeError(str(last or 'balance lookup failed'))

    async def prepare(self, cycle_id: int) -> dict[str,Any]:
        pool=self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle=await conn.fetchrow('SELECT * FROM bot_core.cashback_cycles WHERE id=$1 FOR UPDATE',cycle_id)
                if not cycle or str(cycle['status']) not in {'open','preparing'} or cycle['cycle_end']>_utcnow(): return {'done':False}
                await conn.execute("UPDATE bot_core.cashback_cycles SET status='preparing',updated_at=NOW() WHERE id=$1",cycle_id)
                users=await conn.fetch(
                    """SELECT DISTINCT telegram_id FROM bot_core.ichancy_cashback_allocations
                       WHERE status='success' AND eligible_amount_syp>0 AND settled_at < $1 ORDER BY telegram_id""",cycle['cycle_end'])
        eligible_count=failed_count=total_loss=total_due=0
        for ur in users:
            tg=int(ur['telegram_id'])
            user_loss=0; start_total=dep_total=wd_total=end_bal_total=0; details=[]; failed=None
            async with pool.acquire() as conn:
                accounts=await conn.fetch(
                    """SELECT DISTINCT account_id FROM bot_core.ichancy_cashback_allocations
                       WHERE telegram_id=$1 AND status='success' AND eligible_amount_syp>0 AND settled_at < $2""",tg,cycle['cycle_end'])
            for ar in accounts:
                aid=ar['account_id']
                async with pool.acquire() as conn:
                    p=await self._account_principal(conn,aid,cycle['cycle_start'],cycle['cycle_end'],tg)
                if p['end_principal']<=0:
                    start_total+=p['start']; dep_total+=p['dep']; wd_total+=p['wd']; continue
                try:
                    bal,adj=await self._balance_account_at_end(aid,cycle['cycle_end'])
                except Exception as exc:
                    failed=str(exc); details.append({'account_id':str(aid),'status':'failed','error':failed,'principal_at_end':p['end_principal']}); break
                loss=max(0,p['end_principal']-bal)
                start_total+=p['start']; dep_total+=p['dep']; wd_total+=p['wd']; end_bal_total+=bal; user_loss+=loss
                details.append({'account_id':str(aid),**p,'end_balance':bal,'loss':loss,**adj})
            async with pool.acquire() as conn:
                async with conn.transaction():
                    if failed:
                        failed_count+=1
                        await conn.execute(
                            """INSERT INTO bot_core.cashback_cycle_users(cycle_id,telegram_id,status,error_message,details,attempts,prepared_at)
                               VALUES($1,$2,'failed',$3,$4::jsonb,1,NOW())
                               ON CONFLICT(cycle_id,telegram_id) DO UPDATE SET status='failed',error_message=$3,details=$4::jsonb,attempts=bot_core.cashback_cycle_users.attempts+1,prepared_at=NOW()""",
                            cycle_id,tg,failed[:1200],json.dumps({'players':details},ensure_ascii=False))
                        for d in details:
                            if d.get('principal_at_end',0)>0:
                                await conn.execute(
                                    """INSERT INTO bot_core.cashback_principal_holds(cycle_id,telegram_id,account_id,amount_syp,status)
                                       VALUES($1,$2,$3,$4,'active') ON CONFLICT(cycle_id,telegram_id,account_id) DO UPDATE SET amount_syp=EXCLUDED.amount_syp,status='active',resolved_at=NULL""",
                                    cycle_id,tg,UUID(d['account_id']),int(d['principal_at_end']))
                        continue
                    cashback=int((Decimal(user_loss)*Decimal(str(cycle['pct']))/Decimal(100))) if user_loss>=int(cycle['min_turnover']) and Decimal(str(cycle['pct']))>0 else 0
                    status='ready' if cashback>0 else 'not_eligible'
                    if cashback>0: eligible_count+=1; total_due+=cashback
                    total_loss+=user_loss
                    await conn.execute(
                        """INSERT INTO bot_core.cashback_cycle_users(cycle_id,telegram_id,start_principal_syp,eligible_deposits_syp,eligible_withdrawals_syp,end_balance_syp,net_loss_syp,cashback_syp,status,details,prepared_at)
                           VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb,NOW())
                           ON CONFLICT(cycle_id,telegram_id) DO UPDATE SET start_principal_syp=EXCLUDED.start_principal_syp,eligible_deposits_syp=EXCLUDED.eligible_deposits_syp,
                           eligible_withdrawals_syp=EXCLUDED.eligible_withdrawals_syp,end_balance_syp=EXCLUDED.end_balance_syp,net_loss_syp=EXCLUDED.net_loss_syp,
                           cashback_syp=EXCLUDED.cashback_syp,status=EXCLUDED.status,error_message=NULL,details=EXCLUDED.details,prepared_at=NOW()""",
                        cycle_id,tg,start_total,dep_total,wd_total,end_bal_total,user_loss,cashback,status,json.dumps({'players':details},ensure_ascii=False))
                    await conn.execute("UPDATE bot_core.cashback_principal_holds SET status='resolved',resolved_at=NOW() WHERE cycle_id=$1 AND telegram_id=$2 AND status='active'",cycle_id,tg)
                    for d in details:
                        if int(d.get('loss') or 0)>0:
                            await conn.execute(
                                """INSERT INTO bot_core.cashback_principal_settlements(cycle_id,telegram_id,account_id,amount_syp)
                                   VALUES($1,$2,$3,$4) ON CONFLICT(cycle_id,telegram_id,account_id) DO UPDATE SET amount_syp=EXCLUDED.amount_syp""",
                                cycle_id,tg,UUID(d['account_id']),int(d['loss']))
        async with pool.acquire() as conn:
            async with conn.transaction():
                status='ready' if eligible_count>0 or failed_count>0 else 'empty'
                await conn.execute(
                    "UPDATE bot_core.cashback_cycles SET status=$2,eligible_count=$3,failed_count=$4,total_loss_syp=$5,total_due_syp=$6,prepared_at=NOW(),updated_at=NOW() WHERE id=$1",
                    cycle_id,status,eligible_count,failed_count,total_loss,total_due)
        return {'done':True,'status':status,'eligible_count':eligible_count,'failed_count':failed_count,'total_loss':total_loss,'total_due':total_due}

    async def due(self, cycle_id: int|None=None, limit:int=100, offset:int=0) -> tuple[asyncpg.Record|None,list[asyncpg.Record]]:
        pool=self.db.require_pool();
        async with pool.acquire() as conn:
            if cycle_id is None:
                cycle=await conn.fetchrow("SELECT * FROM bot_core.cashback_cycles WHERE status IN ('ready','distributing') ORDER BY id DESC LIMIT 1")
            else: cycle=await conn.fetchrow("SELECT * FROM bot_core.cashback_cycles WHERE id=$1",cycle_id)
            if not cycle: return None,[]
            rows=await conn.fetch("SELECT * FROM bot_core.cashback_cycle_users WHERE cycle_id=$1 AND status IN ('ready','paid') AND cashback_syp>0 ORDER BY cashback_syp DESC,telegram_id LIMIT $2 OFFSET $3",cycle['id'],limit,offset)
            return cycle,rows

    async def ready_cycle(self) -> asyncpg.Record | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetchrow(
                "SELECT * FROM bot_core.cashback_cycles WHERE status IN ('ready','empty','distributing') ORDER BY id DESC LIMIT 1"
            )

    async def cycle_detail(self, cycle_id: int) -> asyncpg.Record | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetchrow("SELECT * FROM bot_core.cashback_cycles WHERE id=$1", int(cycle_id))

    async def failed_users(self, cycle_id: int, limit: int = 10, offset: int = 0) -> list[asyncpg.Record]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(
                """
                SELECT cu.*,u.first_name,u.username
                FROM bot_core.cashback_cycle_users cu
                JOIN bot_core.users u ON u.telegram_id=cu.telegram_id
                WHERE cu.cycle_id=$1 AND cu.status='failed'
                ORDER BY cu.telegram_id LIMIT $2 OFFSET $3
                """,
                int(cycle_id), max(1,min(50,int(limit))), max(0,int(offset)),
            )

    async def retry_failed(self, cycle_id: int) -> dict[str, Any]:
        """Retry only failed snapshots; already-finalized users are never recalculated.

        Principal holds created by a failed snapshot remain quarantined until the
        retry succeeds. This mirrors the reference implementation and prevents later cycles from using
        uncertain principal while an authoritative iChancy balance is unavailable.
        """
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            cycle = await conn.fetchrow("SELECT * FROM bot_core.cashback_cycles WHERE id=$1", int(cycle_id))
            if not cycle or str(cycle['status']) not in {'ready','empty'}:
                raise ValueError('CASHBACK_NOT_RETRYABLE')
            failed_rows = await conn.fetch(
                "SELECT telegram_id FROM bot_core.cashback_cycle_users WHERE cycle_id=$1 AND status='failed' ORDER BY telegram_id",
                int(cycle_id),
            )
        for ur in failed_rows:
            tg = int(ur['telegram_id'])
            user_loss=0; start_total=dep_total=wd_total=end_bal_total=0; details=[]; failure=None
            async with pool.acquire() as conn:
                accounts = await conn.fetch(
                    """SELECT DISTINCT account_id FROM bot_core.ichancy_cashback_allocations
                       WHERE telegram_id=$1 AND status='success' AND eligible_amount_syp>0 AND settled_at < $2""",
                    tg, cycle['cycle_end'],
                )
            for ar in accounts:
                aid=ar['account_id']
                async with pool.acquire() as conn:
                    principal=await self._account_principal(conn,aid,cycle['cycle_start'],cycle['cycle_end'],tg)
                if principal['end_principal']<=0:
                    start_total+=principal['start']; dep_total+=principal['dep']; wd_total+=principal['wd']; continue
                try:
                    bal,adj=await self._balance_account_at_end(aid,cycle['cycle_end'])
                except Exception as exc:
                    failure=str(exc)
                    details.append({'account_id':str(aid),'status':'failed','error':failure,'principal_at_end':principal['end_principal']})
                    break
                loss=max(0,principal['end_principal']-bal)
                start_total+=principal['start']; dep_total+=principal['dep']; wd_total+=principal['wd']; end_bal_total+=bal; user_loss+=loss
                details.append({'account_id':str(aid),**principal,'end_balance':bal,'loss':loss,**adj})
            async with pool.acquire() as conn:
                async with conn.transaction():
                    if failure:
                        await conn.execute(
                            """UPDATE bot_core.cashback_cycle_users SET status='failed',error_message=$3,details=$4::jsonb,attempts=attempts+1,prepared_at=NOW()
                               WHERE cycle_id=$1 AND telegram_id=$2""",
                            int(cycle_id),tg,failure[:1200],json.dumps({'players':details},ensure_ascii=False),
                        )
                        for d in details:
                            if int(d.get('principal_at_end') or 0)>0:
                                await conn.execute(
                                    """INSERT INTO bot_core.cashback_principal_holds(cycle_id,telegram_id,account_id,amount_syp,status)
                                       VALUES($1,$2,$3,$4,'active') ON CONFLICT(cycle_id,telegram_id,account_id) DO UPDATE
                                       SET amount_syp=EXCLUDED.amount_syp,status='active',resolved_at=NULL""",
                                    int(cycle_id),tg,UUID(d['account_id']),int(d['principal_at_end']),
                                )
                        continue
                    cashback=int(Decimal(user_loss)*Decimal(str(cycle['pct']))/Decimal(100)) if user_loss>=int(cycle['min_turnover']) and Decimal(str(cycle['pct']))>0 else 0
                    status='ready' if cashback>0 else 'not_eligible'
                    await conn.execute(
                        """UPDATE bot_core.cashback_cycle_users SET start_principal_syp=$3,eligible_deposits_syp=$4,eligible_withdrawals_syp=$5,
                           end_balance_syp=$6,net_loss_syp=$7,cashback_syp=$8,status=$9,error_message=NULL,details=$10::jsonb,attempts=attempts+1,prepared_at=NOW()
                           WHERE cycle_id=$1 AND telegram_id=$2""",
                        int(cycle_id),tg,start_total,dep_total,wd_total,end_bal_total,user_loss,cashback,status,json.dumps({'players':details},ensure_ascii=False),
                    )
                    await conn.execute(
                        "UPDATE bot_core.cashback_principal_holds SET status='resolved',resolved_at=NOW() WHERE cycle_id=$1 AND telegram_id=$2 AND status='active'",
                        int(cycle_id),tg,
                    )
                    for d in details:
                        if int(d.get('loss') or 0)>0:
                            await conn.execute(
                                """INSERT INTO bot_core.cashback_principal_settlements(cycle_id,telegram_id,account_id,amount_syp)
                                   VALUES($1,$2,$3,$4) ON CONFLICT(cycle_id,telegram_id,account_id) DO UPDATE SET amount_syp=EXCLUDED.amount_syp""",
                                int(cycle_id),tg,UUID(d['account_id']),int(d['loss']),
                            )
        async with pool.acquire() as conn:
            async with conn.transaction():
                sums=await conn.fetchrow(
                    """SELECT COUNT(*) FILTER (WHERE status='ready' AND cashback_syp>0) eligible,
                              COUNT(*) FILTER (WHERE status='failed') failed,
                              COALESCE(SUM(net_loss_syp) FILTER (WHERE status<>'failed'),0) total_loss,
                              COALESCE(SUM(cashback_syp) FILTER (WHERE status='ready'),0) total_due
                       FROM bot_core.cashback_cycle_users WHERE cycle_id=$1""", int(cycle_id),
                )
                status='ready' if int(sums['eligible'] or 0)>0 or int(sums['failed'] or 0)>0 else 'empty'
                cycle=await conn.fetchrow(
                    """UPDATE bot_core.cashback_cycles SET status=$2,eligible_count=$3,failed_count=$4,total_loss_syp=$5,total_due_syp=$6,updated_at=NOW()
                       WHERE id=$1 RETURNING *""",
                    int(cycle_id),status,int(sums['eligible'] or 0),int(sums['failed'] or 0),int(sums['total_loss'] or 0),int(sums['total_due'] or 0),
                )
        return {'cycle':dict(cycle),'retried':len(failed_rows),'remaining_failed':int(cycle['failed_count'] or 0)}

    async def distribute(self,cycle_id:int,admin_id:int)->dict[str,int]:
        pool=self.db.require_pool(); paid=total=0
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle=await conn.fetchrow('SELECT * FROM bot_core.cashback_cycles WHERE id=$1 FOR UPDATE',cycle_id)
                if not cycle or str(cycle['status']) not in {'ready','distributing'}: raise ValueError('CASHBACK_NOT_READY')
                if int(cycle['failed_count'] or 0)>0: raise ValueError('CASHBACK_HAS_FAILED_SNAPSHOTS')
                await conn.execute("UPDATE bot_core.cashback_cycles SET status='distributing' WHERE id=$1",cycle_id)
                rows=await conn.fetch("SELECT * FROM bot_core.cashback_cycle_users WHERE cycle_id=$1 AND status='ready' AND cashback_syp>0 FOR UPDATE",cycle_id)
                for row in rows:
                    tg=int(row['telegram_id']); amount=int(row['cashback_syp'])
                    valid=bool(await conn.fetchval(
                        "SELECT 1 FROM bot_core.users WHERE telegram_id=$1 AND NOT is_blocked AND NOT is_bot", tg
                    ))
                    if amount<=0 or not valid:
                        await conn.execute(
                            "UPDATE bot_core.cashback_cycle_users SET status='skipped',error_message='ineligible_before_payout' WHERE cycle_id=$1 AND telegram_id=$2 AND status='ready'",
                            cycle_id,tg,
                        )
                        continue
                    mutation=await self.wallet.credit_in_transaction(conn,tg,amount,idempotency_key=f'cashback:{cycle_id}:{tg}',reason='cashback_distribution',actor_telegram_id=admin_id,metadata={'cycle_id':cycle_id,'cashback_eligible':False})
                    await conn.execute("UPDATE bot_core.cashback_cycle_users SET status='paid',paid_at=NOW(),wallet_operation_id=$3 WHERE cycle_id=$1 AND telegram_id=$2",cycle_id,tg,mutation.operation_id)
                    if self.outbox is not None:
                        await self.outbox.enqueue(
                            event_key=f"cashback-user:{cycle_id}:{tg}", target_chat_id=tg, conn=conn,
                            text=(
                                "🎁 <b>تم توزيع الاسترداد</b>\n\n"
                                f"💰 قيمة الاسترداد: <code>{amount:,}</code> ل.س\n"
                                f"👛 رصيدك الحالي: <code>{mutation.balance_after.available:,}</code> ل.س"
                            ),
                        )
                    paid+=1; total+=amount
                await conn.execute(
                    "UPDATE bot_core.cashback_cycles SET status='distributed',distributed_at=NOW(),distributed_by=$2,paid_count=$3,total_paid_syp=$4,updated_at=NOW() WHERE id=$1",
                    cycle_id,admin_id,paid,total,
                )
        return {'paid_count':paid,'total':total}

    async def skip(self,cycle_id:int,admin_id:int)->None:
        pool=self.db.require_pool();
        async with pool.acquire() as conn:
            async with conn.transaction():
                cycle=await conn.fetchrow('SELECT * FROM bot_core.cashback_cycles WHERE id=$1 FOR UPDATE',cycle_id)
                if not cycle or str(cycle['status']) not in {'ready','empty'}: raise ValueError('CASHBACK_NOT_SKIPPABLE')
                skipped=await conn.fetchrow(
                    "SELECT COUNT(*) cnt,COALESCE(SUM(cashback_syp),0) amount FROM bot_core.cashback_cycle_users WHERE cycle_id=$1 AND status='ready'",
                    cycle_id,
                )
                await conn.execute("UPDATE bot_core.cashback_cycle_users SET status='skipped' WHERE cycle_id=$1 AND status='ready'",cycle_id)
                await conn.execute(
                    "UPDATE bot_core.cashback_cycles SET status='skipped',skipped_at=NOW(),skipped_by=$2,skipped_eligible_count=$3,skipped_amount_syp=$4,updated_at=NOW() WHERE id=$1",
                    cycle_id,admin_id,int(skipped['cnt'] or 0),int(skipped['amount'] or 0),
                )

    async def history(self,limit:int=10,offset:int=0)->list[asyncpg.Record]:
        pool=self.db.require_pool();
        async with pool.acquire() as conn:
            return await conn.fetch("SELECT * FROM bot_core.cashback_cycles ORDER BY id DESC LIMIT $1 OFFSET $2",limit,offset)


class RewardsMaintenanceService:
    def __init__(self, cashback: CashbackService, referrals: ReferralService, bot: Bot, admin_ids: set[int]) -> None:
        self.cashback=cashback; self.referrals=referrals; self.bot=bot; self.admin_ids={int(x) for x in admin_ids}; self._stop=asyncio.Event()

    def stop(self)->None: self._stop.set()

    async def run(self,interval:float=30.0)->None:
        while not self._stop.is_set():
            try:
                await self._tick()
            except asyncio.CancelledError: raise
            except Exception: logger.exception('rewards maintenance tick failed')
            try: await asyncio.wait_for(self._stop.wait(),timeout=max(10.0,float(interval)))
            except asyncio.TimeoutError: pass

    async def _notify_admins(self,text:str)->None:
        for admin in self.admin_ids:
            try: await self.bot.send_message(admin,text)
            except Exception: logger.exception('reward admin notification failed admin=%s',admin)

    async def _tick(self)->None:
        cycle=await self.cashback.ensure_cycle()
        if str(cycle['status']) in {'open','preparing'} and cycle['cycle_end']<=_utcnow():
            result=await self.cashback.prepare(int(cycle['id']))
            if result.get('done'):
                await self._notify_admins(
                    '✅ انتهت دورة الاسترداد وتم تثبيت نتائجها\n\n'
                    f"👥 المستحقون: {int(result.get('eligible_count') or 0)}\n"
                    f"📉 إجمالي الخسائر المعتمدة: {int(result.get('total_loss') or 0):,} SYP\n"
                    f"🎁 إجمالي الاسترداد: {int(result.get('total_due') or 0):,} SYP\n"
                    f"⚠️ تعذر الاحتساب: {int(result.get('failed_count') or 0)}"
                )
                await self.cashback.ensure_cycle()
        ref=await self.referrals.current_cycle()
        if ref and str(ref['status']) in {'active','preparing'} and ref['cycle_end']<=_utcnow():
            result=await self.referrals.prepare_ended_cycle(int(ref['id']))
            if result.get('done'):
                await self._notify_admins(
                    '✅ انتهت دورة الإحالات وتم تثبيت نتائجها\n\n'
                    f"📅 الدورة: #{int(ref['id'])}\n👥 المستحقون: {int(result.get('count') or 0)}\n"
                    f"💰 إجمالي الأرباح: {int(result.get('total') or 0):,} SYP"
                )
