from __future__ import annotations

import html
import json
from decimal import Decimal

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.services.rewards import CashbackService, ReferralService, WheelService
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin_rewards")


class RewardsAdminStates(StatesGroup):
    numeric = State()


def _admin(uid: int, settings: Settings) -> bool:
    return int(uid) in settings.super_admin_ids


def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data=data)


def _num(raw: str) -> Decimal:
    text = str(raw or "").translate(str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")).strip()
    return Decimal(text.replace("٬", "").replace(",", ".").replace("٫", "."))


def _remaining(seconds: int) -> str:
    seconds=max(0,int(seconds or 0)); days,rem=divmod(seconds,86400); hours,rem=divmod(rem,3600); minutes,_=divmod(rem,60)
    parts=[]
    if days: parts.append(f"{days} يوم")
    if hours: parts.append(f"{hours} ساعة")
    if minutes or not parts: parts.append(f"{minutes} دقيقة")
    return " و ".join(parts)


# ---------------- Cashback / الاسترداد ----------------

def _cb_status(status: str) -> str:
    return {
        "open":"🟢 جارية", "preparing":"🔄 قيد الاحتساب", "ready":"✅ جاهزة للتوزيع",
        "empty":"✅ منتهية بلا مستحقين", "distributing":"⏳ قيد التوزيع",
        "distributed":"✅ موزعة", "skipped":"⏭ انتهت بدون توزيع",
    }.get(status,status or "-")


async def _cashback_view(service: CashbackService, runtime: RuntimeSettingsService) -> tuple[str, InlineKeyboardMarkup]:
    info=await service.current_info(); ready=await service.ready_cycle(); pending=runtime.get_int("cashback.next_cycle_days",0)
    mode="يومي" if int(info.get("cycle_days") or 7)<=1 else "أسبوعي"
    text=(
        "🎁 <b>إدارة الاسترداد</b>\n━━━━━━━━━━━━━━\n\n"
        f"النمط الحالي: <b>استرداد {mode}</b>\n"
        f"نسبة الاسترداد: <code>{float(info.get('pct') or 0):g}%</code>\n"
        f"حد صافي الخسارة: <code>{int(info.get('min_turnover') or 0):,} SYP</code>\n\n"
        f"بداية الدورة الجارية: <code>{info.get('start_local','-')}</code>\n"
        f"نهاية الدورة: <code>{info.get('end_local','-')}</code>\n"
        f"الحالة: <b>{_cb_status(str(info.get('status') or ''))}</b>\n"
        f"⏳ المتبقي: {_remaining(int(info.get('remaining_seconds') or 0))}"
    )
    if pending:
        text += f"\n📌 النمط المجدول للدورة القادمة: <b>{'يومي' if pending<=1 else 'أسبوعي'}</b>"
    if ready:
        text += (
            "\n\n━━━━━━━━━━━━━━\n"
            f"📌 توجد دورة منتهية #{int(ready['id'])} — {_cb_status(str(ready['status']))}\n"
            f"👥 المستحقون: <code>{int(ready['eligible_count'] or 0)}</code>\n"
            f"📉 الخسائر المعتمدة: <code>{int(ready['total_loss_syp'] or 0):,} SYP</code>\n"
            f"🎁 الاسترداد المستحق: <code>{int(ready['total_due_syp'] or 0):,} SYP</code>\n"
            f"⚠️ حالات التعذر: <code>{int(ready['failed_count'] or 0)}</code>"
        )
    rows=[
        [_btn("✅ استرداد يومي","admin:cashback_mode:daily"),_btn("✅ استرداد أسبوعي","admin:cashback_mode:weekly")],
        [_btn("💯 نسبة الاسترداد","admin:cashback_pct"),_btn("🎯 حد صافي الخسارة","admin:cashback_min")],
    ]
    if ready:
        cid=int(ready['id'])
        rows.append([_btn("📋 عرض المستحقين",f"admin:cashback_due:{cid}:0"),_btn("💰 توزيع الاسترداد",f"admin:cashback_distribute:{cid}")])
        if int(ready['failed_count'] or 0)>0:
            rows.append([_btn(f"⚠️ حالات التعذر ({int(ready['failed_count'])})",f"admin:cashback_failed:{cid}:0")])
        rows.append([_btn("⏭ تجاهل التوزيع وإنهاء الدورة",f"admin:cashback_skip:{cid}")])
    rows.extend([[_btn("📜 سجل دورات الاسترداد","admin:cashback_history:0")],[_btn("⬅️ رجوع","admin:home")]])
    return text,InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin:cashback")
async def cashback_home(callback:CallbackQuery,state:FSMContext,settings:Settings,cashback_service:CashbackService,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.clear(); text,kb=await _cashback_view(cashback_service,runtime_settings); await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data.startswith("admin:cashback_mode:"))
async def cashback_mode(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(callback.from_user.id,settings): return
    result=await cashback_service.set_mode(1 if str(callback.data).endswith("daily") else 7,callback.from_user.id)
    if result.get("scheduled"): await callback.answer("تم جدولة التغيير للدورة القادمة حتى لا تضيع أي عمليات.",show_alert=True)
    text,kb=await _cashback_view(cashback_service,runtime_settings); await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data.in_({"admin:cashback_pct","admin:cashback_min"}))
async def cashback_numeric_start(callback:CallbackQuery,state:FSMContext,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    kind="cashback_pct" if callback.data.endswith("_pct") else "cashback_min"; info=await cashback_service.current_info()
    current=float(info.get("pct") or 0) if kind=="cashback_pct" else int(info.get("min_turnover") or 0)
    await state.set_state(RewardsAdminStates.numeric); await state.set_data({"kind":kind})
    prompt="💸 أرسل نسبة الاسترداد الجديدة من 0 إلى 100%." if kind=="cashback_pct" else "🎯 أرسل حد صافي الخسارة الجديد بالليرة السورية."
    await safe_edit(callback,f"{prompt}\n\nالقيمة الحالية: <code>{current}</code>",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:cashback")]]))


@router.callback_query(F.data.startswith("admin:cashback_due:"))
async def cashback_due(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    parts=str(callback.data).split(":"); cid=int(parts[2]); page=max(0,int(parts[3]) if len(parts)>3 else 0)
    cycle,rows=await cashback_service.due(cid,10,page*10)
    if not cycle:
        await callback.answer("لم يتم العثور على الدورة.",show_alert=True); return
    lines=["📋 <b>مستحقو الاسترداد</b>",f"الدورة #{cid}",""]
    if not rows: lines.append("لا يوجد مستحقون في هذه الصفحة.")
    for i,r in enumerate(rows,start=page*10+1):
        lines.append(f"{i}) <code>{int(r['telegram_id'])}</code>\n📉 خسارة: {int(r['net_loss_syp']):,} SYP\n🎁 استرداد: <b>{int(r['cashback_syp']):,} SYP</b>")
    if int(cycle['failed_count'] or 0): lines.extend(["",f"⚠️ يوجد {int(cycle['failed_count'])} حالة تعذر، والتوزيع مقفول حتى تُحسم."])
    nav=[]
    if page>0: nav.append(_btn("⬅️ السابق",f"admin:cashback_due:{cid}:{page-1}"))
    if len(rows)==10: nav.append(_btn("التالي ➡️",f"admin:cashback_due:{cid}:{page+1}"))
    kb=[nav] if nav else []
    kb.extend([[_btn("💰 توزيع الاسترداد",f"admin:cashback_distribute:{cid}")],[_btn("⬅️ تفاصيل الدورة",f"admin:cashback_cycle:{cid}")]])
    await safe_edit(callback,"\n\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data.startswith("admin:cashback_distribute_confirm:"))
async def cashback_distribute_confirm(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1])
    try: result=await cashback_service.distribute(cid,callback.from_user.id)
    except ValueError as exc:
        await callback.answer("يوجد حالات تعذر يجب إعادة فحصها أولاً." if "FAILED" in str(exc) else "الدورة ليست جاهزة للتوزيع.",show_alert=True); return
    await safe_edit(callback,f"✅ اكتمل توزيع الاسترداد.\n\n👥 تم الدفع: {result['paid_count']}\n💰 المبلغ الموزع: {result['total']:,} SYP",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ إدارة الاسترداد","admin:cashback")]]))


@router.callback_query(F.data.startswith("admin:cashback_distribute:"))
async def cashback_distribute_prompt(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1]); cycle=await cashback_service.cycle_detail(cid)
    if not cycle or str(cycle['status'])!='ready': await callback.answer("الدورة ليست جاهزة للتوزيع.",show_alert=True); return
    if int(cycle['failed_count'] or 0)>0: await callback.answer("يجب إعادة فحص حالات التعذر قبل التوزيع.",show_alert=True); return
    text=("⚠️ <b>تأكيد توزيع الاسترداد</b>\n\n"f"الدورة: #{cid}\n👥 المستحقون: {int(cycle['eligible_count'] or 0)}\n💰 الإجمالي: {int(cycle['total_due_syp'] or 0):,} SYP\n\nسيتم إضافة المبالغ إلى محافظ المستخدمين. هل أنت متأكد؟")
    kb=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ نعم، وزّع",f"admin:cashback_distribute_confirm:{cid}")],[_btn("❌ إلغاء",f"admin:cashback_cycle:{cid}")]])
    await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data.startswith("admin:cashback_skip_confirm:"))
async def cashback_skip_confirm(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1]); await cashback_service.skip(cid,callback.from_user.id)
    await safe_edit(callback,"⏭ تم إنهاء دورة الاسترداد بدون توزيع.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ إدارة الاسترداد","admin:cashback")]]))


@router.callback_query(F.data.startswith("admin:cashback_skip:"))
async def cashback_skip_prompt(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1]); cycle=await cashback_service.cycle_detail(cid)
    if not cycle or str(cycle['status']) not in {'ready','empty'}: await callback.answer("لا يمكن إنهاء هذه الدورة الآن.",show_alert=True); return
    text=("⚠️ <b>تأكيد إنهاء الدورة بدون توزيع</b>\n\n"f"سيتم تجاهل مبلغ مستحق قدره <code>{int(cycle['total_due_syp'] or 0):,} SYP</code>.\nلا يتم تنفيذ هذا الإجراء إلا بعد التأكيد.")
    await safe_edit(callback,text,reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⏭ نعم، أنهِ بدون توزيع",f"admin:cashback_skip_confirm:{cid}")],[_btn("❌ إلغاء",f"admin:cashback_cycle:{cid}")]]))


@router.callback_query(F.data.startswith("admin:cashback_history:"))
async def cashback_history(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    page=max(0,int(str(callback.data).split(":")[-1])); rows=await cashback_service.history(8,page*8)
    lines=["📜 <b>سجل دورات الاسترداد</b>",""]; kb=[]
    if not rows: lines.append("لا توجد دورات محفوظة بعد.")
    for r in rows:
        lines.append(f"• #{int(r['id'])} — {_cb_status(str(r['status']))}\n  {int(r['cycle_days'])} يوم | {float(r['pct']):g}% | 💰 {int(r['total_paid_syp'] or 0):,}/{int(r['total_due_syp'] or 0):,}")
        kb.append([_btn(f"📊 تفاصيل الدورة #{int(r['id'])}",f"admin:cashback_cycle:{int(r['id'])}")])
    nav=[]
    if page>0: nav.append(_btn("⬅️ السابق",f"admin:cashback_history:{page-1}"))
    if len(rows)==8: nav.append(_btn("التالي ➡️",f"admin:cashback_history:{page+1}"))
    if nav: kb.append(nav)
    kb.append([_btn("⬅️ رجوع","admin:cashback")]); await safe_edit(callback,"\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data.startswith("admin:cashback_cycle:"))
async def cashback_cycle_detail(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1]); r=await cashback_service.cycle_detail(cid)
    if not r: await callback.answer("لم يتم العثور على الدورة.",show_alert=True); return
    text=("📊 <b>تفاصيل دورة الاسترداد</b>\n\n"f"الدورة: #{cid}\nالحالة: {_cb_status(str(r['status']))}\nالنوع: {'يومي' if int(r['cycle_days'])<=1 else 'أسبوعي'}\nالنسبة: {float(r['pct']):g}%\n\n"f"✅ المستحقون: {int(r['eligible_count'] or 0)}\n⚠️ تعذر الاحتساب: {int(r['failed_count'] or 0)}\n📉 إجمالي الخسائر: {int(r['total_loss_syp'] or 0):,} SYP\n🎁 المستحق: {int(r['total_due_syp'] or 0):,} SYP\n💸 الموزع: {int(r['total_paid_syp'] or 0):,} SYP")
    if str(r['status'])=='skipped': text+=f"\n\n⏭ غير الموزع: {int(r['skipped_amount_syp'] or 0):,} SYP"
    kb=[[_btn("📋 المستحقون",f"admin:cashback_due:{cid}:0")]]
    if int(r['failed_count'] or 0)>0: kb.append([_btn("⚠️ حالات التعذر",f"admin:cashback_failed:{cid}:0")])
    if str(r['status'])=='ready': kb.append([_btn("💰 توزيع الاسترداد",f"admin:cashback_distribute:{cid}"),_btn("⏭ إنهاء بلا توزيع",f"admin:cashback_skip:{cid}")])
    kb.append([_btn("⬅️ سجل الدورات","admin:cashback_history:0")]); await safe_edit(callback,text,reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data.startswith("admin:cashback_failed:"))
async def cashback_failed(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    parts=str(callback.data).split(":"); cid=int(parts[2]); page=max(0,int(parts[3]) if len(parts)>3 else 0); rows=await cashback_service.failed_users(cid,10,page*10)
    lines=["⚠️ <b>حالات تعذر احتساب الاسترداد</b>",""]
    if not rows: lines.append("لا توجد حالات تعذر في هذه الدورة.")
    for idx,r in enumerate(rows,start=page*10+1):
        try: detail=json.loads(r['details']) if isinstance(r['details'],str) else (r['details'] or {})
        except Exception: detail={}
        player_ids=", ".join(str(x.get('account_id','-')) for x in detail.get('players',[]) if isinstance(x,dict)) or "-"
        name=r['first_name'] or (f"@{r['username']}" if r['username'] else "-")
        lines.extend([f"{idx}) 👤 {html.escape(str(name))}",f"🆔 <code>{int(r['telegram_id'])}</code>",f"🎮 الحسابات: <code>{html.escape(player_ids)}</code>",f"🔁 المحاولات: {int(r['attempts'] or 0)}",f"❌ السبب: {html.escape(str(r['error_message'] or 'غير معروف'))}",""])
    kb=[]; nav=[]
    if page>0: nav.append(_btn("⬅️ السابق",f"admin:cashback_failed:{cid}:{page-1}"))
    if len(rows)==10: nav.append(_btn("التالي ➡️",f"admin:cashback_failed:{cid}:{page+1}"))
    if nav: kb.append(nav)
    if rows: kb.append([_btn("🔄 إعادة فحص المتعذرين",f"admin:cashback_retry_failed:{cid}")])
    kb.append([_btn("⬅️ تفاصيل الدورة",f"admin:cashback_cycle:{cid}")]); await safe_edit(callback,"\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data.startswith("admin:cashback_retry_failed:"))
async def cashback_retry_failed(callback:CallbackQuery,settings:Settings,cashback_service:CashbackService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1])
    await safe_edit(callback,"🔄 جاري إعادة فحص الحالات المتعذرة...\n\nلا يتم توزيع أي مبلغ أثناء الفحص.")
    try: result=await cashback_service.retry_failed(cid)
    except Exception as exc:
        await callback.message.answer(f"❌ تعذر إعادة الفحص: {html.escape(str(exc))}",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ إدارة الاسترداد","admin:cashback")]])); return
    cycle=result['cycle']
    await callback.message.answer(("✅ اكتملت إعادة فحص الحالات المتعذرة.\n\n"f"👥 المستحقون الآن: {int(cycle.get('eligible_count') or 0)}\n⚠️ المتعذرون المتبقون: {int(cycle.get('failed_count') or 0)}\n🎁 الإجمالي: {int(cycle.get('total_due_syp') or 0):,} SYP"),reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ إدارة الاسترداد","admin:cashback")]]))


# ---------------- Referral / الإحالات ----------------

def _ref_status(s:str)->str:
    return {"active":"🟢 فعالة","preparing":"⏳ جاري تجهيز النتائج","ready":"✅ جاهزة للتوزيع","empty":"✅ انتهت بلا مستحقين","distributing":"💸 جاري التوزيع","distributed":"✅ موزعة","skipped":"⏭ منتهية بدون توزيع"}.get(s,s or "-")


async def _ref_view(service:ReferralService,runtime:RuntimeSettingsService)->tuple[str,InlineKeyboardMarkup]:
    cycle=await service.current_cycle(); fixed=service.fixed_settings(); mode=str(runtime.get("referral.mode","direct")); days=runtime.get_int("referral.cycle_days",10); min_refs=runtime.get_int("referral.min_active_refs",3); active_min=runtime.get_int("referral.active_min_deposit",0)
    direct=runtime.get_decimal("referral.direct_pct",4); p1=runtime.get_decimal("referral.level1_pct",4); p2=runtime.get_decimal("referral.level2_pct",2); p3=runtime.get_decimal("referral.level3_pct",1)
    lines=["🤝 <b>إدارة الإحالات</b>","━━━━━━━━━━━━━━",""]
    if cycle:
        lines.extend([f"رقم الدورة: <code>#{int(cycle['id'])}</code>",f"الحالة: <b>{_ref_status(str(cycle['status']))}</b>",f"النظام: <b>{'🌳 هرمي' if cycle['mode']=='hierarchical' else '🤝 مباشر'}</b>",f"المدة: <code>{int(cycle['duration_days'])} يوم</code>",f"البداية: <code>{cycle['cycle_start'].strftime('%Y-%m-%d %H:%M')}</code>",f"النهاية: <code>{cycle['cycle_end'].strftime('%Y-%m-%d %H:%M')}</code>",f"الحد الأدنى للإحالات النشطة: <code>{int(cycle['min_active_refs'])}</code>",f"حد الشحن للنشاط: <code>{int(cycle['active_min_deposit']):,} SYP</code>"])
        if cycle['mode']=='hierarchical': lines.append(f"المستويات: {float(cycle['level1_pct']):g}% / {float(cycle['level2_pct']):g}% / {float(cycle['level3_pct']):g}%")
        else: lines.append(f"النسبة: {float(cycle['direct_pct']):g}%")
        if str(cycle['status'])=='active':
            from datetime import datetime,timezone
            lines.append(f"⏳ المتبقي: {_remaining(int((cycle['cycle_end']-datetime.now(timezone.utc)).total_seconds()))}")
            lines.append("🔒 إعدادات هذه الدورة مثبتة حتى تنتهي.")
        if str(cycle['status']) in {'ready','empty','distributing'}: lines.extend([f"👥 المستحقون: <code>{int(cycle['eligible_count'] or 0)}</code>",f"💰 إجمالي الأرباح: <code>{int(cycle['total_amount_syp'] or 0):,} SYP</code>"])
    else:
        lines.extend(["⚪ لا توجد دورة أرباح إحالات فعالة حالياً.","",f"إعداد النظام القادم: {'🌳 هرمي' if mode=='hierarchical' else '🤝 مباشر'}",f"المدة: {days} يوم",f"شرط الإحالات النشطة: {min_refs}",f"حد شحن الإحالة النشطة: {active_min:,} SYP",f"المباشر: {direct:g}% — المستويات: {p1:g}% / {p2:g}% / {p3:g}%"])
    lines.extend(["","━━━━━━━━━━━━━━","",f"🎁 مكافأة الإحالة الثابتة: {'✅ مفعلة' if fixed['enabled'] else '❌ متوقفة'}",f"القيمة: <code>{int(fixed['amount']):,} SYP</code>",f"الاستحقاق: <b>{'بعد أول شحن حقيقي' if fixed['trigger']=='first_deposit' else 'عند تأكيد الإحالة'}</b>"])
    rows=[]
    if not cycle:
        rows.append([_btn("▶️ بدء دورة جديدة","admin:ref_start")])
        rows.append([_btn("🤝 النظام المباشر","admin:ref_mode:direct"),_btn("🌳 النظام الهرمي","admin:ref_mode:hierarchical")])
        rows.append([_btn("💯 النسبة المباشرة","admin:ref_set:direct_pct"),_btn("⏱ مدة الدورة","admin:ref_set:cycle_days")])
        rows.append([_btn("1️⃣ المستوى 1","admin:ref_set:level1_pct"),_btn("2️⃣ المستوى 2","admin:ref_set:level2_pct")])
        rows.append([_btn("3️⃣ المستوى 3","admin:ref_set:level3_pct")])
        rows.append([_btn("👥 حد الإحالات النشطة","admin:ref_set:min_active_refs"),_btn("💳 حد الشحن للنشاط","admin:ref_set:active_min_deposit")])
    elif str(cycle['status']) in {'ready','empty'}:
        rows.append([_btn("📋 عرض المستحقين",f"admin:referrals_due:{int(cycle['id'])}:0"),_btn("💰 توزيع الأرباح",f"admin:referrals_distribute:{int(cycle['id'])}")])
        rows.append([_btn("⏭ تجاهل التوزيع وإنهاء الدورة",f"admin:referrals_skip:{int(cycle['id'])}")])
    rows.extend([[_btn("🎁 مكافأة الإحالة الثابتة","admin:ref_fixed")],[_btn("📜 سجل دورات الإحالات","admin:ref_history:0")],[_btn("⬅️ رجوع","admin:home")]])
    return "\n".join(lines),InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin:referrals")
async def referrals_home(callback:CallbackQuery,state:FSMContext,settings:Settings,referral_service:ReferralService,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.clear(); text,kb=await _ref_view(referral_service,runtime_settings); await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data.startswith("admin:ref_mode:"))
async def ref_mode(callback:CallbackQuery,settings:Settings,referral_service:ReferralService,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(callback.from_user.id,settings): return
    if await referral_service.current_cycle(): await callback.answer("لا يمكن تغيير النظام قبل إنهاء الدورة الحالية.",show_alert=True); return
    mode=str(callback.data).split(":")[-1]; await runtime_settings.set("referral.mode","hierarchical" if mode=="hierarchical" else "direct",updated_by=callback.from_user.id)
    text,kb=await _ref_view(referral_service,runtime_settings); await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data == "admin:ref_start")
async def ref_start_choice(callback:CallbackQuery,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    if await referral_service.current_cycle(): await callback.answer("توجد دورة غير منتهية بالفعل.",show_alert=True); return
    await safe_edit(callback,"▶️ <b>بدء دورة إحالات جديدة</b>\n\nاختر نظام أرباح الدورة الجديدة:",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("🤝 النظام المباشر","admin:ref_start_mode:direct")],[_btn("🌳 النظام الهرمي","admin:ref_start_mode:hierarchical")],[_btn("⬅️ رجوع","admin:referrals")]]))


@router.callback_query(F.data.startswith("admin:ref_start_mode:"))
async def ref_start_mode(callback:CallbackQuery,settings:Settings,referral_service:ReferralService,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(callback.from_user.id,settings): return
    if await referral_service.current_cycle(): await callback.answer("توجد دورة غير منتهية بالفعل.",show_alert=True); return
    mode="hierarchical" if str(callback.data).endswith("hierarchical") else "direct"; days=runtime_settings.get_int("referral.cycle_days",10); min_refs=runtime_settings.get_int("referral.min_active_refs",3); active_min=runtime_settings.get_int("referral.active_min_deposit",0)
    if mode=='hierarchical': rates=f"1️⃣ {runtime_settings.get_decimal('referral.level1_pct',4):g}%\n2️⃣ {runtime_settings.get_decimal('referral.level2_pct',2):g}%\n3️⃣ {runtime_settings.get_decimal('referral.level3_pct',1):g}%"
    else: rates=f"💯 النسبة: {runtime_settings.get_decimal('referral.direct_pct',4):g}%"
    text=(f"{'🌳 إعدادات النظام الهرمي' if mode=='hierarchical' else '🤝 إعدادات النظام المباشر'}\n\n{rates}\n\n👥 الحد الأدنى للإحالات النشطة: {min_refs}\n💳 حد الشحن للنشاط: {active_min:,} SYP\n⏱ مدة الدورة: {days} أيام\n\n🔒 لن تتغير هذه الإعدادات بعد بدء الدورة حتى تنتهي.")
    await safe_edit(callback,text,reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ بدء الدورة",f"admin:ref_start_confirm:{mode}")],[_btn("⬅️ رجوع","admin:ref_start")]]))


@router.callback_query(F.data.startswith("admin:ref_start_confirm:"))
async def ref_start_confirm(callback:CallbackQuery,settings:Settings,referral_service:ReferralService,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(callback.from_user.id,settings): return
    mode=str(callback.data).split(":")[-1]
    try: cycle=await referral_service.start_cycle(mode=mode,admin_id=callback.from_user.id)
    except ValueError: await callback.answer("توجد دورة إحالات غير منتهية بالفعل.",show_alert=True); return
    await runtime_settings.set("referral.mode",mode,updated_by=callback.from_user.id)
    await safe_edit(callback,f"✅ تم بدء دورة الإحالات #{int(cycle['id'])} بنجاح.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ إدارة الإحالات","admin:referrals")]]))


_REF_KEYS={"direct_pct":"referral.direct_pct","level1_pct":"referral.level1_pct","level2_pct":"referral.level2_pct","level3_pct":"referral.level3_pct","cycle_days":"referral.cycle_days","min_active_refs":"referral.min_active_refs","active_min_deposit":"referral.active_min_deposit"}
@router.callback_query(F.data.startswith("admin:ref_set:"))
async def ref_set_start(callback:CallbackQuery,state:FSMContext,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    if await referral_service.current_cycle(): await callback.answer("إعدادات الدورة ثابتة حتى تنتهي الدورة الحالية.",show_alert=True); return
    kind=str(callback.data).split(":")[-1]
    if kind not in _REF_KEYS: return
    await state.set_state(RewardsAdminStates.numeric); await state.set_data({"kind":f"ref:{kind}"})
    await safe_edit(callback,"أرسل القيمة الجديدة.\n\nالنسب من 0 إلى 100، والمدة/الأعداد أرقام صحيحة.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:referrals")]]))


@router.callback_query(F.data == "admin:ref_fixed")
async def ref_fixed(callback:CallbackQuery,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    cfg=referral_service.fixed_settings(); text=("🎁 <b>مكافأة الإحالة الثابتة</b>\n\n"f"الحالة: {'✅ مفعلة' if cfg['enabled'] else '❌ متوقفة'}\n"f"المكافأة: <code>{int(cfg['amount']):,} SYP</code>\n"f"شرط الاستحقاق: <b>{'بعد أول شحن حقيقي' if cfg['trigger']=='first_deposit' else 'عند تأكيد الإحالة'}</b>\n\nهذا النظام مستقل عن أرباح الدورة ولا يدخل ضمن الاسترداد المؤهل.")
    kb=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إيقاف" if cfg['enabled'] else "✅ تشغيل","admin:ref_fixed_toggle")],[_btn("💰 تعديل قيمة المكافأة","admin:ref_fixed_amount")],[_btn("✅ عند التأكيد","admin:ref_fixed_trigger:verify")],[_btn("✅ بعد أول شحن حقيقي","admin:ref_fixed_trigger:first_deposit")],[_btn("⬅️ رجوع","admin:referrals")]])
    await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data == "admin:ref_fixed_toggle")
async def ref_fixed_toggle(callback:CallbackQuery,settings:Settings,referral_service:ReferralService,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(callback.from_user.id,settings): return
    cfg=referral_service.fixed_settings(); await runtime_settings.set("referral.fixed_enabled",not cfg['enabled'],updated_by=callback.from_user.id); await ref_fixed(callback,settings,referral_service)


@router.callback_query(F.data == "admin:ref_fixed_amount")
async def ref_fixed_amount(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.set_state(RewardsAdminStates.numeric); await state.set_data({"kind":"ref_fixed_amount"}); await safe_edit(callback,"💰 أرسل قيمة مكافأة الإحالة الثابتة بالليرة.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:ref_fixed")]]))


@router.callback_query(F.data.startswith("admin:ref_fixed_trigger:"))
async def ref_fixed_trigger(callback:CallbackQuery,settings:Settings,referral_service:ReferralService,runtime_settings:RuntimeSettingsService)->None:
    if not _admin(callback.from_user.id,settings): return
    trg=str(callback.data).split(":")[-1]; await runtime_settings.set("referral.fixed_trigger","first_deposit" if trg=="first_deposit" else "verify",updated_by=callback.from_user.id); await ref_fixed(callback,settings,referral_service)


@router.callback_query(F.data.startswith("admin:referrals_due:"))
async def referrals_due(callback:CallbackQuery,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    parts=str(callback.data).split(":"); cid=int(parts[2]); page=max(0,int(parts[3]) if len(parts)>3 else 0); cycle,payouts=await referral_service.cycle_detail(cid)
    if not cycle: await callback.answer("لم يتم العثور على الدورة.",show_alert=True); return
    rows=payouts[page*10:page*10+10]; lines=["📋 <b>مستحقو دورة الإحالات</b>",f"الدورة #{cid}",""]
    if not rows: lines.append("لا يوجد مستحقون.")
    for i,r in enumerate(rows,start=page*10+1): lines.append(f"{i}) <code>{int(r['referrer_telegram_id'])}</code> — <b>{int(r['amount_syp']):,} SYP</b> — إحالات نشطة: {int(r['active_referrals'])}")
    nav=[]
    if page>0: nav.append(_btn("⬅️ السابق",f"admin:referrals_due:{cid}:{page-1}"))
    if len(rows)==10: nav.append(_btn("التالي ➡️",f"admin:referrals_due:{cid}:{page+1}"))
    kb=[nav] if nav else []; kb.extend([[_btn("💰 توزيع الأرباح",f"admin:referrals_distribute:{cid}")],[_btn("⬅️ إدارة الإحالات","admin:referrals")]])
    await safe_edit(callback,"\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data.startswith("admin:referrals_distribute_confirm:"))
async def referrals_distribute_confirm(callback:CallbackQuery,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1])
    try: result=await referral_service.distribute(cid,callback.from_user.id)
    except ValueError: await callback.answer("الدورة ليست جاهزة للتوزيع.",show_alert=True); return
    await safe_edit(callback,f"✅ تم توزيع أرباح الإحالات.\n\n👥 المستفيدون: {result['paid_count']}\n💰 الإجمالي: {result['total']:,} SYP",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ إدارة الإحالات","admin:referrals")]]))


@router.callback_query(F.data.startswith("admin:referrals_distribute:"))
async def referrals_distribute_prompt(callback:CallbackQuery,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1]); cycle,_=await referral_service.cycle_detail(cid)
    if not cycle or str(cycle['status'])!='ready': await callback.answer("الدورة ليست جاهزة للتوزيع.",show_alert=True); return
    text=("⚠️ <b>تأكيد توزيع أرباح الإحالات</b>\n\n"f"الدورة: #{cid}\n👥 المستحقون: {int(cycle['eligible_count'] or 0)}\n💰 الإجمالي: {int(cycle['total_amount_syp'] or 0):,} SYP\n\nهل أنت متأكد من إضافة الأرباح إلى المحافظ؟")
    await safe_edit(callback,text,reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ نعم، وزّع",f"admin:referrals_distribute_confirm:{cid}")],[_btn("❌ إلغاء","admin:referrals")]]))


@router.callback_query(F.data.startswith("admin:referrals_skip_confirm:"))
async def referrals_skip_confirm(callback:CallbackQuery,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1]); await referral_service.skip(cid,callback.from_user.id); await safe_edit(callback,"⏭ تم إنهاء دورة الإحالات بدون توزيع.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ إدارة الإحالات","admin:referrals")]]))


@router.callback_query(F.data.startswith("admin:referrals_skip:"))
async def referrals_skip_prompt(callback:CallbackQuery,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1]); cycle,_=await referral_service.cycle_detail(cid)
    if not cycle or str(cycle['status']) not in {'ready','empty'}: await callback.answer("لا يمكن إنهاء هذه الدورة الآن.",show_alert=True); return
    await safe_edit(callback,("⚠️ <b>تأكيد إنهاء دورة الإحالات بدون توزيع</b>\n\n"f"الإجمالي غير الموزع: <code>{int(cycle['total_amount_syp'] or 0):,} SYP</code>\n\nهل أنت متأكد؟"),reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⏭ نعم، أنهِ الدورة",f"admin:referrals_skip_confirm:{cid}")],[_btn("❌ إلغاء","admin:referrals")]]))


@router.callback_query(F.data.startswith("admin:ref_history:"))
async def referral_history(callback:CallbackQuery,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    page=max(0,int(str(callback.data).split(":")[-1])); rows=await referral_service.history(8,page*8); lines=["📜 <b>سجل دورات الإحالات</b>",""]; kb=[]
    if not rows: lines.append("لا توجد دورات محفوظة بعد.")
    for r in rows:
        lines.append(f"• #{int(r['id'])} — {_ref_status(str(r['status']))} — {'هرمي' if r['mode']=='hierarchical' else 'مباشر'} — {int(r['total_paid_syp'] or 0):,}/{int(r['total_amount_syp'] or 0):,} SYP")
        kb.append([_btn(f"📊 تفاصيل الدورة #{int(r['id'])}",f"admin:ref_cycle_detail:{int(r['id'])}")])
    nav=[]
    if page>0: nav.append(_btn("⬅️ السابق",f"admin:ref_history:{page-1}"))
    if len(rows)==8: nav.append(_btn("التالي ➡️",f"admin:ref_history:{page+1}"))
    if nav: kb.append(nav)
    kb.append([_btn("⬅️ رجوع","admin:referrals")]); await safe_edit(callback,"\n".join(lines),reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data.startswith("admin:ref_cycle_detail:"))
async def referral_cycle_detail(callback:CallbackQuery,settings:Settings,referral_service:ReferralService)->None:
    if not _admin(callback.from_user.id,settings): return
    cid=int(str(callback.data).split(":")[-1]); r,payouts=await referral_service.cycle_detail(cid)
    if not r: await callback.answer("لم يتم العثور على الدورة.",show_alert=True); return
    text=("📊 <b>تفاصيل دورة الإحالات</b>\n\n"f"الدورة: #{cid}\nالحالة: {_ref_status(str(r['status']))}\nالنظام: {'هرمي' if r['mode']=='hierarchical' else 'مباشر'}\nالمدة: {int(r['duration_days'])} يوم\n\n👥 المستحقون: {int(r['eligible_count'] or 0)}\n💰 المستحق: {int(r['total_amount_syp'] or 0):,} SYP\n💸 الموزع: {int(r['total_paid_syp'] or 0):,} SYP\n👤 تم الدفع لهم: {int(r['paid_count'] or 0)}")
    kb=[]
    if payouts: kb.append([_btn("📋 المستحقون",f"admin:referrals_due:{cid}:0")])
    kb.append([_btn("⬅️ سجل الدورات","admin:ref_history:0")]); await safe_edit(callback,text,reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


# ---------------- Wheel / عجلة الحظ ----------------
async def _wheel_view(runtime:RuntimeSettingsService,wheel:WheelService)->tuple[str,InlineKeyboardMarkup]:
    min_dep,prize=wheel.settings(); enabled,free=wheel.free_settings(); since=runtime.get("wheel.free_spin_started_at")
    text=("🎡 <b>إدارة عجلة الحظ</b>\n\n"f"⚙️ حد الشحن الحالي: <code>{min_dep:,}</code> SYP\n"f"🎯 نتيجة لفة شرط الشحن: <code>{prize:,}</code> SYP\n\n"f"🆕 اللفة المجانية للمستخدمين الجدد: {'✅ مفعلة' if enabled else '⛔ متوقفة'}\n"f"🎁 نتيجة اللفة المجانية: <code>{free:,}</code> SYP"+(f"\n🕒 آخر تفعيل: <code>{html.escape(str(since))}</code>" if since else "")+"\n\nℹ️ اللفة المجانية تُمنح مرة واحدة فقط للمستخدم الذي يسجل لأول مرة أثناء تفعيل الميزة، ولا تشمل المستخدمين السابقين.")
    kb=InlineKeyboardMarkup(inline_keyboard=[[_btn("⚙️ حد شحن العجلة","admin:wheel_set:min")],[_btn("🎡 نتيجة لفة شرط الشحن","admin:wheel_set:prize")],[_btn("🎁 نتيجة اللفة المجانية","admin:wheel_set:free_prize")],[_btn("⛔ إيقاف اللفة المجانية" if enabled else "✅ تشغيل اللفة المجانية","admin:wheel_free_toggle")],[_btn("⬅️ رجوع","admin:home")]])
    return text,kb


@router.callback_query(F.data == "admin:wheel_manage")
async def wheel_manage(callback:CallbackQuery,state:FSMContext,settings:Settings,runtime_settings:RuntimeSettingsService,wheel_service:WheelService)->None:
    if not _admin(callback.from_user.id,settings): return
    await state.clear(); text,kb=await _wheel_view(runtime_settings,wheel_service); await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data == "admin:wheel_free_toggle")
async def wheel_toggle(callback:CallbackQuery,settings:Settings,runtime_settings:RuntimeSettingsService,wheel_service:WheelService)->None:
    if not _admin(callback.from_user.id,settings): return
    enabled,_=wheel_service.free_settings(); await runtime_settings.set("wheel.free_spin_enabled",not enabled,updated_by=callback.from_user.id)
    if not enabled:
        from datetime import datetime,timezone
        await runtime_settings.set("wheel.free_spin_started_at",datetime.now(timezone.utc).isoformat(),updated_by=callback.from_user.id)
    text,kb=await _wheel_view(runtime_settings,wheel_service); await safe_edit(callback,text,reply_markup=kb)


@router.callback_query(F.data.startswith("admin:wheel_set:"))
async def wheel_set(callback:CallbackQuery,state:FSMContext,settings:Settings)->None:
    if not _admin(callback.from_user.id,settings): return
    kind=str(callback.data).split(":")[-1]; await state.set_state(RewardsAdminStates.numeric); await state.set_data({"kind":f"wheel:{kind}"})
    await safe_edit(callback,"أرسل القيمة الجديدة بالليرة السورية. يمكن وضع 0 لنتيجة عجلة بلا جائزة.",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء","admin:wheel_manage")]]))


@router.message(RewardsAdminStates.numeric,F.text)
async def numeric_value(message:Message,state:FSMContext,settings:Settings,cashback_service:CashbackService,referral_service:ReferralService,runtime_settings:RuntimeSettingsService,wheel_service:WheelService)->None:
    if message.from_user is None or not _admin(message.from_user.id,settings): return
    data=await state.get_data(); kind=str(data.get("kind") or "")
    try: value=_num(message.text or "")
    except Exception: await message.answer("❌ أرسل رقماً صحيحاً."); return
    try:
        if kind=="cashback_pct":
            if value<0 or value>100: raise ValueError
            await cashback_service.set_pct(value,message.from_user.id); target="admin:cashback"
        elif kind=="cashback_min":
            if value<0 or value!=value.to_integral_value(): raise ValueError
            await cashback_service.set_min_turnover(int(value),message.from_user.id); target="admin:cashback"
        elif kind.startswith("ref:"):
            sub=kind.split(":",1)[1]; key=_REF_KEYS[sub]
            if sub.endswith("pct"):
                if value<0 or value>100: raise ValueError
                store=str(value)
            else:
                if value<0 or value!=value.to_integral_value() or (sub=="cycle_days" and value<1): raise ValueError
                store=int(value)
            await runtime_settings.set(key,store,updated_by=message.from_user.id); target="admin:referrals"
        elif kind=="ref_fixed_amount":
            if value<0 or value!=value.to_integral_value(): raise ValueError
            await runtime_settings.set("referral.fixed_amount",int(value),updated_by=message.from_user.id); target="admin:ref_fixed"
        elif kind.startswith("wheel:"):
            if value<0 or value!=value.to_integral_value(): raise ValueError
            sub=kind.split(":",1)[1]; key={"min":"wheel.min_deposit","prize":"wheel.fixed_prize","free_prize":"wheel.free_prize"}[sub]
            await runtime_settings.set(key,int(value),updated_by=message.from_user.id); target="admin:wheel_manage"
        else: raise ValueError
    except Exception:
        await message.answer("❌ القيمة غير صالحة لهذا الإعداد."); return
    await state.clear()
    if target=="admin:cashback": text,kb=await _cashback_view(cashback_service,runtime_settings)
    elif target=="admin:referrals": text,kb=await _ref_view(referral_service,runtime_settings)
    elif target=="admin:ref_fixed":
        cfg=referral_service.fixed_settings(); text=("✅ تم الحفظ.\n\n🎁 مكافأة الإحالة الثابتة\n"f"الحالة: {'مفعلة' if cfg['enabled'] else 'متوقفة'}\nالقيمة: {int(cfg['amount']):,} SYP")
        kb=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ رجوع","admin:ref_fixed")]])
    else: text,kb=await _wheel_view(runtime_settings,wheel_service)
    await message.answer("✅ تم الحفظ.\n\n"+text,reply_markup=kb)
