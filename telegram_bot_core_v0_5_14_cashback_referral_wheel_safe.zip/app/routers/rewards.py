from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from app.core.ui import safe_edit
from app.services.rewards import CashbackService, ReferralService, WheelService
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="rewards")


def _back(data: str = "core:home") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ رجوع", callback_data=data)]])


@router.callback_query(F.data == "cashback:home")
async def cashback_home(callback: CallbackQuery, cashback_service: CashbackService, runtime_settings: RuntimeSettingsService) -> None:
    info = await cashback_service.current_info()
    def pct(key: str) -> str:
        v = runtime_settings.get_decimal(key, 0)
        return f"{v.normalize():f}" if v else "0"
    cards: list[str] = []
    methods = [
        ("bonus.sham_syp_pct", "💳 <b>شام كاش - ليرة</b>"),
        ("bonus.sham_usd_pct", "💵 <b>شام كاش - دولار</b>"),
        ("bonus.syriatel_pct", "📲 <b>سيرياتيل كاش</b>"),
        ("bonus.binance_usdt_pct", "🟡 <b>Binance USDT</b>"),
        ("bonus.whish_money_pct", "💵 <b>Whish Money</b>"),
    ]
    for key, label in methods:
        val = runtime_settings.get_decimal(key, 0)
        if val > 0:
            cards.append(f"{label}\nنسبة الزيادة على التعبئة: <code>{pct(key)}%</code>")
    cb_pct = info.get("pct") or 0
    if cb_pct and float(cb_pct) > 0:
        name = "الاسترداد اليومي" if int(info.get("cycle_days") or 7) <= 1 else "الاسترداد الأسبوعي"
        cards.append(
            f"📉 <b>{name}</b>\n"
            f"نسبة الاسترداد: <code>{float(cb_pct):g}%</code>\n"
            "شرط الاسترداد:\n"
            f"يجب أن تصل خسارة الأصل الحقيقي المؤهل إلى <code>{int(info.get('min_turnover') or 0):,} ل.س</code> أو أكثر خلال الدورة.\n"
            "يُحتسب فقط أصل الأموال الحقيقية المؤهلة، ولا تدخل البونصات أو الهدايا أو الإحالات أو الاستردادات السابقة في الحساب."
        )
    if runtime_settings.get_decimal("withdraw.fee_pct", 0) == 0:
        cards.append("💸 <b>عمولة السحب</b>\nالنسبة: <code>0%</code>")
    if not cards:
        cards.append("لا توجد عروض مفعلة حالياً.")
    text = "🎁 <b>عروضنا الحالية</b>\n━━━━━━━━━━━━━━\n\n" + "\n\n━━━━━━━━━━━━━━\n\n".join(cards)
    await safe_edit(callback, text, reply_markup=_back())


@router.callback_query(F.data == "ref:home")
async def referral_home(callback: CallbackQuery, referral_service: ReferralService) -> None:
    info = await referral_service.dashboard(callback.from_user.id)
    me = await callback.bot.get_me()
    link = f"https://t.me/{me.username}?start={callback.from_user.id}" if me.username else "-"
    fixed = ""
    if info.get("fixed_enabled") and int(info.get("fixed_amount") or 0) > 0:
        amount = int(info["fixed_amount"])
        fixed = (
            f"<b>🎁 مكافأة الإحالة:</b> {amount:,} ل.س\n"
            + ("تحصل عليها عندما تقوم إحالتك المباشرة بأول عملية شحن ناجحة." if info.get("fixed_trigger") == "first_deposit"
               else "تحصل عليها عن كل إحالة مباشرة جديدة يتم تأكيدها.")
        )
    status = str(info.get("status") or "none")
    active_cycle = status in {"active", "preparing", "ready", "distributing"}
    mode = str(info.get("mode") or "direct")
    if active_cycle and mode == "hierarchical":
        text = (
            "<b>🌳 نظام الإحالات الهرمي مفعّل</b>\n\n"
            "اربح من صافي الخسارة المؤهلة لشبكة إحالاتك على 3 مستويات خلال دورة الإحالات.\n\n"
            f"<b>المستوى الأول:</b> {float(info.get('level1_pct') or 0):g}%\n"
            f"<b>المستوى الثاني:</b> {float(info.get('level2_pct') or 0):g}%\n"
            f"<b>المستوى الثالث:</b> {float(info.get('level3_pct') or 0):g}%\n\n"
            + (fixed + "\n\n" if fixed else "")
            + "1- انسخ رابط الإحالة الخاص بك وانشره.\n"
              "2- أي مستخدم يدخل عبر رابطك يصبح ضمن المستوى الأول لديك.\n"
              "3- عندما يدعو إحالاتك أشخاصاً آخرين يتم احتسابهم ضمن المستويات التالية.\n"
              "4- الأرباح تُحسب عند نهاية الدورة على صافي الخسارة المؤهلة وفق إعدادات الإدارة.\n\n"
            f"<b>رابط الإحالة الخاص بك:</b>\n{link}\n\n"
            f"<b>إجمالي الإحالات المباشرة:</b> {int(info.get('total') or 0)}\n"
            f"<b>الإحالات النشطة خلال الدورة:</b> {int(info.get('active') or 0)}\n"
            f"<b>مدة حساب الأرباح:</b> {int(info.get('cycle_days') or 0)} يوم/أيام\n"
            f"<b>المدة المتبقية:</b> {int(info.get('remaining_days') or 0)} يوم/أيام"
        )
    elif active_cycle:
        text = (
            "<b>🤝 نظام الإحالات المباشر مفعّل</b>\n\n"
            "اربح نسبة ثابتة من صافي الخسارة المؤهلة للأشخاص الذين انضموا عن طريق رابطك خلال الدورة.\n\n"
            f"<b>نسبة الأرباح الحالية:</b> {float(info.get('direct_pct') or 0):g}%\n\n"
            + (fixed + "\n\n" if fixed else "")
            + f"<b>رابط الإحالة الخاص بك:</b>\n{link}\n\n"
            f"<b>إجمالي الإحالات المباشرة:</b> {int(info.get('total') or 0)}\n"
            f"<b>الإحالات النشطة خلال الدورة:</b> {int(info.get('active') or 0)}\n"
            f"<b>مدة حساب الأرباح:</b> {int(info.get('cycle_days') or 0)} يوم/أيام\n"
            f"<b>المدة المتبقية:</b> {int(info.get('remaining_days') or 0)} يوم/أيام"
        )
    elif fixed:
        text = (
            "<b>🎁 دعوة الأصدقاء</b>\n\nادعُ أصدقاءك إلى البوت واحصل على مكافأة مقابل كل إحالة يتم تأكيدها بنجاح.\n\n"
            f"<b>رابط الإحالة الخاص بك:</b>\n{link}\n\n{fixed}\n\n"
            f"<b>إجمالي الإحالات المباشرة:</b> {int(info.get('total') or 0)}"
        )
    else:
        text = (
            "<b>🤝 الإحالات</b>\n\n"
            f"<b>رابط الإحالة الخاص بك:</b>\n{link}\n\n"
            f"<b>إجمالي الإحالات المباشرة:</b> {int(info.get('total') or 0)}\n"
            f"<b>الإحالات النشطة المباشرة:</b> {int(info.get('active') or 0)}\n\n"
            "لا يوجد حاليًا نظام أرباح إحالات فعال."
        )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👥 إحالاتي", callback_data="ref:my"), InlineKeyboardButton(text="📜 سجل أرباحي", callback_data="ref:earnings")],
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="core:home")],
    ])
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "ref:my")
async def referral_my(callback: CallbackQuery, referral_service: ReferralService) -> None:
    rows, total = await referral_service.my_referrals(callback.from_user.id)
    lines = ["👥 إحالاتي", "", f"إجمالي الإحالات المؤكدة: {total}", ""]
    if not rows:
        lines.append("لا توجد إحالات مؤكدة حتى الآن.")
    for idx, r in enumerate(rows, 1):
        user = f" @{r['username']}" if r.get("username") else ""
        state = "🟢 نشطة" if r.get("is_active") else "⚪ مؤكدة"
        lines.append(f"{idx}) {r.get('first_name') or 'مستخدم'}{user} — {state}")
    if total > len(rows):
        lines.extend(["", f"… يتم عرض آخر {len(rows)} إحالة من أصل {total}."])
    await safe_edit(callback, "\n".join(lines), reply_markup=_back("ref:home"))


@router.callback_query(F.data == "ref:earnings")
async def referral_earnings(callback: CallbackQuery, referral_service: ReferralService) -> None:
    rep = await referral_service.earnings_report(callback.from_user.id)
    lines = [
        "📜 سجل أرباحي", "",
        f"🎁 مكافآت الإحالات: {int(rep.get('fixed') or 0):,} ل.س",
        f"🤝/🌳 أرباح الدورات الموزعة: {int(rep.get('distributed') or 0):,} ل.س",
        f"⏳ أرباح دورة معلقة: {int(rep.get('pending') or 0):,} ل.س", "",
        f"💰 الإجمالي المدفوع: {int(rep.get('fixed') or 0)+int(rep.get('distributed') or 0):,} ل.س",
    ]
    if rep.get("latest"):
        lines.extend(["", "آخر أرباح الدورات:"])
        for r in rep["latest"]:
            lines.append(f"• مستوى {int(r.get('level') or 1)} — {int(r.get('amount_syp') or 0):,} ل.س — {r.get('status') or '-'}")
    await safe_edit(callback, "\n".join(lines), reply_markup=_back("ref:home"))


@router.callback_query(F.data == "wheel:open")
async def wheel_open(callback: CallbackQuery, wheel_service: WheelService) -> None:
    if await wheel_service.free_eligible(callback.from_user.id):
        _, prize = wheel_service.free_settings()
        text = "🎡 عجلة حظ Ichancy\n\n🎁 لديك لفة مجانية خاصة بالمستخدمين الجدد!\nاضغط على الزر أدناه لفتح العجلة ومعرفة جائزتك."
    else:
        ok, err, prize = await wheel_service.eligibility(callback.from_user.id)
        if not ok:
            await callback.answer(err, show_alert=True)
            return
        text = "🎡 عجلة حظ Ichancy\n\nلقد أتممت شروط الشحن لليوم وتستحق تدويرة مجانية!\nاضغط على الزر أدناه لفتح العجلة ومعرفة جائزتك."
    me = await callback.bot.get_me()
    if not me.username:
        await callback.answer("❌ تعذر فتح العجلة الآن. اسم البوت غير متاح.", show_alert=True)
        return
    url = f"https://super-nasturtium-2ead66.netlify.app/?prize={int(prize)}&bot={me.username}"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="أدر العجلة الآن 🎡", web_app=WebAppInfo(url=url))],
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="core:home")],
    ])
    await safe_edit(callback, text, reply_markup=kb)
