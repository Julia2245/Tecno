from __future__ import annotations

import html
import re
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from zoneinfo import ZoneInfo

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.services.finance_rules import FinanceRulesService
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin_bonus")
_DAMASCUS = ZoneInfo("Asia/Damascus")
_NUM_TRANSLATION = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


class BonusAdminStates(StatesGroup):
    percent_value = State()
    tier_amount = State()
    tier_pct = State()
    tier_method = State()
    special_tg = State()
    special_pct = State()
    special_duration = State()
    welcome_amount = State()


def _admin(user_id: int, settings: Settings) -> bool:
    return user_id in settings.super_admin_ids


def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data=data)


def _fmt(value) -> str:
    dec = Decimal(str(value or 0))
    return str(int(dec)) if dec == dec.to_integral_value() else format(dec.normalize(), "f")


def _normalize_number(raw: str, *, decimal: bool = True) -> str:
    value = str(raw or "").translate(_NUM_TRANSLATION).strip().replace("٬", "").replace(",", "." if decimal else "")
    return value.replace("٫", ".") if decimal else value


def _scope_label(scope: str) -> str:
    return {
        "all": "كل وسائل الشحن",
        "syriatel": "سيرياتيل كاش",
        "sham_syp": "شام كاش – ليرة",
        "sham_usd": "شام كاش – دولار",
        "binance": "Binance USDT",
        "whish": "Whish Money",
    }.get(str(scope or "all"), str(scope or "all"))


async def _bonus_view(runtime: RuntimeSettingsService, rules: FinanceRulesService) -> tuple[str, InlineKeyboardMarkup]:
    tiers = await rules.list_deposit_tiers()
    enabled = runtime.get_bool("bonus.deposit_tiers_enabled", True)
    vals = {
        "syriatel": runtime.get_decimal("bonus.syriatel_pct", 0),
        "sham_syp": runtime.get_decimal("bonus.sham_syp_pct", 0),
        "sham_usd": runtime.get_decimal("bonus.sham_usd_pct", 0),
        "binance": runtime.get_decimal("bonus.binance_usdt_pct", 0),
        "whish": runtime.get_decimal("bonus.whish_money_pct", 0),
    }
    text = (
        "🎁 <b>إدارة البونص</b>\n\n"
        f"🧩 بونص فئات الشحن: <b>{'مفعل' if enabled else 'متوقف'}</b> — {len(tiers)} فئة\n\n"
        f"📲 سيرياتيل العادي: <code>{_fmt(vals['syriatel'])}%</code>\n"
        f"💳 شام كاش ليرة العادي: <code>{_fmt(vals['sham_syp'])}%</code>\n"
        f"💵 شام كاش دولار العادي: <code>{_fmt(vals['sham_usd'])}%</code>\n"
        f"🟡 Binance العادي: <code>{_fmt(vals['binance'])}%</code>\n"
        f"💵 Whish Money العادي: <code>{_fmt(vals['whish'])}%</code>\n\n"
        "عند انطباق فئة شحن، تستبدل البونص العادي ولا تُجمع معه.\n"
        "الأولوية: بونص أول شحن، ثم البونص الخاص، ثم الفئات، ثم البونص العادي."
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [_btn("🧩 بونص فئات الشحن", "admin:deposit_bonus_tiers")],
        [_btn(f"🎁 بونص سيرياتيل ({_fmt(vals['syriatel'])}%)", "admin:bonus_set:syriatel")],
        [_btn(f"🎁 بونص شام ليرة ({_fmt(vals['sham_syp'])}%)", "admin:bonus_set:sham_syp")],
        [_btn(f"🎁 بونص شام دولار ({_fmt(vals['sham_usd'])}%)", "admin:bonus_set:sham_usd")],
        [_btn(f"🎁 بونص Binance ({_fmt(vals['binance'])}%)", "admin:bonus_set:binance")],
        [_btn(f"🎁 بونص Whish Money ({_fmt(vals['whish'])}%)", "admin:bonus_set:whish")],
        [_btn("🎁 بونص خاص لمستخدم", "admin:special_bonus")],
        [_btn("🎁 بونص أول دخول", "admin:welcome_bonus")],
        [_btn("⬅️ رجوع", "admin:finance")],
    ])
    return text, kb


async def _commission_view(runtime: RuntimeSettingsService, rules: FinanceRulesService) -> tuple[str, InlineKeyboardMarkup]:
    tiers = await rules.list_withdraw_tiers()
    enabled = runtime.get_bool("commission.withdraw_tiers_enabled", True)
    regular = runtime.get_decimal("withdraw.fee_pct", 0)
    hawala = runtime.get_decimal("withdraw.hawala_fee_pct", 0)
    text = (
        "💰 <b>إدارة العمولة</b>\n\n"
        f"🧩 عمولة فئات السحب: <b>{'مفعلة' if enabled else 'متوقفة'}</b> — {len(tiers)} فئة\n\n"
        f"💸 عمولة السحب العادية: <code>{_fmt(regular)}%</code>\n"
        f"🏦 عمولة الحوالة العادية: <code>{_fmt(hawala)}%</code>\n\n"
        "عند انطباق فئة سحب، تستبدل العمولة العادية ولا تُجمع معها."
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [_btn("🧩 عمولة فئات السحب", "admin:withdraw_fee_tiers")],
        [_btn(f"💰 عمولة السحب العادية ({_fmt(regular)}%)", "admin:commission_set:regular")],
        [_btn(f"🏦 عمولة الحوالة العادية ({_fmt(hawala)}%)", "admin:commission_set:hawala")],
        [_btn("⬅️ رجوع", "admin:finance")],
    ])
    return text, kb


@router.callback_query(F.data == "admin:bonus_manage")
async def bonus_manage(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    text, kb = await _bonus_view(runtime_settings, finance_rules)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:commission_manage")
async def commission_manage(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    text, kb = await _commission_view(runtime_settings, finance_rules)
    await safe_edit(callback, text, reply_markup=kb)


_BONUS_KEYS = {
    "syriatel": ("bonus.syriatel_pct", "بونص سيرياتيل"),
    "sham_syp": ("bonus.sham_syp_pct", "بونص شام كاش ليرة"),
    "sham_usd": ("bonus.sham_usd_pct", "بونص شام كاش دولار"),
    "binance": ("bonus.binance_usdt_pct", "بونص Binance"),
    "whish": ("bonus.whish_money_pct", "بونص Whish Money"),
}


@router.callback_query(F.data.startswith("admin:bonus_set:"))
async def bonus_set_start(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    kind = str(callback.data).rsplit(":", 1)[-1]
    meta = _BONUS_KEYS.get(kind)
    if not meta: return
    key, label = meta
    await state.set_state(BonusAdminStates.percent_value)
    await state.set_data({"percent_key": key, "percent_return": "bonus", "percent_label": label})
    await safe_edit(callback, f"🎁 <b>{html.escape(label)}</b>\n\nالقيمة الحالية: <code>{_fmt(runtime_settings.get_decimal(key,0))}%</code>\n\nأرسل النسبة الجديدة من 0 إلى 100.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:bonus_manage")]]))


@router.callback_query(F.data.startswith("admin:commission_set:"))
async def commission_set_start(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    kind = str(callback.data).rsplit(":", 1)[-1]
    key = "withdraw.hawala_fee_pct" if kind == "hawala" else "withdraw.fee_pct"
    label = "عمولة الحوالة العادية" if kind == "hawala" else "عمولة السحب العادية"
    await state.set_state(BonusAdminStates.percent_value)
    await state.set_data({"percent_key": key, "percent_return": "commission", "percent_label": label})
    await safe_edit(callback, f"💰 <b>{label}</b>\n\nالقيمة الحالية: <code>{_fmt(runtime_settings.get_decimal(key,0))}%</code>\n\nأرسل النسبة الجديدة من 0 إلى 100.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:commission_manage")]]))


@router.message(BonusAdminStates.percent_value, F.text)
async def percent_value(message: Message, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService, finance_rules: FinanceRulesService) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data()
    try:
        pct = Decimal(_normalize_number(message.text or ""))
    except Exception:
        await message.answer("❌ أرسل نسبة صحيحة، مثال: 3 أو 12.5")
        return
    if pct < 0 or pct > 100:
        await message.answer("❌ النسبة يجب أن تكون بين 0 و100%.")
        return
    key = str(data.get("percent_key") or "")
    await runtime_settings.set(key, str(pct), updated_by=message.from_user.id)
    target = str(data.get("percent_return") or "bonus")
    await state.clear()
    if target == "commission":
        text, kb = await _commission_view(runtime_settings, finance_rules)
    elif target == "welcome":
        text, kb = _welcome_view(runtime_settings)
    else:
        text, kb = await _bonus_view(runtime_settings, finance_rules)
    await message.answer("✅ تم الحفظ.\n\n" + text, reply_markup=kb)


def _welcome_enabled_since_text(runtime: RuntimeSettingsService) -> str:
    raw = runtime.get("bonus.welcome_enabled_since")
    if not raw:
        return "غير محدد"
    try:
        dt = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(_DAMASCUS).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return html.escape(str(raw))


def _welcome_view(runtime: RuntimeSettingsService) -> tuple[str, InlineKeyboardMarkup]:
    enabled = runtime.get_bool("bonus.welcome_enabled", False)
    mode = str(runtime.get("bonus.welcome_mode", "instant") or "instant")
    if mode not in {"instant", "first_deposit"}:
        mode = "instant"
    amount = max(0, runtime.get_int("bonus.welcome_amount", 0))
    pct = runtime.get_decimal("bonus.welcome_first_deposit_pct", 0)
    mode_label = "بونص مباشر" if mode == "instant" else "بونص شحن أول"
    text = (
        "🎁 بونص أول دخول\n\n"
        f"الحالة: {'✅ مفعل' if enabled else '❌ متوقف'}\n"
        f"النوع الحالي: {mode_label}\n"
        f"قيمة البونص المباشر: {amount:,} SYP\n"
        f"قيمة بونص أول شحن: {_fmt(pct)}%\n"
        f"يبدأ الاستحقاق من: {_welcome_enabled_since_text(runtime)}\n\n"
        "• البونص المباشر يُضاف فوراً للمحفظة عند أول دخول مؤهل.\n"
        "• بونص أول شحن يُحفظ كمعلّق ويُضاف على أول عملية شحن ناجحة فقط، وله أولوية على بونص المستخدم والفئات وطريقة الشحن."
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [_btn("⛔ إيقاف" if enabled else "✅ تشغيل", "admin:welcome_bonus_toggle")],
        [_btn(f"🔘 النوع الحالي: {mode_label}", "admin:welcome_bonus_mode_menu")],
        [_btn(f"💰 قيمة البونص المباشر ({amount:,} SYP)", "admin:welcome_bonus_amount")],
        [_btn(f"📥 بونص أول شحن ({_fmt(pct)}%)", "admin:welcome_bonus_first_pct")],
        [_btn("⬅️ رجوع", "admin:bonus_manage")],
    ])
    return text, kb


@router.callback_query(F.data == "admin:welcome_bonus")
async def welcome_bonus_home(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    text, kb = _welcome_view(runtime_settings)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:welcome_bonus_toggle")
async def welcome_bonus_toggle(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    enabled = runtime_settings.get_bool("bonus.welcome_enabled", False)
    if enabled:
        await runtime_settings.set("bonus.welcome_enabled", False, updated_by=callback.from_user.id)
    else:
        # every activation creates a new eligibility boundary; only users
        # created on/after this boundary can receive a claim. Existing claims remain audit history.
        await runtime_settings.set("bonus.welcome_enabled_since", datetime.now(timezone.utc).isoformat(), updated_by=callback.from_user.id)
        await runtime_settings.set("bonus.welcome_enabled", True, updated_by=callback.from_user.id)
    text, kb = _welcome_view(runtime_settings)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:welcome_bonus_mode_menu")
async def welcome_bonus_mode_menu(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    mode = str(runtime_settings.get("bonus.welcome_mode", "instant") or "instant")
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [_btn(("✅ " if mode == "instant" else "") + "بونص مباشر", "admin:welcome_bonus_mode:instant")],
        [_btn(("✅ " if mode == "first_deposit" else "") + "بونص شحن أول", "admin:welcome_bonus_mode:first_deposit")],
        [_btn("⬅️ رجوع", "admin:welcome_bonus")],
    ])
    await safe_edit(callback, "اختر نوع بونص أول دخول:", reply_markup=kb)


@router.callback_query(F.data.startswith("admin:welcome_bonus_mode:"))
async def welcome_bonus_mode_set(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    mode = str(callback.data).rsplit(":", 1)[-1]
    if mode not in {"instant", "first_deposit"}: return
    await runtime_settings.set("bonus.welcome_mode", mode, updated_by=callback.from_user.id)
    text, kb = _welcome_view(runtime_settings)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:welcome_bonus_amount")
async def welcome_bonus_amount_start(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.set_state(BonusAdminStates.welcome_amount)
    current = max(0, runtime_settings.get_int("bonus.welcome_amount", 0))
    await safe_edit(callback, f"💰 <b>قيمة البونص المباشر</b>\n\nالقيمة الحالية: <code>{current:,} SYP</code>\n\nأرسل القيمة الجديدة كرقم صحيح (0 لإيقاف القيمة).", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:welcome_bonus")]]))


@router.message(BonusAdminStates.welcome_amount, F.text)
async def welcome_bonus_amount_value(message: Message, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    raw = _normalize_number(message.text or "", decimal=False)
    if not raw.isdigit():
        await message.answer("❌ أرسل مبلغاً صحيحاً بدون فواصل."); return
    amount = int(raw)
    if amount < 0 or amount > 9_000_000_000_000_000_000:
        await message.answer("❌ المبلغ خارج النطاق المسموح."); return
    await runtime_settings.set("bonus.welcome_amount", amount, updated_by=message.from_user.id)
    await state.clear()
    text, kb = _welcome_view(runtime_settings)
    await message.answer("✅ تم الحفظ.\n\n" + text, reply_markup=kb)


@router.callback_query(F.data == "admin:welcome_bonus_first_pct")
async def welcome_bonus_first_pct_start(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    key = "bonus.welcome_first_deposit_pct"
    await state.set_state(BonusAdminStates.percent_value)
    await state.set_data({"percent_key": key, "percent_return": "welcome", "percent_label": "بونص أول شحن"})
    await safe_edit(callback, f"📥 <b>بونص أول شحن</b>\n\nالقيمة الحالية: <code>{_fmt(runtime_settings.get_decimal(key,0))}%</code>\n\nأرسل النسبة الجديدة من 0 إلى 100.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:welcome_bonus")]]))


def _tier_info(kind: str):
    if kind == "deposit":
        return "بونص فئات الشحن", "bonus.deposit_tiers_enabled", "admin:bonus_manage"
    if kind == "withdraw":
        return "عمولة فئات السحب", "commission.withdraw_tiers_enabled", "admin:commission_manage"
    raise ValueError("نوع الفئة غير صالح")


async def _tier_view(kind: str, runtime: RuntimeSettingsService, rules: FinanceRulesService) -> tuple[str, InlineKeyboardMarkup]:
    title, setting_key, back = _tier_info(kind)
    enabled = runtime.get_bool(setting_key, True)
    tiers = await (rules.list_deposit_tiers() if kind == "deposit" else rules.list_withdraw_tiers())
    lines = [f"🧩 <b>{title}</b>", "━━━━━━━━━━━━━━", f"الحالة: <b>{'✅ مفعل' if enabled else '⛔ متوقف'}</b>", ""]
    if kind == "deposit":
        lines += ["يتم اختيار أعلى فئة مؤهلة حسب <b>مبلغ الشحن الأصلي قبل التحويل</b> ووسيلة الشحن.", "قيمة البونص تُحسب على الرصيد الأساسي بعد التحويل لعملة البوت.", "إذا لم تنطبق فئة، يبقى البونص العادي."]
    else:
        lines += ["يتم اختيار أعلى فئة مؤهلة حسب مبلغ السحب بعملة البوت.", "إذا لم تنطبق فئة، تبقى العمولة العادية."]
    lines += ["", "<b>الفئات الحالية:</b>"]
    if not tiers:
        lines.append("لا توجد فئات مضافة بعد.")
    rows = [[_btn("➕ إضافة فئة", f"admin:tier_add:{kind}")]]
    for row in tiers[:20]:
        if kind == "deposit":
            amount = int(row["min_amount_input"])
            lines.append(f"• {_scope_label(row['method_scope'])}: من <code>{amount:,}</code> فأكثر → <b>{_fmt(row['pct'])}%</b>")
            label = f"✏️ {amount:,}+ • {_fmt(row['pct'])}% • {_scope_label(row['method_scope'])}"
        else:
            amount = int(row["min_amount_wallet"])
            lines.append(f"• من <code>{amount:,} SYP</code> فأكثر → <b>{_fmt(row['pct'])}%</b>")
            label = f"✏️ {amount:,}+ • {_fmt(row['pct'])}%"
        rows.append([_btn(label, f"admin:tier_view:{kind}:{int(row['id'])}")])
    rows.append([_btn("⛔ إيقاف النظام" if enabled else "✅ تشغيل النظام", f"admin:tier_toggle:{kind}:{0 if enabled else 1}")])
    rows.append([_btn("⬅️ رجوع", back)])
    return "\n".join(lines), InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data.in_({"admin:deposit_bonus_tiers", "admin:withdraw_fee_tiers"}))
async def tier_home(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    kind = "deposit" if callback.data == "admin:deposit_bonus_tiers" else "withdraw"
    text, kb = await _tier_view(kind, runtime_settings, finance_rules)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.startswith("admin:tier_toggle:"))
async def tier_toggle(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    _, _, kind, value = str(callback.data).split(":")
    key = _tier_info(kind)[1]
    await runtime_settings.set(key, value == "1", updated_by=callback.from_user.id)
    text, kb = await _tier_view(kind, runtime_settings, finance_rules)
    await safe_edit(callback, ("✅ تم تشغيل النظام.\n\n" if value == "1" else "⛔ تم إيقاف النظام.\n\n") + text, reply_markup=kb)


async def _tier_detail(kind: str, tier_id: int, rules: FinanceRulesService) -> tuple[str, InlineKeyboardMarkup] | None:
    row = await rules.get_tier(kind, tier_id)
    if not row: return None
    if kind == "deposit":
        text = f"🧩 <b>بونص فئات الشحن</b>\n\n💰 الحد الأدنى لمبلغ الشحن الأصلي: <code>{int(row['min_amount_input']):,}</code>\n🎯 البونص: <code>{_fmt(row['pct'])}%</code>\n💳 الوسيلة: <b>{_scope_label(row['method_scope'])}</b>"
    else:
        text = f"🧩 <b>عمولة فئات السحب</b>\n\n💰 الحد الأدنى: <code>{int(row['min_amount_wallet']):,} SYP</code>\n📊 العمولة: <code>{_fmt(row['pct'])}%</code>"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [_btn("✏️ تعديل الفئة", f"admin:tier_edit:{kind}:{tier_id}")],
        [_btn("🗑 حذف الفئة", f"admin:tier_delete_confirm:{kind}:{tier_id}")],
        [_btn("⬅️ رجوع", "admin:deposit_bonus_tiers" if kind == "deposit" else "admin:withdraw_fee_tiers")],
    ])
    return text, kb


@router.callback_query(F.data.startswith("admin:tier_view:"))
async def tier_detail(callback: CallbackQuery, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    _, _, kind, raw_id = str(callback.data).split(":")
    result = await _tier_detail(kind, int(raw_id), finance_rules)
    if not result:
        await safe_edit(callback, "⚠️ هذه الفئة لم تعد موجودة.")
        return
    await safe_edit(callback, result[0], reply_markup=result[1])


@router.callback_query(F.data.startswith("admin:tier_delete_confirm:"))
async def tier_delete_confirm(callback: CallbackQuery, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    _, _, kind, raw_id = str(callback.data).split(":")
    result = await _tier_detail(kind, int(raw_id), finance_rules)
    if not result:
        await safe_edit(callback, "⚠️ الفئة غير موجودة.")
        return
    await safe_edit(callback, "⚠️ <b>تأكيد حذف الفئة</b>\n\n" + result[0], reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("🗑 نعم، حذف", f"admin:tier_delete:{kind}:{raw_id}")], [_btn("⬅️ إلغاء", f"admin:tier_view:{kind}:{raw_id}")]]))


@router.callback_query(F.data.startswith("admin:tier_delete:"))
async def tier_delete(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    _, _, kind, raw_id = str(callback.data).split(":")
    await finance_rules.delete_tier(kind, int(raw_id))
    text, kb = await _tier_view(kind, runtime_settings, finance_rules)
    await safe_edit(callback, "✅ تم حذف الفئة.\n\n" + text, reply_markup=kb)


@router.callback_query(F.data.startswith("admin:tier_add:") | F.data.startswith("admin:tier_edit:"))
async def tier_add_edit(callback: CallbackQuery, state: FSMContext, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    parts = str(callback.data).split(":")
    action, kind = parts[1], parts[2]
    tier_id = int(parts[3]) if action == "tier_edit" and len(parts) > 3 else None
    if tier_id is not None and not await finance_rules.get_tier(kind, tier_id):
        await safe_edit(callback, "⚠️ الفئة غير موجودة.")
        return
    await state.set_state(BonusAdminStates.tier_amount)
    await state.set_data({"tier_kind": kind, "tier_edit_id": tier_id})
    prompt = "🎁 <b>بونص فئات الشحن</b>\n\nأرسل الحد الأدنى من <b>مبلغ الشحن الأصلي</b>.\nمثال: <code>5000</code>" if kind == "deposit" else "💰 <b>عمولة فئات السحب</b>\n\nأرسل الحد الأدنى لمبلغ السحب بعملة البوت."
    await safe_edit(callback, prompt, reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:tier_cancel")]]))


@router.message(BonusAdminStates.tier_amount, F.text)
async def tier_amount(message: Message, state: FSMContext, settings: Settings) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data(); kind = str(data.get("tier_kind") or "deposit")
    raw = _normalize_number(message.text or "", decimal=False)
    if not raw.isdigit() or int(raw) <= 0:
        await message.answer("❌ أرسل مبلغاً صحيحاً أكبر من صفر.")
        return
    amount = int(raw)
    await state.update_data(tier_amount=str(amount))
    await state.set_state(BonusAdminStates.tier_pct)
    await message.answer(f"💰 الحد الأدنى: {_fmt(amount)}\n\nأدخل نسبة {'البونص' if kind=='deposit' else 'العمولة'}. مثال: <code>3</code>")


@router.message(BonusAdminStates.tier_pct, F.text)
async def tier_pct(message: Message, state: FSMContext, settings: Settings) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    try:
        pct = Decimal(_normalize_number(message.text or ""))
    except Exception:
        pct = Decimal("-1")
    if pct < 0 or pct > 100:
        await message.answer("❌ أرسل نسبة بين 0 و100.")
        return
    data = await state.get_data(); kind = str(data.get("tier_kind") or "deposit")
    await state.update_data(tier_pct=str(pct))
    if kind == "deposit":
        await state.set_state(BonusAdminStates.tier_method)
        await message.answer("💳 <b>اختر وسيلة الشحن:</b>", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [_btn("🌐 كل وسائل الشحن", "admin:tier_method:all")],
            [_btn("🔴 سيرياتيل كاش", "admin:tier_method:syriatel")],
            [_btn("🔵 شام كاش – ليرة", "admin:tier_method:sham_syp")],
            [_btn("💵 شام كاش – دولار", "admin:tier_method:sham_usd")],
            [_btn("🟡 Binance USDT", "admin:tier_method:binance")],
            [_btn("💵 Whish Money", "admin:tier_method:whish")],
            [_btn("❌ إلغاء", "admin:tier_cancel")],
        ]))
        return
    await _show_tier_confirm_message(message, state)


async def _tier_confirm_text(state: FSMContext) -> str:
    data = await state.get_data(); kind = str(data.get("tier_kind") or "deposit")
    amount = Decimal(str(data.get("tier_amount") or 0)); pct = Decimal(str(data.get("tier_pct") or 0))
    if kind == "deposit":
        scope = str(data.get("tier_scope") or "all"); label = _scope_label(scope)
        return f"🎁 <b>تأكيد بونص فئة الشحن</b>\n\n💰 الحد الأدنى الأصلي: <code>{int(amount):,}</code>\n🎯 البونص: <code>{_fmt(pct)}%</code>\n💳 الوسيلة: <b>{label}</b>\n\nسيطبق على أي شحن عبر {label} يساوي {int(amount):,} أو أكثر، والبونص يحسب على رصيد البوت بعد التحويل.\n\nهل أنت متأكد؟"
    return f"💰 <b>تأكيد فئة عمولة السحب</b>\n\n💵 الحد الأدنى: <code>{int(amount):,} SYP</code>\n📊 العمولة: <code>{_fmt(pct)}%</code>\n\nهل أنت متأكد؟"


async def _show_tier_confirm_message(message: Message, state: FSMContext) -> None:
    await message.answer(await _tier_confirm_text(state), reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ تأكيد", "admin:tier_save"), _btn("❌ إلغاء", "admin:tier_cancel")]]))


@router.callback_query(F.data.startswith("admin:tier_method:"), BonusAdminStates.tier_method)
async def tier_method(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    scope = str(callback.data).rsplit(":",1)[-1]
    if scope not in {"all","syriatel","sham_syp","sham_usd","binance","whish"}: return
    await state.update_data(tier_scope=scope)
    await safe_edit(callback, await _tier_confirm_text(state), reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ تأكيد", "admin:tier_save"), _btn("❌ إلغاء", "admin:tier_cancel")]]))


@router.callback_query(F.data == "admin:tier_save")
async def tier_save(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    data = await state.get_data(); kind = str(data.get("tier_kind") or "deposit")
    try:
        tier_id = await finance_rules.save_tier(
            kind, Decimal(str(data.get("tier_amount"))), Decimal(str(data.get("tier_pct"))),
            created_by=callback.from_user.id, tier_id=data.get("tier_edit_id"), method_scope=str(data.get("tier_scope") or "all"),
        )
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc)[:300])}")
        await state.clear(); return
    await state.clear()
    text, kb = await _tier_view(kind, runtime_settings, finance_rules)
    await safe_edit(callback, f"✅ تم حفظ الفئة وتفعيلها. <code>#{tier_id}</code>\n\n" + text, reply_markup=kb)


@router.callback_query(F.data == "admin:tier_cancel")
async def tier_cancel(callback: CallbackQuery, state: FSMContext, settings: Settings, runtime_settings: RuntimeSettingsService, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    data = await state.get_data(); kind = str(data.get("tier_kind") or "deposit")
    await state.clear()
    text, kb = await _tier_view(kind, runtime_settings, finance_rules)
    await safe_edit(callback, "❌ تم الإلغاء.\n\n" + text, reply_markup=kb)


def _special_home_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn("➕ إضافة / تعديل بونص خاص", "admin:special_bonus_add")],
        [_btn("📋 البونصات النشطة", "admin:special_bonus_list")],
        [_btn("⬅️ رجوع", "admin:bonus_manage")],
    ])


def _special_time(row: dict) -> str:
    if str(row.get("mode") or "once") == "once": return "مرة واحدة"
    exp = row.get("expires_at")
    if not exp: return "مدة محددة"
    if getattr(exp, "tzinfo", None) is None: exp = exp.replace(tzinfo=timezone.utc)
    return "حتى " + exp.astimezone(_DAMASCUS).strftime("%Y-%m-%d %H:%M")


@router.callback_query(F.data == "admin:special_bonus")
async def special_home(callback: CallbackQuery, state: FSMContext, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear(); active = await finance_rules.list_active_specials(100)
    await safe_edit(callback, "🎁 <b>البونص الخاص لمستخدم</b>\n━━━━━━━━━━━━━━\n\nيستبدل بونص طريقة الشحن العادي وفئات الشحن لهذا المستخدم فقط، ولا يُجمع معها.\nبونص أول شحن يحتفظ بأولويته ولا يُجمع معه.\n\n" f"البونصات النشطة الآن: <b>{len(active)}</b>\n\nالأنواع المتاحة: مرة واحدة، 24 ساعة، أو مدة مخصصة.", reply_markup=_special_home_kb())


@router.callback_query(F.data == "admin:special_bonus_add")
async def special_add(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.set_state(BonusAdminStates.special_tg); await state.set_data({})
    await safe_edit(callback, "🎁 <b>إضافة / تعديل بونص خاص</b>\n\nأرسل Telegram ID للمستخدم.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:special_bonus")]]))


@router.message(BonusAdminStates.special_tg, F.text)
async def special_tg(message: Message, state: FSMContext, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    raw = _normalize_number(message.text or "", decimal=False)
    if not raw.isdigit() or int(raw) <= 0:
        await message.answer("❌ أرسل Telegram ID صحيحاً."); return
    # Validate the user before continuing, using the same repository that owns the rule.
    pool = finance_rules.repository.db.require_pool()
    async with pool.acquire() as conn:
        exists = await conn.fetchval("SELECT 1 FROM bot_core.users WHERE telegram_id=$1", int(raw))
    if not exists:
        await message.answer("❌ هذا المستخدم غير موجود في البوت."); return
    await state.update_data(special_tg=int(raw)); await state.set_state(BonusAdminStates.special_pct)
    await message.answer(f"👤 المستخدم: <code>{int(raw)}</code>\n\nأرسل نسبة البونص الخاصة.\nمثال: <code>10</code> أو <code>12.5</code>")


@router.message(BonusAdminStates.special_pct, F.text)
async def special_pct(message: Message, state: FSMContext, settings: Settings) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    try: pct = Decimal(_normalize_number(message.text or ""))
    except Exception: pct = Decimal("0")
    if pct <= 0 or pct > 100:
        await message.answer("❌ النسبة يجب أن تكون أكبر من 0 وحتى 100%."); return
    await state.update_data(special_pct=str(pct))
    await message.answer(f"🎁 النسبة: <b>{_fmt(pct)}%</b>\n\nاختر مدة البونص:", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [_btn("1️⃣ مرة واحدة", "admin:special_bonus_mode:once"), _btn("🕐 24 ساعة", "admin:special_bonus_mode:24h")],
        [_btn("⏱ مدة مخصصة", "admin:special_bonus_mode:custom")],
        [_btn("❌ إلغاء", "admin:special_bonus")],
    ]))


@router.callback_query(F.data.startswith("admin:special_bonus_mode:"))
async def special_mode(callback: CallbackQuery, state: FSMContext, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    data = await state.get_data()
    try: tg = int(data["special_tg"]); pct = Decimal(str(data["special_pct"]))
    except Exception:
        await state.clear(); await safe_edit(callback, "⚠️ انتهت جلسة الإضافة. ابدأ من جديد.", reply_markup=_special_home_kb()); return
    mode = str(callback.data).rsplit(":",1)[-1]
    if mode == "custom":
        await state.set_state(BonusAdminStates.special_duration)
        await safe_edit(callback, "⏱ <b>المدة المخصصة</b>\n\nأرسل المدة بإحدى الصيغ:\n• <code>6h</code> = 6 ساعات\n• <code>3d</code> = 3 أيام\n• <code>2026-10-20 18:30</code> = وقت انتهاء محدد بتوقيت دمشق\n\nوإذا أرسلت رقمًا فقط مثل <code>12</code> سيُعتبر عدد ساعات.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:special_bonus")]])); return
    expires = datetime.now(timezone.utc) + timedelta(hours=24) if mode == "24h" else None
    row = await finance_rules.set_special(tg, pct, "timed" if mode == "24h" else "once", created_by=callback.from_user.id, expires_at=expires)
    await state.clear()
    await safe_edit(callback, f"✅ <b>تم تفعيل البونص الخاص</b>\n\nTelegram ID: <code>{tg}</code>\nالنسبة: <b>{_fmt(pct)}%</b>\nالمدة: <b>{_special_time(row)}</b>", reply_markup=_special_home_kb())


def _parse_expiry(raw: str) -> datetime:
    value = str(raw or "").strip().translate(_NUM_TRANSLATION).lower().replace("،", ".")
    now = datetime.now(timezone.utc)
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(h|hr|hrs|ساعة|ساعات|س)?", value)
    if m:
        hours = float(m.group(1))
        if not (0 < hours <= 24*365): raise ValueError("المدة يجب أن تكون أكبر من صفر وأقل من سنة.")
        return now + timedelta(hours=hours)
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(d|day|days|يوم|ايام|أيام)", value)
    if m:
        days = float(m.group(1))
        if not (0 < days <= 365): raise ValueError("المدة يجب أن تكون أكبر من صفر وأقل من سنة.")
        return now + timedelta(days=days)
    normalized = value.replace("/", "-")
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            dt = datetime.strptime(normalized, fmt).replace(tzinfo=_DAMASCUS).astimezone(timezone.utc)
            if dt <= now: raise ValueError("وقت الانتهاء يجب أن يكون في المستقبل.")
            return dt
        except ValueError as exc:
            if "المستقبل" in str(exc): raise
    raise ValueError("صيغة المدة غير صحيحة. استخدم 6h أو 3d أو تاريخاً مثل 2026-10-20 18:30")


@router.message(BonusAdminStates.special_duration, F.text)
async def special_duration(message: Message, state: FSMContext, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data()
    try:
        tg = int(data["special_tg"]); pct = Decimal(str(data["special_pct"])); exp = _parse_expiry(message.text or "")
        row = await finance_rules.set_special(tg, pct, "timed", created_by=message.from_user.id, expires_at=exp)
    except Exception as exc:
        await message.answer(f"❌ {html.escape(str(exc)[:300])}"); return
    await state.clear()
    await message.answer(f"✅ تم تفعيل البونص الخاص بنجاح.\n\nTelegram ID: <code>{tg}</code>\nالنسبة: <b>{_fmt(pct)}%</b>\nالمدة: <b>{_special_time(row)}</b>", reply_markup=_special_home_kb())


@router.callback_query(F.data == "admin:special_bonus_list")
async def special_list(callback: CallbackQuery, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    rows = await finance_rules.list_active_specials(50)
    if not rows:
        await safe_edit(callback, "📋 لا يوجد أي بونص خاص نشط حاليًا.", reply_markup=_special_home_kb()); return
    lines = ["📋 <b>البونصات الخاصة النشطة</b>", "━━━━━━━━━━━━━━", ""]
    kb = []
    for r in rows:
        uname = f"@{str(r.get('username') or '').lstrip('@')}" if r.get("username") else (r.get("first_name") or "-")
        lines += [f"🎁 <b>#{int(r['id'])}</b> — {html.escape(str(uname))}", f"ID: <code>{int(r['telegram_id'])}</code> | النسبة: <b>{_fmt(r['pct'])}%</b>", f"المدة: {_special_time(r)} | الاستخدامات: <b>{int(r.get('use_count') or 0)}</b>", ""]
        kb.append([_btn(f"🔎 إدارة #{int(r['id'])}", f"admin:special_bonus_view:{int(r['id'])}")])
    kb.append([_btn("⬅️ رجوع", "admin:special_bonus")])
    await safe_edit(callback, "\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data.startswith("admin:special_bonus_view:"))
async def special_view(callback: CallbackQuery, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    bonus_id = int(str(callback.data).rsplit(":",1)[-1]); row = await finance_rules.get_special(bonus_id)
    if not row:
        await safe_edit(callback, "❌ سجل البونص غير موجود.", reply_markup=_special_home_kb()); return
    labels = {"active":"✅ نشط","used":"✅ تم استخدامه","expired":"⌛ منتهي","cancelled":"⛔ ملغى"}
    started = row["starts_at"]
    if getattr(started,"tzinfo",None) is None: started=started.replace(tzinfo=timezone.utc)
    text = f"🎁 <b>تفاصيل البونص الخاص</b>\n\nالسجل: <code>#{bonus_id}</code>\nTelegram ID: <code>{int(row['telegram_id'])}</code>\nالنسبة: <b>{_fmt(row['pct'])}%</b>\nالحالة: <b>{labels.get(str(row['status']),str(row['status']))}</b>\nالمدة: <b>{_special_time(row)}</b>\nبدأ: <code>{started.astimezone(_DAMASCUS).strftime('%Y-%m-%d %H:%M')}</code>\nعدد الاستخدامات: <b>{int(row.get('use_count') or 0)}</b>"
    kb=[]
    if str(row.get("status"))=="active":
        kb += [[_btn("✏️ تعديل لهذا المستخدم", f"admin:special_bonus_edit:{int(row['telegram_id'])}")], [_btn("⛔ إلغاء البونص", f"admin:special_bonus_cancel_confirm:{bonus_id}")]]
    kb.append([_btn("⬅️ القائمة", "admin:special_bonus_list")])
    await safe_edit(callback, text, reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))


@router.callback_query(F.data.startswith("admin:special_bonus_edit:"))
async def special_edit(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    tg = int(str(callback.data).rsplit(":",1)[-1])
    await state.set_state(BonusAdminStates.special_pct); await state.set_data({"special_tg":tg})
    await safe_edit(callback, f"✏️ تعديل البونص للمستخدم <code>{tg}</code>\n\nأرسل النسبة الجديدة:")


@router.callback_query(F.data.startswith("admin:special_bonus_cancel_confirm:"))
async def special_cancel_confirm(callback: CallbackQuery, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    bonus_id=int(str(callback.data).rsplit(":",1)[-1])
    await safe_edit(callback, f"⚠️ هل تريد إلغاء البونص الخاص رقم <code>#{bonus_id}</code>؟", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("✅ نعم، إلغاء",f"admin:special_bonus_cancel:{bonus_id}")],[_btn("⬅️ رجوع",f"admin:special_bonus_view:{bonus_id}")]]))


@router.callback_query(F.data.startswith("admin:special_bonus_cancel:"))
async def special_cancel(callback: CallbackQuery, settings: Settings, finance_rules: FinanceRulesService) -> None:
    if not _admin(callback.from_user.id, settings): return
    bonus_id=int(str(callback.data).rsplit(":",1)[-1]); ok=await finance_rules.cancel_special(bonus_id,callback.from_user.id)
    await safe_edit(callback, "✅ تم إلغاء البونص الخاص." if ok else "⚠️ البونص غير نشط أو تمت معالجته مسبقًا.", reply_markup=_special_home_kb())
