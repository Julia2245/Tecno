from __future__ import annotations

import html
from decimal import Decimal
from typing import Any

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from app.config import Settings
from app.core.syriatel import parse_syriatel_cash_codes
from app.core.ui import safe_edit
from app.providers.binance import BinanceDepositClient
from app.providers.payment import PaymentProviderManager
from app.services.ichancy_accounts import IchancyAccountsService
from app.services.runtime_settings import RuntimeSettingsService

router = Router(name="admin_wallet")


def _admin(user_id: int, settings: Settings) -> bool:
    return user_id in settings.super_admin_ids


def _kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📲 محفظة سيرياتيل كاش", callback_data="admin:wallet:syriatel"),
            InlineKeyboardButton(text="💳 محفظة شام كاش", callback_data="admin:wallet:sham"),
        ],
        [
            InlineKeyboardButton(text="🟡 رصيد Binance USDT", callback_data="admin:wallet:binance"),
            InlineKeyboardButton(text="💼 رصيد الكاشيرة", callback_data="admin:wallet:ichancy_agent"),
        ],
        [InlineKeyboardButton(text="💸 حوالات يدوية", callback_data="admin:manual_transfers")],
        [InlineKeyboardButton(text="⬅️ رجوع", callback_data="admin:home")],
    ])


def _detail_kb(kind: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 تحديث الرصيد", callback_data=f"admin:wallet:{kind}")],
        [InlineKeyboardButton(text="⬅️ رجوع لمحفظة الأدمن", callback_data="admin:wallet")],
    ])


def _fmt(value: object) -> str:
    try:
        number = Decimal(str(value).replace(",", "").strip())
        if number == number.to_integral_value():
            return f"{int(number):,}"
        return f"{number:,.2f}"
    except Exception:
        return html.escape(str(value or "-"))


def _extract_ichancy_wallets(resp: dict | None) -> list[dict]:
    result = (resp or {}).get("result")
    if isinstance(result, list):
        return [dict(item) for item in result if isinstance(item, dict)]
    if isinstance(result, dict):
        records = result.get("records")
        if isinstance(records, list):
            return [dict(item) for item in records if isinstance(item, dict)]
        return [dict(result)]
    return []


def _format_ichancy_wallets(resp: dict | None, preferred_currency: str = "") -> str:
    wallets = _extract_ichancy_wallets(resp)
    if not wallets:
        return "💼 <b>رصيد الكاشيرة على Ichancy</b>\n━━━━━━━━━━━━━━\n\n⚠️ لم يتم العثور على محافظ للوكيل."
    preferred = str(preferred_currency or "").upper().strip()
    wallets.sort(key=lambda item: 0 if str(item.get("currencyCode") or "").upper() == preferred else 1)
    lines = ["💼 <b>رصيد الكاشيرة على Ichancy</b>", "━━━━━━━━━━━━━━", ""]
    for idx, item in enumerate(wallets, 1):
        cur = html.escape(str(item.get("currencyCode") or item.get("currency") or "-"))
        name = html.escape(str(item.get("currencyName") or "").strip())
        title = f"<b>المحفظة #{idx} - {cur}</b>"
        if name:
            title += f" <code>{name}</code>"
        lines.extend([title, f"🏦 الرصيد: <b>{_fmt(item.get('balance'))}</b>", ""])
    return "\n".join(lines).rstrip()


async def _syriatel_account_map(provider: Any) -> dict[str, tuple[str, str]]:
    """Best-effort display mapping only; balance reads never depend on this."""
    mapping: dict[str, tuple[str, str]] = {}
    try:
        payload = await provider.list_accounts()
        items = ((payload.get("data") or {}).get("syriatel") or []) if isinstance(payload, dict) else []
        for item in items if isinstance(items, list) else []:
            if not isinstance(item, dict):
                continue
            gsm = str(item.get("gsm") or "").strip()
            cash = str(item.get("cash_code") or "").strip()
            for value in (gsm, cash):
                if value:
                    mapping[value] = (gsm, cash)
    except Exception:
        pass
    return mapping


@router.callback_query(F.data == "admin:wallet")
async def admin_wallet(
    callback: CallbackQuery,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    payment_providers: PaymentProviderManager,
    ichancy_accounts: IchancyAccountsService,
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    codes = parse_syriatel_cash_codes(runtime_settings.get("deposit.syriatel.codes", ""))
    sham_syp = str(runtime_settings.get("deposit.sham.address_syp", "") or "").strip()
    sham_usd = str(runtime_settings.get("deposit.sham.address_usd", "") or "").strip()
    cashier = await ichancy_accounts.active_cashier()
    provider = payment_providers.active()
    provider_label = html.escape(str(getattr(provider, "provider_label", "API")))
    text = (
        "👛 <b>محفظة الأدمن</b>\n"
        "━━━━━━━━━━━━━━\n\n"
        "اختر المحفظة التي تريد عرض رصيدها من حسابات الشحن المخزنة.\n\n"
        f"📲 سيرياتيل كاش: <code>{len(codes)}</code> كود مخزن\n"
        f"💳 شام كاش ليرة: <code>{'مضبوط' if sham_syp else 'غير مضبوط'}</code>\n"
        f"💵 شام كاش دولار: <code>{'مضبوط' if sham_usd else 'غير مضبوط'}</code>\n"
        f"💼 كاشيرة Ichancy: <code>{'متاحة' if cashier is not None else 'غير مضبوطة'}</code>\n\n"
        f"يتم جلب أرصدة سيرياتيل وشام كاش عبر {provider_label}، ورصيد الكاشيرة عبر Ichancy API."
    )
    await safe_edit(callback, text, reply_markup=_kb())


@router.callback_query(F.data == "admin:wallet:ichancy_agent")
async def admin_wallet_ichancy(
    callback: CallbackQuery,
    settings: Settings,
    ichancy_accounts: IchancyAccountsService,
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    try:
        cashier, resp = await ichancy_accounts.active_cashier_wallets()
        if cashier is None:
            text = (
                "💼 <b>رصيد الكاشيرة على Ichancy</b>\n"
                "━━━━━━━━━━━━━━\n\n⚠️ لا توجد كاشيرة iChancy نشطة حالياً."
            )
        else:
            text = _format_ichancy_wallets(resp, cashier.currency)
    except Exception as exc:
        text = (
            "💼 <b>رصيد الكاشيرة على Ichancy</b>\n"
            "━━━━━━━━━━━━━━\n\n"
            "⚠️ تعذر جلب رصيد الكاشيرة حالياً.\n"
            f"<code>{html.escape(str(exc))}</code>"
        )
    await safe_edit(callback, text, reply_markup=_detail_kb("ichancy_agent"))


@router.callback_query(F.data == "admin:wallet:syriatel")
async def admin_wallet_syriatel(
    callback: CallbackQuery,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    payment_providers: PaymentProviderManager,
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    codes = parse_syriatel_cash_codes(runtime_settings.get("deposit.syriatel.codes", ""))
    if not codes:
        await safe_edit(
            callback,
            "📲 <b>محفظة سيرياتيل كاش</b>\n━━━━━━━━━━━━━━\n\n⚠️ لا يوجد كود سيرياتيل كاش مخزن في إدارة الشحن.",
            reply_markup=_detail_kb("syriatel"),
        )
        return
    provider = payment_providers.active()  # Freeze one provider for this whole screen refresh.
    account_map = await _syriatel_account_map(provider)
    lines = ["📲 <b>محفظة سيرياتيل كاش</b>", "━━━━━━━━━━━━━━", ""]
    total = Decimal("0")
    ok_count = 0
    for idx, code in enumerate(codes, 1):
        try:
            actual, balance = await provider.syriatel_balance(code)
            ok_count += 1
            total += Decimal(str(balance))
            gsm, cash = account_map.get(code, account_map.get(str(actual), (str(actual), str(code))))
            gsm = gsm or str(actual) or str(code)
            cash = cash or str(code)
            lines.extend([
                f"<b>الحساب #{idx}</b>",
                f"📱 الرقم: <code>{html.escape(gsm)}</code>",
                f"🔑 كود الكاش: <code>{html.escape(cash)}</code>",
                f"💰 الرصيد: <b>{_fmt(balance)}</b> SYP",
                "",
            ])
        except Exception as exc:
            lines.extend([
                f"<b>الحساب #{idx}</b>",
                f"🔑 الكود/الرقم: <code>{html.escape(str(code))}</code>",
                f"⚠️ الحالة: {html.escape(str(exc))}",
                "",
            ])
    lines.extend([
        "━━━━━━━━━━━━━━",
        f"✅ الحسابات المقروءة: <code>{ok_count}/{len(codes)}</code>",
        f"💼 الإجمالي التقريبي: <b>{_fmt(total)}</b> SYP",
    ])
    await safe_edit(callback, "\n".join(lines), reply_markup=_detail_kb("syriatel"))


@router.callback_query(F.data == "admin:wallet:sham")
async def admin_wallet_sham(
    callback: CallbackQuery,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    payment_providers: PaymentProviderManager,
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    accounts: list[tuple[str, str]] = []
    syp = str(runtime_settings.get("deposit.sham.address_syp", "") or "").strip()
    usd = str(runtime_settings.get("deposit.sham.address_usd", "") or "").strip()
    if syp:
        accounts.append(("ليرة", syp))
    if usd and usd != syp:
        accounts.append(("دولار", usd))
    if not accounts:
        await safe_edit(
            callback,
            "💳 <b>محفظة شام كاش</b>\n━━━━━━━━━━━━━━\n\n⚠️ لا يوجد عنوان شام كاش مخزن في إدارة الشحن.",
            reply_markup=_detail_kb("sham"),
        )
        return
    provider = payment_providers.active()  # Freeze one provider for this whole screen refresh.
    totals: dict[str, Decimal] = {}
    ok_count = 0
    lines = ["💳 <b>محفظة شام كاش</b>", "━━━━━━━━━━━━━━", ""]
    for idx, (label, address) in enumerate(accounts, 1):
        lines.extend([f"<b>الحساب #{idx} - {label}</b>", f"🏷️ العنوان: <code>{html.escape(address)}</code>"])
        try:
            balances = await provider.shamcash_balances(address)
            ok_count += 1
        except Exception as exc:
            lines.extend([f"⚠️ الحالة: {html.escape(str(exc))}", ""])
            continue
        if not balances:
            lines.extend(["💰 لا توجد أرصدة ظاهرة لهذا الحساب.", ""])
            continue
        for item in balances:
            cur = str(item.get("currency") or "-").upper()
            raw = item.get("balance", 0)
            try:
                amount = Decimal(str(raw).replace(",", ""))
                totals[cur] = totals.get(cur, Decimal("0")) + amount
            except Exception:
                pass
            lines.append(f"💰 {html.escape(cur)}: <b>{_fmt(raw)}</b>")
        lines.append("")
    lines.extend(["━━━━━━━━━━━━━━", f"✅ الحسابات المقروءة: <code>{ok_count}/{len(accounts)}</code>"])
    if totals:
        lines.append("💼 <b>الإجمالي حسب العملة:</b>")
        for cur in sorted(totals):
            lines.append(f"• {html.escape(cur)}: <b>{_fmt(totals[cur])}</b>")
    await safe_edit(callback, "\n".join(lines), reply_markup=_detail_kb("sham"))


@router.callback_query(F.data == "admin:wallet:binance")
async def admin_wallet_binance(
    callback: CallbackQuery,
    settings: Settings,
    binance_client: BinanceDepositClient,
) -> None:
    if not _admin(callback.from_user.id, settings):
        return
    if not binance_client.configured:
        await safe_edit(
            callback,
            "🟡 <b>رصيد Binance USDT</b>\n━━━━━━━━━━━━━━\n\n"
            "⚠️ لم يتم ضبط Binance API Key و Secret Key بعد.\n"
            "اضبطها من إعدادات Binance في البوت.",
            reply_markup=_detail_kb("binance"),
        )
        return
    try:
        coin = await binance_client.get_coin_info("USDT")
    except Exception as exc:
        await safe_edit(
            callback,
            "🟡 <b>رصيد Binance USDT</b>\n━━━━━━━━━━━━━━\n\n"
            "❌ تعذر قراءة الرصيد من Binance.\n"
            f"<code>{html.escape(str(exc))}</code>",
            reply_markup=_detail_kb("binance"),
        )
        return

    def val(key: str) -> str:
        return html.escape(str(coin.get(key, "0") or "0"))

    trc_enabled = "غير ظاهر"
    bep_enabled = "غير ظاهر"
    for network in coin.get("networkList") or []:
        if not isinstance(network, dict):
            continue
        name = str(network.get("network") or "").upper()
        enabled = bool(network.get("depositEnable"))
        if name in {"TRX", "TRC20"}:
            trc_enabled = "مفعل" if enabled else "متوقف"
        if name in {"BSC", "BEP20"}:
            bep_enabled = "مفعل" if enabled else "متوقف"
    text = (
        "🟡 <b>رصيد Binance USDT</b>\n"
        "━━━━━━━━━━━━━━\n\n"
        f"💰 المتاح: <b>{val('free')}</b> USDT\n"
        f"🔒 المحجوز: <b>{val('locked')}</b> USDT\n"
        f"❄️ مجمد: <b>{val('freeze')}</b> USDT\n"
        f"📤 قيد السحب: <b>{val('withdrawing')}</b> USDT\n\n"
        f"🟢 إيداع TRC20: <b>{trc_enabled}</b>\n"
        f"🟡 إيداع BEP20: <b>{bep_enabled}</b>"
    )
    await safe_edit(callback, text, reply_markup=_detail_kb("binance"))
