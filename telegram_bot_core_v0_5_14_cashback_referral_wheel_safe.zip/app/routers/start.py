from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.emojis import LOADING
from app.keyboards.common import main_menu
from app.services.users import UserService
from app.services.deposits import DepositService
from app.services.finance_rules import FinanceRulesService
from app.services.rewards import ReferralService, WheelService

router = Router(name="start")


def _home_text(display_name: str) -> str:
    name = display_name or "البوت"
    return (
        f"<b>{name}</b>\n\n"
        "أهلاً بك 👋\n"
        "اختر الخدمة التي تريدها من القائمة أدناه."
    )


def _verification_text() -> str:
    return (
        f"{LOADING} <b>لديك عملية شحن قيد التحقق حالياً</b>\n\n"
        "انتظر نتيجة العملية الحالية. لا يمكن بدء عملية شحن ثانية قبل انتهاء التحقق."
    )


def _start_arg(message: Message) -> str:
    text = (message.text or "").strip()
    parts = text.split(maxsplit=1)
    return parts[1].strip() if len(parts) > 1 else ""


@router.message(CommandStart())
async def start_handler(
    message: Message,
    settings: Settings,
    user_service: UserService,
    deposit_service: DepositService,
    finance_rules: FinanceRulesService,
    wheel_service: WheelService,
    referral_service: ReferralService,
) -> None:
    if message.from_user is None:
        return

    user_id = int(message.from_user.id)
    arg = _start_arg(message)

    # Creation detection is atomic.  It is intentionally used for both the
    # reference-style first-touch referral rule and the once-ever free-wheel grant:
    # neither can be backfilled by opening a deep link later.
    _user, created = await user_service.sync_profile_with_created(message.from_user)
    if created:
        pool = referral_service.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await wheel_service.grant_new_user_free_entitlement(conn, user_id)
                if arg.isdigit():
                    referrer_id = int(arg)
                    if referrer_id != user_id:
                        await referral_service.attach_first_touch(conn, user_id, referrer_id)

    # The WebApp only animates/displays the wheel.  The authoritative award is
    # always calculated here; no prize coming from the URL/client is trusted.
    if arg.startswith("claim_wheel"):
        try:
            result = await wheel_service.claim(user_id)
            if result.ok:
                if result.prize > 0:
                    text = (
                        "🎉 <b>مبروك!</b>\n\n"
                        f"ربحت <code>{result.prize:,}</code> ل.س من عجلة الحظ.\n"
                        f"👛 رصيدك الحالي: <code>{result.balance:,}</code> ل.س"
                    )
                else:
                    text = "😔 للأسف، لم تربح جائزة في هذه اللفة.\nحظاً أوفر في المرة القادمة 🍀"
            else:
                text = result.message or "❌ تعذر استلام نتيجة عجلة الحظ."
        except Exception:
            text = "❌ حدث خطأ أثناء استلام جائزة عجلة الحظ. يرجى المحاولة لاحقاً."
        await message.answer(
            text,
            reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids),
        )
        return

    if user_id not in settings.super_admin_ids:
        try:
            welcome = await finance_rules.grant_welcome_if_eligible(user_id)
        except Exception:
            welcome = {"granted": False}
        if welcome.get("granted"):
            if welcome.get("mode") == "first_deposit":
                pct = welcome.get("bonus_pct", 0)
                await message.answer(
                    "🎁 مبروك\n"
                    f"حصلت على بونص بقيمة {pct:g}%، سيتم إضافته تلقائياً على أول عملية شحن ناجحة تقوم بها."
                )
            else:
                await message.answer(
                    "🎁 مبروك\n"
                    f"تمت إضافة بونص أول دخول إلى رصيدك بقيمة {int(welcome.get('amount') or 0):,} SYP\n"
                    f"👛 رصيدك الحالي: {int(welcome.get('balance') or 0):,} SYP"
                )

    if deposit_service.verification_in_progress(user_id):
        await message.answer(_verification_text())
        return
    await message.answer(
        _home_text(settings.bot_display_name),
        reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids),
    )


@router.message(Command("menu"))
async def menu_handler(message: Message, settings: Settings, deposit_service: DepositService) -> None:
    if message.from_user is None:
        return
    if deposit_service.verification_in_progress(message.from_user.id):
        await message.answer(_verification_text())
        return
    await message.answer(
        _home_text(settings.bot_display_name),
        reply_markup=main_menu(is_admin=message.from_user.id in settings.super_admin_ids),
    )


@router.callback_query(F.data == "core:home")
async def home_callback(callback: CallbackQuery, settings: Settings, deposit_service: DepositService) -> None:
    user_id = callback.from_user.id
    if deposit_service.verification_in_progress(user_id):
        await safe_edit(callback, _verification_text())
        return
    await safe_edit(
        callback,
        _home_text(settings.bot_display_name),
        reply_markup=main_menu(is_admin=user_id in settings.super_admin_ids),
    )
