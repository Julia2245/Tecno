from aiogram import Router

from . import admin, admin_wallet, admin_finance, admin_bonus, admin_ichancy, admin_rewards, deposits, errors, ichancy, performance, rewards, start, withdrawals


def build_root_router() -> Router:
    root = Router(name="root")
    root.include_router(start.router)
    root.include_router(performance.router)
    root.include_router(admin.router)
    root.include_router(admin_wallet.router)
    root.include_router(admin_finance.router)
    root.include_router(admin_bonus.router)
    root.include_router(admin_ichancy.router)
    root.include_router(admin_rewards.router)
    root.include_router(deposits.router)
    root.include_router(withdrawals.router)
    root.include_router(ichancy.router)
    root.include_router(rewards.router)
    # Register at the parent so failures from every child router are covered.
    root.errors.register(errors.global_error_handler)
    return root
