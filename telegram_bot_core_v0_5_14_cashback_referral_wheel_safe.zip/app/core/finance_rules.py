from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal


@dataclass(slots=True, frozen=True)
class DepositBonusDecision:
    pct: Decimal
    source: str
    special_bonus_id: int | None = None
    special_mode: str | None = None
    welcome_claim_id: int | None = None
