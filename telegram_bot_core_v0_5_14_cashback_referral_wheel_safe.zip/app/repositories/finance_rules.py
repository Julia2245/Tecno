from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID

import asyncpg

from app.core.db import Database


class FinanceRulesRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    @staticmethod
    def normalize_scope(method: str) -> str:
        method = str(method or "").strip().lower()
        if method.startswith("binance_"):
            return "binance"
        if method == "whish_money":
            return "whish"
        if method in {"syriatel", "sham_syp", "sham_usd"}:
            return method
        return method or "all"

    async def list_deposit_tiers(self) -> list[dict[str, Any]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM bot_core.deposit_bonus_tiers ORDER BY min_amount_input ASC,id ASC"
            )
        return [dict(r) for r in rows]

    async def list_withdraw_tiers(self) -> list[dict[str, Any]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM bot_core.withdraw_fee_tiers ORDER BY min_amount_wallet ASC,id ASC"
            )
        return [dict(r) for r in rows]

    @staticmethod
    def _tier_table(kind: str) -> str:
        if kind == "deposit":
            return "deposit_bonus_tiers"
        if kind == "withdraw":
            return "withdraw_fee_tiers"
        raise ValueError("نوع الفئة غير صالح")

    async def get_tier(self, kind: str, tier_id: int) -> dict[str, Any] | None:
        table = self._tier_table(kind)
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(f"SELECT * FROM bot_core.{table} WHERE id=$1", int(tier_id))
        return dict(row) if row else None

    async def save_tier(
        self,
        kind: str,
        minimum: Decimal | int,
        pct: Decimal,
        *,
        created_by: int,
        tier_id: int | None = None,
        method_scope: str = "all",
    ) -> int:
        if kind not in {"deposit", "withdraw"}:
            raise ValueError("نوع الفئة غير صالح")
        pct = Decimal(str(pct))
        if pct < 0 or pct > 100:
            raise ValueError("النسبة يجب أن تكون بين 0 و100")
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                if kind == "deposit":
                    minimum_int = int(minimum)
                    if Decimal(str(minimum)) != Decimal(minimum_int) or minimum_int <= 0:
                        raise ValueError("الحد الأدنى يجب أن يكون مبلغاً صحيحاً أكبر من صفر")
                    scope = str(method_scope or "all").strip().lower()
                    if scope not in {"all","syriatel","sham_syp","sham_usd","binance","whish"}:
                        raise ValueError("وسيلة الشحن غير صالحة")
                    duplicate = await conn.fetchval(
                        "SELECT id FROM bot_core.deposit_bonus_tiers WHERE min_amount_input=$1 AND method_scope=$2 AND ($3::bigint IS NULL OR id<>$3)",
                        minimum_int, scope, tier_id,
                    )
                    if duplicate:
                        raise ValueError("توجد فئة أخرى بنفس الحد الأدنى ووسيلة الشحن")
                    if tier_id is None:
                        row = await conn.fetchrow(
                            "INSERT INTO bot_core.deposit_bonus_tiers(min_amount_input,pct,method_scope,active,created_by) VALUES($1,$2,$3,TRUE,$4) RETURNING id",
                            minimum_int, pct, scope, created_by,
                        )
                    else:
                        row = await conn.fetchrow(
                            "UPDATE bot_core.deposit_bonus_tiers SET min_amount_input=$1,pct=$2,method_scope=$3,active=TRUE,updated_at=NOW() WHERE id=$4 RETURNING id",
                            minimum_int, pct, scope, tier_id,
                        )
                else:
                    minimum_int = int(minimum)
                    if minimum_int <= 0:
                        raise ValueError("الحد الأدنى يجب أن يكون أكبر من صفر")
                    duplicate = await conn.fetchval(
                        "SELECT id FROM bot_core.withdraw_fee_tiers WHERE min_amount_wallet=$1 AND ($2::bigint IS NULL OR id<>$2)",
                        minimum_int, tier_id,
                    )
                    if duplicate:
                        raise ValueError("توجد فئة أخرى بنفس الحد الأدنى")
                    if tier_id is None:
                        row = await conn.fetchrow(
                            "INSERT INTO bot_core.withdraw_fee_tiers(min_amount_wallet,pct,active,created_by) VALUES($1,$2,TRUE,$3) RETURNING id",
                            minimum_int, pct, created_by,
                        )
                    else:
                        row = await conn.fetchrow(
                            "UPDATE bot_core.withdraw_fee_tiers SET min_amount_wallet=$1,pct=$2,active=TRUE,updated_at=NOW() WHERE id=$3 RETURNING id",
                            minimum_int, pct, tier_id,
                        )
                if row is None:
                    raise ValueError("الفئة غير موجودة")
                return int(row["id"])

    async def delete_tier(self, kind: str, tier_id: int) -> None:
        table = self._tier_table(kind)
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            await conn.execute(f"DELETE FROM bot_core.{table} WHERE id=$1", int(tier_id))

    async def active_deposit_tier(
        self, conn: asyncpg.Connection, amount_input: Decimal, method: str
    ) -> asyncpg.Record | None:
        scope = self.normalize_scope(method)
        return await conn.fetchrow(
            """
            SELECT * FROM bot_core.deposit_bonus_tiers
            WHERE active=TRUE AND min_amount_input<=$1 AND method_scope IN ('all',$2)
            ORDER BY min_amount_input DESC,
                     CASE WHEN method_scope='all' THEN 0 ELSE 1 END DESC,
                     id DESC LIMIT 1
            """,
            Decimal(str(amount_input)), scope,
        )

    async def active_withdraw_tier(self, amount_wallet: int) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM bot_core.withdraw_fee_tiers WHERE active=TRUE AND min_amount_wallet<=$1 ORDER BY min_amount_wallet DESC,id DESC LIMIT 1",
                int(amount_wallet),
            )
        return dict(row) if row else None

    async def _expire_specials(self, conn: asyncpg.Connection, telegram_id: int | None = None) -> None:
        if telegram_id is None:
            await conn.execute(
                "UPDATE bot_core.user_special_deposit_bonuses SET status='expired',updated_at=NOW() WHERE status='active' AND mode='timed' AND expires_at IS NOT NULL AND expires_at<=NOW()"
            )
        else:
            await conn.execute(
                "UPDATE bot_core.user_special_deposit_bonuses SET status='expired',updated_at=NOW() WHERE telegram_id=$1 AND status='active' AND mode='timed' AND expires_at IS NOT NULL AND expires_at<=NOW()",
                int(telegram_id),
            )

    async def active_special_for_update(self, conn: asyncpg.Connection, telegram_id: int) -> asyncpg.Record | None:
        await self._expire_specials(conn, telegram_id)
        return await conn.fetchrow(
            """
            SELECT * FROM bot_core.user_special_deposit_bonuses
            WHERE telegram_id=$1 AND status='active' AND starts_at<=NOW()
              AND (mode='once' OR expires_at IS NULL OR expires_at>NOW())
            ORDER BY id DESC LIMIT 1 FOR UPDATE
            """,
            int(telegram_id),
        )

    async def pending_welcome_for_update(
        self, conn: asyncpg.Connection, telegram_id: int
    ) -> asyncpg.Record | None:
        return await conn.fetchrow(
            """
            SELECT * FROM bot_core.welcome_bonus_claims
            WHERE telegram_id=$1 AND claim_type='first_deposit' AND status='pending'
            ORDER BY id DESC LIMIT 1 FOR UPDATE
            """,
            int(telegram_id),
        )

    async def existing_welcome_claim_for_update(
        self, conn: asyncpg.Connection, telegram_id: int
    ) -> asyncpg.Record | None:
        return await conn.fetchrow(
            "SELECT * FROM bot_core.welcome_bonus_claims WHERE telegram_id=$1 FOR UPDATE",
            int(telegram_id),
        )

    async def create_welcome_claim(
        self,
        conn: asyncpg.Connection,
        *,
        telegram_id: int,
        claim_type: str,
        amount_syp: int,
        bonus_pct: Decimal,
        enabled_since: datetime,
    ) -> asyncpg.Record:
        status = "pending" if claim_type == "first_deposit" else "used"
        row = await conn.fetchrow(
            """
            INSERT INTO bot_core.welcome_bonus_claims(
                telegram_id,claim_type,status,amount_syp,bonus_pct,enabled_since,used_at
            ) VALUES($1,$2,$3,$4,$5,$6,CASE WHEN $3='used' THEN NOW() ELSE NULL END)
            RETURNING *
            """,
            int(telegram_id), str(claim_type), str(status), int(amount_syp),
            Decimal(str(bonus_pct)), enabled_since,
        )
        if row is None:
            raise ValueError("تعذر إنشاء استحقاق بونص أول دخول")
        return row

    async def consume_welcome_first_deposit(
        self,
        conn: asyncpg.Connection,
        *,
        claim_id: int,
        deposit_id: UUID,
        amount_syp: int,
    ) -> None:
        tag = await conn.execute(
            """
            UPDATE bot_core.welcome_bonus_claims
            SET amount_syp=$3,status='used',used_at=NOW(),deposit_id=$2
            WHERE id=$1 AND claim_type='first_deposit' AND status='pending'
            """,
            int(claim_id), deposit_id, int(amount_syp),
        )
        if not tag.endswith("1"):
            raise ValueError("بونص أول شحن لم يعد متاحاً")

    async def get_active_special(self, telegram_id: int) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await self.active_special_for_update(conn, telegram_id)
                return dict(row) if row else None

    async def set_special(
        self,
        telegram_id: int,
        pct: Decimal,
        mode: str,
        *,
        created_by: int,
        expires_at: datetime | None = None,
    ) -> dict[str, Any]:
        pct = Decimal(str(pct))
        if pct <= 0 or pct > 100:
            raise ValueError("نسبة البونص يجب أن تكون أكبر من 0 وحتى 100%.")
        mode = str(mode or "").lower()
        if mode not in {"once", "timed"}:
            raise ValueError("نوع البونص غير صالح.")
        if mode == "timed":
            if expires_at is None:
                raise ValueError("وقت انتهاء البونص مطلوب.")
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            if expires_at <= datetime.now(timezone.utc):
                raise ValueError("وقت انتهاء البونص يجب أن يكون في المستقبل.")
        else:
            expires_at = None
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                exists = await conn.fetchval("SELECT 1 FROM bot_core.users WHERE telegram_id=$1", int(telegram_id))
                if not exists:
                    raise ValueError("المستخدم غير موجود في البوت.")
                await conn.execute(
                    "UPDATE bot_core.user_special_deposit_bonuses SET status='cancelled',cancelled_at=NOW(),cancelled_by=$2,updated_at=NOW() WHERE telegram_id=$1 AND status='active'",
                    int(telegram_id), int(created_by),
                )
                row = await conn.fetchrow(
                    """
                    INSERT INTO bot_core.user_special_deposit_bonuses(
                        telegram_id,pct,mode,expires_at,status,created_by
                    ) VALUES($1,$2,$3,$4,'active',$5)
                    RETURNING *
                    """,
                    int(telegram_id), pct, mode, expires_at, int(created_by),
                )
                return dict(row)

    async def list_active_specials(self, limit: int = 50) -> list[dict[str, Any]]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._expire_specials(conn)
                rows = await conn.fetch(
                    """
                    SELECT b.*,u.username,u.first_name
                    FROM bot_core.user_special_deposit_bonuses b
                    LEFT JOIN bot_core.users u ON u.telegram_id=b.telegram_id
                    WHERE b.status='active'
                    ORDER BY b.id DESC LIMIT $1
                    """,
                    max(1, min(100, int(limit))),
                )
        return [dict(r) for r in rows]

    async def get_special(self, bonus_id: int) -> dict[str, Any] | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._expire_specials(conn)
                row = await conn.fetchrow(
                    """
                    SELECT b.*,u.username,u.first_name
                    FROM bot_core.user_special_deposit_bonuses b
                    LEFT JOIN bot_core.users u ON u.telegram_id=b.telegram_id
                    WHERE b.id=$1
                    """,
                    int(bonus_id),
                )
        return dict(row) if row else None

    async def cancel_special(self, bonus_id: int, cancelled_by: int) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            tag = await conn.execute(
                "UPDATE bot_core.user_special_deposit_bonuses SET status='cancelled',cancelled_at=NOW(),cancelled_by=$2,updated_at=NOW() WHERE id=$1 AND status='active'",
                int(bonus_id), int(cancelled_by),
            )
        return tag.endswith("1")

    async def consume_special(
        self,
        conn: asyncpg.Connection,
        *,
        bonus_id: int,
        mode: str,
        deposit_id: UUID,
    ) -> None:
        if mode == "once":
            tag = await conn.execute(
                """
                UPDATE bot_core.user_special_deposit_bonuses
                SET status='used',used_at=NOW(),used_deposit_id=$2,use_count=use_count+1,updated_at=NOW()
                WHERE id=$1 AND status='active'
                """,
                int(bonus_id), deposit_id,
            )
            if not tag.endswith("1"):
                raise ValueError("البونص الخاص لم يعد متاحاً")
        else:
            tag = await conn.execute(
                """
                UPDATE bot_core.user_special_deposit_bonuses
                SET used_at=NOW(),used_deposit_id=$2,use_count=use_count+1,updated_at=NOW()
                WHERE id=$1 AND status='active' AND (expires_at IS NULL OR expires_at>NOW())
                """,
                int(bonus_id), deposit_id,
            )
            if not tag.endswith("1"):
                raise ValueError("البونص الخاص انتهت صلاحيته")
