from __future__ import annotations

import json
from decimal import Decimal
from typing import Any, Mapping
from uuid import UUID, uuid4

import asyncpg

from app.core.db import Database
from app.core.deposits import DepositAlreadyProcessed, DepositAlreadyUsed, DepositNotFound, DepositRecord


class DepositRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def system_started_at(self):
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return await conn.fetchval(
                "SELECT started_at FROM bot_core.deposit_runtime WHERE singleton=TRUE"
            )

    async def get(self, deposit_id: UUID | str) -> DepositRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM bot_core.deposit_requests WHERE id=$1", UUID(str(deposit_id))
            )
        return self._record(row) if row else None

    async def get_by_request_key(self, request_key: str) -> DepositRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM bot_core.deposit_requests WHERE request_key=$1", request_key
            )
        return self._record(row) if row else None

    async def get_claimed(self, provider_scope: str, provider_tx: str) -> DepositRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT d.*
                FROM bot_core.deposit_tx_claims c
                JOIN bot_core.deposit_requests d ON d.id=c.deposit_id
                WHERE c.provider_scope=$1 AND c.provider_tx=$2
                """,
                provider_scope,
                provider_tx,
            )
        return self._record(row) if row else None

    async def is_reserved(self, provider_scope: str, provider_tx: str) -> bool:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            return bool(
                await conn.fetchval(
                    """
                    SELECT EXISTS(
                        SELECT 1 FROM bot_core.reserved_transaction_numbers
                        WHERE provider_scope=$1 AND provider_tx=$2
                    )
                    """,
                    provider_scope,
                    provider_tx,
                )
            )

    async def find_by_provider_tx(self, provider_tx: str, limit: int = 20) -> list[DepositRecord]:
        wanted = str(provider_tx or "").strip()
        if not wanted:
            return []
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.deposit_requests
                WHERE provider_tx=$1
                ORDER BY created_at DESC,id DESC LIMIT $2
                """,
                wanted, max(1, min(100, int(limit))),
            )
        return [self._record(row) for row in rows]

    async def list_successful_for_user(self, telegram_id: int, limit: int = 3) -> list[DepositRecord]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.deposit_requests
                WHERE telegram_id=$1 AND status='success'
                ORDER BY settled_at DESC NULLS LAST, created_at DESC, id DESC
                LIMIT $2
                """,
                int(telegram_id), max(1, min(20, int(limit))),
            )
        return [self._record(row) for row in rows]

    async def list_manual_pending(self, limit: int = 50) -> list[DepositRecord]:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM bot_core.deposit_requests
                WHERE status='manual_pending'
                ORDER BY created_at ASC, id ASC
                LIMIT $1
                """,
                max(1, min(100, int(limit))),
            )
        return [self._record(row) for row in rows]

    async def insert_request(
        self,
        conn: asyncpg.Connection,
        *,
        telegram_id: int,
        method: str,
        request_key: str | None,
        provider_scope: str | None,
        provider_tx: str | None,
        amount_input: Decimal,
        currency: str,
        rate: Decimal,
        bonus_pct: Decimal,
        bonus_source: str,
        base_credit_syp: int,
        bonus_credit_syp: int,
        total_credit_syp: int,
        status: str,
        target_ref: str | None,
        proof_file_id: str | None,
        provider_payload: Mapping[str, Any] | None = None,
    ) -> DepositRecord:
        deposit_id = uuid4()
        row = await conn.fetchrow(
            """
            INSERT INTO bot_core.deposit_requests (
                id, telegram_id, method, request_key, provider_scope, provider_tx,
                amount_input, currency, rate, bonus_pct, bonus_source,
                base_credit_syp, bonus_credit_syp, total_credit_syp,
                status, target_ref, proof_file_id, provider_payload
            )
            VALUES (
                $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18::jsonb
            )
            RETURNING *
            """,
            deposit_id,
            telegram_id,
            method,
            request_key,
            provider_scope,
            provider_tx,
            amount_input,
            currency,
            rate,
            bonus_pct,
            bonus_source,
            base_credit_syp,
            bonus_credit_syp,
            total_credit_syp,
            status,
            target_ref,
            proof_file_id,
            json.dumps(dict(provider_payload or {}), ensure_ascii=False, separators=(",", ":"), default=str),
        )
        await self.add_event(
            conn,
            deposit_id=deposit_id,
            event_type="created",
            actor_telegram_id=telegram_id,
            details={"status": status, "method": method},
        )
        return self._record(row)

    async def claim_provider_tx(
        self,
        conn: asyncpg.Connection,
        *,
        deposit: DepositRecord,
    ) -> None:
        if not deposit.provider_scope or not deposit.provider_tx:
            return

        reserved = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM bot_core.reserved_transaction_numbers
                WHERE provider_scope=$1 AND provider_tx=$2
            )
            """,
            deposit.provider_scope,
            deposit.provider_tx,
        )
        if reserved:
            raise DepositAlreadyUsed("provider transaction is reserved")

        claimed = await conn.fetchrow(
            """
            INSERT INTO bot_core.deposit_tx_claims(provider_scope, provider_tx, deposit_id)
            VALUES ($1,$2,$3)
            ON CONFLICT (provider_scope, provider_tx) DO NOTHING
            RETURNING deposit_id
            """,
            deposit.provider_scope,
            deposit.provider_tx,
            deposit.id,
        )
        if claimed is not None:
            return

        other = await conn.fetchrow(
            """
            SELECT d.id, d.telegram_id, d.status
            FROM bot_core.deposit_tx_claims c
            JOIN bot_core.deposit_requests d ON d.id=c.deposit_id
            WHERE c.provider_scope=$1 AND c.provider_tx=$2
            FOR UPDATE OF c
            """,
            deposit.provider_scope,
            deposit.provider_tx,
        )
        if other is None:
            raise DepositAlreadyUsed()
        if other["id"] == deposit.id:
            return
        raise DepositAlreadyUsed(
            deposit_id=other["id"],
            telegram_id=int(other["telegram_id"]),
            status=str(other["status"]),
        )

    async def lock(self, conn: asyncpg.Connection, deposit_id: UUID) -> DepositRecord:
        row = await conn.fetchrow(
            "SELECT * FROM bot_core.deposit_requests WHERE id=$1 FOR UPDATE", deposit_id
        )
        if row is None:
            raise DepositNotFound(str(deposit_id))
        return self._record(row)

    async def update_bonus_terms(
        self,
        conn: asyncpg.Connection,
        *,
        deposit_id: UUID,
        bonus_pct: Decimal,
        bonus_source: str,
        bonus_credit_syp: int,
    ) -> DepositRecord:
        row = await conn.fetchrow(
            """
            UPDATE bot_core.deposit_requests
            SET bonus_pct=$2, bonus_source=$3, bonus_credit_syp=$4,
                total_credit_syp=base_credit_syp+$4, updated_at=NOW()
            WHERE id=$1 AND status='manual_pending'
            RETURNING *
            """,
            deposit_id, bonus_pct, str(bonus_source), int(bonus_credit_syp),
        )
        if row is None:
            current = await self.lock(conn, deposit_id)
            raise DepositAlreadyProcessed(status=current.status)
        await self.add_event(
            conn, deposit_id=deposit_id, event_type="bonus_terms_refreshed",
            actor_telegram_id=None,
            details={"bonus_pct": str(bonus_pct), "bonus_source": str(bonus_source), "bonus_credit_syp": int(bonus_credit_syp)},
        )
        return self._record(row)

    async def mark_success(
        self,
        conn: asyncpg.Connection,
        *,
        deposit_id: UUID,
        wallet_operation_id: UUID,
        reviewed_by: int | None,
    ) -> DepositRecord:
        row = await conn.fetchrow(
            """
            UPDATE bot_core.deposit_requests
            SET status='success', wallet_operation_id=$2, reviewed_by=$3,
                updated_at=NOW(), settled_at=NOW()
            WHERE id=$1 AND status IN ('verifying','manual_pending')
            RETURNING *
            """,
            deposit_id,
            wallet_operation_id,
            reviewed_by,
        )
        if row is None:
            current = await self.lock(conn, deposit_id)
            raise DepositAlreadyProcessed(status=current.status)
        await self.add_event(
            conn,
            deposit_id=deposit_id,
            event_type="success",
            actor_telegram_id=reviewed_by,
            details={"wallet_operation_id": str(wallet_operation_id)},
        )
        return self._record(row)

    async def reject_manual(
        self,
        conn: asyncpg.Connection,
        *,
        deposit_id: UUID,
        admin_id: int,
        note: str,
    ) -> DepositRecord:
        current = await self.lock(conn, deposit_id)
        if current.status != "manual_pending":
            raise DepositAlreadyProcessed(status=current.status)
        row = await conn.fetchrow(
            """
            UPDATE bot_core.deposit_requests
            SET status='rejected', reviewed_by=$2, review_note=$3, updated_at=NOW()
            WHERE id=$1 AND status='manual_pending'
            RETURNING *
            """,
            deposit_id,
            admin_id,
            note[:1000],
        )
        if row is None:
            raise DepositAlreadyProcessed()
        await self.add_event(
            conn,
            deposit_id=deposit_id,
            event_type="rejected",
            actor_telegram_id=admin_id,
            details={"note": note[:1000]},
        )
        return self._record(row)

    async def add_event(
        self,
        conn: asyncpg.Connection,
        *,
        deposit_id: UUID,
        event_type: str,
        actor_telegram_id: int | None,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        await conn.execute(
            """
            INSERT INTO bot_core.deposit_events(deposit_id,event_type,actor_telegram_id,details)
            VALUES($1,$2,$3,$4::jsonb)
            """,
            deposit_id,
            event_type,
            actor_telegram_id,
            json.dumps(dict(details or {}), ensure_ascii=False, separators=(",", ":"), default=str),
        )

    @staticmethod
    def _record(row: asyncpg.Record) -> DepositRecord:
        return DepositRecord(
            id=row["id"],
            telegram_id=int(row["telegram_id"]),
            method=str(row["method"]),
            request_key=str(row["request_key"]) if row["request_key"] is not None else None,
            provider_scope=str(row["provider_scope"]) if row["provider_scope"] is not None else None,
            provider_tx=str(row["provider_tx"]) if row["provider_tx"] is not None else None,
            amount_input=Decimal(row["amount_input"]),
            currency=str(row["currency"]),
            rate=Decimal(row["rate"]),
            bonus_pct=Decimal(row["bonus_pct"]),
            bonus_source=str(row["bonus_source"]),
            base_credit_syp=int(row["base_credit_syp"]),
            bonus_credit_syp=int(row["bonus_credit_syp"]),
            total_credit_syp=int(row["total_credit_syp"]),
            status=str(row["status"]),
            target_ref=str(row["target_ref"]) if row["target_ref"] is not None else None,
            proof_file_id=str(row["proof_file_id"]) if row["proof_file_id"] is not None else None,
            wallet_operation_id=row["wallet_operation_id"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            settled_at=row["settled_at"],
            reviewed_by=int(row["reviewed_by"]) if row["reviewed_by"] is not None else None,
            review_note=str(row["review_note"]) if row["review_note"] is not None else None,
        )
