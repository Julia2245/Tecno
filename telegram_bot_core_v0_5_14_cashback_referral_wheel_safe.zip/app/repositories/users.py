from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from aiogram.types import User as TelegramUser

from app.core.db import Database


@dataclass(slots=True, frozen=True)
class UserRecord:
    telegram_id: int
    username: str | None
    first_name: str
    last_name: str | None
    language_code: str | None
    is_blocked: bool
    created_at: datetime
    updated_at: datetime


class UserRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def upsert_from_telegram(self, user: TelegramUser) -> UserRecord:
        record, _created = await self.upsert_from_telegram_with_created(user)
        return record

    async def upsert_from_telegram_with_created(self, user: TelegramUser) -> tuple[UserRecord, bool]:
        """Upsert profile and report first-ever creation without a race window."""
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    """
                    WITH ins AS (
                        INSERT INTO bot_core.users (
                            telegram_id, username, first_name, last_name, language_code, is_bot
                        ) VALUES ($1,$2,$3,$4,$5,$6)
                        ON CONFLICT (telegram_id) DO NOTHING
                        RETURNING telegram_id,username,first_name,last_name,language_code,is_blocked,created_at,updated_at,TRUE AS created
                    ), upd AS (
                        UPDATE bot_core.users SET
                            username=$2, first_name=$3, last_name=$4, language_code=$5, is_bot=$6, updated_at=NOW()
                        WHERE telegram_id=$1 AND NOT EXISTS (SELECT 1 FROM ins)
                        RETURNING telegram_id,username,first_name,last_name,language_code,is_blocked,created_at,updated_at,FALSE AS created
                    )
                    SELECT * FROM ins UNION ALL SELECT * FROM upd LIMIT 1
                    """,
                    user.id, user.username, user.first_name or "", user.last_name, user.language_code, user.is_bot,
                )
        data=dict(row); created=bool(data.pop("created"))
        return UserRecord(**data), created

    async def get(self, telegram_id: int) -> UserRecord | None:
        pool = self.db.require_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT telegram_id, username, first_name, last_name, language_code,
                       is_blocked, created_at, updated_at
                FROM bot_core.users
                WHERE telegram_id = $1
                """,
                telegram_id,
            )
        return UserRecord(**dict(row)) if row else None
