-- Repair successful bot-wallet deposit notifications queued by pre-split versions.
-- Only deposit success events are retargeted; withdrawal/iChancy events are untouched.
UPDATE bot_core.notification_outbox
SET target_key = 'notify.bot_deposits'
WHERE target_key = 'notify.bot_operations'
  AND event_key LIKE 'bot-deposit-success:%'
  AND status <> 'sent';
