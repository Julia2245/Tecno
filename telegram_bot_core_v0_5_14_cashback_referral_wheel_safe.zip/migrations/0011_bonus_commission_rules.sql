-- Deposit bonus and withdrawal commission rules.

CREATE TABLE IF NOT EXISTS bot_core.deposit_bonus_tiers (
    id BIGSERIAL PRIMARY KEY,
    min_amount_input BIGINT NOT NULL,
    pct NUMERIC(9,4) NOT NULL,
    method_scope TEXT NOT NULL DEFAULT 'all',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT deposit_bonus_tier_amount_positive CHECK (min_amount_input > 0),
    CONSTRAINT deposit_bonus_tier_pct_range CHECK (pct BETWEEN 0 AND 100),
    CONSTRAINT deposit_bonus_tier_scope_allowed CHECK (
        method_scope IN ('all','syriatel','sham_syp','sham_usd','binance','whish')
    ),
    UNIQUE(min_amount_input, method_scope)
);

CREATE TABLE IF NOT EXISTS bot_core.withdraw_fee_tiers (
    id BIGSERIAL PRIMARY KEY,
    min_amount_wallet BIGINT NOT NULL UNIQUE,
    pct NUMERIC(9,4) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT withdraw_fee_tier_amount_positive CHECK (min_amount_wallet > 0),
    CONSTRAINT withdraw_fee_tier_pct_range CHECK (pct BETWEEN 0 AND 100)
);

CREATE TABLE IF NOT EXISTS bot_core.user_special_deposit_bonuses (
    id BIGSERIAL PRIMARY KEY,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    pct NUMERIC(9,4) NOT NULL,
    mode TEXT NOT NULL,
    starts_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    status TEXT NOT NULL DEFAULT 'active',
    created_by BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    cancelled_at TIMESTAMPTZ,
    cancelled_by BIGINT,
    used_at TIMESTAMPTZ,
    used_deposit_id UUID REFERENCES bot_core.deposit_requests(id) ON DELETE SET NULL,
    use_count INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT special_bonus_pct_range CHECK (pct > 0 AND pct <= 100),
    CONSTRAINT special_bonus_mode_allowed CHECK (mode IN ('once','timed')),
    CONSTRAINT special_bonus_status_allowed CHECK (status IN ('active','used','expired','cancelled')),
    CONSTRAINT special_bonus_timed_expiry CHECK (
        (mode='once' AND expires_at IS NULL) OR (mode='timed' AND expires_at IS NOT NULL)
    )
);
CREATE INDEX IF NOT EXISTS idx_special_bonus_user_status
    ON bot_core.user_special_deposit_bonuses(telegram_id,status,id DESC);
CREATE INDEX IF NOT EXISTS idx_special_bonus_expiry
    ON bot_core.user_special_deposit_bonuses(status,expires_at,id);
CREATE UNIQUE INDEX IF NOT EXISTS ux_special_bonus_one_active_per_user
    ON bot_core.user_special_deposit_bonuses(telegram_id) WHERE status='active';

-- Reference-compatible first-entry bonus snapshot. A user can qualify only once;
-- first-deposit percentage is frozen when eligibility is granted.
CREATE TABLE IF NOT EXISTS bot_core.welcome_bonus_claims (
    id BIGSERIAL PRIMARY KEY,
    telegram_id BIGINT NOT NULL UNIQUE REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    claim_type TEXT NOT NULL,
    status TEXT NOT NULL,
    amount_syp BIGINT NOT NULL DEFAULT 0,
    bonus_pct NUMERIC(9,4) NOT NULL DEFAULT 0,
    enabled_since TIMESTAMPTZ NOT NULL,
    granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    used_at TIMESTAMPTZ,
    deposit_id UUID REFERENCES bot_core.deposit_requests(id) ON DELETE SET NULL,
    CONSTRAINT welcome_bonus_claim_type_allowed CHECK (claim_type IN ('instant','first_deposit')),
    CONSTRAINT welcome_bonus_status_allowed CHECK (status IN ('pending','used')),
    CONSTRAINT welcome_bonus_amount_nonnegative CHECK (amount_syp >= 0),
    CONSTRAINT welcome_bonus_pct_range CHECK (bonus_pct BETWEEN 0 AND 100),
    CONSTRAINT welcome_bonus_shape CHECK (
        (claim_type='instant' AND status='used' AND amount_syp >= 0 AND bonus_pct=0)
        OR
        (claim_type='first_deposit' AND amount_syp >= 0 AND bonus_pct > 0)
    )
);
CREATE INDEX IF NOT EXISTS idx_welcome_bonus_claims_status
    ON bot_core.welcome_bonus_claims(status,claim_type,granted_at);

-- Manual requests are created before an admin approves them. Their base amount,
-- provider identity and exchange rate stay immutable, but the bonus decision is
-- deliberately refreshed at approval time so time-limited/user-specific rules
-- behave exactly like automatic successful deposits.
CREATE OR REPLACE FUNCTION bot_core.guard_deposit_request_update()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    manual_bonus_refresh BOOLEAN;
BEGIN
    manual_bonus_refresh := (
        OLD.status='manual_pending' AND NEW.status='manual_pending'
        AND OLD.wallet_operation_id IS NULL AND NEW.wallet_operation_id IS NULL
        AND NEW.base_credit_syp = OLD.base_credit_syp
        AND NEW.total_credit_syp = NEW.base_credit_syp + NEW.bonus_credit_syp
    );

    IF NEW.id <> OLD.id
       OR NEW.telegram_id <> OLD.telegram_id
       OR NEW.method <> OLD.method
       OR NEW.request_key IS DISTINCT FROM OLD.request_key
       OR NEW.provider_scope IS DISTINCT FROM OLD.provider_scope
       OR NEW.provider_tx IS DISTINCT FROM OLD.provider_tx
       OR NEW.amount_input <> OLD.amount_input
       OR NEW.currency <> OLD.currency
       OR NEW.rate <> OLD.rate
       OR NEW.base_credit_syp <> OLD.base_credit_syp
       OR NEW.target_ref IS DISTINCT FROM OLD.target_ref
       OR NEW.proof_file_id IS DISTINCT FROM OLD.proof_file_id
       OR NEW.provider_payload <> OLD.provider_payload
       OR NEW.created_at <> OLD.created_at THEN
        RAISE EXCEPTION 'deposit identity/base financial terms are immutable';
    END IF;

    IF (NEW.bonus_pct <> OLD.bonus_pct
        OR NEW.bonus_source <> OLD.bonus_source
        OR NEW.bonus_credit_syp <> OLD.bonus_credit_syp
        OR NEW.total_credit_syp <> OLD.total_credit_syp)
       AND NOT manual_bonus_refresh THEN
        RAISE EXCEPTION 'deposit bonus terms are immutable outside manual approval refresh';
    END IF;

    IF OLD.status IN ('success', 'rejected') THEN
        RAISE EXCEPTION 'terminal deposit cannot be changed';
    END IF;

    IF OLD.status = 'manual_pending' AND NEW.status NOT IN ('manual_pending','success','rejected') THEN
        RAISE EXCEPTION 'manual deposit can only stay pending, be approved or rejected';
    END IF;

    IF OLD.status = 'verifying' AND NEW.status <> 'success' THEN
        RAISE EXCEPTION 'verified automatic deposit can only settle successfully';
    END IF;

    RETURN NEW;
END;
$$;
