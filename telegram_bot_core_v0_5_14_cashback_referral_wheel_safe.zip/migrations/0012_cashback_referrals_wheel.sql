-- reference-compatible cashback, referrals and daily/free wheel.

ALTER TABLE bot_core.users ADD COLUMN IF NOT EXISTS referrer_telegram_id BIGINT REFERENCES bot_core.users(telegram_id) ON DELETE SET NULL;
ALTER TABLE bot_core.users ADD COLUMN IF NOT EXISTS referral_status TEXT NOT NULL DEFAULT 'none';
ALTER TABLE bot_core.users ADD COLUMN IF NOT EXISTS referral_first_seen_at TIMESTAMPTZ;
ALTER TABLE bot_core.users ADD COLUMN IF NOT EXISTS referral_confirmed_at TIMESTAMPTZ;
ALTER TABLE bot_core.users DROP CONSTRAINT IF EXISTS users_referral_status_allowed;
ALTER TABLE bot_core.users ADD CONSTRAINT users_referral_status_allowed CHECK (referral_status IN ('none','pending','confirmed','cancelled'));
CREATE INDEX IF NOT EXISTS idx_users_referrer_status ON bot_core.users(referrer_telegram_id, referral_status, referral_confirmed_at DESC);

-- Tracks only real-deposit principal still present in the bot wallet. Bonuses and
-- every internal reward stay outside this number by design.
CREATE TABLE IF NOT EXISTS bot_core.cashback_wallet_principal (
    telegram_id BIGINT PRIMARY KEY REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    eligible_syp BIGINT NOT NULL DEFAULT 0 CHECK (eligible_syp >= 0),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS bot_core.cashback_wallet_holds (
    source_type TEXT NOT NULL,
    source_id UUID NOT NULL,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    amount_syp BIGINT NOT NULL CHECK (amount_syp >= 0),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','consumed','released')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at TIMESTAMPTZ,
    PRIMARY KEY(source_type, source_id)
);

CREATE TABLE IF NOT EXISTS bot_core.ichancy_cashback_allocations (
    job_id UUID PRIMARY KEY REFERENCES bot_core.ichancy_jobs(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    account_id UUID NOT NULL REFERENCES bot_core.ichancy_accounts(id) ON DELETE RESTRICT,
    operation_type TEXT NOT NULL CHECK (operation_type IN ('deposit','withdraw','retirement_withdraw')),
    amount_syp BIGINT NOT NULL CHECK (amount_syp > 0),
    eligible_amount_syp BIGINT NOT NULL DEFAULT 0 CHECK (eligible_amount_syp >= 0),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','success','released')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    settled_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_ichancy_cb_alloc_user_status ON bot_core.ichancy_cashback_allocations(telegram_id,status,created_at);
CREATE INDEX IF NOT EXISTS idx_ichancy_cb_alloc_account_status ON bot_core.ichancy_cashback_allocations(account_id,status,created_at);

CREATE TABLE IF NOT EXISTS bot_core.cashback_cycles (
    id BIGSERIAL PRIMARY KEY,
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','preparing','ready','empty','distributing','distributed','skipped')),
    cycle_days INTEGER NOT NULL CHECK (cycle_days IN (1,7)),
    cycle_start TIMESTAMPTZ NOT NULL,
    cycle_end TIMESTAMPTZ NOT NULL,
    pct NUMERIC(9,4) NOT NULL DEFAULT 0 CHECK (pct BETWEEN 0 AND 100),
    min_turnover BIGINT NOT NULL DEFAULT 200000 CHECK (min_turnover >= 0),
    eligible_count INTEGER NOT NULL DEFAULT 0,
    failed_count INTEGER NOT NULL DEFAULT 0,
    total_loss_syp BIGINT NOT NULL DEFAULT 0,
    total_due_syp BIGINT NOT NULL DEFAULT 0,
    paid_count INTEGER NOT NULL DEFAULT 0,
    total_paid_syp BIGINT NOT NULL DEFAULT 0,
    skipped_eligible_count INTEGER NOT NULL DEFAULT 0,
    skipped_amount_syp BIGINT NOT NULL DEFAULT 0,
    prepared_at TIMESTAMPTZ,
    distributed_at TIMESTAMPTZ,
    distributed_by BIGINT,
    skipped_at TIMESTAMPTZ,
    skipped_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (cycle_end > cycle_start)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_cashback_one_open_cycle ON bot_core.cashback_cycles((1)) WHERE status IN ('open','preparing');
CREATE INDEX IF NOT EXISTS idx_cashback_cycles_status_end ON bot_core.cashback_cycles(status,cycle_end);

CREATE TABLE IF NOT EXISTS bot_core.cashback_cycle_users (
    cycle_id BIGINT NOT NULL REFERENCES bot_core.cashback_cycles(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    start_principal_syp BIGINT NOT NULL DEFAULT 0,
    eligible_deposits_syp BIGINT NOT NULL DEFAULT 0,
    eligible_withdrawals_syp BIGINT NOT NULL DEFAULT 0,
    end_balance_syp BIGINT NOT NULL DEFAULT 0,
    net_loss_syp BIGINT NOT NULL DEFAULT 0,
    cashback_syp BIGINT NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','ready','not_eligible','failed','paid','skipped')),
    attempts INTEGER NOT NULL DEFAULT 0,
    error_message TEXT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    prepared_at TIMESTAMPTZ,
    paid_at TIMESTAMPTZ,
    wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE SET NULL,
    PRIMARY KEY(cycle_id,telegram_id)
);
CREATE INDEX IF NOT EXISTS idx_cashback_cycle_users_status ON bot_core.cashback_cycle_users(cycle_id,status,telegram_id);

CREATE TABLE IF NOT EXISTS bot_core.cashback_principal_settlements (
    cycle_id BIGINT NOT NULL REFERENCES bot_core.cashback_cycles(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    account_id UUID NOT NULL REFERENCES bot_core.ichancy_accounts(id) ON DELETE RESTRICT,
    amount_syp BIGINT NOT NULL DEFAULT 0 CHECK (amount_syp >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY(cycle_id,telegram_id,account_id)
);

CREATE TABLE IF NOT EXISTS bot_core.referral_cycles (
    id BIGSERIAL PRIMARY KEY,
    mode TEXT NOT NULL CHECK (mode IN ('direct','hierarchical')),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','preparing','ready','empty','distributing','distributed','skipped')),
    duration_days INTEGER NOT NULL CHECK (duration_days >= 1),
    cycle_start TIMESTAMPTZ NOT NULL,
    cycle_end TIMESTAMPTZ NOT NULL,
    direct_pct NUMERIC(9,4) NOT NULL DEFAULT 0 CHECK (direct_pct BETWEEN 0 AND 100),
    level1_pct NUMERIC(9,4) NOT NULL DEFAULT 0 CHECK (level1_pct BETWEEN 0 AND 100),
    level2_pct NUMERIC(9,4) NOT NULL DEFAULT 0 CHECK (level2_pct BETWEEN 0 AND 100),
    level3_pct NUMERIC(9,4) NOT NULL DEFAULT 0 CHECK (level3_pct BETWEEN 0 AND 100),
    min_active_refs INTEGER NOT NULL DEFAULT 3 CHECK (min_active_refs >= 0),
    active_min_deposit BIGINT NOT NULL DEFAULT 0 CHECK (active_min_deposit >= 0),
    eligible_count INTEGER NOT NULL DEFAULT 0,
    total_amount_syp BIGINT NOT NULL DEFAULT 0,
    paid_count INTEGER NOT NULL DEFAULT 0,
    total_paid_syp BIGINT NOT NULL DEFAULT 0,
    skipped_count INTEGER NOT NULL DEFAULT 0,
    skipped_eligible_count INTEGER NOT NULL DEFAULT 0,
    skipped_amount_syp BIGINT NOT NULL DEFAULT 0,
    prepared_at TIMESTAMPTZ,
    distributed_at TIMESTAMPTZ,
    distributed_by BIGINT,
    skipped_at TIMESTAMPTZ,
    skipped_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (cycle_end > cycle_start)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_referral_one_open_cycle ON bot_core.referral_cycles((1)) WHERE status IN ('active','preparing');
CREATE INDEX IF NOT EXISTS idx_referral_cycles_status_end ON bot_core.referral_cycles(status,cycle_end);

CREATE TABLE IF NOT EXISTS bot_core.referral_loss_snapshots (
    cycle_id BIGINT NOT NULL REFERENCES bot_core.referral_cycles(id) ON DELETE CASCADE,
    referred_telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    window_start TIMESTAMPTZ NOT NULL,
    window_end TIMESTAMPTZ NOT NULL,
    net_result_syp BIGINT NOT NULL DEFAULT 0,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    status TEXT NOT NULL DEFAULT 'ready' CHECK (status IN ('ready','failed')),
    prepared_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY(cycle_id,referred_telegram_id)
);

CREATE TABLE IF NOT EXISTS bot_core.referral_earnings (
    id BIGSERIAL PRIMARY KEY,
    cycle_id BIGINT NOT NULL REFERENCES bot_core.referral_cycles(id) ON DELETE CASCADE,
    referrer_telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    level INTEGER NOT NULL CHECK (level BETWEEN 1 AND 3),
    pct NUMERIC(9,4) NOT NULL CHECK (pct BETWEEN 0 AND 100),
    base_net_loss_syp BIGINT NOT NULL DEFAULT 0,
    amount_syp BIGINT NOT NULL CHECK (amount_syp >= 0),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','skipped')),
    distributed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(cycle_id,referrer_telegram_id,level)
);
CREATE TABLE IF NOT EXISTS bot_core.referral_cycle_payouts (
    cycle_id BIGINT NOT NULL REFERENCES bot_core.referral_cycles(id) ON DELETE CASCADE,
    referrer_telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    amount_syp BIGINT NOT NULL CHECK (amount_syp >= 0),
    active_referrals INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','skipped')),
    paid_at TIMESTAMPTZ,
    wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE SET NULL,
    PRIMARY KEY(cycle_id,referrer_telegram_id)
);

CREATE TABLE IF NOT EXISTS bot_core.referral_fixed_entitlements (
    referred_telegram_id BIGINT PRIMARY KEY REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    referrer_telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    amount_syp BIGINT NOT NULL CHECK (amount_syp >= 0),
    trigger_type TEXT NOT NULL CHECK (trigger_type IN ('verify','first_deposit')),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','cancelled')),
    deposit_id UUID REFERENCES bot_core.deposit_requests(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    eligible_at TIMESTAMPTZ,
    paid_at TIMESTAMPTZ,
    cancelled_at TIMESTAMPTZ,
    cancel_reason TEXT
);
CREATE TABLE IF NOT EXISTS bot_core.referral_fixed_rewards (
    referred_telegram_id BIGINT PRIMARY KEY REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    referrer_telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    amount_syp BIGINT NOT NULL CHECK (amount_syp > 0),
    trigger_type TEXT NOT NULL CHECK (trigger_type IN ('verify','first_deposit')),
    deposit_id UUID REFERENCES bot_core.deposit_requests(id) ON DELETE SET NULL,
    paid_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_referral_fixed_rewards_referrer ON bot_core.referral_fixed_rewards(referrer_telegram_id,paid_at DESC);

CREATE TABLE IF NOT EXISTS bot_core.wheel_claims (
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    claim_day DATE NOT NULL,
    prize_syp BIGINT NOT NULL DEFAULT 0 CHECK (prize_syp >= 0),
    claimed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE SET NULL,
    PRIMARY KEY(telegram_id,claim_day)
);
CREATE TABLE IF NOT EXISTS bot_core.wheel_free_entitlements (
    telegram_id BIGINT PRIMARY KEY REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    eligible_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    claimed_at TIMESTAMPTZ,
    prize_syp BIGINT NOT NULL DEFAULT 0 CHECK (prize_syp >= 0),
    wallet_operation_id UUID REFERENCES bot_core.wallet_operations(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_wheel_claims_day ON bot_core.wheel_claims(claim_day,telegram_id);

CREATE TABLE IF NOT EXISTS bot_core.cashback_principal_holds (
    cycle_id BIGINT NOT NULL REFERENCES bot_core.cashback_cycles(id) ON DELETE CASCADE,
    telegram_id BIGINT NOT NULL REFERENCES bot_core.users(telegram_id) ON DELETE CASCADE,
    account_id UUID NOT NULL REFERENCES bot_core.ichancy_accounts(id) ON DELETE RESTRICT,
    amount_syp BIGINT NOT NULL DEFAULT 0 CHECK (amount_syp >= 0),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','resolved')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    PRIMARY KEY(cycle_id,telegram_id,account_id)
);
