from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_ichancy_withdraw_has_two_stage_live_balance_protection() -> None:
    router = read("app/routers/ichancy.py")
    jobs = read("app/services/ichancy_jobs.py")
    assert "precheck_withdraw_balance" in router
    assert "جاري التحقق من رصيد حسابك" in router
    assert "جاري سحب رصيد حسابك" in router
    assert "precheck_withdraw_balance" in jobs
    # The worker still performs the authoritative pre-POST snapshot/read.
    assert "_read_balances" in jobs
    assert "mark_financial_post_started" in jobs


def test_bot_operation_channels_are_split_with_final_deposit_and_live_withdraw_request() -> None:
    deposits = read("app/services/deposits.py")
    withdrawals_router = read("app/routers/withdrawals.py")
    withdrawals_repo = read("app/repositories/withdrawals.py")
    runtime = read("app/services/runtime_settings.py")
    assert 'target_key="notify.bot_deposits"' in deposits
    assert 'runtime_settings.get("notify.bot_withdrawals")' in withdrawals_router
    assert "save_channel_message" in withdrawals_router
    # The withdrawal channel is the live request card; success edits that same
    # message instead of queuing a duplicate success post to the channel.
    assert "notify.bot_withdrawals" not in withdrawals_repo
    assert '"notify.bot_deposits": None' in runtime
    assert '"notify.bot_withdrawals": None' in runtime


def test_per_method_deposit_minimums_are_runtime_editable() -> None:
    source = read("app/services/deposits.py")
    for key in (
        "deposit.syriatel.min",
        "deposit.sham_syp.min",
        "deposit.sham_usd.min",
        "deposit.whish_money.min",
        "deposit.binance_trc20.min",
        "deposit.binance_bep20.min",
    ):
        assert key in source


def test_admin_setting_flow_updates_origin_message_and_cleans_cancel_state() -> None:
    source = read("app/routers/admin_finance.py")
    assert 'origin_message_id=callback.message.message_id' in source
    assert 'await runtime_settings.set(key, value' in source
    assert 'message.bot.edit_message_text' in source
    assert 'F.data == "admin:setting:cancel"' in source
    assert 'await state.clear()' in source
    assert '_NUM_TRANSLATION' in source


def test_admin_withdraw_menu_has_method_pages_review_security_and_history() -> None:
    source = read("app/routers/admin_finance.py")
    for callback in (
        "admin:withdraws:pending",
        "admin:withdraws:review",
        "admin:withdraw:method:syriatel",
        "admin:withdraw:method:shamcash",
        "admin:withdraw:method:hawala",
        "admin:withdraw:method:usdt",
        "admin:withdraw:commission",
        "admin:withdraw:security",
        "admin:withdraws:history",
    ):
        assert callback in source


def test_custom_emoji_registry_matches_approved_ids() -> None:
    source = read("app/core/emojis.py")
    for emoji_id in (
        "5994683681220861528",
        "5996853812231413145",
        "5994366253072916034",
        "5994385322727709668",
        "5377548235709619284",
        "5321057299664480450",
        "5278560792998854087",
        "5454037226679718826",
        "5452010672130902785",
        "5454204635914981438",
        "5386367538735104399",
        "5884447890960552542",
        "5796205953913196373",
    ):
        assert emoji_id in source


def test_manual_deposit_request_stays_out_of_final_deposit_channel() -> None:
    router = read("app/routers/deposits.py")
    service = read("app/services/deposits.py")
    # Pending/manual review keeps Julia's dedicated review target (or admin DM
    # fallback); the bot-deposits channel is reserved for settled operations.
    assert "deposit_manual_review_chat_id" in router
    assert 'runtime_settings.get("notify.bot_deposits")' not in router
    assert 'await _send_manual_review_message(bot, chat_id, deposit)' in router
    assert 'target_key="notify.bot_deposits"' in service


def test_shamcash_source_is_normalized_before_provider_transfer() -> None:
    source = read("app/services/withdrawals.py")
    deposits = read("app/services/deposits.py")
    migration = read("migrations/0008_shamcash_address_cleanup.sql")
    assert "normalize_shamcash_address" in source
    assert "normalize_shamcash_address" in deposits
    assert "deposit.sham.address_syp" in migration
    assert "regexp_replace" in migration


def test_syriatel_withdraw_pin_is_runtime_editable_and_encrypted() -> None:
    admin = read("app/routers/admin_finance.py")
    service = read("app/services/withdrawals.py")
    main = read("app/main.py")
    assert 'admin:setting:withdraw.syriatel.pin' in admin
    assert 'PIN السحب:' in admin
    assert 'set_syriatel_pin' in service
    assert 'withdraw.syriatel.pin_enc' in service
    assert 'self.secret_cipher.encrypt(clean)' in service
    assert 'pin = self.syriatel_pin()' in service
    assert 'cipher,' in main


def test_withdraw_channel_is_actionable_and_same_message_is_persisted() -> None:
    router = read("app/routers/withdrawals.py")
    admin = read("app/routers/admin_finance.py")
    ui = read("app/core/withdrawal_admin_ui.py")
    migration = read("migrations/0009_withdraw_channel_manual_transfers.sql")
    assert 'runtime_settings.get("notify.bot_withdrawals")' in router
    assert "withdraw_actions(rec, include_back=False)" in router
    assert "save_channel_message" in router
    assert "channel_chat_id" in migration and "channel_message_id" in migration
    for callback in (
        "admin:withdraw:auto:",
        "admin:withdraw:paid:",
        "admin:withdraw:reject:",
        "admin:withdraw:notpaid:",
    ):
        assert callback in ui
    # Automatic execution follows the same provider-source selection + explicit
    # confirmation flow used by the reference bot before the one financial POST.
    for callback in ("admin:withdraw:pick:", "admin:withdraw:execute:", "admin:withdraw:back:", "wd:exec:"):
        assert callback in admin
    assert "select_source" in admin
    assert "_source_token" in admin
    assert "withdraw_source_balance" in admin
    assert "تأكيد التنفيذ الآن" in admin
    assert "_mark_withdraw_channel_processing" in admin
    assert "_sync_withdraw_channel" in admin


def test_withdraw_user_notifications_only_cover_confirmed_success_and_explicit_admin_reject() -> None:
    service = read("app/services/withdrawals.py")
    repo = read("app/repositories/withdrawals.py")
    assert "bot-withdraw-user-success:" in repo
    assert "bot-withdraw-user-rejected:" in service
    # Provider uncertainty only changes administrative state. It must not notify
    # the user as success/failure/rejection.
    uncertain = service[service.index("except ApiSyriaFinancialUncertain"):service.index("provider_ref =", service.index("except ApiSyriaFinancialUncertain"))]
    assert "mark_needs_review" in uncertain
    assert "outbox" not in uncertain
    assert "user_text" not in uncertain
    reject = service[service.index("async def reject_admin"):service.index("async def execute_auto")]
    assert "bot-withdraw-user-rejected:" in reject


def test_sham_withdraw_success_card_contains_name_and_real_provider_reference_fields() -> None:
    service = read("app/services/withdrawals.py")
    ui = read("app/core/withdrawal_admin_ui.py")
    api = read("app/providers/api_syria.py")
    assert "resolve_shamcash_outgoing_transfer" in service
    assert "shamcash_outgoing_snapshot" in service
    assert "اسم حساب شام كاش" in ui
    assert "رقم عملية شام كاش" in ui
    assert "transaction_no" in api and "tran_id" in api and "billcode" in api


def test_manual_transfers_match_julia_flow_and_are_durably_one_post() -> None:
    admin = read("app/routers/admin_finance.py")
    service = read("app/services/manual_transfers.py")
    repo = read("app/repositories/manual_transfers.py")
    api = read("app/providers/api_syria.py")
    migration = read("migrations/0009_withdraw_channel_manual_transfers.sql")
    for label in (
        "💸 <b>حوالات يدوية</b>",
        "➕ إرسال حوالة",
        "📋 سجل الحوالات",
        "💳 شام كاش",
        "📲 سيرياتيل كاش",
        "✅ تأكيد الإرسال",
        "❌ إلغاء",
    ):
        assert label in admin
    assert "source_options" in service
    assert "source_balance" in service
    assert "source_still_valid" in service
    assert "claim_intent" in service and "processing_new" in service
    assert "source_is_linked" in service
    # Julia manual Sham Cash transfers intentionally omit note entirely.
    assert "note=None" in service
    assert "if note is not None" in api
    assert "admin_manual_transfer_intents" in migration
    assert "admin_manual_transfers" in migration
    assert "immutable" in migration
    assert "ON CONFLICT(intent_key) DO NOTHING" in repo
    assert "recover_stale_processing" in repo


def test_manual_transfer_first_message_is_consumed_and_same_admin_card_updates() -> None:
    admin = read("app/routers/admin_finance.py")
    receiver = admin[admin.index("async def manual_transfer_receiver_input"):admin.index("async def manual_transfer_amount_input")]
    amount = admin[admin.index("async def manual_transfer_amount_input"):admin.index('@router.callback_query(F.data == "admin:send_transfer_cancel")')]
    for block in (receiver, amount):
        assert "await _delete_input(message)" in block
        assert "await _edit_origin(" in block
    assert "origin_message_id" in admin and "origin_chat_id" in admin


def test_transaction_search_is_read_only_and_matches_julia_sources() -> None:
    admin = read("app/routers/admin_finance.py")
    repo = read("app/repositories/deposits.py")
    block = admin[admin.index("def _tx_search_source_menu"):admin.index("def _bonus_manage", admin.index("def _tx_search_source_menu")) if "def _bonus_manage" in admin[admin.index("def _tx_search_source_menu"):] else len(admin)]
    assert "🔎 <b>البحث عن عملية</b>" in block
    assert "💳 فحص شام كاش" in block
    assert "📲 فحص سيرياتيل" in block
    assert "🗂 بحث في سجلات البوت" in block
    assert "find_shamcash" in block
    assert "find_syriatel" in block
    assert "find_by_provider_tx" in block
    assert "credit_in_transaction" not in block
    assert "wallet_service.credit" not in block
    assert "transfer_shamcash" not in block
    assert "transfer_syriatel" not in block
    assert "find_by_provider_tx" in repo
