from __future__ import annotations

import hashlib
import html
import logging
import math
from decimal import Decimal
from uuid import UUID, uuid4

from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import Settings
from app.core.ui import safe_edit
from app.core.withdrawal_admin_ui import (
    withdraw_card as build_withdraw_card,
    withdraw_actions as build_withdraw_actions,
    status_label as build_withdraw_status_label,
)
from app.core.emojis import (
    PROCESSING,
    SUCCESS,
    BOT_DEPOSIT_EMOJI_ID,
    BOT_WITHDRAW_EMOJI_ID,
    SHAM_CASH_EMOJI_ID,
    SYRIATEL_CASH_EMOJI_ID,
)
from app.core.withdrawals import WithdrawStateError, WithdrawValidationError
from app.services.runtime_settings import RuntimeSettingsService
from app.core.syriatel import parse_syriatel_cash_codes
from app.core.shamcash import normalize_shamcash_address
from app.services.deposits import DepositService
from app.services.withdrawals import WithdrawService
from app.services.manual_transfers import (
    ManualTransferService, ManualTransferError, ManualTransferOutcomeUncertain,
)

router = Router(name="admin_finance")
logger = logging.getLogger(__name__)


class AdminFinanceStates(StatesGroup):
    waiting_setting = State()
    manual_receiver = State()
    manual_amount = State()
    manual_confirm = State()
    tx_search = State()


def _admin(user_id: int, settings: Settings) -> bool:
    return user_id in settings.super_admin_ids


async def _delete_input(message: Message) -> None:
    try:
        await message.delete()
    except Exception:
        pass


def _btn(text: str, callback_data: str, icon_id: str | None = None) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data=callback_data, icon_custom_emoji_id=icon_id)


def _finance_view() -> tuple[str, InlineKeyboardMarkup]:
    return (
        "💳 <b>إدارة الشحن والسحب</b>\n\nاختر القسم:",
        InlineKeyboardMarkup(inline_keyboard=[
            [
                _btn("إدارة الشحن", "admin:finance:deposits", BOT_DEPOSIT_EMOJI_ID),
                _btn("إدارة السحب", "admin:finance:withdraws", BOT_WITHDRAW_EMOJI_ID),
            ],
            [_btn("💱 معامل العملة المحلية", "admin:setting:money.local_syp_wallet_multiplier")],
            [_btn("🔎 البحث عن عملية شحن", "admin:deposit_tx_search")],
            [_btn("💸 حوالات يدوية", "admin:manual_transfers")],
            [_btn("🚨 تنبيهات المبالغ الكبيرة", "admin:finance:alerts")],
            [_btn("📢 قنوات العمليات", "admin:finance:channels")],
            [_btn("⬅️ لوحة الإدارة", "admin:home")],
        ]),
    )


def _fmt_decimal(value: Decimal) -> str:
    return str(int(value)) if value == value.to_integral_value() else format(value.normalize(), "f")


def _source_token(source: str) -> str:
    """Short callback-safe fingerprint so the confirmed source cannot silently change."""
    return hashlib.sha256(str(source or "").encode("utf-8")).hexdigest()[:8]


_NUM_TRANSLATION = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")

def _normalize_numeric_input(raw: str, *, decimal: bool = False) -> str:
    value = str(raw or "").translate(_NUM_TRANSLATION).strip()
    value = value.replace("٬", "").replace(",", "")
    if decimal:
        value = value.replace("٫", ".")
    return value


def _mode_label(value: str) -> str:
    return {"auto": "آلي", "manual": "يدوي", "off": "متوقف"}.get(str(value).lower(), str(value))


def _deposits_view(runtime: RuntimeSettingsService, service: DepositService) -> tuple[str, InlineKeyboardMarkup]:
    mult = runtime.get_decimal("money.local_syp_wallet_multiplier", 100)
    sy = service.method_config("syriatel")
    sh_syp = service.method_config("sham_syp")
    sh_usd = service.method_config("sham_usd")
    whish = service.method_config("whish_money")
    trc = service.method_config("binance_trc20")
    bep = service.method_config("binance_bep20")
    api_status = "✅ جاهز" if service.api_syria.configured else "❌ غير مضبوط"
    text = (
        "💳 <b>إدارة الشحن</b>\n\n"
        f"🔌 API Syria: <b>{api_status}</b>\n"
        f"💱 العملة المحلية: <b>1 = {_fmt_decimal(mult)}</b> رصيد بالمحفظة\n\n"
        f"📱 سيرياتيل: <b>{_mode_label(sy.mode)}</b> — حد {_fmt_decimal(sy.minimum)}\n"
        f"💵 شام SYP: <b>{_mode_label(sh_syp.mode)}</b> — حد {_fmt_decimal(sh_syp.minimum)}\n"
        f"💵 شام USD: <b>{_mode_label(sh_usd.mode)}</b> — حد {_fmt_decimal(sh_usd.minimum)}\n"
        f"💸 Whish: <b>{'مفعل' if whish.enabled else 'متوقف'}</b> — حد {_fmt_decimal(whish.minimum)}\n"
        f"🪙 Binance TRC20: <b>{'مفعل' if trc.enabled else 'متوقف'}</b> — حد {_fmt_decimal(trc.minimum)}\n"
        f"🪙 Binance BEP20: <b>{'مفعل' if bep.enabled else 'متوقف'}</b> — حد {_fmt_decimal(bep.minimum)}"
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [_btn("سيرياتيل كاش", "admin:deposit:method:syriatel", SYRIATEL_CASH_EMOJI_ID)],
        [
            _btn("شام كاش SYP", "admin:deposit:method:sham_syp", SHAM_CASH_EMOJI_ID),
            _btn("شام كاش USD", "admin:deposit:method:sham_usd", SHAM_CASH_EMOJI_ID),
        ],
        [_btn("💸 Whish Money", "admin:deposit:method:whish_money")],
        [
            _btn("🪙 Binance TRC20", "admin:deposit:method:binance_trc20"),
            _btn("🪙 Binance BEP20", "admin:deposit:method:binance_bep20"),
        ],
        [_btn("📋 طلبات الشحن اليدوي", "admin:deposits:pending")],
        [_btn("💱 تعديل معامل العملة", "admin:setting:money.local_syp_wallet_multiplier")],
        [_btn("⬅️ إدارة الشحن والسحب", "admin:finance")],
    ])
    return text, kb


def _deposit_method_view(method: str, runtime: RuntimeSettingsService, service: DepositService) -> tuple[str, InlineKeyboardMarkup]:
    cfg = service.method_config(method)
    rows: list[list[InlineKeyboardButton]] = []
    state_text = "✅ متاحة" if cfg.enabled else "❌ غير متاحة"
    text = (
        f"💳 <b>إعدادات {html.escape(cfg.label)}</b>\n\n"
        f"الحالة: <b>{state_text}</b>\n"
        f"الوضع: <b>{_mode_label(cfg.mode)}</b>\n"
        f"الحد الأدنى: <b>{_fmt_decimal(cfg.minimum)} {html.escape(cfg.currency)}</b>\n"
        f"التحويل للمحفظة: <b>1 {html.escape(cfg.currency)} = {_fmt_decimal(cfg.rate)} SYP</b>\n"
        f"الحساب/العنوان: <code>{html.escape(cfg.target or 'غير مضبوط')}</code>"
    )
    min_key = {
        "syriatel": "deposit.syriatel.min",
        "sham_syp": "deposit.sham_syp.min",
        "sham_usd": "deposit.sham_usd.min",
        "whish_money": "deposit.whish_money.min",
        "binance_trc20": "deposit.binance_trc20.min",
        "binance_bep20": "deposit.binance_bep20.min",
    }[method]
    rows.append([_btn("📏 تعديل الحد الأدنى", f"admin:setting:{min_key}")])
    if method == "syriatel":
        rows.append([
            _btn("Auto", "admin:deposit:mode:syriatel:auto"),
            _btn("Manual", "admin:deposit:mode:syriatel:manual"),
            _btn("Off", "admin:deposit:mode:syriatel:off"),
        ])
        rows.append([_btn("أكواد/أرقام الاستلام", "admin:setting:deposit.syriatel.codes", SYRIATEL_CASH_EMOJI_ID)])
    elif method in {"sham_syp", "sham_usd"}:
        rows.append([
            _btn("Auto", f"admin:deposit:mode:sham:auto:{method}"),
            _btn("Manual", f"admin:deposit:mode:sham:manual:{method}"),
            _btn("Off", f"admin:deposit:mode:sham:off:{method}"),
        ])
        addr_key = "deposit.sham.address_syp" if method == "sham_syp" else "deposit.sham.address_usd"
        rows.append([_btn("تعديل عنوان الاستلام", f"admin:setting:{addr_key}", SHAM_CASH_EMOJI_ID)])
    elif method == "whish_money":
        rows.append([_btn(f"{'✅' if runtime.get_bool('deposit.whish.enabled', service.settings.whish_money_enabled) else '❌'} تفعيل/إيقاف", "admin:deposit:toggle:whish")])
    else:
        rows.append([_btn(f"{'✅' if runtime.get_bool('deposit.binance.enabled', service.settings.binance_deposit_enabled) else '❌'} تفعيل/إيقاف Binance", "admin:deposit:toggle:binance")])
    rows.append([_btn("⬅️ إدارة الشحن", "admin:finance:deposits")])
    return text, InlineKeyboardMarkup(inline_keyboard=rows)


def _withdraws_view(runtime: RuntimeSettingsService, service: WithdrawService) -> tuple[str, InlineKeyboardMarkup]:
    states = []
    for method, label in (("syriatel", "سيرياتيل"), ("shamcash", "شام كاش"), ("hawala", "حوالة"), ("usdt", "USDT")):
        states.append(f"{'✅' if service.method_enabled(method) else '❌'} {label}")
    text = (
        "💸 <b>إدارة السحب</b>\n\n"
        + " • ".join(states)
        + "\n\nكل وسيلة لها إعداداتها وحدها، وأي تعديل يُطبق فوراً على الطلبات الجديدة."
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            _btn("📋 الطلبات المعلقة", "admin:withdraws:pending"),
            _btn("⚠️ قيد المراجعة", "admin:withdraws:review"),
        ],
        [
            _btn("سيرياتيل كاش", "admin:withdraw:method:syriatel", SYRIATEL_CASH_EMOJI_ID),
            _btn("شام كاش", "admin:withdraw:method:shamcash", SHAM_CASH_EMOJI_ID),
        ],
        [
            _btn("💸 الحوالات", "admin:withdraw:method:hawala"),
            _btn("🪙 USDT", "admin:withdraw:method:usdt"),
        ],
        [_btn("💸 إدارة العمولة", "admin:withdraw:commission")],
        [_btn("🛡️ إعدادات الأمان", "admin:withdraw:security")],
        [_btn("✅ سجل السحوبات", "admin:withdraws:history")],
        [_btn("⬅️ إدارة الشحن والسحب", "admin:finance")],
    ])
    return text, kb


def _withdraw_method_view(method: str, runtime: RuntimeSettingsService, service: WithdrawService) -> tuple[str, InlineKeyboardMarkup]:
    labels = {"syriatel": "سيرياتيل كاش", "shamcash": "شام كاش", "hawala": "الحوالات", "usdt": "USDT"}
    label = labels[method]
    enabled = service.method_enabled(method)
    minimum = service.minimum(method)
    fee = service.fee_pct(method)
    rows: list[list[InlineKeyboardButton]] = [
        [_btn(f"{'✅' if enabled else '❌'} تفعيل/إيقاف", f"admin:withdraw:toggle:{method}")],
    ]
    if method == "syriatel":
        min_key = "withdraw.syriatel.min_wallet"
        pin_status = "✅ مضبوط" if service.syriatel_pin_configured() else "❌ غير مضبوط"
        extra = (
            f"حسابات المصدر: <code>{html.escape(', '.join(service.syriatel_sources()) or 'غير مضبوطة')}</code>\n"
            f"PIN السحب: <b>{pin_status}</b>"
        )
    elif method == "shamcash":
        min_key = "withdraw.shamcash.min_wallet"
        extra = f"حساب المصدر: <code>{html.escape(service.shamcash_source() or 'غير مضبوط')}</code>"
    elif method == "hawala":
        min_key = "withdraw.hawala_min_wallet"
        extra = "التنفيذ: <b>يدوي مع تأكيد الدفع</b>"
    else:
        min_key = "withdraw.usdt.min_wallet"
        extra = f"سعر USDT: <b>{_fmt_decimal(service.usdt_rate())}</b> من رصيد المحفظة"
    text = (
        f"💸 <b>إعدادات {html.escape(label)}</b>\n\n"
        f"الحالة: <b>{'✅ مفعلة' if enabled else '❌ متوقفة'}</b>\n"
        f"الحد الأدنى: <b>{minimum:,}</b>\n"
        f"العمولة: <b>{_fmt_decimal(fee)}%</b>\n"
        f"{extra}"
    )
    rows.append([_btn("📏 تعديل الحد الأدنى", f"admin:setting:{min_key}")])
    if method == "syriatel":
        pin_button = "🔐 تغيير PIN السحب" if service.syriatel_pin_configured() else "🔐 ضبط PIN السحب"
        rows.append([_btn(pin_button, "admin:setting:withdraw.syriatel.pin")])
    if method == "usdt":
        trc = service.network_enabled("TRC20")
        bep = service.network_enabled("BEP20")
        rows.append([
            _btn(f"{'✅' if trc else '❌'} TRC20", "admin:withdraw:network:TRC20"),
            _btn(f"{'✅' if bep else '❌'} BEP20", "admin:withdraw:network:BEP20"),
        ])
        rows.append([_btn("💵 تعديل سعر USDT", "admin:setting:withdraw.usdt.rate")])
    rows.append([_btn("⬅️ إدارة السحب", "admin:finance:withdraws")])
    return text, InlineKeyboardMarkup(inline_keyboard=rows)


def _withdraw_commission_view(runtime: RuntimeSettingsService) -> tuple[str, InlineKeyboardMarkup]:
    regular = runtime.get_decimal("withdraw.fee_pct", 0)
    hawala = runtime.get_decimal("withdraw.hawala_fee_pct", 0)
    return (
        "💸 <b>إدارة عمولة السحب</b>\n\n"
        f"العمولة العامة: <b>{_fmt_decimal(regular)}%</b>\n"
        f"عمولة الحوالات: <b>{_fmt_decimal(hawala)}%</b>",
        InlineKeyboardMarkup(inline_keyboard=[
            [_btn("💸 تعديل العمولة العامة", "admin:setting:withdraw.fee_pct")],
            [_btn("💸 تعديل عمولة الحوالات", "admin:setting:withdraw.hawala_fee_pct")],
            [_btn("⬅️ إدارة السحب", "admin:finance:withdraws")],
        ]),
    )


def _withdraw_security_view() -> tuple[str, InlineKeyboardMarkup]:
    return (
        "🛡️ <b>أمان السحب المالي</b>\n\n"
        "✅ حجز الرصيد وطلب السحب بمعاملة ذرية واحدة.\n"
        "✅ Claim ذري قبل التنفيذ يمنع ضغطتين/أدمنين من تنفيذ الطلب مرتين.\n"
        "✅ الفشل المؤكد يعيد الطلب للانتظار بدون فك الحجز.\n"
        "✅ Timeout/Network بعد POST لا يُعاد إرساله؛ يتحول لمراجعة.\n"
        "✅ نجاح المزود يُثبت محلياً بدون POST مالي ثانٍ.\n\n"
        "هذه الحمايات أساسية وغير قابلة للإيقاف من الواجهة.",
        InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ إدارة السحب", "admin:finance:withdraws")]]),
    )


def _alerts_menu(runtime: RuntimeSettingsService) -> InlineKeyboardMarkup:
    specs = [
        ("alerts.ichancy_deposit_large", "شحن iChancy"),
        ("alerts.ichancy_withdraw_large", "سحب iChancy"),
        ("alerts.bot_deposit_large", "شحن البوت"),
        ("alerts.bot_withdraw_large", "سحب البوت"),
    ]
    rows = []
    for key, label in specs:
        value = runtime.get_int(key, 0)
        shown = f"{value:,}" if value > 0 else "متوقف"
        rows.append([_btn(f"🚨 {label}: {shown}", f"admin:setting:{key}")])
    rows.append([_btn("⬅️ رجوع", "admin:finance")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _channels_view(runtime: RuntimeSettingsService) -> tuple[str, InlineKeyboardMarkup]:
    def shown(key: str) -> str:
        value = runtime.get(key)
        return "غير مضبوطة" if value in (None, "", 0, "0") else str(value)
    text = (
        "📢 <b>قنوات الإشعارات</b>\n\n"
        "عمليات محفظة البوت مفصولة بالكامل: الشحن لا يذهب لقناة السحب والعكس.\n\n"
        f"💳 قناة الشحن: <code>{html.escape(shown('notify.bot_deposits'))}</code>\n"
        f"💸 قناة السحب: <code>{html.escape(shown('notify.bot_withdrawals'))}</code>\n"
        f"🎰 عمليات iChancy: <code>{html.escape(shown('notify.ichancy_operations'))}</code>\n"
        f"👤 حسابات iChancy: <code>{html.escape(shown('notify.ichancy_accounts'))}</code>"
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [_btn("قناة عمليات الشحن", "admin:setting:notify.bot_deposits", BOT_DEPOSIT_EMOJI_ID)],
        [_btn("قناة عمليات السحب", "admin:setting:notify.bot_withdrawals", BOT_WITHDRAW_EMOJI_ID)],
        [
            _btn("🧪 اختبار الشحن", "admin:channel:test:bot_deposits"),
            _btn("🧪 اختبار السحب", "admin:channel:test:bot_withdrawals"),
        ],
        [_btn("🎰 قناة عمليات iChancy", "admin:setting:notify.ichancy_operations")],
        [_btn("👤 قناة حسابات iChancy", "admin:setting:notify.ichancy_accounts")],
        [_btn("⬅️ رجوع", "admin:finance")],
    ])
    return text, kb


_SETTING_META = {
    "money.local_syp_wallet_multiplier": ("معامل تحويل العملة المحلية إلى رصيد المحفظة", "decimal", "admin:finance"),
    "alerts.ichancy_deposit_large": ("حد تنبيه شحن iChancy الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "alerts.ichancy_withdraw_large": ("حد تنبيه سحب iChancy الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "alerts.bot_deposit_large": ("حد تنبيه شحن البوت الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "alerts.bot_withdraw_large": ("حد تنبيه سحب البوت الكبير (0 = إيقاف)", "int0", "admin:finance:alerts"),
    "notify.ichancy_accounts": ("معرف قناة حسابات iChancy", "chat", "admin:finance:channels"),
    "notify.ichancy_operations": ("معرف قناة عمليات iChancy", "chat", "admin:finance:channels"),
    "notify.bot_deposits": ("معرف قناة عمليات الشحن", "chat", "admin:finance:channels"),
    "notify.bot_withdrawals": ("معرف قناة عمليات السحب", "chat", "admin:finance:channels"),
    "deposit.syriatel.min": ("الحد الأدنى لشحن سيرياتيل كاش", "decimal", "admin:deposit:method:syriatel"),
    "deposit.sham_syp.min": ("الحد الأدنى لشحن شام كاش SYP", "decimal", "admin:deposit:method:sham_syp"),
    "deposit.sham_usd.min": ("الحد الأدنى لشحن شام كاش USD", "decimal", "admin:deposit:method:sham_usd"),
    "deposit.whish_money.min": ("الحد الأدنى لشحن Whish Money", "decimal", "admin:deposit:method:whish_money"),
    "deposit.binance_trc20.min": ("الحد الأدنى لشحن Binance TRC20", "decimal", "admin:deposit:method:binance_trc20"),
    "deposit.binance_bep20.min": ("الحد الأدنى لشحن Binance BEP20", "decimal", "admin:deposit:method:binance_bep20"),
    "deposit.syriatel.codes": ("أكواد/أرقام سيرياتيل كاش للاستلام", "syriatel_codes", "admin:deposit:method:syriatel"),
    "deposit.sham.address_syp": ("عنوان شام كاش SYP", "sham_address", "admin:deposit:method:sham_syp"),
    "deposit.sham.address_usd": ("عنوان شام كاش USD", "sham_address", "admin:deposit:method:sham_usd"),
    "withdraw.min_wallet": ("الحد الأدنى العام القديم للسحب", "positive_int", "admin:finance:withdraws"),
    "withdraw.syriatel.min_wallet": ("الحد الأدنى لسحب سيرياتيل كاش", "positive_int", "admin:withdraw:method:syriatel"),
    "withdraw.syriatel.pin": ("PIN سحب سيرياتيل كاش", "syriatel_pin", "admin:withdraw:method:syriatel"),
    "withdraw.shamcash.min_wallet": ("الحد الأدنى لسحب شام كاش", "positive_int", "admin:withdraw:method:shamcash"),
    "withdraw.hawala_min_wallet": ("الحد الأدنى لسحب الحوالة", "positive_int", "admin:withdraw:method:hawala"),
    "withdraw.usdt.min_wallet": ("الحد الأدنى لسحب USDT من رصيد المحفظة", "positive_int", "admin:withdraw:method:usdt"),
    "withdraw.fee_pct": ("عمولة السحب العامة %", "pct", "admin:withdraw:commission"),
    "withdraw.hawala_fee_pct": ("عمولة الحوالات %", "pct", "admin:withdraw:commission"),
    "withdraw.usdt.rate": ("سعر USDT للسحب مقابل رصيد المحفظة", "decimal", "admin:withdraw:method:usdt"),
}


async def _return_view(
    return_cb: str,
    runtime: RuntimeSettingsService,
    deposit_service: DepositService,
    withdraw_service: WithdrawService,
) -> tuple[str, InlineKeyboardMarkup]:
    if return_cb == "admin:finance":
        return _finance_view()
    if return_cb == "admin:finance:deposits":
        return _deposits_view(runtime, deposit_service)
    if return_cb.startswith("admin:deposit:method:"):
        return _deposit_method_view(return_cb.rsplit(":", 1)[-1], runtime, deposit_service)
    if return_cb == "admin:finance:withdraws":
        return _withdraws_view(runtime, withdraw_service)
    if return_cb.startswith("admin:withdraw:method:"):
        return _withdraw_method_view(return_cb.rsplit(":", 1)[-1], runtime, withdraw_service)
    if return_cb == "admin:withdraw:commission":
        return _withdraw_commission_view(runtime)
    if return_cb == "admin:withdraw:security":
        return _withdraw_security_view()
    if return_cb == "admin:finance:channels":
        return _channels_view(runtime)
    if return_cb == "admin:finance:alerts":
        return (
            "🚨 <b>تنبيهات المبالغ الكبيرة</b>\n\nالتنبيه يظهر داخل نفس إشعار العملية.",
            _alerts_menu(runtime),
        )
    return _finance_view()


@router.callback_query(F.data == "admin:finance")
async def finance_home(callback: CallbackQuery, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _finance_view()
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:finance:deposits")
async def deposits_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _deposits_view(runtime_settings, deposit_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.startswith("admin:deposit:method:"))
async def deposit_method_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService) -> None:
    if not _admin(callback.from_user.id, settings): return
    method = str(callback.data or "").rsplit(":", 1)[-1]
    if method not in {"syriatel", "sham_syp", "sham_usd", "whish_money", "binance_trc20", "binance_bep20"}: return
    text, kb = _deposit_method_view(method, runtime_settings, deposit_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:deposit:mode:(syriatel|sham):(auto|manual|off)(?::(sham_syp|sham_usd))?$"))
async def set_deposit_mode(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService) -> None:
    if not _admin(callback.from_user.id, settings): return
    parts = str(callback.data).split(":")
    provider = parts[3]
    mode = parts[4]
    await runtime_settings.set(f"deposit.{provider}.mode", mode, updated_by=callback.from_user.id)
    method = "syriatel" if provider == "syriatel" else (parts[5] if len(parts) > 5 else "sham_syp")
    text, kb = _deposit_method_view(method, runtime_settings, deposit_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:deposit:toggle:(whish|binance)$"))
async def toggle_deposit_method(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, deposit_service: DepositService) -> None:
    if not _admin(callback.from_user.id, settings): return
    name = str(callback.data).rsplit(":", 1)[-1]
    if name == "whish":
        key, fallback, method = "deposit.whish.enabled", deposit_service.settings.whish_money_enabled, "whish_money"
    else:
        key, fallback, method = "deposit.binance.enabled", deposit_service.settings.binance_deposit_enabled, "binance_trc20"
    await runtime_settings.set(key, not runtime_settings.get_bool(key, fallback), updated_by=callback.from_user.id)
    text, kb = _deposit_method_view(method, runtime_settings, deposit_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:finance:withdraws")
async def withdraws_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _withdraws_view(runtime_settings, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.startswith("admin:withdraw:method:"))
async def withdraw_method_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    method = str(callback.data or "").rsplit(":", 1)[-1]
    if method not in {"syriatel", "shamcash", "hawala", "usdt"}: return
    text, kb = _withdraw_method_view(method, runtime_settings, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:withdraw:toggle:(syriatel|shamcash|hawala|usdt)$"))
async def toggle_withdraw_method(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    method = str(callback.data).rsplit(":",1)[-1]
    key = f"withdraw.{method}.enabled"
    await runtime_settings.set(key, not runtime_settings.get_bool(key, True), updated_by=callback.from_user.id)
    text, kb = _withdraw_method_view(method, runtime_settings, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:withdraw:network:(TRC20|BEP20)$"))
async def toggle_withdraw_network(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    network = str(callback.data).rsplit(":", 1)[-1].lower()
    key = f"withdraw.usdt.{network}.enabled"
    await runtime_settings.set(key, not runtime_settings.get_bool(key, True), updated_by=callback.from_user.id)
    text, kb = _withdraw_method_view("usdt", runtime_settings, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:withdraw:commission")
async def withdraw_commission(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _withdraw_commission_view(runtime_settings)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:withdraw:security")
async def withdraw_security(callback: CallbackQuery, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _withdraw_security_view()
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data == "admin:finance:alerts")
async def alerts_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    await safe_edit(callback, "🚨 <b>تنبيهات المبالغ الكبيرة</b>\n\nالتنبيه يظهر داخل نفس إشعار العملية ولا يتم إرسال رسالة مستقلة.", reply_markup=_alerts_menu(runtime_settings))


@router.callback_query(F.data == "admin:finance:channels")
async def channels_admin(callback: CallbackQuery, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    text, kb = _channels_view(runtime_settings)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.regexp(r"^admin:channel:test:(bot_deposits|bot_withdrawals)$"))
async def test_channel(callback: CallbackQuery, bot: Bot, settings: Settings, runtime_settings: RuntimeSettingsService) -> None:
    if not _admin(callback.from_user.id, settings): return
    name = str(callback.data).rsplit(":", 1)[-1]
    key = f"notify.{name}"
    target = runtime_settings.get(key)
    if target in (None, "", 0, "0"):
        text, kb = _channels_view(runtime_settings)
        await safe_edit(callback, "❌ القناة غير مضبوطة بعد.\n\n" + text, reply_markup=kb)
        return
    try:
        chat_id = int(str(target).strip()) if str(target).lstrip("-").isdigit() else str(target).strip()
        title = "اختبار قناة عمليات الشحن" if name == "bot_deposits" else "اختبار قناة عمليات السحب"
        await bot.send_message(chat_id, f"✅ <b>{title}</b>\n\nتم ربط القناة بنجاح.")
        text, kb = _channels_view(runtime_settings)
        await safe_edit(callback, f"{SUCCESS} <b>تم إرسال رسالة الاختبار بنجاح.</b>\n\n" + text, reply_markup=kb)
    except Exception as exc:
        text, kb = _channels_view(runtime_settings)
        await safe_edit(callback, f"❌ فشل إرسال الاختبار: <code>{html.escape(str(exc)[:300])}</code>\n\n" + text, reply_markup=kb)


@router.callback_query(F.data == "admin:setting:cancel")
async def setting_cancel(
    callback: CallbackQuery,
    state: FSMContext,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    deposit_service: DepositService,
    withdraw_service: WithdrawService,
) -> None:
    if not _admin(callback.from_user.id, settings): return
    data = await state.get_data()
    return_cb = str(data.get("setting_return") or "admin:finance")
    await state.clear()
    text, kb = await _return_view(return_cb, runtime_settings, deposit_service, withdraw_service)
    await safe_edit(callback, text, reply_markup=kb)


@router.callback_query(F.data.startswith("admin:setting:"))
async def setting_start(
    callback: CallbackQuery,
    state: FSMContext,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    deposit_service: DepositService,
    withdraw_service: WithdrawService,
) -> None:
    if not _admin(callback.from_user.id, settings): return
    key = str(callback.data or "")[len("admin:setting:"):]
    meta = _SETTING_META.get(key)
    if not meta: return
    label, kind, return_cb = meta
    current = runtime_settings.get(key)
    # Missing runtime overrides should display the effective fallback that users see now.
    if current is None:
        deposit_min_methods = {
            "deposit.syriatel.min": "syriatel",
            "deposit.sham_syp.min": "sham_syp",
            "deposit.sham_usd.min": "sham_usd",
            "deposit.whish_money.min": "whish_money",
            "deposit.binance_trc20.min": "binance_trc20",
            "deposit.binance_bep20.min": "binance_bep20",
        }
        withdraw_min_methods = {
            "withdraw.syriatel.min_wallet": "syriatel",
            "withdraw.shamcash.min_wallet": "shamcash",
            "withdraw.hawala_min_wallet": "hawala",
            "withdraw.usdt.min_wallet": "usdt",
        }
        if key in deposit_min_methods:
            current = _fmt_decimal(deposit_service.method_config(deposit_min_methods[key]).minimum)
        elif key in withdraw_min_methods:
            current = withdraw_service.minimum(withdraw_min_methods[key])
    if kind == "syriatel_codes":
        current = ",".join(parse_syriatel_cash_codes(current))
    elif kind == "syriatel_pin":
        current = "✅ مضبوط" if withdraw_service.syriatel_pin_configured() else "❌ غير مضبوط"
    await state.clear()
    await state.update_data(
        setting_key=key,
        setting_kind=kind,
        setting_label=label,
        setting_return=return_cb,
        origin_chat_id=callback.message.chat.id if isinstance(callback.message, Message) else None,
        origin_message_id=callback.message.message_id if isinstance(callback.message, Message) else None,
    )
    await state.set_state(AdminFinanceStates.waiting_setting)
    prompt = (
        f"🔐 <b>{html.escape(label)}</b>\n\nالحالة الحالية: <b>{html.escape(str(current))}</b>\n\n"
        "أرسل PIN الجديد الآن. لن يتم عرض قيمته أو تسجيلها."
        if kind == "syriatel_pin"
        else f"✏️ <b>{html.escape(label)}</b>\n\nالقيمة الحالية: <code>{html.escape(str(current))}</code>\n\nأرسل القيمة الجديدة الآن."
    )
    await safe_edit(
        callback,
        prompt,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:setting:cancel")]]),
    )


@router.message(AdminFinanceStates.waiting_setting, F.text)
async def setting_value(
    message: Message,
    state: FSMContext,
    settings: Settings,
    runtime_settings: RuntimeSettingsService,
    deposit_service: DepositService,
    withdraw_service: WithdrawService,
) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data()
    key = str(data.get("setting_key") or "")
    kind = str(data.get("setting_kind") or "")
    raw = (message.text or "").strip()
    try:
        if kind == "positive_int":
            value = int(_normalize_numeric_input(raw))
            if value <= 0: raise ValueError
        elif kind == "int0":
            value = int(_normalize_numeric_input(raw))
            if value < 0: raise ValueError
        elif kind == "decimal":
            value_d = Decimal(_normalize_numeric_input(raw, decimal=True))
            if value_d <= 0: raise ValueError
            value = format(value_d.normalize(), "f")
        elif kind == "pct":
            value_d = Decimal(_normalize_numeric_input(raw, decimal=True))
            if not (Decimal("0") <= value_d <= Decimal("100")): raise ValueError
            value = format(value_d.normalize(), "f")
        elif kind == "chat":
            if raw.lower() in {"off", "0", "تعطيل", "الغاء", "إلغاء"}:
                value = None
            else:
                normalized_chat = raw.translate(_NUM_TRANSLATION)
                value = int(normalized_chat) if normalized_chat.lstrip("-").isdigit() else raw
        elif kind == "syriatel_codes":
            parts = list(parse_syriatel_cash_codes(raw.translate(_NUM_TRANSLATION)))
            if not parts or len(parts) > 30 or any(not p.isdigit() or not (3 <= len(p) <= 30) for p in parts):
                raise ValueError
            value = ",".join(parts)
        elif kind == "sham_address":
            value = normalize_shamcash_address(raw)
            if not (6 <= len(value) <= 160): raise ValueError
        elif kind == "syriatel_pin":
            value = _normalize_numeric_input(raw)
            if not value.isdigit() or not (4 <= len(value) <= 20): raise ValueError
        else:
            raise ValueError
    except Exception:
        await _delete_input(message)
        chat_id, message_id = data.get("origin_chat_id"), data.get("origin_message_id")
        if chat_id and message_id:
            try:
                await message.bot.edit_message_text(
                    chat_id=int(chat_id), message_id=int(message_id),
                    text="❌ القيمة غير صالحة. أرسل قيمة صحيحة الآن.",
                    reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:setting:cancel")]]),
                    parse_mode="HTML",
                )
            except Exception:
                pass
        return

    if kind == "syriatel_pin":
        try:
            await withdraw_service.set_syriatel_pin(str(value), updated_by=message.from_user.id)
        except WithdrawValidationError:
            await _delete_input(message)
            chat_id, message_id = data.get("origin_chat_id"), data.get("origin_message_id")
            if chat_id and message_id:
                try:
                    await message.bot.edit_message_text(
                        chat_id=int(chat_id), message_id=int(message_id),
                        text="❌ تعذر حفظ PIN بأمان. تأكد أن مفتاح التشفير مضبوط ثم حاول من جديد.",
                        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:setting:cancel")]]),
                        parse_mode="HTML",
                    )
                except Exception:
                    pass
            return
    else:
        await runtime_settings.set(key, value, updated_by=message.from_user.id)
    await _delete_input(message)
    return_cb = str(data.get("setting_return") or "admin:finance")
    text, kb = await _return_view(return_cb, runtime_settings, deposit_service, withdraw_service)
    await state.clear()
    chat_id, message_id = data.get("origin_chat_id"), data.get("origin_message_id")
    if chat_id and message_id:
        try:
            await message.bot.edit_message_text(
                chat_id=int(chat_id), message_id=int(message_id),
                text=f"{SUCCESS} <b>تم حفظ الإعداد وتطبيقه فوراً.</b>\n\n{text}",
                reply_markup=kb, parse_mode="HTML",
            )
            return
        except Exception:
            pass
    await message.answer(f"{SUCCESS} تم حفظ الإعداد وتطبيقه فوراً.\n\n{text}", reply_markup=kb)

# ---------------------------------------------------------------------------
# Direct admin transfers
# ---------------------------------------------------------------------------

def _manual_transfers_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn("➕ إرسال حوالة", "admin:send_transfer")],
        [_btn("📋 سجل الحوالات", "admin:manual_transfer_log:0")],
        [_btn("⬅️ إدارة الشحن والسحب", "admin:finance")],
    ])


def _manual_transfer_methods_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn("💳 شام كاش", "admin:send_transfer_method:shamcash", SHAM_CASH_EMOJI_ID)],
        [_btn("📲 سيرياتيل كاش", "admin:send_transfer_method:syriatel", SYRIATEL_CASH_EMOJI_ID)],
        [_btn("⬅️ رجوع", "admin:manual_transfers")],
    ])


def _manual_transfer_confirm_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [_btn("✅ تأكيد الإرسال", "admin:send_transfer_confirm")],
        [_btn("❌ إلغاء", "admin:send_transfer_cancel")],
    ])


def _manual_amount_text(value: object) -> str:
    try:
        dec = Decimal(str(value))
        return str(int(dec)) if dec == dec.to_integral_value() else format(dec.normalize(), "f")
    except Exception:
        return str(value or "-")


async def _edit_origin(message: Message, data: dict, text: str, reply_markup: InlineKeyboardMarkup | None = None) -> bool:
    chat_id = data.get("origin_chat_id")
    message_id = data.get("origin_message_id")
    if not chat_id or not message_id:
        return False
    try:
        await message.bot.edit_message_text(
            chat_id=int(chat_id), message_id=int(message_id), text=text,
            reply_markup=reply_markup, parse_mode="HTML",
        )
        return True
    except Exception:
        return False


def _manual_transfer_review(data: dict) -> str:
    method = str(data.get("manual_method") or "")
    label = "شام كاش" if method == "shamcash" else "سيرياتيل كاش"
    receiver_label = "عنوان المستلم" if method == "shamcash" else "رقم المستلم"
    return (
        "⚠️ مراجعة الحوالة قبل الإرسال\n\n"
        f"💳 الطريقة: {label}\n"
        f"🏦 المصدر: <b>{html.escape(str(data.get('manual_source_label') or '-'))}</b>\n"
        f"👛 الحساب: <code>{html.escape(str(data.get('manual_source') or '-'))}</code>\n"
        f"👤 {receiver_label}: <code>{html.escape(str(data.get('manual_receiver') or '-'))}</code>\n"
        f"💰 المبلغ: <code>{html.escape(str(data.get('manual_amount') or '-'))}</code> "
        f"{html.escape(str(data.get('manual_currency') or 'SYP'))}\n\n"
        "تأكد من البيانات جيداً، ثم اضغط تأكيد الإرسال."
    )


@router.callback_query(F.data == "admin:manual_transfers")
async def manual_transfers_home(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    await safe_edit(
        callback, "💸 <b>حوالات يدوية</b>\n\nاختر العملية المطلوبة:",
        reply_markup=_manual_transfers_menu(),
    )


@router.callback_query(F.data == "admin:send_transfer")
async def manual_transfer_start(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    await safe_edit(callback, "💸 إرسال حوالة\n\nاختر طريقة التحويل:", reply_markup=_manual_transfer_methods_menu())


@router.callback_query(F.data.startswith("admin:send_transfer_method:"))
async def manual_transfer_method(
    callback: CallbackQuery, state: FSMContext, settings: Settings, manual_transfer_service: ManualTransferService,
) -> None:
    if not _admin(callback.from_user.id, settings): return
    method = str(callback.data or "").rsplit(":", 1)[-1]
    if method not in {"shamcash", "syriatel"}: return
    options = manual_transfer_service.source_options(method)
    if not options:
        await state.clear()
        await safe_edit(
            callback, "⚠️ لا توجد محافظ/حسابات مضبوطة لهذه الطريقة داخل إدارة الشحن.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ رجوع", "admin:send_transfer")]]),
        )
        return
    await state.clear()
    await state.update_data(
        manual_method=method,
        manual_sources=[{"method": o.method, "source": o.source, "currency": o.currency, "label": o.label} for o in options],
    )
    title = "💳 شام كاش" if method == "shamcash" else "📲 سيرياتيل كاش"
    lines = [f"{title} — <b>اختيار حساب الإرسال</b>", "", "اختر المحفظة/الحساب الذي تريد الإرسال منه:"]
    rows: list[list[InlineKeyboardButton]] = []
    for idx, opt in enumerate(options):
        try:
            bal = await manual_transfer_service.source_balance(method, opt.source, opt.currency)
            bal_text = _manual_amount_text(bal)
            lines.append(
                f"\n▫️ {html.escape(opt.label)}\n   <code>{html.escape(opt.source)}</code>\n"
                f"   💰 <b>{html.escape(bal_text)} {html.escape(opt.currency)}</b>"
            )
            button_text = f"🏦 {opt.label} • {bal_text}"
        except Exception:
            lines.append(f"\n▫️ {html.escape(opt.label)}\n   <code>{html.escape(opt.source)}</code>\n   ⚠️ تعذر قراءة الرصيد")
            button_text = f"🏦 {opt.label}"
        rows.append([_btn(button_text[:60], f"admin:send_transfer_source:{idx}")])
    rows.append([_btn("⬅️ رجوع", "admin:send_transfer")])
    await safe_edit(callback, "\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("admin:send_transfer_source:"))
async def manual_transfer_source(
    callback: CallbackQuery, state: FSMContext, settings: Settings, manual_transfer_service: ManualTransferService,
) -> None:
    if not _admin(callback.from_user.id, settings): return
    data = await state.get_data()
    method = str(data.get("manual_method") or "")
    options = list(data.get("manual_sources") or [])
    try:
        idx = int(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception:
        idx = -1
    if method not in {"shamcash", "syriatel"} or idx < 0 or idx >= len(options):
        await state.clear()
        await safe_edit(callback, "❌ انتهت جلسة اختيار الحساب. ابدأ من جديد.", reply_markup=_manual_transfers_menu())
        return
    opt = dict(options[idx])
    source = str(opt.get("source") or "")
    currency = str(opt.get("currency") or "SYP").upper()
    if not manual_transfer_service.source_still_valid(method, source, currency):
        await state.clear()
        await safe_edit(callback, "❌ هذا الحساب لم يعد ضمن الحسابات المضبوطة.", reply_markup=_manual_transfers_menu())
        return
    await state.update_data(
        manual_source=source,
        manual_source_label=str(opt.get("label") or source),
        manual_currency=currency,
        manual_intent_id=str(uuid4()),
        origin_chat_id=callback.message.chat.id if isinstance(callback.message, Message) else None,
        origin_message_id=callback.message.message_id if isinstance(callback.message, Message) else None,
    )
    await state.set_state(AdminFinanceStates.manual_receiver)
    try:
        balance = await manual_transfer_service.source_balance(method, source, currency)
        balance_line = f"💰 الرصيد الحالي: <b>{html.escape(_manual_amount_text(balance))} {html.escape(currency)}</b>"
    except Exception as exc:
        balance_line = f"⚠️ تعذر قراءة الرصيد: {html.escape(str(exc))}"
    receiver_prompt = "أرسل عنوان المستلم الآن" if method == "shamcash" else "أرسل رقم المستلم الآن"
    await safe_edit(
        callback,
        f"🏦 المصدر المختار: <b>{html.escape(str(opt.get('label') or source))}</b>\n"
        f"👛 الحساب: <code>{html.escape(source)}</code>\n{balance_line}\n\n👇 {receiver_prompt}",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [_btn("⬅️ تغيير المصدر", f"admin:send_transfer_method:{method}")],
            [_btn("❌ إلغاء", "admin:send_transfer_cancel")],
        ]),
    )


@router.message(AdminFinanceStates.manual_receiver, F.text)
async def manual_transfer_receiver_input(message: Message, state: FSMContext, settings: Settings) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data()
    method = str(data.get("manual_method") or "")
    receiver = str(message.text or "").strip()
    if method == "syriatel":
        receiver = _normalize_numeric_input(receiver)
        valid = receiver.isdigit() and 7 <= len(receiver) <= 20
        error = "❌ رقم المستلم غير صالح. أرسل الرقم بالأرقام فقط."
    else:
        receiver = normalize_shamcash_address(receiver)
        valid = 3 <= len(receiver) <= 180
        error = "❌ عنوان المستلم غير صالح. أرسله كما يظهر في شام كاش."
    await _delete_input(message)
    if not valid:
        await _edit_origin(message, data, error, InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:send_transfer_cancel")]]))
        return
    await state.update_data(manual_receiver=receiver)
    await state.set_state(AdminFinanceStates.manual_amount)
    data = await state.get_data()
    await _edit_origin(
        message, data,
        f"🏦 المصدر: {html.escape(str(data.get('manual_source_label') or '-'))}\n"
        f"💱 العملة: {html.escape(str(data.get('manual_currency') or 'SYP'))}\n\n💰 أرسل المبلغ المراد تحويله الآن:",
        InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:send_transfer_cancel")]]),
    )


@router.message(AdminFinanceStates.manual_amount, F.text)
async def manual_transfer_amount_input(message: Message, state: FSMContext, settings: Settings) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data()
    raw = _normalize_numeric_input(message.text or "", decimal=True)
    await _delete_input(message)
    try:
        amount = Decimal(raw)
        if amount <= 0 or amount.as_tuple().exponent < -6:
            raise ValueError
    except Exception:
        await _edit_origin(
            message, data, "❌ المبلغ غير صالح. أرسل رقماً أكبر من صفر.",
            InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:send_transfer_cancel")]]),
        )
        return
    amount_text = _manual_amount_text(amount)
    await state.update_data(manual_amount=amount_text)
    await state.set_state(AdminFinanceStates.manual_confirm)
    data = await state.get_data()
    await _edit_origin(message, data, _manual_transfer_review(data), _manual_transfer_confirm_menu())


@router.callback_query(F.data == "admin:send_transfer_cancel")
async def manual_transfer_cancel(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    await safe_edit(callback, "✅ تم إلغاء الحوالة بدون تنفيذ أي تحويل.", reply_markup=_manual_transfers_menu())


@router.callback_query(F.data == "admin:send_transfer_confirm")
async def manual_transfer_confirm(
    callback: CallbackQuery, state: FSMContext, settings: Settings, manual_transfer_service: ManualTransferService,
) -> None:
    if not _admin(callback.from_user.id, settings): return
    data = await state.get_data()
    try:
        method = str(data["manual_method"])
        receiver = str(data["manual_receiver"])
        amount = Decimal(str(data["manual_amount"]))
        currency = str(data["manual_currency"]).upper()
        source = str(data["manual_source"])
        source_label = str(data["manual_source_label"])
        intent_id = UUID(str(data["manual_intent_id"]))
    except Exception:
        await state.clear()
        await safe_edit(callback, "❌ انتهت جلسة الحوالة أو البيانات ناقصة. ابدأ من جديد.", reply_markup=_manual_transfers_menu())
        return
    if not manual_transfer_service.source_still_valid(method, source, currency):
        await state.clear()
        await safe_edit(callback, "❌ حساب الإرسال المختار تغير أو تم حذفه. اختر المصدر من جديد.", reply_markup=_manual_transfers_menu())
        return
    await safe_edit(callback, f"{PROCESSING} <b>جاري تنفيذ الحوالة عبر API...</b>")
    try:
        item = await manual_transfer_service.execute(
            intent_id=intent_id, admin_id=callback.from_user.id, method=method,
            receiver=receiver, amount=amount, currency=currency, source=source,
            source_label=source_label,
        )
    except ManualTransferOutcomeUncertain as exc:
        await state.clear()
        await safe_edit(
            callback,
            "⚠️ <b>نتيجة الحوالة غير محسومة</b>\n\n"
            f"{html.escape(str(exc))}\n\n"
            "لم يتم إرسال POST مالي ثانٍ. افحص العملية وسجل المزود قبل أي محاولة جديدة.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [_btn("🔎 فحص عملية", "admin:deposit_tx_search")],
                [_btn("⬅️ حوالات يدوية", "admin:manual_transfers")],
            ]),
        )
        return
    except ManualTransferError as exc:
        await state.clear()
        await safe_edit(
            callback, f"❌ لم يتم إرسال الحوالة.\n\nالسبب: {html.escape(str(exc))}",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [_btn("🔄 المحاولة من جديد", "admin:send_transfer")],
                [_btn("⬅️ حوالات يدوية", "admin:manual_transfers")],
            ]),
        )
        return
    except Exception as exc:
        await state.clear()
        logger.exception("Unexpected manual transfer failure")
        await safe_edit(
            callback, f"⚠️ تعذر حسم نتيجة الحوالة: {html.escape(str(exc))}\nلا تعِد الإرسال قبل التحقق.",
            reply_markup=_manual_transfers_menu(),
        )
        return
    await state.clear()
    tx = str(item.get("provider_reference") or "غير متوفر من API")
    recipient = str(item.get("recipient_name") or item.get("receiver") or receiver)
    created = _fmt_dt(item.get("created_at"))
    text = (
        "✅ تم إرسال الحوالة بنجاح\n\n"
        f"💳 الطريقة: {html.escape(str(item.get('method_label') or ('شام كاش' if method == 'shamcash' else 'سيرياتيل كاش')))}\n"
        f"🏦 المصدر: <b>{html.escape(str(item.get('source_label') or source_label))}</b>\n"
        f"👛 الحساب: <code>{html.escape(str(item.get('source') or source))}</code>\n"
        f"👤 المستلم: <code>{html.escape(recipient)}</code>\n"
        f"💰 المبلغ: <code>{html.escape(_manual_amount_text(item.get('amount') or amount))}</code> {html.escape(currency)}\n"
        f"🔖 رقم العملية: <code>{html.escape(tx)}</code>\n"
        f"📅 التاريخ: <code>{html.escape(created)}</code>"
    )
    if item.get("source_balance_after") is not None:
        text += f"\n💼 الرصيد بعد العملية: <code>{html.escape(_manual_amount_text(item.get('source_balance_after')))} {html.escape(currency)}</code>"
    await safe_edit(callback, text, reply_markup=_manual_transfers_menu())


def _manual_transfer_log_card(item: dict) -> str:
    method = str(item.get("method") or "")
    label = str(item.get("method_label") or ("شام كاش" if method == "shamcash" else "سيرياتيل كاش"))
    tx = str(item.get("provider_reference") or "غير متوفر من API")
    lines = [
        f"💸 <b>تفاصيل الحوالة #{int(item.get('id') or 0)}</b>", "━━━━━━━━━━━━━━", "",
        "✅ الحالة: <b>ناجحة</b>",
        f"💳 الطريقة: <b>{html.escape(label)}</b>",
        f"🏦 المصدر: <code>{html.escape(str(item.get('source_label') or item.get('source') or '-'))}</code>",
        f"👤 المستلم: <code>{html.escape(str(item.get('recipient_name') or item.get('receiver') or '-'))}</code>",
        f"💰 المبلغ: <b>{html.escape(_manual_amount_text(item.get('amount')))} {html.escape(str(item.get('currency') or ''))}</b>",
        f"🔖 رقم العملية: <code>{html.escape(tx)}</code>",
        f"👮 الأدمن: <code>{int(item.get('admin_telegram_id') or 0)}</code>",
        f"📅 التاريخ: <code>{html.escape(_fmt_dt(item.get('created_at')))}</code>",
    ]
    if item.get("source_balance_before") is not None:
        lines.append(f"💼 الرصيد قبل: <code>{html.escape(_manual_amount_text(item.get('source_balance_before')))}</code>")
    if item.get("source_balance_after") is not None:
        lines.append(f"💼 الرصيد بعد: <code>{html.escape(_manual_amount_text(item.get('source_balance_after')))}</code>")
    return "\n".join(lines)


@router.callback_query(F.data.startswith("admin:manual_transfer_log:"))
async def manual_transfer_log(
    callback: CallbackQuery, settings: Settings, manual_transfer_service: ManualTransferService,
) -> None:
    if not _admin(callback.from_user.id, settings): return
    try:
        page = max(0, int(str(callback.data or "").rsplit(":", 1)[-1]))
    except Exception:
        page = 0
    per = 8
    total, items = await manual_transfer_service.repository.list_success(limit=per, offset=page * per)
    pages = max(1, math.ceil(total / per))
    if page >= pages:
        page = pages - 1
        total, items = await manual_transfer_service.repository.list_success(limit=per, offset=page * per)
    lines = ["📋 <b>سجل الحوالات اليدوية</b>", "━━━━━━━━━━━━━━", "", f"إجمالي الحوالات الناجحة: <code>{total}</code>"]
    rows: list[list[InlineKeyboardButton]] = []
    if not items:
        lines += ["", "لا توجد حوالات مسجلة حتى الآن."]
    for item in items:
        method = "شام" if str(item.get("method")) == "shamcash" else "سيرياتيل"
        amount = _manual_amount_text(item.get("amount"))
        currency = str(item.get("currency") or "")
        tx = str(item.get("provider_reference") or "غير متوفر من API")
        lines.append(f"\n• #{item['id']} | {method} | {amount} {currency} | {html.escape(tx)}")
        rows.append([_btn(f"🔎 تفاصيل #{item['id']} • {amount} {currency}", f"admin:manual_transfer_detail:{item['id']}:{page}")])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(_btn("⬅️ السابق", f"admin:manual_transfer_log:{page-1}"))
    if page + 1 < pages:
        nav.append(_btn("التالي ➡️", f"admin:manual_transfer_log:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([_btn("⬅️ حوالات يدوية", "admin:manual_transfers")])
    await safe_edit(callback, "\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("admin:manual_transfer_detail:"))
async def manual_transfer_detail(
    callback: CallbackQuery, settings: Settings, manual_transfer_service: ManualTransferService,
) -> None:
    if not _admin(callback.from_user.id, settings): return
    parts = str(callback.data or "").split(":")
    try:
        log_id = int(parts[-2]); page = max(0, int(parts[-1]))
    except Exception:
        return
    item = await manual_transfer_service.repository.get(log_id)
    if not item:
        await safe_edit(callback, "❌ لم يعد سجل الحوالة موجوداً.", reply_markup=_manual_transfers_menu())
        return
    await safe_edit(
        callback, _manual_transfer_log_card(item),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("⬅️ سجل الحوالات", f"admin:manual_transfer_log:{page}")]]),
    )


# ---------------------------------------------------------------------------
# Read-only provider transaction check
# ---------------------------------------------------------------------------

def _tx_search_source_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            _btn("💳 شام كاش", "admin:deposit_tx_search_method:sham", SHAM_CASH_EMOJI_ID),
            _btn("📲 سيرياتيل كاش", "admin:deposit_tx_search_method:syriatel", SYRIATEL_CASH_EMOJI_ID),
        ],
        [_btn("🗂 بحث داخل سجلات البوت", "admin:deposit_tx_search_method:local")],
        [_btn("⬅️ رجوع", "admin:finance")],
    ])


def _tx_search_result_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            _btn("💳 فحص شام كاش", "admin:deposit_tx_search_method:sham", SHAM_CASH_EMOJI_ID),
            _btn("📲 فحص سيرياتيل", "admin:deposit_tx_search_method:syriatel", SYRIATEL_CASH_EMOJI_ID),
        ],
        [_btn("🗂 بحث في سجلات البوت", "admin:deposit_tx_search_method:local")],
        [_btn("⬅️ إدارة الشحن والسحب", "admin:finance")],
    ])


def _deposit_status_label(status: str) -> str:
    return {
        "success": "✅ ناجحة", "verifying": "⏳ قيد المعالجة",
        "manual_pending": "🟡 بانتظار تنفيذ الأدمن", "rejected": "❌ مرفوضة",
    }.get(str(status or ""), str(status or "-"))


def _provider_tx_first(tx: dict, *keys: str, default: object = "-") -> object:
    for key in keys:
        value = (tx or {}).get(key)
        if value not in (None, ""):
            return value
    return default


def _local_tx_usage_lines(matches, kind: str) -> list[str]:
    relevant = [
        r for r in matches
        if (kind == "syriatel" and r.method == "syriatel")
        or (kind == "sham" and r.method in {"sham_syp", "sham_usd"})
    ]
    lines = ["", "♻️ <b>الاستخدام داخل البوت</b>", "━━━━━━━━━━━━━━"]
    if not relevant:
        lines.append("✅ <b>لم تُستخدم هذه العملية داخل البوت حتى الآن.</b>")
        return lines
    for idx, dep in enumerate(relevant[:5], 1):
        if dep.status == "success":
            usage = "✅ مستخدمة ومعتمدة بالفعل"
        elif dep.status in {"verifying", "manual_pending"}:
            usage = "⏳ يوجد طلب مرتبط بها قيد المعالجة"
        else:
            usage = "⚠️ توجد محاولة سابقة لكنها غير معتمدة"
        lines += [
            usage,
            f"🆔 المستخدم: <code>{dep.telegram_id}</code>",
            f"📄 رقم الطلب: <code>{dep.id}</code>",
            f"💳 الطريقة: <b>{html.escape(_deposit_method_label(dep.method))}</b>",
            f"💰 المبلغ المسجل: <code>{html.escape(_manual_amount_text(dep.amount_input))} {html.escape(dep.currency)}</code>",
            f"🏦 المبلغ المضاف: <code>{dep.total_credit_syp:,} SYP</code>",
            f"🕒 تاريخ الطلب: <code>{html.escape(_fmt_dt(dep.created_at))}</code>",
            f"✅ تاريخ الاعتماد: <code>{html.escape(_fmt_dt(dep.settled_at))}</code>",
        ]
        if idx < min(5, len(relevant)):
            lines.append("────────────")
    return lines


def _format_provider_tx(kind: str, tx_no: str, account: str, provider_tx, local_matches) -> str:
    tx = dict(provider_tx.raw or {})
    title = "💳 <b>نتيجة فحص معاملة شام كاش</b>" if kind == "sham" else "📲 <b>نتيجة فحص معاملة سيرياتيل كاش</b>"
    raw_dt = _provider_tx_first(tx, "datetime", "date", "created_at", "time", default="-")
    lines = [
        title, "━━━━━━━━━━━━━━",
        f"🧾 رقم العملية: <code>{html.escape(tx_no)}</code>",
        "✅ حالة الوصول: <b>المعاملة واصلة للحساب</b>",
        f"💰 المبلغ: <b>{html.escape(_manual_amount_text(provider_tx.amount))} {html.escape(provider_tx.currency)}</b>",
        f"🗓 تاريخ العملية: <code>{html.escape(str(raw_dt))}</code>",
    ]
    if kind == "sham":
        from_name = _provider_tx_first(tx, "from_name", "sender_name", "fromName")
        to_name = _provider_tx_first(tx, "to_name", "receiver_name", "toName")
        from_addr = _provider_tx_first(tx, "from", "from_address", "sender", "sender_address", default="-")
        to_addr = _provider_tx_first(tx, "to", "to_address", "receiver", "receiver_address", default=account)
        note = _provider_tx_first(tx, "note", "comment", "description", default="-")
        lines += [
            f"👤 من: <b>{html.escape(str(from_name))}</b>",
            f"👤 إلى: <b>{html.escape(str(to_name))}</b>",
            f"👛 عنوان المرسل: <code>{html.escape(str(from_addr))}</code>",
            f"🏦 عنوان المستلم: <code>{html.escape(str(to_addr))}</code>",
            f"📝 الملاحظة: {html.escape(str(note))}",
        ]
    else:
        sender = _provider_tx_first(tx, "from", "from_gsm", "sender", "sender_gsm", "mobile", default="-")
        receiver = _provider_tx_first(tx, "to", "to_gsm", "receiver", "receiver_gsm", default=account)
        lines += [
            f"📤 الرقم المرسل منه: <code>{html.escape(str(sender))}</code>",
            f"📥 الرقم المستلم: <code>{html.escape(str(receiver))}</code>",
        ]
    lines += _local_tx_usage_lines(local_matches, kind)
    return "\n".join(lines)


def _format_local_deposit(dep, index: int, total: int) -> str:
    title = "🔎 <b>نتيجة البحث عن عملية الشحن</b>"
    if total > 1:
        title += f" — <b>{index}/{total}</b>"
    return "\n".join([
        title, "",
        f"🧾 رقم العملية: <code>{html.escape(str(dep.provider_tx or '-'))}</code>",
        f"📌 رقم السجل: <code>{dep.id}</code>",
        f"📊 الحالة: <b>{html.escape(_deposit_status_label(dep.status))}</b>", "",
        "👤 <b>المستخدم</b>",
        f"Telegram ID: <code>{dep.telegram_id}</code>", "",
        "💳 <b>تفاصيل الشحن</b>",
        f"الطريقة: <b>{html.escape(_deposit_method_label(dep.method))}</b>",
        f"المبلغ المُدخل: <code>{html.escape(_manual_amount_text(dep.amount_input))} {html.escape(dep.currency)}</code>",
        f"سعر التحويل: <code>{html.escape(_manual_amount_text(dep.rate))}</code>",
        f"البونص: <code>{dep.bonus_credit_syp:,} SYP</code> ({dep.bonus_pct:g}%)",
        f"المبلغ المضاف للمحفظة: <code>{dep.total_credit_syp:,} SYP</code>", "",
        "🕒 <b>التوقيت</b>",
        f"إنشاء الطلب: <code>{html.escape(_fmt_dt(dep.created_at))}</code>",
        f"نجاح العملية: <code>{html.escape(_fmt_dt(dep.settled_at))}</code>",
    ])


@router.callback_query(F.data == "admin:deposit_tx_search")
async def tx_search_home(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    await safe_edit(
        callback,
        "🔎 <b>البحث عن عملية</b>\n\n"
        "اختر وسيلة الدفع التي تريد فحص معاملتها.\n"
        "فحص شام كاش وسيرياتيل يتم مباشرة عبر API ثم تتم مطابقة رقم العملية مع سجلات البوت.",
        reply_markup=_tx_search_source_menu(),
    )


@router.callback_query(F.data.startswith("admin:deposit_tx_search_method:"))
async def tx_search_method(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    kind = str(callback.data or "").rsplit(":", 1)[-1]
    if kind not in {"sham", "syriatel", "local"}: return
    labels = {"sham": "شام كاش", "syriatel": "سيرياتيل كاش", "local": "سجلات البوت"}
    await state.clear()
    await state.update_data(
        tx_search_kind=kind,
        origin_chat_id=callback.message.chat.id if isinstance(callback.message, Message) else None,
        origin_message_id=callback.message.message_id if isinstance(callback.message, Message) else None,
    )
    await state.set_state(AdminFinanceStates.tx_search)
    await safe_edit(
        callback, f"🔎 <b>البحث — {labels[kind]}</b>\n\nأرسل رقم العملية الآن كما هو بدون تعديل.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:deposit_tx_search_cancel")]]),
    )


@router.callback_query(F.data == "admin:deposit_tx_search_cancel")
async def tx_search_cancel(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not _admin(callback.from_user.id, settings): return
    await state.clear()
    text, kb = _finance_view()
    await safe_edit(callback, text, reply_markup=kb)


@router.message(AdminFinanceStates.tx_search, F.text)
async def tx_search_input(
    message: Message, state: FSMContext, settings: Settings, deposit_service: DepositService,
) -> None:
    if message.from_user is None or not _admin(message.from_user.id, settings): return
    data = await state.get_data()
    kind = str(data.get("tx_search_kind") or "local")
    raw = str(message.text or "").strip()
    normalized = _normalize_numeric_input(raw)
    if normalized.isdigit():
        raw = normalized
    await _delete_input(message)
    if not raw:
        await _edit_origin(
            message, data, "❌ أرسل رقم عملية صحيح.",
            InlineKeyboardMarkup(inline_keyboard=[[_btn("❌ إلغاء", "admin:deposit_tx_search_cancel")]]),
        )
        return
    local_matches = await deposit_service.repository.find_by_provider_tx(raw, 20)
    await state.clear()
    if kind == "local":
        if not local_matches:
            text = f"❌ لم يتم العثور على عملية داخل سجلات البوت برقم:\n<code>{html.escape(raw)}</code>"
        else:
            text = "\n\n━━━━━━━━━━━━━━\n\n".join(
                _format_local_deposit(dep, i, len(local_matches)) for i, dep in enumerate(local_matches, 1)
            )
        await _edit_origin(message, data, text, _tx_search_result_menu())
        return

    found: list[tuple[str, object]] = []
    errors: list[str] = []
    if kind == "syriatel":
        accounts = list(deposit_service.syriatel_codes())
        for account in accounts:
            try:
                tx = await deposit_service.api_syria.find_syriatel(raw, account)
                if tx is not None:
                    found.append((account, tx))
            except Exception as exc:
                errors.append(f"{account}: {exc}")
    else:
        accounts = []
        for method in ("sham_syp", "sham_usd"):
            cfg = deposit_service.method_config(method)
            account = normalize_shamcash_address(cfg.target)
            if account and account not in accounts:
                accounts.append(account)
        for account in accounts:
            try:
                tx = await deposit_service.api_syria.find_shamcash(raw, account)
                if tx is not None:
                    fingerprint = repr(sorted((tx.raw or {}).items()))
                    if not any(repr(sorted((existing.raw or {}).items())) == fingerprint for _, existing in found):
                        found.append((account, tx))
            except Exception as exc:
                errors.append(f"{account}: {exc}")

    if found:
        text = "\n\n━━━━━━━━━━━━━━━━\n\n".join(
            _format_provider_tx(kind, raw, account, tx, local_matches) for account, tx in found
        )
        await _edit_origin(message, data, text, _tx_search_result_menu())
        return
    title = "شام كاش" if kind == "sham" else "سيرياتيل كاش"
    lines = [
        f"🔎 <b>نتيجة فحص {title}</b>", "━━━━━━━━━━━━━━",
        f"🧾 رقم العملية: <code>{html.escape(raw)}</code>",
        "❌ <b>لم يتم العثور على المعاملة في حسابات الاستقبال المضبوطة عبر API.</b>",
    ]
    if errors:
        lines += ["", "⚠️ ملاحظة API:", f"<code>{html.escape(errors[0][:500])}</code>"]
    lines += _local_tx_usage_lines(local_matches, kind)
    await _edit_origin(message, data, "\n".join(lines), _tx_search_result_menu())


def _deposit_method_label(method: str) -> str:
    return {
        "syriatel": "سيرياتيل كاش",
        "sham_syp": "شام كاش – ليرة",
        "sham_usd": "شام كاش – دولار",
        "whish_money": "Whish Money",
        "binance_trc20": "Binance USDT TRC20",
        "binance_bep20": "Binance USDT BEP20",
    }.get(str(method or ""), str(method or "-") or "-")


def _fmt_dt(value) -> str:
    if value is None:
        return "—"
    try:
        # Keep the stored timezone/offset visible instead of silently converting it.
        return value.isoformat(sep=" ", timespec="seconds")
    except Exception:
        return str(value)


def _withdraw_status_label(status: str) -> str:
    return build_withdraw_status_label(status)


def _withdraw_card(rec, last_deposits=()) -> str:
    return build_withdraw_card(rec, last_deposits)


def _withdraw_actions(rec) -> InlineKeyboardMarkup | None:
    return build_withdraw_actions(rec, include_back=True)


def _withdraw_actions_for_callback(callback: CallbackQuery, rec) -> InlineKeyboardMarkup | None:
    """Keep channel cards channel-clean while internal admin cards keep their back button."""
    try:
        msg = callback.message
        in_channel_card = bool(
            isinstance(msg, Message)
            and rec.channel_chat_id
            and rec.channel_message_id
            and int(msg.chat.id) == int(rec.channel_chat_id)
            and int(msg.message_id) == int(rec.channel_message_id)
        )
    except Exception:
        in_channel_card = False
    return build_withdraw_actions(rec, include_back=not in_channel_card)


async def _sync_withdraw_channel(bot: Bot, withdraw_service: WithdrawService, rec) -> None:
    if not rec or not rec.channel_chat_id or not rec.channel_message_id:
        return
    try:
        last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
        await bot.edit_message_text(
            chat_id=rec.channel_chat_id,
            message_id=rec.channel_message_id,
            text=build_withdraw_card(rec, last_deposits),
            reply_markup=build_withdraw_actions(rec, include_back=False),
        )
    except Exception:
        logger.debug("Could not sync withdrawal channel card %s", getattr(rec, "id", "-"), exc_info=True)


async def _mark_withdraw_channel_processing(bot: Bot, rec, *, source: str = "") -> None:
    if not rec or not rec.channel_chat_id or not rec.channel_message_id:
        return
    try:
        await bot.edit_message_text(
            chat_id=rec.channel_chat_id, message_id=rec.channel_message_id,
            text=(
                f"{PROCESSING} <b>جاري تنفيذ طلب السحب عبر المزود...</b>\n\n"
                f"🧾 رقم الطلب: <code>{rec.id}</code>\n"
                "🔒 تم تعطيل أزرار التنفيذ مؤقتاً حتى تظهر النتيجة الإدارية النهائية."
            ),
            reply_markup=None,
        )
    except Exception:
        logger.debug("Could not mark withdrawal channel processing %s", getattr(rec, "id", "-"), exc_info=True)


@router.callback_query(F.data == "admin:withdraws:pending")
async def pending_withdraws(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    items = await withdraw_service.repository.list_pending(30)
    rows = [[InlineKeyboardButton(text=f"{r.method} • {r.amount_wallet:,} • {r.status}", callback_data=f"admin:withdraw:view:{r.id}")] for r in items]
    rows.append([InlineKeyboardButton(text="⬅️ إدارة السحب", callback_data="admin:finance:withdraws")])
    await safe_edit(callback, f"📋 <b>طلبات السحب المعلقة</b>\n\nالعدد: {len(items)}", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data == "admin:withdraws:review")
async def review_withdraws(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    items = await withdraw_service.repository.list_by_status("needs_review", 30)
    rows = [[_btn(f"⚠️ {r.method} • {r.amount_wallet:,}", f"admin:withdraw:view:{r.id}")] for r in items]
    rows.append([_btn("⬅️ إدارة السحب", "admin:finance:withdraws")])
    await safe_edit(
        callback,
        f"⚠️ <b>طلبات السحب قيد المراجعة</b>\n\nالعدد: <b>{len(items)}</b>\nلا يتم إعادة POST مالي تلقائياً لهذه الطلبات.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data == "admin:withdraws:history")
async def withdraw_history(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    items = await withdraw_service.repository.list_recent_terminal(30)
    rows = [[_btn(f"{_withdraw_status_label(r.status)} • {r.method} • {r.amount_wallet:,}", f"admin:withdraw:view:{r.id}")] for r in items]
    rows.append([_btn("⬅️ إدارة السحب", "admin:finance:withdraws")])
    await safe_edit(
        callback,
        f"✅ <b>سجل السحوبات الأخيرة</b>\n\nالعدد المعروض: <b>{len(items)}</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data.startswith("admin:withdraw:view:"))
async def view_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    try: wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    except Exception: return
    rec = await withdraw_service.repository.get(wid)
    if not rec:
        await safe_edit(callback, "❌ الطلب غير موجود.")
        return
    last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
    await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions_for_callback(callback, rec))


async def _show_withdraw_auto_sources(callback: CallbackQuery, withdraw_service: WithdrawService, rec) -> None:
    if rec.status != "pending":
        last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
        await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions_for_callback(callback, rec))
        return
    sources = withdraw_service.withdraw_sources(rec.method)
    if not sources:
        await safe_edit(
            callback,
            "⚠️ لا توجد محافظ/أكواد مخزنة لهذا النوع داخل إدارة الشحن.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [_btn("⬅️ رجوع للطلب", f"admin:withdraw:back:{rec.id}")],
            ]),
        )
        return
    lines = [
        f"⚡ <b>تنفيذ آلي لطلب السحب</b>", "",
        f"🧾 رقم الطلب: <code>{rec.id}</code>",
        f"👤 المستخدم: <code>{rec.telegram_id}</code>",
        f"💰 المبلغ المطلوب تحويله: <code>{rec.net_wallet:,}</code>",
        f"💳 قيمة التحويل عبر API: <code>{_fmt_decimal(rec.payout_amount)} {html.escape(rec.payout_currency)}</code>",
        f"📌 المستلم: <code>{html.escape(rec.receiver)}</code>", "",
        "اختر المحفظة/الكود الذي تريد التنفيذ منه:",
    ]
    rows: list[list[InlineKeyboardButton]] = []
    for idx, (kind, source, label) in enumerate(sources):
        try:
            balance = await withdraw_service.withdraw_source_balance(kind, source)
            bal_text = _fmt_decimal(balance)
            lines.append(f"\n▫️ {html.escape(label)}: الرصيد <code>{html.escape(bal_text)}</code>")
        except Exception as exc:
            lines.append(f"\n▫️ {html.escape(label)}: ⚠️ تعذر قراءة الرصيد: {html.escape(str(exc))}")
        short = source[-8:] if len(source) > 12 else source
        rows.append([_btn(f"🚀 تنفيذ عبر {label} ({short})"[:60], f"admin:withdraw:pick:{rec.id}:{idx}")])
    rows.append([_btn("⬅️ رجوع للطلب", f"admin:withdraw:back:{rec.id}")])
    await safe_edit(callback, "\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("admin:withdraw:back:"))
async def withdraw_back_to_card(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    try:
        wid = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception:
        return
    rec = await withdraw_service.repository.get(wid)
    if not rec:
        await safe_edit(callback, "❌ الطلب غير موجود.")
        return
    last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
    # This callback can come from the withdrawal channel or the internal admin view.
    # Keep the same live request card and actions in either place.
    await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions_for_callback(callback, rec))


@router.callback_query(F.data.startswith("admin:withdraw:auto:"))
async def auto_withdraw_sources(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    try:
        wid = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception:
        return
    rec = await withdraw_service.repository.get(wid)
    if not rec:
        await safe_edit(callback, "❌ الطلب غير موجود.")
        return
    if rec.method not in {"syriatel", "shamcash"}:
        await safe_edit(callback, "⚠️ هذه الطريقة تُنفذ يدوياً فقط.")
        return
    await _show_withdraw_auto_sources(callback, withdraw_service, rec)


@router.callback_query(F.data.startswith("admin:withdraw:pick:"))
async def pick_withdraw_source(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    parts = str(callback.data or "").split(":")
    if len(parts) != 5:
        return
    try:
        wid = UUID(parts[3]); idx = int(parts[4])
    except Exception:
        return
    rec = await withdraw_service.repository.get(wid)
    if not rec or rec.status != "pending":
        if rec:
            last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
            await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions_for_callback(callback, rec))
        else:
            await safe_edit(callback, "❌ الطلب غير موجود.")
        return
    sources = withdraw_service.withdraw_sources(rec.method)
    if idx < 0 or idx >= len(sources):
        await safe_edit(callback, "❌ حساب التنفيذ المختار لم يعد صالحاً.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [_btn("⬅️ اختيار حساب آخر", f"admin:withdraw:auto:{wid}")],
        ]))
        return
    kind, source, label = sources[idx]
    try:
        balance = await withdraw_service.withdraw_source_balance(kind, source)
        balance_line = f"💼 رصيد المصدر: <code>{html.escape(_fmt_decimal(balance))}</code>"
    except Exception as exc:
        balance_line = f"⚠️ تعذر قراءة رصيد المصدر: {html.escape(str(exc))}"
    # Persist the selected source before confirmation. execute_auto re-validates it
    # against current settings before claiming the request and before the one POST.
    rec = await withdraw_service.repository.select_source(wid, source)
    text = (
        "⚠️ <b>تأكيد تنفيذ السحب الآلي</b>\n\n"
        f"🧾 رقم الطلب: <code>{rec.id}</code>\n"
        f"👤 المستخدم: <code>{rec.telegram_id}</code>\n"
        f"💰 المبلغ المرسل: <code>{_fmt_decimal(rec.payout_amount)} {html.escape(rec.payout_currency)}</code>\n"
        f"📌 المستلم: <code>{html.escape(rec.receiver)}</code>\n"
        f"🏦 المصدر: <b>{html.escape(label)}</b>\n"
        f"👛 الحساب: <code>{html.escape(source)}</code>\n"
        f"{balance_line}\n\n"
        "اضغط تأكيد فقط إذا كانت البيانات صحيحة."
    )
    await safe_edit(callback, text, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [_btn("✅ تأكيد التنفيذ الآن", f"wd:exec:{wid}:{idx}:{_source_token(source)}")],
        [_btn("⬅️ رجوع لاختيار الحساب", f"admin:withdraw:auto:{wid}")],
    ]))


@router.callback_query(F.data.startswith("admin:withdraw:execute:"))
async def legacy_execute_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    """Compatibility for already-rendered pre-selection buttons: never execute directly."""
    if not _admin(callback.from_user.id, settings): return
    try:
        wid = UUID(str(callback.data or "").rsplit(":", 1)[-1])
    except Exception:
        return
    rec = await withdraw_service.repository.get(wid)
    if not rec:
        await safe_edit(callback, "❌ الطلب غير موجود.")
        return
    await _show_withdraw_auto_sources(callback, withdraw_service, rec)


@router.callback_query(F.data.startswith("wd:exec:"))
async def execute_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    parts = str(callback.data or "").split(":")
    if len(parts) != 5:
        return
    try:
        wid = UUID(parts[2]); idx = int(parts[3]); expected_token = parts[4]
    except Exception:
        return
    before = await withdraw_service.repository.get(wid)
    if before is None:
        await safe_edit(callback, "❌ الطلب غير موجود.")
        return
    sources = withdraw_service.withdraw_sources(before.method)
    if idx < 0 or idx >= len(sources):
        await safe_edit(callback, "❌ حساب التنفيذ تغير أو تم حذفه. اختر المصدر من جديد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [_btn("⚡ اختيار حساب التنفيذ", f"admin:withdraw:auto:{wid}")],
        ]))
        return
    _kind, source, _label = sources[idx]
    if _source_token(source) != expected_token:
        await safe_edit(callback, "❌ إعدادات حساب التنفيذ تغيرت بعد شاشة التأكيد. اختر المصدر من جديد.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [_btn("⚡ اختيار حساب التنفيذ", f"admin:withdraw:auto:{wid}")],
        ]))
        return
    await safe_edit(
        callback,
        f"{PROCESSING} <b>جاري تنفيذ السحب عبر المزود...</b>\n\n"
        f"🧾 رقم الطلب: <code>{wid}</code>\n"
        f"🏦 المصدر: <code>{html.escape(source)}</code>\n"
        "يرجى عدم إعادة الضغط أو الرجوع حتى تظهر النتيجة. الحماية المالية تمنع إرسال POST مالي ثانٍ لنفس الطلب.",
    )
    await _mark_withdraw_channel_processing(callback.bot, before, source=source)
    try:
        rec = await withdraw_service.execute_auto(wid, callback.from_user.id, source=source)
        last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
        await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions_for_callback(callback, rec))
        await _sync_withdraw_channel(callback.bot, withdraw_service, rec)
    except (WithdrawValidationError, WithdrawStateError) as exc:
        rec = await withdraw_service.repository.get(wid)
        if rec:
            last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
            await safe_edit(callback, f"⚠️ {html.escape(str(exc))}\n\n" + _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions_for_callback(callback, rec))
            await _sync_withdraw_channel(callback.bot, withdraw_service, rec)
        else:
            await safe_edit(callback, f"⚠️ {html.escape(str(exc))}")


@router.callback_query(F.data.startswith("admin:withdraw:paid:"))
async def paid_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    try:
        rec = await withdraw_service.confirm_paid(wid, callback.from_user.id)
        last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
        await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions_for_callback(callback, rec))
        await _sync_withdraw_channel(callback.bot, withdraw_service, rec)
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}")


@router.callback_query(F.data.startswith("admin:withdraw:notpaid:"))
async def notpaid_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    try:
        rec = await withdraw_service.confirm_not_paid(wid, callback.from_user.id)
        last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
        await safe_edit(
            callback, _withdraw_card(rec, last_deposits) + "\n\n✅ تم إرجاع الطلب إلى حالة معلّق بعد تأكيدك أن التحويل لم يتم.",
            reply_markup=_withdraw_actions_for_callback(callback, rec),
        )
        await _sync_withdraw_channel(callback.bot, withdraw_service, rec)
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}")


@router.callback_query(F.data.startswith("admin:withdraw:reject:"))
async def reject_withdraw(callback: CallbackQuery, settings: Settings, withdraw_service: WithdrawService) -> None:
    if not _admin(callback.from_user.id, settings): return
    wid = UUID(str(callback.data or "").rsplit(":",1)[-1])
    try:
        rec = await withdraw_service.reject_admin(wid, callback.from_user.id, "rejected by admin")
        last_deposits = await withdraw_service.last_successful_deposits(rec.telegram_id, 3)
        await safe_edit(callback, _withdraw_card(rec, last_deposits), reply_markup=_withdraw_actions_for_callback(callback, rec))
        await _sync_withdraw_channel(callback.bot, withdraw_service, rec)
    except Exception as exc:
        await safe_edit(callback, f"❌ {html.escape(str(exc))}")
