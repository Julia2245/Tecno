from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

from app.config import get_settings
from app.core.db import Database

PROJECT_ROOT = Path(__file__).resolve().parent.parent
KEY = "test.ichancy_fault"


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="One-shot iChancy pre-launch fault lab")
    sub = p.add_subparsers(dest="command", required=True)

    arm = sub.add_parser("arm", help="arm exactly one fault")
    arm.add_argument("mode", choices=["timeout_after_post"])
    arm.add_argument("--operation", choices=["deposit", "withdraw", "any"], default="deposit")
    arm.add_argument("--telegram-id", type=int, default=0, help="0 means next matching user")

    sub.add_parser("status", help="show currently armed fault")
    last = sub.add_parser("last", help="show the latest iChancy job and immutable events")
    last.add_argument("--operation", choices=["deposit", "withdraw", "any"], default="any")
    sub.add_parser("disarm", help="remove any armed fault")
    return p


async def run(args: argparse.Namespace) -> int:
    settings = get_settings()
    db = Database(settings.database_url, min_size=1, max_size=2, command_timeout=settings.pg_command_timeout)
    await db.connect()
    try:
        await db.apply_migrations(PROJECT_ROOT / "migrations")
        pool = db.require_pool()
        async with pool.acquire() as conn:
            if args.command == "arm":
                if args.telegram_id < 0:
                    raise SystemExit("--telegram-id must be >= 0")
                payload = {
                    "mode": args.mode,
                    "stage": "after_post_response",
                    "operation_type": args.operation,
                    "telegram_id": int(args.telegram_id),
                }
                await conn.execute(
                    """
                    INSERT INTO bot_core.runtime_settings(key,value,updated_by)
                    VALUES($1,$2::jsonb,NULL)
                    ON CONFLICT(key) DO UPDATE
                    SET value=EXCLUDED.value, updated_by=NULL, updated_at=NOW()
                    """,
                    KEY,
                    json.dumps(payload, separators=(",", ":")),
                )
                print("ICHANCY FAULT LAB: ARMED (ONE SHOT)")
                print(payload)
                print("WARNING: the next matching financial iChancy POST will be real; only its returned response is intentionally discarded.")
                return 0
            if args.command == "status":
                row = await conn.fetchrow("SELECT value,updated_at FROM bot_core.runtime_settings WHERE key=$1", KEY)
                if not row:
                    print("ICHANCY FAULT LAB: DISARMED")
                else:
                    print("ICHANCY FAULT LAB: ARMED")
                    print("value:", row["value"])
                    print("updated_at:", row["updated_at"])
                return 0
            if args.command == "last":
                if args.operation == "any":
                    row = await conn.fetchrow("SELECT * FROM bot_core.ichancy_jobs ORDER BY created_at DESC,id DESC LIMIT 1")
                else:
                    row = await conn.fetchrow(
                        "SELECT * FROM bot_core.ichancy_jobs WHERE operation_type=$1 ORDER BY created_at DESC,id DESC LIMIT 1",
                        args.operation,
                    )
                if not row:
                    print("ICHANCY FAULT LAB: no jobs")
                    return 0
                events = await conn.fetch(
                    "SELECT id,event_type,details,created_at FROM bot_core.ichancy_job_events WHERE job_id=$1 ORDER BY id",
                    row["id"],
                )
                post_count = sum(1 for e in events if str(e["event_type"]) == "financial_post_started")
                print("ICHANCY FAULT LAB: LAST JOB")
                print("id:", row["id"])
                print("operation_type:", row["operation_type"])
                print("amount:", row["amount"])
                print("status:", row["status"])
                print("provider_reference:", row["provider_reference"])
                print("financial_post_started_count:", post_count)
                print("reconcile_attempt_count:", row["reconcile_attempt_count"])
                print("last_error:", row["last_error"])
                print("events:")
                for e in events:
                    print(f"  {e['id']} | {e['created_at']} | {e['event_type']} | {e['details']}")
                return 0
            if args.command == "disarm":
                result = await conn.execute("DELETE FROM bot_core.runtime_settings WHERE key=$1", KEY)
                print("ICHANCY FAULT LAB: DISARMED", result)
                return 0
        return 0
    finally:
        await db.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run(parser().parse_args())))
